declare module 'rc-form'{
  export function createForm(): any
  
}