declare module 'msr' {
  function MediaStreamRecorder(stream: any){};
}
