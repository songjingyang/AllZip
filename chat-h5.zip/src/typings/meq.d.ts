declare module 'meq2' {
  declare function connect(opts: any): any
}
