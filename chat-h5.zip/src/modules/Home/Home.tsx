import React, { Fragment } from 'react';
import {History} from 'history'

import {
  TabBar,
} from 'antd-mobile';
import Index from '../Home/Index';
import Chat from '../Chat/Index'
import Concat from '../Concat/Index'
import My from '../My/Index'

import  ChatType from '../../models/Chat'
import  ConcatType from '../../models/Concat'
import MyType from '../../models/My'
import User from '../../models/User'
import './Home.less';
import { match } from 'react-router';
import { inject } from 'mobx-react';
import Global from '../../models/Global';

interface Props {
  selectedTab: string;
  fullScreen: boolean;
  history: History;
  match: match;
  chat: ChatType;
  concat: ConcatType;
  my : MyType;
  user: User
  global: Global;
}

interface State{
  selectedTab: string;
  fullScreen: boolean;
}

interface Params{
  home: string;
}

@inject('chat', 'concat', 'my', 'user', 'global')
export default class Home extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      selectedTab: 'home',
      fullScreen: true,
    };
  }
  state: State
  
  componentDidMount() {
    const params = this.props.match.params as Params;
    this.setState({
      selectedTab: params.home,
    });
  }

  jumpTab = (tab: string) => {
    this.setState({
      selectedTab: tab,
    });
    this.props.history.push(`/home/${tab}`);
  };
  render() {
    return (
      <Fragment>
        <div
          style={
            this.state.fullScreen
              ? {
                  position: 'fixed',
                  height: '100%',
                  width: '100%',
                  top: 0,
                  background: '#F9F9F9',
                }
              : { height: 400 }
          }
        >
          <TabBar
            unselectedTintColor="#3A310B"
            tintColor="#3A310B"
            barTintColor="#fff"
            // hidden={this.state.hidden}
          >
            <TabBar.Item
              title="首页"
              key="home"
              icon={<div className="tab home" />}
              selectedIcon={<div className="tab home-on" />}
              selected={this.state.selectedTab === 'home'}
              onPress={() => this.jumpTab('home')}
              data-seed="logId"
            >
              <Index></Index>
            </TabBar.Item>
            <TabBar.Item
              icon={<div className="tab chat" />}
              selectedIcon={<div className="tab chat-on" />}
              title="聊天"
              key="chat"
              selected={this.state.selectedTab === 'chat'}
              onPress={() => this.jumpTab('chat')}
            >
              <Chat 
              chat={this.props.chat}
              >
              </Chat>
            </TabBar.Item>
            <TabBar.Item
              icon={<div className="tab concat" />}
              selectedIcon={<div className="tab concat-on" />}
              title="通讯录"
              key="concat"
              selected={this.state.selectedTab === 'concat'}
              onPress={() => this.jumpTab('concat')}
            >
              <Concat concat={this.props.concat} user={this.props.user}></Concat>
            </TabBar.Item>
            <TabBar.Item
              icon={<div className="tab my" />}
              selectedIcon={<div className="tab my-on" />}
              title="我的"
              key="my"
              selected={this.state.selectedTab === 'my'}
              onPress={() => this.jumpTab('my')}
            >
              <My 
              my={this.props.my} 
              global={this.props.global}
              >
              </My>
            </TabBar.Item>
          </TabBar>
        </div>
      </Fragment>
    );
  }
}
