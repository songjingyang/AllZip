import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';

import {
  TabBar,
  List,

} from 'antd-mobile';

import './Index.less';


interface Props {
 
}

interface State {
  
}

export default class Index extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      
    };
  }
  state: State

  componentDidMount() {
    
  }

  
  render() {
    return (
      <Fragment>
        Home内容
      </Fragment>
    )
  }
}
