import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';

import {
  NavBar,
  Icon,
  SwipeAction,
  Button,
  Toast
} from 'antd-mobile';
import { History } from 'history';

import './NewFriends.less';
import User from '../../models/User';
import Concat from '../../models/Concat';
import { inject, observer } from 'mobx-react';

interface Props {
  user: User,
  concat: Concat,
  history: History
}

interface State {

}

@inject('user', 'concat')
@observer
export default class NewFriends extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {

    }
  }

  componentDidMount() {
    this.props.concat.getConcat({
      data: {
        merch_id: this.props.user.userInfo.merchid,
        id: this.props.user.userInfo.id
      }
    })
  }

  accept = (item: any) => {
    this.props.concat.acceptapply({
      data: {
        'merch_id': this.props.user.userInfo.merchid,
        'host_id': this.props.user.userInfo.id,
        'guest_id': item.id,
        'accept': 1,
        'remark': "朋友备注"
      },
      callback: res => {
        console.log('code:', res)
        if (res.code === '1') {
          this.props.concat.getConcat({
            data: {
              merch_id: this.props.user.userInfo.merchid,
              id: this.props.user.userInfo.id
            }
          })
        }
      }
    })
  }
  delete = (uid: string)=>{
		console.log('TCL: NewFriends -> delete -> uid', uid)
    const accept = '1接受， 2拒绝'
    this.props.concat.rejectapply({
      data: {
        'merch_id': this.props.user.userInfo.merchid,
        'host_id': this.props.user.userInfo.id,
        'guest_id': uid,
        'accept': 1,
        'remark': "朋友备注"
      },
      callback: res => {
        if (res.code === 200) {
          Toast.success('已通过', 1)
          // this.setState({
          //   isAccept: true
          // })
        }
      }
    })
  }
  render() {
    return <div className='newfriends-module main-bg'>
      <NavBar
        icon={<Icon type="left" />}
        onLeftClick={() => this.props.history.goBack()}
      >新朋友</NavBar>

      <div styleName="newfriends-list">
        {this.props.concat.concatList.new_friends.map((item: any) => 
          <SwipeAction
            right={[
              {
                text: '删除',
                onPress: () => { this.delete('1091935347534733222')},
                style: { width: '120px', backgroundColor: '#F4333C', color: 'white' },
              },
            ]}
            key={item.id}
          >
            <div styleName="newfriends-item">
              <div styleName='left'>
                <div styleName="avatar">
                  <img src={item.avatar ? item.avatar : ''} alt=""/>
                </div>
                <span styleName="info">{item.nickname ? item.nickname : ''}</span>
              </div>
              {item.status == 1 ?
                <Button onClick={() => this.accept(item)} className='btn-primary'>通过</Button> :
                <Button size='small' type='ghost' disabled>已通过</Button>}
            </div>
          </SwipeAction>
        )}
      </div>

    </div>
  }
}