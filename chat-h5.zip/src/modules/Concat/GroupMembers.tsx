import React, { Fragment } from 'react';
import { Link, match } from 'react-router-dom';
import { StickyContainer, Sticky } from 'react-sticky';
import { NavBar, Icon} from 'antd-mobile';
import concat from '../../models/Concat'
import { History } from 'history';
import Group from '../../models/Group';


import './GroupMembers.less';
import { inject, observer } from 'mobx-react';
import User, { UserInfo } from '../../models/User';
import List from '../../components/List'


interface Params {
  groupId: string
}
interface Props {
  group: Group
  user: User
  history: History
  match: match<Params>
}

interface State {
  
}

@inject('group', 'user')
@observer
export default class GroupMembers extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
  

    this.state = {
      
    };
  }

  componentDidMount() {
    const params = this.props.match.params;
		console.log('TCL: GroupMembers -> componentDidMount -> params', params)
    this.props.group.getGroupMemberList({
      data: {
        group_id: params.groupId
      },
    });
  }

  renderItem(data: any){
    return (
      <div className="group-members-item">
        <div className="avatar">
          <img
            src="https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1548741312&di=f14ded4ba16ffcf3079c68a848829179&src=http://b-ssl.duitang.com/uploads/item/201507/02/20150702193124_zrLFJ.jpeg"
            alt=""
          />
        </div>
        <span className="info">{data}</span>
      </div>
    );
  }

 

  render() {
    console.log('this.props.group.groupMemberList', this.props.group.groupMemberList);
    // const list = this.props.group.groupMemberList.map(item => { return { label: item.nickname, value: item.player_id, spell: item.nickname } })

    return (
      <div>
        <NavBar
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
          rightContent={<Icon key="1" type="plus" />}
        >
          群聊成员
        </NavBar>
        <div>
          <List
            className="group-members-container"
            data={this.props.group.groupMemberList}
            keyMap={{ label: 'nickname', value: 'player_id' }}
            listViewClassName="group-members-list-view"
            renderItem={this.renderItem}
          />
        </div>
      </div>
    );
  }
}
