import React, { Fragment } from 'react';
import { Link, match } from 'react-router-dom';
import { StickyContainer, Sticky } from 'react-sticky';
import { NavBar, Icon } from 'antd-mobile';
import { History } from 'history';

import './Index.less';
import { inject, observer } from 'mobx-react';
import User, { UserInfo } from '../../models/User';
import List from '../../components/List'
import Concat from '../../models/Concat';

interface Params {
  groupId: string
}

interface Props {
  concat: Concat
  user: User
  // history: History
}

interface State {

}

@inject('concat', 'user')
@observer
export default class Index extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {

    }
  }

  componentDidMount() {
    this.props.concat.getConcat({
      data: {
        merch_id: this.props.user.userInfo.merchid,
        id: this.props.user.userInfo.id
      }
    })
  }
  renderItem(data: any) {
     return (
       <Link to={`/concat/personalinfo/${data.id}`} className="concat-item">
        <div className="avatar">
          <img
            src={data.avatar?data.avatar:''}
            alt=""
          />
        </div>
        <span className="info">{data.label?data.label:''}</span>
      </Link>
    );


  }
  render() {
    // const list = this.props.concat.concatList.contact.map(item => { return { label: item.nickname, value: item.player_id, spell: item.nickname } })
    console.log('list: ', this.props.concat.concatList.contact)

    return (
      <div>
        <NavBar>通讯录</NavBar>
        <div>
          <List
            className="concat-container"
            data={this.props.concat.concatList.contact}
            keyMap={{ label: 'nickname', value: 'id' }}
            listViewClassName="concat-list-view"
            renderItem={this.renderItem}
            count={this.props.concat.concatList.new_friends.length}
          />
        </div>
      </div>
    )
  }
}