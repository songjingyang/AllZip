import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';

import {
  NavBar,
  Icon,
  SwipeAction
} from 'antd-mobile';
import concat from '../../models/Concat'
import { History } from 'history';
import Group from '../../models/Group';

import './GroupChat.less';
import { inject, observer } from 'mobx-react';
import User, { UserInfo } from '../../models/User';

interface Props {
  group: Group;
  user: User;
  history: History
}

interface State {
  
}

@inject('group', 'user')
@observer
export default class GroupChat extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      
    }
  }

  componentDidMount() {
    const userInfo: UserInfo = this.props.user.userInfo;
    const group: Group = this.props.group;
    group.getGroupList({
      data: {
        "merch_id": userInfo.merchid,
        "admin_id": "",
        "player_id": ""
      }
    })
  }

  render() {
    
    return (
      <div className="groupchat-module">
        <NavBar
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
        >
          群聊
        </NavBar>

        <div styleName="groupchat-list">
          {this.props.group.groupList.map(item => (
            <Link to={`/concat/groupMembers/${item.group_id}`}>
              <div styleName="groupchat-item">
                <div styleName="avatar">
                  <img
                    src="https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1548741312&di=f14ded4ba16ffcf3079c68a848829179&src=http://b-ssl.duitang.com/uploads/item/201507/02/20150702193124_zrLFJ.jpeg"
                    alt=""
                  />
                </div>
                <span styleName="info">{item.name}</span>
              </div>
            </Link>
          ))}

          {/* <div styleName="groupchat-item">
          <div styleName="avatar">
            <img src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=815774226,3864393983&fm=26&gp=0.jpg" alt=""/>
          </div>
          <span styleName="info">今天就开始尬聊吧</span>
        </div> */}
        </div>
      </div>
    );
  }
}
