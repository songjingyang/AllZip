import React, { Fragment } from 'react';
import { Link, match } from 'react-router-dom';
import {
  NavBar,
  Icon,
  Tag,
  InputItem,
  Button,
  Popover
} from 'antd-mobile';
import { History } from 'history'

import CheckedTag from '../../components/CheckedTag/index'
import './SetLabel.less';

const Item = Popover.Item

interface Props {
  history: History,
  match: match
}

interface State {
  visible: boolean
  value: string
  labelBox: any
  labelAll: any
}

export default class SetLabel extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      visible: false,
      value: '',
      labelBox: [],
      labelAll: [
        {value: '11', label: '你是'},
        {value: '22', label: '你发发开发可使肌肤'},
        {value: '33', label: '1231'},
        {value: '44', label: '同学'},
        {value: '55', label: '朋友'}
      ]
    }
  }

  componentDidMount() {}
  
  onChange = (selected: any, value: any) => {
    // console.log('selected', selected, 'value:', value)
    if (value.selected) {
      this.state.labelBox.push(value)
      this.setState({
        labelBox: this.state.labelBox
      })
    } else {
      for (let index = 0; index < this.state.labelBox.length; index++) {
        if (this.state.labelBox[index]===value){
          this.state.labelBox.splice(index,1)
          break;
        }
      }
      this.setState({
        labelBox: this.state.labelBox
      })
    }
  }
  deleteTag = (selected: any, value: any) => {
    if (!value.selected) {
      for (let index = 0; index < this.state.labelBox.length; index++) {
        if (this.state.labelBox[index]===value){
          this.state.labelBox.splice(index,1)
          break;
        }
      }
      this.setState({
        labelBox: this.state.labelBox
      })
    }
  }
  onSelect = (opt: any) => {
    this.setState({
      visible: false,
    })
    for (let index = 0; index < this.state.labelBox.length; index++) {
      if (this.state.labelBox[index]===this.state.value){
        this.state.labelBox.splice(index,1)
        break;
      }
    }
    this.setState({
      labelBox: this.state.labelBox
    })
  }
  jumpSetRemark = () => {
    // console.log('uid:', this.props.match.params.uid)
    const params: any = this.props.match.params
    this.props.history.push(`/concat/setremark/${params.uid}`)
    localStorage.setItem("labels", JSON.stringify(this.state.labelBox))
  }
  addLabels = (e: any) => {
    if (e.keyCode === 13) {
      this.state.labelAll.push(e.target.value)
    }
    console.log('labelbox:', this.state.labelAll)
  }
  
  render() {
    return <div className="setlabel-module">
      <NavBar
        icon={<Icon type='left' />}
        onLeftClick={() => this.props.history.goBack()}
        rightContent={<span onClick={this.jumpSetRemark} style={{fontSize: '28px'}}>确定</span>}
      >设置标签</NavBar>

      <div styleName='user-list'>
        <div styleName='ipt-list'>
          <div styleName='label-box'>
              <CheckedTag
                data={this.state.labelBox}
                onChange={this.deleteTag}
              />
          </div>
          <InputItem
            placeholder='输入标签'
            onKeyDown={this.addLabels}
          />
        </div>
        <span styleName='label-title'>所有标签</span>
        <div styleName='label-list'>
          <CheckedTag
            data={this.state.labelAll}
            onChange={this.onChange}
          />
        </div>
      </div>
    </div>
  }
}