import React, { Fragment } from 'react';
import { Link, match } from 'react-router-dom';
import {
  NavBar,
  Icon,
  ActionSheet
} from 'antd-mobile';
import { History } from 'history'
import Concat from '../../models/Concat'

import './PersonalInfo.less';
import { any } from 'prop-types';
import { inject, observer } from 'mobx-react';
import User from '../../models/User';

interface Props {
  user: User
  concat: Concat
  history: History
  match: match
}
interface State { 
}

@inject('user', 'concat')
@observer
export default class PersonalInfo extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      
    }
  }

  componentDidMount() {
    const params: any = this.props.match.params 
    this.props.concat.getPersonalInfo({data: {
      uid: params.uid
    }})
  }
  showActionSheet = () => {
    const BUTTONS: any = ['删除联系人', '取消'];
    ActionSheet.showActionSheetWithOptions({
      options: BUTTONS,
      cancelButtonIndex: BUTTONS.length - 1,
      destructiveButtonIndex: BUTTONS.length - 2,
      // title: 'title',
      message: `请将联系人"${this.props.concat.personalInfoInfo.nickname}"删除，同时删除与该联系人的聊天记录`,
      maskClosable: true,
      // 'data-seed': 'logId',
      // wrapProps: any,
    },
    (buttonIndex: number) => {
      // console.log('buttonIndex', buttonIndex)
      this.setState({ clicked: BUTTONS[buttonIndex] });
      if (buttonIndex === 0) {
        // console.log(0, buttonIndex)
        this.props.concat.removefriends({data: {
          'merch_id': this.props.user.userInfo.merchid,
          'host_id': this.props.user.userInfo.id,
          'guest_id': this.props.concat.personalInfoInfo.uid
        }})
      } else {
        console.log(1, buttonIndex)
      }
    });
  }
  
  render() {
    const win: any = window;
    const info = this.props.concat.personalInfoInfo
		console.log('TCL: PersonalInfo -> render -> info', info)
    return <div className="personalinfo-module">
      <NavBar
        icon={<Icon type="left" />}
        onLeftClick={() => this.props.history.push('/home/concat')}
      >个人信息</NavBar>

      <div styleName="personalinfo-list">
        <div styleName="personalinfo-item">
          <div styleName="avatar">
            <img src={info.avatar} alt=""/>
          </div>
          <span styleName="info">{info.nickname}</span>
        </div>

        <Link to={`/concat/setremark/${info.uid}`} styleName="personalinfo-item remark-item">
          <span>备注</span>
          <Icon type="right" />
        </Link>
        <Link to={`/chat/chatroom/${info.uid}/${0}/${info.nickname}/${win.encodeURIComponent(info.avatar) || 0}`} styleName="sendmsg-item">
          发消息
        </Link>
        <div onClick={this.showActionSheet} styleName="sendmsg-item">
          删除好友
        </div>
      </div>
    </div>
  }
}
