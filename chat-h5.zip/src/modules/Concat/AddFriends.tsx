import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';

import {
  NavBar,
  Icon,
  SearchBar,
  SwipeAction,
  Button
} from 'antd-mobile';
import { History } from 'history';
import { inject, observer } from 'mobx-react';
import User from '../../models/User';
import Concat from '../../models/Concat';

import './AddFriends.less';
import { AnyMxRecord } from 'dns';

interface Props {
  history: History
  user: User
  concat: Concat
}

interface State {
  isShow: boolean
  inputValue: string
  isAdd: boolean
  statusMap: any
}

@inject('user', 'concat')
@observer
export default class AddFriends extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      isShow: false,
      inputValue: '',
      isAdd: false,
      statusMap: {
        1: '添加',
        2: '已添加'
      }
    };
  }

  // componentDidMount() {}

  onSearch = (val: string) => {
    this.props.concat.searchfriends({
      data: {
        nm: val,
        pg: 0
      }
    })
    if (val.length !== 0) {
      this.setState({
        isShow: true,
        inputValue: val
      })
    } else {
      this.setState({
        isShow: false,
        inputValue: ''
      })
    }
  }

  add = (item: any) => {
    item.status = 2
    this.props.concat.addfriends({
      data: {
        'merch_id': this.props.user.userInfo.merchid,
        'host_id': this.props.user.userInfo.id,
        'guest_id': item.id
      },
      callback: res => {
        if (res.code === '1') {
          this.setState({
            isAdd: true
          })
        }
      }
    })
  }
  
  render() {
    return <div className="addfriends-module">
      <NavBar
        icon={<Icon type="left" />}
        onLeftClick={() => this.props.history.goBack()}
      >添加朋友</NavBar>

      <SearchBar
        value={this.state.inputValue}
        placeholder="搜索昵称"
        onChange={this.onSearch}
        onClear={() => { console.log('onClear'); }}
        onCancel={() => { console.log('onCancel'); }}
        maxLength={8}
      />
      {this.state.inputValue.length !== 0 && <div styleName="addfriends-list">
        {this.props.concat.searchfriendsList !== undefined ? this.props.concat.searchfriendsList.players.map((item: any) =>
          <SwipeAction
            right={[
              {
                text: '删除',
                onPress: () => console.log('删除'),
                style: { width: '120px', backgroundColor: '#F4333C', color: 'white' },
              },
            ]}
          >
            <div styleName="addfriends-item">
              <div styleName='left'>
                <div styleName="avatar">
                  <img src={item.avatar ? item.avatar : ''} alt=""/>
                </div>
                <span styleName="info">{item.nickname ? item.nickname : ''}</span>
              </div>

              {/* {item.status == 1 ?  */}
                <Button
                  onClick={() => this.add(item)}
                  className={item.status == 1 ? 'btn-primary' : ''}
                  disabled={item.status == 1 ? false : true}
                  type={item.status == 1 ? undefined : 'ghost'}
                  size={item.status == 1 ? undefined : 'small'}
                >{this.state.statusMap[item.status]}</Button>
            </div>
          </SwipeAction>
        ) : ''}
      </div>}
    </div>
  }
}
