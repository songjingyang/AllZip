import React, { Fragment } from 'react';
import { Link, match } from 'react-router-dom';

import {
  NavBar,
  Icon,
  InputItem
} from 'antd-mobile';
import { createForm } from 'rc-form';
import { History } from 'history'

import './SetRemark.less'
import Concat from '../../models/Concat';
import { inject } from 'mobx-react';

interface Props {
  form: any,
  concat: Concat
  history: History,
  match: match,
}

interface State {
  
}

@createForm()
@inject('concat')
export default class SetRemark extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      
    }
  }

  componentDidMount() {}

  jumpRouter = () => {
    const params: any = this.props.match.params
    this.props.concat.setRemark({
      data: {
        uid: params.uid,
        remark: this.props.form.getFieldsValue().remark
      },
      callback: res => {
        if (res.code === '1') {
          this.props.history.push(`/concat/personalinfo/${params.uid}`)
        }
      }
    })
  }
  
  render() {
    const { getFieldProps } = this.props.form
    const params: any = this.props.match.params
    const labels: any = localStorage.getItem('labels')

    return <div className="setremark-module">
      <NavBar
        icon={<Icon type='left' />}
        onLeftClick={() => this.props.history.push(`/concat/personalinfo/${params.uid}`)}
        rightContent={<span onClick={this.jumpRouter} style={{fontSize: '28px'}}>确定</span>}
      >设置备注和标签</NavBar>

      <div styleName="setmark-list">
        <div styleName='setmark-node'>备注名</div>
        <div styleName="setmark-item">
          <InputItem
            { ...getFieldProps('remark', {
              initialValue: ''
            }) }
            className='label'
            clear
            placeholder='添加备注名'
          />
        </div>
        {/* <div styleName='setmark-node'>标签</div>
        <Link to={`/concat/setlabel/${params.uid}`} styleName="setmark-item label-item">
          {JSON.parse(labels) ? <div>
            {JSON.parse(labels).map((item: any, index: number) => {
              return item.label + ((index < JSON.parse(labels).length - 1) ? '，' : '')
            })}
          </div> :
          <span>通过标签给联系人进行分类</span>}
          <Icon type="right" />
        </Link> */}
      </div>
      
    </div>
  }
}
