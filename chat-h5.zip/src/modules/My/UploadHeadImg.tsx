import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import {
  NavBar,
  List,
  Icon,
  Toast
} from 'antd-mobile';
import UploadImg from "../../components/UploadImg";
import './UploadHeadImg.less';
import Global from '../../models/Global';
import My from '../../models/My';
import { History } from 'history';
import { inject, observer } from 'mobx-react';
import { match } from 'react-router';
const Item = List.Item;
export interface Props {
  selectedTab: string;
  fullScreen: boolean;
  history: History;
  global: Global;
  my: My
}
export interface State {
  selectedTab: string;
  fullScreen: boolean;
}
@inject('global', 'user', 'my')
@observer
export default class UploadHeadImg extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      selectedTab: 'home',
      fullScreen: true,

    };
  }
  state: State
  componentDidMount() {
    // const params = this.props.match.params;
    // this.setState({
    //   selectedTab: params.tab,
    // });
    this.props.my.getMyInfo({
      data: {

      }
    })
  }
  jumpTab = (tab: string) => {
    this.setState({
      selectedTab: tab,
    });
    // this.props.dispatch(routerRedux.push(`/home/${tab}`));
  };

  upload = async (formData: any) => {
    const url = await this.props.global.upload(formData)
    this.props.my.saveUpdateInfo({
      data: {
        nickname: this.props.my.myInfo.nickname,
        avatar: url
      },
      callback: res => {
        if (res.code === '1') {
          this.props.my.getMyInfo({
            data: {
            },
            //   callback:res=>{
            //     if (res.code === '1') {
            //      Toast.success(
            //     '上传成功',
            //     2,
            //     (onclose = () => {
            //       this.props.history.goBack()
            //     })
            // );}
            //   }
          })

        }
      }
    },
    )
    return url;
  }

  render() {
    const info = this.props.my.myInfo
    return <div className='UploadHeadImg'>
      <NavBar
        mode="dark"
        onLeftClick={() => this.props.history.goBack()}
        rightContent={[
          <Icon key="1" type="ellipsis" />,
        ]}
        icon={<Icon type="left" />}
      >修改头像</NavBar>
      <div className='Upload_div'>
        <UploadImg
          onUpload={this.upload}
          value={info.avatar}
          label=""
        />
      </div>
    </div>
  }
}
