import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import {
  NavBar,
  List,
  Icon,
  InputItem,
  Toast

} from 'antd-mobile';
import { History } from 'history';
import './UpdateNickName.less';
import { createForm } from 'rc-form';
import { inject, observer } from 'mobx-react';
import My from '../../models/My'

const Item = List.Item;
export interface Props {
  selectedTab: string;
  fullScreen: boolean;
  history: History;
  form: any;
  my: My;
}
export interface State {
  selectedTab: string;
  fullScreen: boolean;
}
@createForm()
@inject('my')
@observer
export default class UpdateNickName extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      selectedTab: 'home',
      fullScreen: true,
    };
  }
  state: State

  componentDidMount() {
    // const params = this.props.match.params;
    // this.setState({
    //   selectedTab: params.tab,
    // });
    this.props.my.getMyInfo({ data: {} })
    console.log('this.props.my :', this.props.my);
  }

  jumpTab = (tab: string) => {
    this.setState({
      selectedTab: tab,
    });
    // this.props.dispatch(routerRedux.push(`/home/${tab}`));
  };
  isSure = () => {
    this.props.my.saveUpdateInfo({
      data: {
        nickname: this.props.form.getFieldsValue().nickname,
        avatar: ''
      },
      callback: res => {
        if (res.code === '1') {
          Toast.success(res.msg, 2, onclose = () => {
            this.props.history.goBack()
          });
        }
      }
    })
  }
  render() {
    const { getFieldProps, getFieldError } = this.props.form;
    const info = this.props.my.myInfo
    return <div className='uploadNickName'>
      <NavBar
        icon={<Icon type="left" />}
        onLeftClick={() => this.props.history.goBack()}
        rightContent={[
          <span key="0" onClick={this.isSure}>确定</span>,
        ]}
      >
        修改昵称
      </NavBar>
      <div className='label'>
        修改昵称
      </div>
      <form>
        <InputItem
          style={{ fontSize: '24px', fontFamily: 'PingFangSC-Medium', fontWeight: "500", color: 'rgba(51,51,51,1)', height: '84px' }}
          {...getFieldProps('nickname', {
            initialValue: info.nickname,
          })}
          clear
          placeholder="输入昵称"
        >
        </InputItem>
      </form>
    </div>;
  }
}
