import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import UploadImg from "../../components/UploadImg";
import {
  NavBar,
  List,
  Icon,
} from 'antd-mobile';
import Global from '../../models/Global';
import './Index.less';
import { inject, observer } from 'mobx-react';
import { match } from 'react-router';
import My from '../../models/My'
const Item = List.Item;
export interface Props {
 my : My;
 global: Global;
}

export interface State {
  selectedTab: string;
  fullScreen: boolean;

}
@inject('global', 'my')
@observer
 export default class Index extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      selectedTab: 'home',
      fullScreen: true,

    };
  }
  state: State

  componentDidMount() {
    // const params = this.props.match.params;
    // this.setState({
    //   selectedTab: params.tab,
    // });
    this.props.my.getMyInfo({ data: {} ,
    })
   
  }

  jumpTab = (tab: string) => {
    this.setState({
      selectedTab: tab,
    });
    // this.props.dispatch(routerRedux.push(`/home/${tab}`));
  };
  ToQrCode = () => {

  }
  ToMyInfo = () => {

  }
  upload = async (formData: any) => {
    const url = await this.props.global.upload(formData)
    return url;
  }
 render() {
    const info = this.props.my.myInfo
    return <div className='MineIndex body main-bg'>
      <NavBar>我的</NavBar>
      <div className="user-item">
        <Link className="avatar" to="/my/headimg">
          <img src={info.avatar} alt="" />
        </Link>
        <Link to='/my/nickname' className="info">{info.nickname}</Link>
        <Icon className="time" type="right" />
      </div>
      <Link to="/my/qrcode" >
        <Item
          style={{ marginTop: '12px' }}
          arrow="horizontal"
          onClick={() => { this.ToQrCode }}
        >我的二维码
         </Item>
      </Link>
      <div className='my_div'>
        {/* <UploadImg
          onUpload={this.upload}
          value={"data:image/png;base64,"+info.qrcode}
          label=""
        /> */}
        <img src={"data:image/png;base64," + info.qrcode} alt=""/>
      </div>
    </div>;
  }
}
