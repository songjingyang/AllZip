import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import {
  NavBar,
  List,
  Icon
} from 'antd-mobile';
import './UploadQrCode.less';
import Global from '../../models/Global';
import My from '../../models/My'
import { inject, observer } from 'mobx-react';
import { History } from 'history';
import UploadImg from "../../components/UploadImg";
const Item = List.Item;
export interface Props {
  selectedTab: string;
  fullScreen: boolean;
  history: History;
  global: Global
  my: My
}

export interface State {
  selectedTab: string;
  fullScreen: boolean;
}
@inject('my')
@observer
export default class QrCode extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      selectedTab: 'home',
      fullScreen: true,
    };
  }
  state: State

  componentDidMount() {
    // const params = this.props.match.params;
    // this.setState({
    //   selectedTab: params.tab,
    // });
    this.props.my.getMyInfo({ data: {} })
  }

  jumpTab = (tab: string) => {
    this.setState({
      selectedTab: tab,
    });
    // this.props.dispatch(routerRedux.push(`/home/${tab}`));
  };

  upload = async (formData: any) => {
    // const url = await this.props.global.upload(formData)
    // return url;
  }
  render() {
    const info = this.props.my.myInfo
    return <div className='body main-bg'>
      <NavBar
        mode="dark"
        onLeftClick={() => this.props.history.goBack()}
        icon={<Icon type="left" />}
      >二维码</NavBar>
      <div className='uploadQrCode'>
        <div className='top'>
          <Link className='img_div' to='/my/headimg'>
            <img
              src={info.avatar}
              alt=""
              className='img'
            />
          </Link>
          <Link to='/my/nickname' className='description'>{info.nickname}</Link>
        </div>

        <div className='qrcode_div'>
          {/* <UploadImg
            onUpload={this.upload}
            value={"data:image/png;base64," + info.qrcode}
            label=""
          /> */}
          <img src={"data:image/png;base64," + info.qrcode} />
        </div>
      </div>

    </div>
  }
}
