import React, { Fragment } from 'react';

import { NavBar, InputItem,  Toast } from 'antd-mobile';
import Button from 'antd-mobile/lib/button'
import {Link} from 'react-router-dom'
import { match } from 'react-router';
import { createForm } from 'rc-form';
import './Login.less';
import { inject, observer } from 'mobx-react';
import User from '../../models/User';
import { History } from 'history';
import { start } from 'repl';
import { validErrorTip } from '../../utils/utils'
interface Props {
  history: History;
  form: any;
  match: match;
  user: User;
}

interface State {
  
}
@createForm()
@inject('user')
@observer
export default class Login extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {};
  }
  state: State;

  componentDidMount() {

  }
  login = () => {
    this.props.form.validateFields((error:any, values:any) => {
			console.log('TCL: Login -> login -> error', error)
      if (error) {
        //为空验证
        validErrorTip(error)
        return
      }
    this.props.user.login({
      data: {
        external_id: values.external_id,
        merch_id: values.merch_id,
      },
      callback: res => {
        if (res.code === '1') {
          Toast.loading(
            'loading...',
            1.5,
            (onclose = () => {
              this.props.history.push({ pathname: '/home/home' });
            })
          );
        }
      },
    });
    })
  }

  render() {
    const { getFieldProps, getFieldError } = this.props.form;
    return <div styleName="user-login " className={'fullscreen'}>
        <NavBar>登录</NavBar>
        <form styleName="form">
          <div styleName="form-item">
            <div styleName="label">账号</div>
          <InputItem styleName="control" {...getFieldProps('merch_id', {
                initialValue: '1234',
                rules: [
                  {
                    required: true,
                    message: '请输入手机号或邮箱',
                    // whitespace: true
  
                  },
                ],
              })} 
              placeholder="请输入手机号或邮箱"
              />
          </div>
          <div styleName="form-item">
            <div styleName="label">额外id</div>
          <InputItem styleName="control" {...getFieldProps('external_id', {
              initialValue: '',
              rules: [
                {
                  required: true,
                  message: '输入密码',
                  whitespace: true
                },
              ],
            })}
            placeholder="输入密码"
            />
          </div>
      </form>
      <Button  onClick={this.login} type="primary" className="register-btn" >
          登录
        </Button>
      <Link to="/user/register" styleName="go-register">前去注册</Link>
      </div>;
  }
}

