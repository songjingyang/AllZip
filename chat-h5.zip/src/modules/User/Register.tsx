import React, { Fragment } from 'react';

import { NavBar, InputItem, Button, Toast } from 'antd-mobile';
import { Link } from 'react-router-dom'
import { createForm } from 'rc-form';
import './Register.less';
import { History } from 'history';
import User from '../../models/User';
import { validErrorTip } from '../../utils/utils'
import { inject } from 'mobx-react';
interface Props {
  form: any;
  history: History;
  user: User;
}
interface State {
  
}
@createForm()
@inject('user')
export default class Register extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {};
  }
  state: State;

  componentDidMount() {}
  register = () => {
    this.props.form.validateFields((error: any, values: any) => {
      if (error) {
        //为空验证
        validErrorTip(error)
        return
      }
    this.props.user.register({
      data: {
        "merch_id": this.props.form.getFieldsValue().email,
        "external_id": this.props.form.getFieldsValue().pass
      },
      callback: (res) => {
        if (res.code === '1') {
          Toast.success(res.msg,1.5,onclose=()=>{
            this.props.history.push({ pathname: "/user/login"})
          })        
        }
      }
    })
    })
  }
  render() {
    const { getFieldProps, getFieldError } = this.props.form;
    return (
      <div className="user-login fullscreen">
        <NavBar>注册</NavBar>
        <form className="form">
          <div className="form-item">
            <div className="label">账号</div>
            <InputItem
              className="control"
              {...getFieldProps('email', {
                initialValue: '',
                rules: [
                  {
                    required: true,
                    message: '请输入手机号或邮箱',
                  },
                ],
              })}
              placeholder="请输入手机号或邮箱"
            />
          </div>
          <div className="form-item">
            <div className="label">密码</div>
            <InputItem
              className="control"
              {...getFieldProps('pass', {
                initialValue: '',
                rules: [
                  {
                    required: true,
                    message: '输入密码',
                  },
                ],
              })}
              placeholder="输入密码"
              type='password'
            />
          </div>
        </form>
        <Button onClick={this.register} type="primary" className="register-btn">
          注册
        </Button>
        <Link to="/user/login/" className="go-register">前去登录</Link>
      </div>
    );
  }
}
