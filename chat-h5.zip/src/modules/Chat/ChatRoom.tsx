import React, { Fragment } from 'react';
import meq from 'meq2';
import produce from 'immer';
import classnames from 'classnames';
import MediaStreamRecorder from 'msr';
import {
  InputItem,
  NavBar,
  Icon,

} from 'antd-mobile';
import { History } from 'history';

import GroupInfo from './GroupInfo'

import './ChatRoom.less';
import Upload from '../../components/Upload';
import Global from '../../models/Global';
import { inject, observer } from 'mobx-react';
import { match } from 'react-router';
import { Stream } from 'stream';
import { observable } from 'mobx';
import Chat from '../../models/Chat';
import User, { UserInfo } from '../../models/User';

interface Params{
  uid: string;
  type: string;
  name: string;
  avatar: string;
}

interface Props {
  selectedTab: string;
  fullScreen: boolean;
  match: match<Params>;
  history: History;
  global: Global;
  chat: Chat,
  user: User
}

enum InputType{
  Keyboard,
  Microphone
}

interface State{
  topic: string;
  isSubed: boolean;
  uid: string;
  users: any[];
  messages: any[];
  message: string;
  unreadCount: number;
  offset: number;
  loadMoreClicked: boolean;
  isShowMore: boolean;
  isShowGroupMember: boolean;
  msgType: number;
  name: string;
  avatar: string;
  type: string;
  inputType: InputType;
  media: any;
}

export interface TextMsg{
  msg: string;
}
export interface ImgMsg{
  type: number;
  name: string;
  md5: string;
  url: string;
  ext: string;
  w: number;  
  h: number; 
  size: number | string;
}
export interface VoiceMsg{
  dur: number;
  ext: string;
  md5: string
  size: number
  url: string
}
export interface VideoMsg{
  dur: number;
  ext: string;
  h: number;
  md5: string
  size: number;
  url: string
  w: number;
}
export interface LocationMsg{
  msg: string;
}
export interface FileMsg{
  msg: string;
}
export interface CustomMsg{
  msg: string;
}

@inject('global', 'user', 'chat')
@observer
export default class ChatIndex extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      topic: '',
      isSubed: false,
      uid: '',
      users: [],
      messages: [],
      message: '',
      unreadCount: 0,
      offset: 0,
      loadMoreClicked: false,
      isShowMore: false,
      isShowGroupMember: false,
      msgType: 0,
      name: '',
      avatar: '',
      type: 'chat',
      inputType: InputType.Microphone,
      media: '',
    };
    this.chatRecordList = null;
  }
  m: any
  chatRecordList: any;

  static getDerivedStateFromProps(nextProps: any, prevState: State) {
    return null;
  }
  
  componentDidMount() {
    const win: any = window
    const params = this.props.match.params;
		console.log('TCL: ChatIndex -> componentDidMount -> params', params)
    // const uid: string = params.uid;
    const name = params.name;
    const avatar = win.decodeURIComponent(params.avatar);
    const type = params.type === '1' ? 'group' : 'p2p';
    const otherId = params.uid;
    const myId = this.props.user.userInfo.id;
    const unionId = otherId < myId ? `${otherId}_${myId}` : `${myId}_${otherId}`;
    const topic = `/${this.props.user.appid}/${type === 'p2p' ? '11' : '22'}/${type}/${unionId}`;
    const otherTopic = `/${this.props.user.appid}/${type === 'p2p' ? '11' : '22'}/${type}/${otherId}`;
    this.setState({
      uid: otherId,
      topic: topic,
      name: name,
      avatar: avatar,
      type: params.type,
    }, () => {
      this.connect();
    });
    this.props.chat.m.subscribe(otherTopic, () => {
			console.log('TCL:发送给对方topic发一次 ChatIndex -> componentDidMount -> otherTopic', otherTopic)
      this.m.publish(otherTopic, {msg: 'hello'}, 86400, 1, 0);
    })
  }

  connect(){
    const m = this.props.chat.m;
    this.m = m;
  
    // m.on("connect", () => {
				console.log('TCL: chatroom other -> connect -> this.state.topic', this.state.topic)
      m.subscribe(this.state.topic, () => {
        this.setState({isSubed: true})
        m.usersAll(this.state.topic, (users: any) => {
          for (var i = 0; i < users.length; i++) {
            // this.state.users.push({
            //   id: users[i].toString(),
            //   status: '0'
            // })
            this.setState(produce(state => {
              state.users.push({
                id: users[i].toString(),
                status: '0'
              })
            }))
          }
          m.presenceAll(this.state.topic,  (users: any) => {
            for (var i = 0; i < users.length; i++) {
              for (var j = 0; j < this.state.users.length; j++) {
                if (users[i].toString() == this.state.users[j].id) {
                  this.state.users[j].status = '1'
                }
              }
            }
          });
          m.joinchat(this.state.topic);

          // pull messages
          m.pull(this.state.topic, m.NEWEST_MSG, 10);
        });
      });
    // });


    m.on("unread", (res: any) => {
      let unreadCount = 0;;
      if (res.count - 10 < 0) {
        unreadCount = 0
      } else {
        unreadCount = res.count - 10
      }
      this.setState({unreadCount})
    });

    m.on("message", (msg: any) => {
			console.log('TCL: chatRoom -> connect -> msg', msg)
      msg.payload = JSON.parse(msg.payload)
      msg.nickname = this.getUser(msg.sender).nickname;
      var l = this.state.messages.length

    if(l){
      console.log('TCL: ChatIndex -> connect -> msg.id小了啊 ===', msg.id,  this.state.messages[l - 1].id, msg.id.toString() <  this.state.messages[l - 1].id.toString())
    }
      
      if (l == 0) {
        this.setState(produce(state =>{
          state.messages.push(msg)
          state.offset = msg.id
        }))
      }
      else if (msg.id < this.state.messages[l - 1].id) {
        this.setState(produce(state => {
          state.messages.unshift(msg)
          state.offset = msg.id
        }))
      } else {
        this.setState(produce(state => {
          state.messages.push(msg)
        }))
      }

      if (!this.state.loadMoreClicked) {
        // var chat = document.getElementById("chat-room");
        this.scrollToBottom();
      }
    });

    m.on("joinchat", (msg: any) => {
      var exist = false
      var id = msg.user.toString()
      for (var i = 0; i < this.state.users.length; i++) {
        if (this.state.users[i].id == id) {
          this.state.users[i].status = '1'
          exist = true
        }
      }

      if (!exist) {
        this.setState({
          users: [
            ...this.state.users,
            {
              id: msg.user.toString(),
              status: '1',
            },
          ],
        });
        // this.state.users.push()
      }
    });

    m.on("leavechat", (msg: any) => {
			console.error('TCL: ChatIndex -> connect -> msg', msg)
      var id = msg.user.toString()
      for (var i = 0; i < this.state.users.length; i++) {
        if (this.state.users[i].id == id) {
          this.state.users.splice(i, 1)
        }
      }
    });

    m.on("online", (msg: any) =>{
      var id = msg.user.toString()
      for (var i = 0; i < this.state.users.length; i++) {
        if (this.state.users[i].id == id) {
          this.state.users[i].stauts = '1'
        }
      }
    });

    m.on("offline", (msg: any) => {
      var id = msg.user.toString()
      for (var i = 0; i < this.state.users.length; i++) {
        if (this.state.users[i].id == id) {
          this.state.users[i].status = '0'
        }
      }
    });

    m.on("retrieve", (msg: any) => {
      console.log("msg retrieve", msg.topic.toString(), msg.msgid.toString());
    });
  }

  sendMessage = (e: any) => {
    if (e.keyCode === 13) {
      const msgType = 0;
      const msg = this.getTextMsg(e.target.value);

      this.send(msg, msgType);
    }
  }

  sendImg = (url: string) => {
    const img = this.getImgMsg(url)
    this.send(img, 1);
  }

  send = (data: any, msgType: number) => {
    this.m.publish(this.state.topic, data, 86400, 1, msgType);

    this.scrollToBottom();
    this.setState({
      message: ''
    })
    this.props.chat.addChatSession({
      avatar: this.state.avatar,
      ope: this.state.type,
      title: this.state.name,
      uid: this.state.uid
    })
  }

  getTextMsg = (str: string): TextMsg =>{
    return {msg: str}
  }

  getImgMsg = (url: string): ImgMsg => {
    return {
      type: 1,
      "name": '',
      "md5": "",
      "url": url,
      "ext": "",
      "w": 0,  // 宽
      "h": 0,  // 高
      "size": "" //byte
    }
  }

  scrollToBottom = () => {
    setTimeout(() => {
      if(this.chatRecordList){
        this.chatRecordList.scrollTop = this.chatRecordList.scrollHeight;
      }
    }, 200);
  }

  upload = async (formData: any) => {
    const url = await this.props.global.upload(formData)
    this.sendImg(url)
    return url;
  }
  record = () => {
    var mediaConstraints = { audio: true };

    navigator.getUserMedia(mediaConstraints, onMediaSuccess, onMediaError);
    const self = this;
    function onMediaSuccess(stream: any) {
      const MediaStreamRecorderTmp: any = MediaStreamRecorder;
      var mediaRecorder = new MediaStreamRecorderTmp(stream);
      mediaRecorder.mimeType = 'audio/ogg'; // audio/webm or audio/ogg or audio/wav
      mediaRecorder.ondataavailable = (blob: Blob) => {
        self.setState({ media: blob });
        // POST/PUT "Blob" using FormData/XHR2
        var blobURL = URL.createObjectURL(blob);
        alert(blobURL);
      };+
      mediaRecorder.start(3000);
    }

    function onMediaError(e: any) {
      alert(e)
      console.error('media error', e);
    }
  }

  getUser = (uid: string) => {
    const userModel = this.props.user;
    const user: UserInfo = userModel.usersMap[uid];
    if(user){
      return user;
    }else{
      
				console.log('TCL: ChatIndex -> getUser -> userModel.usersMapReqing[uid]', userModel.usersMapReqing[uid])
      !userModel.usersMapReqing[uid] && userModel.getUser({
        data: { uid: uid},
        callback: (res) => {
          if(res.code === '1'){
            const message = this.state.messages.find(item => item.sender === res.data.uid)
            message.username = res.data.nickname;
          }
        }
      })
      
      return {} as UserInfo;
    }
  }

  showGroupMembers = () => {
    this.setState(produce(state => {
      state.isShowGroupMember = true;
      state.users.forEach((item, index) => {
        const userModel = this.props.user;
        if(userModel.usersMap[item.id]){
          state.users[index] = {
            ...item,
            ...userModel.usersMap[item.id]
          }
        }
      })
    }));
    this.state.users.forEach(item => {
      const userModel = this.props.user;
      if(!userModel.usersMap[item.id]) {
        userModel.getUser({
          data: {
            uid: item.id
          },
          callback: res => {
            if (res.code === '1') {
              this.setState(produce(state => {
                state.users.forEach((user, index) => {
                  if(user.id === item.id){
                    state.users[index] = {
                      ...user,
                      ...res.data
                    }
                  }
                })

              }));
            }
          }
        })
      }
      
    })
   
  }
  
  
  render() {
    const user: UserInfo = this.props.user.userInfo;
    return <div className="chatroom main-bg">
        <NavBar icon={<Icon type="left" />} onLeftClick={() => this.props.history.goBack()} rightContent={this.state.type === '1' ? <Icon onClick={this.showGroupMembers} key="1" type="ellipsis" /> : null}>
          {this.state.name}
        </NavBar>
        <div ref={dom => (this.chatRecordList = dom)} className="chat-record-list">
          {this.state.messages.map(item => <Fragment>
              {<div className={classnames({
                    'chat-record-item': true,
                    left: item.sender !== user.id,
                    right: item.sender === user.id,
                  })}>
                  <div className="avatar">
                    <img src={this.getUser(item.sender).avatar} alt="" />
                  </div>
                  <div className="info">
                <div className="nickname">{this.getUser(item.sender).nickname}</div>
                    <div className="msg unread">
                      {item.type === 0 && item.payload.msg}
                      {item.type === 1 && <img src={item.payload.url} className="img" />}
                      {item.type === 2 && <audio src={item.payload.url} />}
                      {item.type === 3 && <video src={item.payload.url} />}
                      {item.type === 4 && <div>
                          {item.payload.title}
                          <br />
                          经度: {item.payload.title}
                          <br />
                          纬度: {item.payload.title}
                          <br />
                        </div>}
                      {item.type === 5 && <div>
                          {item.payload.name}
                          <br />
                          大小: {item.payload.size}
                          <br />
                        </div>}
                    </div>
                  </div>
                </div>}
              <div className="time"> {item.timestamp}</div>
            </Fragment>)}
          {/* <div className="chat-record-item left">
            <div className="avatar">
              <img src="http://cdn.duitang.com/uploads/item/201410/08/20141008150015_dP8yJ.thumb.700_0.jpeg" alt="" />
            </div>
            <div className="info">
              <div className="nickname">daycool</div>
              <div className="msg unread">daycool</div>
            </div>
          </div>
          <div className="time">2017888888</div>
          <div className="chat-record-item right">
            <div className="avatar">
              <img src="http://cdn.duitang.com/uploads/item/201410/08/20141008150015_dP8yJ.thumb.700_0.jpeg" alt="" />
            </div>
            <div className="info">
              <div className="nickname">daycool</div>
              <div className="msg unread">daycool</div>
            </div>
          </div>
          <div className="time">2017888888</div> */}
        </div>
        {/*        
        用户列表:{this.state.users.map(item => <div>id: {item.id}</div>)}
        消息列表：{this.state.messages.map(item => (
          <div> {item.payload.toString()} {item.timestamp}</div>
        ))} */}
        <audio src={this.state.media} />
        <div className="footer">
          {this.state.inputType === InputType.Microphone && <Fragment>
              <div onClick={() => this.setState({
                    inputType: InputType.Keyboard,
                  })} className="microphone" />
              <InputItem value={this.state.message} type="text" className="message" onKeyDown={this.sendMessage} />
            </Fragment>}
          {this.state.inputType === InputType.Keyboard && <Fragment>
              <div onClick={() => this.setState({
                    inputType: InputType.Microphone,
                  })} className="keyboard" />
              <div onClick={this.record} className="talk-btn">
                按住 说话
              </div>
            </Fragment>}

          <div className="file">
            <Upload onUpload={this.upload} value="" label="" />
          </div>
          <div className="pic">
            <Upload onUpload={this.upload} value="" label="" />
          </div>
        </div>
        {this.state.isShowGroupMember && <GroupInfo users={this.state.users} goBack={() => this.setState(
                { isShowGroupMember: false }
              )} />}
      </div>;
  }
}


