import React from 'react'
import { NavBar, Icon, List, Switch, WhiteSpace } from 'antd-mobile';

import './GroupInfo.less'
import User from '../../models/User';

interface State{
  dnd: boolean;
}

interface Props{
  goBack(): void;
  users: any[];

}


export default class GroupInfo extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {
      dnd: false,
    }
    
  }
  // static getDerivedStateFromProps(nextProps: Props, prevState: State){
  
  //   return null;
  // }

  render(){
    // this.props.users
		console.log('TCL: GroupInfo -> render -> this.props.users', this.props.users)
    return <div className="main-bg fullscreen" styleName="group-info">
        <NavBar icon={<Icon type="left" />} onLeftClick={() => this.props.goBack()}>
          群聊信息
        </NavBar>
        <div styleName="header">成员</div>
        <div styleName="user-list">
        {this.props.users.map(item => 
          <div styleName="user-item">
            <img src={item.avatar} styleName="avatar"></img>
            <span styleName="nickname">{item.nickname}</span>
          </div>
        )}
          
          {/* <div styleName="user-item">
            <img src="http://cdn.duitang.com/uploads/item/201410/08/20141008150015_dP8yJ.thumb.700_0.jpeg" styleName="avatar"></img>
            <span styleName="nickname">薛宝钗</span>
          </div> */}
          <div styleName="user-item">
            <span styleName="plus">
            </span>
            <span styleName="nickname"></span>
          </div>
        </div>
        <WhiteSpace size="sm" />
        <List.Item
          extra={<Switch
            checked={this.state.dnd}
            color="#F9B5D6"
            onChange={() => {
              this.setState({
                dnd: !this.state.dnd,
              });
            }}
          />}
      >消息免打扰</List.Item>
        <div styleName="exit-btn">退出</div>
      </div>;
  }
}