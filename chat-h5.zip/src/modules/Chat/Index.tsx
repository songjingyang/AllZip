import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';

import {
  NavBar,
  Popover,
} from 'antd-mobile';

import './Index.less';
import { inject, observer } from 'mobx-react';
import Chat from '../../models/Chat'
import { observable } from 'mobx';

const Item = Popover.Item;

interface Props {
  chat: Chat

}

interface State {
  isShowPopover: boolean;
}

@inject('chat')
@observer
export default class Index extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    this.state = {
      isShowPopover: false,
    };
  }
  state: State

  componentDidMount() {
    this.props.chat.getChatSession({data: {}})
  }

  render() {
    const win: any = window;
    // this.props.chat.chatSession
		console.log('TCL: Index -> render -> this.props.chat.chatSession', this.props.chat.chatSession)
    const rightContent = <div>
      <Popover  
          overlay={[
            <Link key="1" to="/concat/groupchat"><Item icon={<i className="create-chat" ></i>}>发起群聊</Item></Link>,
            <Link key="2" to="/concat/addfriends"><Item icon={<i className="create-person" ></i>}>添加朋友</Item></Link>,
          ]}
          visible={this.state.isShowPopover}
          align={{ overflow: { adjustY: 0, adjustX: 0 }}}>
        <img className="plus" src={require('../../assets/images/plus.svg')} />
      </Popover>
    </div>
    return <div className="chat-module">
      <NavBar rightContent={rightContent}>聊天</NavBar>
      {/* <Link to="/chat/chatroom">进入聊天室</Link> */}
      <div className="user-list">
        {this.props.chat.chatSession.map(item => (
          <Link
            key={item.uid}
            to={`/chat/chatroom/${item.uid}/${item.ope}/${item.title || 0}/${win.encodeURIComponent(item.avatar) || 0}`}
            className="user-item"
          >
            <div className="avatar">
              <img src={item.avatar} alt="头像" />
            </div>
            <div className="info">{item.title}</div>
            <div className="time">{item.ope}</div>
          </Link>
        ))}

        {/* <div className="user-item">
          <div className="avatar">
            <img src="http://cdn.duitang.com/uploads/item/201410/08/20141008150015_dP8yJ.thumb.700_0.jpeg" alt="" />
          </div>
          <div className="info">今天就开始尬聊吧</div>
          <div className="time">刚刚</div>
        </div>
        <div className="user-item">
          <div className="avatar">
            <img src="http://cdn.duitang.com/uploads/item/201410/08/20141008150015_dP8yJ.thumb.700_0.jpeg" alt="" />
          </div>
          <div className="info">今天就开始尬聊吧</div>
          <div className="time">刚刚</div>
        </div> */}
      </div>
    </div>
  }
}

