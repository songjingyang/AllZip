const urlMaps: { [key: string]: string } = {
  login: '/api/app/v1/user/generate',
  logout: '/api/player/logout/',
  register: '/api/app/v1/user/generate',
  //聊天
  getChatSession: '/api/app/v1/chat/sessions',

  upload: '/api/upload/images',

  // 通讯录
  getConcat: '/api/app/v1/user/members',
  searchfriends: '/api/app/v1/user/members/query',
  addfriends: '/api/app/v1/user/members/add',
  removefriends: '/api/app/v1/user/members/remove',
  acceptapply: '/api/app/v1/user/members/accept',
  rejectapply: '/api/app/v1/user/members/reject',
  getPersonalInfo: '/api/app/v1/user/members/info',
  setremark: '/api/app/v1/user/bkname',
  setlabel: '',

  //群聊
  getGroupList: '/api/app/v1/group/list',
  getGroupMemberList: '/api/app/v1/group/member/list',
  createGroup: '/api/app/v1/group/create',
  inviteGroupMember: '/api/app/v1/group/invite',
  addGroupMember: '/api/app/v1/group/member/add',
  delGroupMember: '/api/app/v1/group/member/rm',

  //我的
  getMyInfo: '/api/app/v1/user/mine/info',
  saveUpdateInfo: '/api/app/v1/user/mine/up',
};
  
// export const baseUrl = 'http://share.axingxing.com/proxy'
export const baseUrl = '';

// export const loginWhiteList = [urlMaps.getUserInfo, urlMaps.getBannerList];

export default urlMaps;
