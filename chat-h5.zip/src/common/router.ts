import React from 'react';

import Home from '../modules/Home/Home';
import ChatRoom from '../modules/Chat/ChatRoom';

// 通讯录
import NewFriends from '../modules/Concat/NewFriends';
import GroupChat from '../modules/Concat/GroupChat';
import AddFriends from '../modules/Concat/AddFriends';
import PersonalInfo from '../modules/Concat/PersonalInfo';
import SetRemark from '../modules/Concat/SetRemark';
import SetLabel from '../modules/Concat/SetLabel';


import GroupMembers from '../modules/Concat/GroupMembers';

// 用户
import Login from '../modules/User/Login';
import Register from '../modules/User/Register';
//我的
import UploadQrCode from '../modules/My/UploadQrCode'
import UploadHeadImg from '../modules/My/UploadHeadImg';
import UpdateNickName from '../modules/My/UpdateNickName';

const routerData = [
  {
    path: '/home/:home',
    component: Home,
    meta: {
      title: '首页',
    },
  },
  {
    path: '/user/login',
    component: Login,
    meta: {
      title: '登录',
    },
  },
  {
    path: '/user/register',
    component: Register,
    meta: {
      title: '注册',
    },
  },
  
  {
    path: '/chat/chatroom/:uid/:type/:name/:avatar',
    component: ChatRoom,
    meta: {
      title: '聊天室',
    },
  },
  {
    path: '/chat/chatroom',
    component: ChatRoom,
    meta: {
      title: '聊天室',
    },
  },
  {
    path: '/concat/newfriends',
    component: NewFriends,
    meta: {
      title: '新朋友',
    },
  },
  {
    path: '/concat/groupchat',
    component: GroupChat,
    meta: {
      title: '群聊',
    },
  },
  {
    path: '/concat/groupMembers/:groupId',
    component: GroupMembers,
    meta: {
      title: '群成员',
    },
  },
  {
    path: '/concat/groupMembers',
    component: GroupMembers,
    meta: {
      title: '群成员',
    },
  },
  {
    path: '/concat/addfriends',
    component: AddFriends,
    meta: {
      title: '添加朋友',
    },
  },
  {
    path: '/concat/personalinfo/:uid',
    component: PersonalInfo,
    meta: {
      title: '个人信息',
    },
  },
  // {
  //   path: '/concat/personalinfo',
  //   component: PersonalInfo,
  //   meta: {
  //     title: '个人信息',
  //   },
  // },
  {
    path: '/concat/setremark/:uid',
    component: SetRemark,
    meta: {
      title: '设置备注和标签',
    },
  },
  {
    path: '/concat/setlabel/:uid',
    component: SetLabel,
    meta: {
      title: '设置标签',
    },
  },
  {
    path: '/my/qrcode',
    component: UploadQrCode,
    meta: {
      title: '二维码',
    },
  },
  {
    path: '/my/headimg',
    component: UploadHeadImg,
    meta: {
      title: '头像',
    },
  },
  {
    path: '/my/nickname',
    component: UpdateNickName,
    meta: {
      title: '昵称',
    },
  },
];

export function getRouterData() {
  return routerData;
}

export default getRouterData;
