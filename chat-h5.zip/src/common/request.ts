import { Toast } from 'antd-mobile';
import axios from 'axios';
import { generatePath } from 'react-router-dom'
import urlMaps, { baseUrl } from './urlMaps';
import { getQueryString } from '../utils/utils';

export {urlMaps}

export interface ReqData {
  data?: any;
  callback?(res: any): void;
}

export interface ResData {
  code: string;
  msg: string;
  err_msg: string;
  ts: string;
  data: any;
}


declare global {
  interface Window {
    timeDiff: number;
  }
}


/**
 * Requests a URL, returning a promise.
 *
 * @param  {string} url       The URL we want to request
 * @param  {object} [options] The options we want to pass to "fetch"
 * @return {object}           An object containing either "data" or "err"
 */
export default async function request(url: string, data: any, options: any = { method: 'GET' }) {

    options.originUrl = url;
    url = baseUrl + url;
    data = data || {};

    // const newOptions = { ...options, data: data };
  // const options = {
  //   // credentials: 'include'
  // };

  let newOptions = { ...options, data: data };
  let user = JSON.parse(window.localStorage.getItem('user') as string) || {};
  newOptions.headers = newOptions.headers || {};
  if (user) {
    newOptions.headers.uid = user.id;
    newOptions.headers.sign = '123456';
  }
  // 所有接口都传merchant_id
  // // MerchantId: 5c1357779dc6d62d43074e1b
  // newOptions.data.merchant_id = getQueryString('merchant_id');
  // newOptions.data.servant_id = getQueryString('kefu');
  // newOptions.headers.MerchantId = newOptions.data.merchant_id;


  if (
    newOptions.method === 'POST' ||
    newOptions.method === 'PUT' ||
    newOptions.method === 'DELETE'
  ) {
    if (!(newOptions.data instanceof FormData)) {
      newOptions.headers = {
        Accept: 'application/json',
        'Content-Type': 'application/json; charset=utf-8',
        ...newOptions.headers,
      };
      newOptions.data = JSON.stringify(newOptions.data);
    } else {
      // newOptions.data is FormData
      newOptions.headers = {
        Accept: 'application/json',
        ...newOptions.headers,
      };
    }
  } else if (newOptions.method === 'GET') {
    newOptions.params = newOptions.data;
    newOptions.headers = {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      ...newOptions.headers,
    };
  }
  newOptions.url = newOptions.url || url;

  return axios(newOptions)
    .then(
      response => {
        // const { dispatch } = store;
        // if (newOptions.method === 'DELETE' || response.status === 204) {
        //   return response.text()
        // }
        if (!('code' in response.data)) {
          return {
            code: 1,
            msg: '',
            data: response,
          };
        }
        if(response.data.ts){
          window.timeDiff = new Date().getTime() - response.data.ts * 1000;
        }

        return response.data;
      },
      res => {
        const response = res.response;
				console.log('TCL: request -> response', response)

        if (response && response.data) {
          if (response.data.code === '-800') {
            window.location.href = generatePath('/user/login')
          }else if (response.data.code !== '1') {
            Toast.fail(response.data.msg, 1);
          } 
        }
        return response;
      }
    )
}
