import { Toast } from 'antd-mobile';
import meq from 'meq2';
import store from '../models/index';
import { ChatSessionItem } from '../models/Chat';

export function getQueryString(name: string, url = ''): string | null {
  url = url || window.location.search;
  var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
  var r = url.substr(1).match(reg);
  if (r != null) {
    return unescape(r[2]);
  }
  return null;
}
export function validErrorTip(error:any) {
  const keys = Object.keys(error)
  Toast.fail(error[keys[0]].errors[0].message,1)
}

export function connect(id: string, appId: string){
  const topic = `/${appId}/11/p2p/${id}`;
	console.log('TCL: connect -> topic', topic)
  // const topic = `/1234567890/22/p2p/1095960538254417920`;
  const m = meq.connect({
    // host: "192.168.2.203",
    // host: '223.203.221.89',
    host: '192.168.2.206',
    port: 9008,
    username: id,
  });

  m.subscribe(topic, () => {
       
  });

  
  // callback(this.m)
  m.on('message', (msg: any) => {
    const payload = JSON.parse(msg.payload);
    console.log('TCL: connect -> payload', payload)
    if (
      !store.chat.chatSession.find(item => item.uid === payload.sender)
    ) {
      store.user.getUser({
        data: {
          id: id,
        },
        callback: res => {
          if (res.code === '1') {
            const resData = res.data;
            const user: ChatSessionItem = {
              avatar: resData.avatar,
              ope: resData.ope,
              title: resData.nickname,
              uid: id,
            };
            store.chat.chatSession.push(user);
          }
        },
      });
    } 
  });
    
  return m;
}

export function saveCache(key: string, json: any){
  localStorage.setItem(key, JSON.stringify(json));
}

export function getCache(key: string): any{
  const value: string | null = localStorage.getItem(key);
  if(value){
    try {
      return JSON.parse(value)
    } catch (error) {
        console.error(error)
        return value;
    }
  }
  return null;
}


/* eslint no-useless-escape:0 */
// const reg = /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+(?::\d+)?|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/;

// export function isUrl(path) {
//   return reg.test(path);
// }
