import React, { Component } from 'react';
import { Provider } from 'mobx-react'
import DevTools from 'mobx-react-devtools';
import './App.css';
import {Button} from 'antd-mobile'
import Hello from './components/Hello'
import store from './models/index'
import meq from 'meq2';

import { BrowserRouter as Router, Route, Link, Switch, Redirect} from 'react-router-dom';
import getRouterData from './common/router';
import UserLogin from './modules/User/Login'
import { UserInfo, usersMap } from './models/User';
import { connect, getCache } from './utils/utils';
import { ChatSessionItem } from './models/Chat';

const Index = () => <h2>Home</h2>;
const About = () => <h2>About</h2>;
const NoMatch = () => <h2>NoMatch</h2>;

const routerData = getRouterData();

const userStr = localStorage.getItem('user');
if (userStr){
  try{
    const user: UserInfo = getCache('user') || {};
    const usersMap: usersMap = getCache('usersMap') || {};
    const chatSession: ChatSessionItem[] = getCache('chatSession') || [];
    store.user.userInfo = user;
    store.user.usersMap = usersMap;
    store.chat.chatSession = chatSession;

    if(user.id){
      const appId = '1234567890';
      const id = user.id;
      // const topic = `sub/${appId}/11/p2p/${id}`;
      store.chat.connect(user.id, store.user.appid );
      // connect(user.id, '1901010001')
    }
  }catch(e){
    console.error(e)
  }
}

class App extends Component {

  render() {
    return <div>
        <Provider {...store}>
          <Router>
            <Switch>
              {routerData.map(item => (
                <Route key={item.path} path={item.path} component={item.component} />
              ))}
              {/* <Route exact component={NoMatch} /> */}
              {/* <Route path="/user/login" component={UserLogin} /> */}
              <Redirect to={{ pathname: '/home/home' }} />
            </Switch>
          </Router>
        </Provider>
        <DevTools></DevTools>
      </div>;
  }
}



export default App;
