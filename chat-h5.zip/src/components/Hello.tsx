import React from 'react'
import {observer} from 'mobx-react'


export interface Props {
  name: string;
  enthusiasmLevel?: number;
  todoList: any;
}

export interface State {
  addr: string
}

@observer
class Hello extends React.Component<Props, State> {
 
 state: State = {
   addr: '北京市'
 }
 
  render() {
    const { name, enthusiasmLevel = 1, todoList } = this.props;
		console.log('​Hello -> render -> todoList', todoList.todos.length)

    if (enthusiasmLevel <= 0) {
      throw new Error('不能小于等于0');
    }

    return <div className="hellow">
        Hello {name + getExclamationMarks(enthusiasmLevel)}
        todoList: {todoList.todos.length}
        <button onClick={() => this.props.todoList.push()}>添加</button>
      </div>;
  }
}

export default Hello

function getExclamationMarks(numChars: number) {
  return Array(numChars + 1).join('!');
}