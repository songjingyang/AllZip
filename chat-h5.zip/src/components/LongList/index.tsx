
import React, { Fragment } from 'react';
import { province } from './data';
import { StickyContainer, Sticky } from 'react-sticky';
import { ListView, List, SearchBar, SwipeAction } from 'antd-mobile';

import './index.less'
import { Link } from 'react-router-dom';
import { History } from 'history'

const { Item } = List;

interface Props {
  // history: History
  onClose?: any,
  onChangeValue?: any,
  concatData?: any
}

interface State {
  renderSectionWrapper?: (
    sectionId: string | number
  ) => React.ReactElement<any>,
  inputValue: string,
  dataSource: any,
  isLoading: boolean
}

export default class LongList extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    const getSectionData = (dataBlob: any, sectionID: string | number) => dataBlob[sectionID];
    const getRowData = (dataBlob: any, sectionID: string | number, rowID: string | number) => dataBlob[rowID];

    const dataSource = new ListView.DataSource({
      getRowData,
      getSectionHeaderData: getSectionData,
      rowHasChanged: (row1: string, row2: string) => row1 !== row2,
      sectionHeaderHasChanged: (s1: string, s2: string) => s1 !== s2,
    });
    this.state = {
      inputValue: '',
      dataSource,
      isLoading: true,
    };
  }
  componentDidMount() {
    setTimeout(() => {
      this.setState({
        dataSource: this.genData(this.state.dataSource, province),
        isLoading: false,
      });
    }, 600)
  }
  genData = (ds: any, provinceData: any) => {
    const dataBlob: any = {};
    const sectionIDs: any = [];
    const rowIDs: any = [];
    Object.keys(provinceData).forEach((item, index) => {
      sectionIDs.push(item);
      dataBlob[item] = item;
      rowIDs[index] = [];
      provinceData[item].forEach((jj: any) => {
        rowIDs[index].push(jj.value);
        dataBlob[jj.value] = jj.label;
      });
    });
    return ds.cloneWithRowsAndSections(dataBlob, sectionIDs, rowIDs);
  }
  onSearch = (val: string) => {
    const pd: any = { ...province };
    Object.keys(pd).forEach((item) => {
      const arr = pd[item].filter((jj: any) => jj.spell.toLocaleLowerCase().indexOf(val) > -1);
      if (!arr.length) {
        delete pd[item];
      } else {
        pd[item] = arr;
      }
    });
    this.setState({
      inputValue: val,
      dataSource: this.genData(this.state.dataSource, pd),
    });
  }
  onChangeValue = (rowID: string | number) => {
    this.props.onClose()
    this.props.onChangeValue(rowID)
  }
  render() {
    const concatItem = this.props.concatData
    const uid = '1089798617117499392'
    return (<div className='longlist-module' style={{ paddingTop: '88px', position: 'relative' }}>
      <div 
      style={{ position: 'absolute', top: 0, left: 0, right: 0 }}
      >
        <SearchBar
          value={this.state.inputValue}
          placeholder="搜索"
          onChange={this.onSearch}
          onClear={() => { console.log('onClear'); }}
          onCancel={() => { console.log('onCancel'); }}
        />
      </div>
      <ListView.IndexedList
        dataSource={this.state.dataSource}
        className="am-list sticky-list"
        useBodyScroll
        renderSectionWrapper={(sectionID) => {
          // console.log('sectionID', sectionID)
          return (
            <StickyContainer
              key={`s_${sectionID}_c`}
              className="sticky-container"
              style={{ zIndex: 4 }}
            />
          )
        }}
        renderSectionHeader={(sectionData: string | number) => (
          <Sticky>
            {({ style }) => {
              // console.log('style', style)
              return (
                <div
                  className="sticky"
                  style={{
                    ...style,
                    zIndex: 3,
                    backgroundColor: '#F9F9F9',
                    color: '#ccc',
                    padding: '7px 15px'
                  }}
                >{sectionData}</div>
              )
            }}
          </Sticky>
        )}
        renderHeader={() => (
          <div styleName="cate">
            <Link styleName="cate-item" to={{pathname: '/concat/newfriends'}}>新朋友</Link>
            <Link styleName="cate-item" to={{pathname: '/concat/groupchat'}}>群聊</Link>
            <Link styleName="cate-item" to={{pathname: '/concat/addfriends'}}>添加好友</Link>
          </div>
        )}
        // renderFooter={() => <div style={{textAlign: "center"}}>{155}位联系人</div>}
        renderRow={(rowData: any, sectionID: string | number, rowID: string | number) => (
          // <Link to={{pathname: `/concat/personalinfo/${concatItem.id}`}} styleName="list-item" onClick={() => this.onChangeValue(rowID)}>
          <SwipeAction
            right={[
              {
                text: '备注',
                onPress: () => console.log('remark'),
                style: { width: '120px', backgroundColor: '#ddd', color: 'white' },
              },
            ]}
          >
            <Link to={{pathname: `/concat/personalinfo/${uid}`}} styleName="list-item" onClick={() => this.onChangeValue(rowID)}>
              <div styleName="avatar">
                <img src="https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1548741312&di=f14ded4ba16ffcf3079c68a848829179&src=http://b-ssl.duitang.com/uploads/item/201507/02/20150702193124_zrLFJ.jpeg" alt=""/>
              </div>
              <span styleName="info">{rowData}</span>
            </Link>
          </SwipeAction>
        )}
        quickSearchBarStyle={{
          top: 350,
        }}

        delayTime={10}
        delayActivityIndicator={<div style={{ padding: 25, textAlign: 'center' }}>rendering...</div>}
        scrollRenderAheadDistance={500}
      />
    </div>);
  }
}