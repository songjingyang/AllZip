
const province =[
    {
      label: '阿尔巴尼亚',
      value: '+355',
      spell: 'aerbaniya'
    },
    {
      label: '阿尔及利亚',
      value: '+213',
      spell: 'aerjiliya'
    },
    {
      label: '阿富汗',
      value: '+93',
      spell: 'afuhan'
    },
    {
      label: '阿根廷',
      value: '+54',
      spell: 'agenting'
    },
    {
      label: '爱尔兰',
      value: '+353',
      spell: 'aierlan'
    },
    {
      label: '埃及',
      value: '+20',
      spell: 'aiji'
    },
    {
      label: '埃塞俄比亚',
      value: '+251',
      spell: 'aisaiebiya'
    },
    {
      label: '爱沙尼亚',
      value: '+372',
      spell: 'Estonia'
    },
    {
      label: '阿拉伯联合酋长国',
      value: '+971',
      spell: 'alabolianheqiuzhangguo'
    },
    {
      label: '阿鲁巴',
      value: '+297',
      spell: 'aluba'
    },
    {
      label: '阿曼',
      value: '+968',
      spell: 'aman'
    },
    {
      label: '安道尔',
      value: '+376',
      spell: 'andaoer'
    },
    {
      label: '安哥拉',
      value: '+244',
      spell: 'angela'
    },
    {
      label: '安圭拉',
      value: '+1264',
      spell: 'anguila'
    },
    {
      label: '安提瓜和巴布达',
      value: '+1268',
      spell: 'atiguahebabuda'
    },
    {
      label: '澳大利亚',
      value: '+61',
      spell: 'aodaliya'
    },
    {
      label: '奥地利',
      value: '+43',
      spell: 'aodili'
    },
    {
      label: '奥兰群岛',
      value: '+358',
      spell: 'aolanqundao'
    },
    {
      label: '澳门（中国)',
      value: '+853',
      spell: 'aomen'
    },
    {
      label: '阿塞拜疆',
      value: '+994',
      spell: 'asaibaijiang'
    },
    {
      label: '阿森松岛',
      value: '+247',
      spell: 'asensongdao'
    },
    {
      label: '巴巴多斯',
      value: '+1246',
      spell: 'babaduosi'
    },
    {
      label: '巴布亚新几内亚',
      value: '+675',
      spell: 'babuyaxinjineiya'
    },
    {
      label: '巴哈马',
      value: '+1242',
      spell: 'bahama'
    },
    {
      label: '白俄罗斯',
      value: '+375',
      spell: 'baieluosi'
    },
    {
      label: '百慕大',
      value: '+1441',
      spell: 'baimuda'
    },
    {
      label: '巴基斯坦',
      value: '+92',
      spell: 'bajisitan'
    },
    {
      label: '巴拉圭',
      value: '+595',
      spell: 'balagui'
    },
    {
      label: '巴勒斯坦领土',
      value: '+970',
      spell: 'balesitanlingtu'
    },
    {
      label: '巴林',
      value: '+973',
      spell: 'balin'
    },
    {
      label: '巴拿马',
      value: '+507',
      spell: 'banama'
    },
    {
      label: '保加利亚',
      value: '+359',
      spell: 'baojialiya'
    },
    {
      label: '巴西',
      value: '+55',
      spell: 'baxi'
    },
    {
      label: '北马里亚纳群岛',
      value: '+1670',
      spell: 'beimaliyanaqundao'
    },
    {
      label: '贝宁',
      value: '+229',
      spell: 'beining'
    },
    {
      label: '比利时',
      value: '+32',
      spell: 'bilishi'
    },
    {
      label: '冰岛',
      value: '+354',
      spell: 'bingdao'
    },
    {
      label: '博茨瓦纳',
      value: '+267',
      spell: 'bociwana'
    },
    {
      label: '波多黎各',
      value: '+1787',
      spell: 'boduolige'
    },
    {
      label: '波多黎各',
      value: '+1939',
      spell: 'boduolige'
    },
    {
      label: '波兰',
      value: '+48',
      spell: 'bolan'
    },
    {
      label: '玻利维亚',
      value: '+591',
      spell: 'boliweiya'
    },
    {
      label: '伯利兹',
      value: '+501',
      spell: 'bolizi'
    },
    {
      label: '波斯尼亚和黑塞哥维那',
      value: '+387',
      spell: 'bosiniyaheheisaigeweina'
    },
    {
      label: '不丹',
      value: '+975',
      spell: 'budan'
    },
    {
      label: '布基拉法索',
      value: '+226',
      spell: 'bujilafasuo'
    },
    {
      label: '布隆迪',
      value: '+257',
      spell: 'bulongdi'
    },
    {
      label: '朝鲜',
      value: '+850',
      spell: 'chaoxian'
    },
    {
      label: '赤道几内亚',
      value: '+240',
      spell: 'chidaojineiya'
    },
    {
      label: '丹麦',
      value: '+45',
      spell: 'danmai'
    },
    {
      label: '德国',
      value: '+49',
      spell: 'deguo'
    },
    {
      label: '东帝汶',
      value: '+670',
      spell: 'dongdiwen'
    },
    {
      label: '多哥',
      value: '+228',
      spell: 'duoge'
    },
    {
      label: '多米尼加共和国',
      value: '+1809',
      spell: 'duominijiagongheguo'
    },
    {
      label: '多米尼加共和国',
      value: '+1829',
      spell: 'duominijiagongheguo'
    },
    {
      label: '多米尼加共和国',
      value: '+1849',
      spell: 'duominijiagongheguo'
    },
    {
      label: '多米尼克',
      value: '+1767',
      spell: 'duominike'
    },
    {
      label: '厄瓜多尔',
      value: '+593',
      spell: 'eguaduoer'
    },
    {
      label: '厄立特里亚',
      value: '+291',
      spell: 'eliteliya'
    },
    {
      label: '俄罗斯',
      value: '+7',
      spell: 'eluosi'
    },
    {
      label: '法国',
      value: '+33',
      spell: 'faguo'
    },
    {
      label: '法罗群岛',
      value: '+298',
      spell: 'faluoqundao'
    },
    {
      label: '法属波利尼西亚',
      value: '+689',
      spell: 'fashubolinixiya'
    },
    {
      label: '法属圭亚那',
      value: '+594',
      spell: 'fashuguinina'
    },
    {
      label: '斐济',
      value: '+679',
      spell: 'feiji'
    },
    {
      label: '梵蒂冈',
      value: '+379',
      spell: 'fandigang'
    },
    {
      label: '菲律宾',
      value: '+63',
      spell: 'feilvbing'
    },
    {
      label: '芬兰',
      value: '+358',
      spell: 'fenlan'
    },
    {
      label: '佛得角',
      value: '+238',
      spell: 'fodejiao'
    },
    {
      label: '福克兰群岛',
      value: '+500',
      spell: 'fukelanqundao'
    },
    {
      label: '冈比亚',
      value: '+220',
      spell: 'gangbiya'
    },
    {
      label: '刚果（布）',
      value: '+242',
      spell: 'gangguo(bu)'
    },
    {
      label: '刚果（金）',
      value: '+243',
      spell: 'gangguo(jin)'
    },
    {
      label: '格陵兰',
      value: '+299',
      spell: 'gelanling'
    },
    {
      label: '格林纳达',
      value: '+1473',
      spell: 'gelinnada'
    },
    {
      label: '格鲁吉亚',
      value: '+995',
      spell: 'gelujiya'
    },
    {
      label: '哥伦比亚',
      value: '+57',
      spell: 'gelunbiya'
    },
    {
      label: '根西岛',
      value: '+44',
      spell: 'genxidao'
    },
    {
      label: '哥斯达黎加',
      value: '+506',
      spell: 'gesidalijia'
    },
    {
      label: '瓜德罗普',
      value: '+590',
      spell: 'guadeluopu'
    },
    {
      label: '关岛',
      value: '+1671',
      spell: 'guandao'
    },
    {
      label: '古巴',
      value: '+53',
      spell: 'guba'
    },
    {
      label: '圭亚那',
      value: '+592',
      spell: 'guiyana'
    },
    {
      label: '海地',
      value: '+509',
      spell: 'haidi'
    },
    {
      label: '韩国',
      value: '+82',
      spell: 'hanguo'
    },
    {
      label: '哈萨克斯坦',
      value: '+7',
      spell: 'hasakesitan'
    },
    {
      label: '黑山',
      value: '+382',
      spell: 'heishan'
    },
    {
      label: '荷兰',
      value: '+31',
      spell: 'helan'
    },
    {
      label: '荷属安的列斯',
      value: '+599',
      spell: 'heshuandeliesi'
    },
    {
      label: '荷属圣马丁',
      value: '+1721',
      spell: 'heshushengmading'
    },
    {
      label: '洪都拉斯',
      value: '+504',
      spell: 'hongdulasi'
    },
    {
      label: '加纳',
      value: '+233',
      spell: 'jiana'
    },
    {
      label: '加拿大',
      value: '+1',
      spell: 'jianada'
    },
    {
      label: '柬埔寨',
      value: '+855',
      spell: 'jianpuzhai'
    },
    {
      label: '加蓬',
      value: '+241',
      spell: 'jiapeng'
    },
    {
      label: '吉布提',
      value: '+253',
      spell: 'jibuti'
    },
    {
      label: '捷克共和国',
      value: '+420',
      spell: 'jiekegongheguo'
    },
    {
      label: '吉尔吉斯斯坦',
      value: '+996',
      spell: 'jierjisisitan'
    },
    {
      label: '基里巴斯',
      value: '+686',
      spell: 'jilibasi'
    },
    {
      label: '津巴布韦',
      value: '+263',
      spell: 'jinbabuwei'
    },
    {
      label: '几内亚',
      value: '+224',
      spell: 'jineiya'
    },
    {
      label: '几内亚比绍',
      value: '+245',
      spell: 'jineiyabishao'
    },
    {
      label: '开曼群岛',
      value: '+1345',
      spell: 'kaimanqundao'
    },
    {
      label: '喀麦隆',
      value: '+237',
      spell: 'kamailong'
    },
    {
      label: '卡塔尔',
      value: '+974',
      spell: 'kataer'
    },
    {
      label: '科科斯（基林）群岛',
      value: '+61',
      spell: 'kekesi(jilin)qundao'
    },
    {
      label: '克罗地亚',
      value: '+385',
      spell: 'keluodiya'
    },
    {
      label: '科摩罗',
      value: '+269',
      spell: 'kemoluo'
    },
    {
      label: '肯尼亚',
      value: '+254',
      spell: 'kenniya'
    },
    {
      label: '科特迪瓦',
      value: '+225',
      spell: 'ketediwa'
    },
    {
      label: '科威特',
      value: '+965',
      spell: 'keweite'
    },
    {
      label: '库克群岛',
      value: '+682',
      spell: 'kukequndao'
    },
    {
      label: '库拉索',
      value: '+599',
      spell: 'kulasuo'
    },
    {
      label: '莱索托',
      value: '+266',
      spell: 'laisuotuo'
    },
    {
      label: '老挝',
      value: '+856',
      spell: 'laowo'
    },
    {
      label: '拉脱维亚',
      value: '+371',
      spell: 'latuoweiya'
    },
    {
      label: '黎巴嫩',
      value: '+961',
      spell: 'libanen'
    },
    {
      label: '利比里亚',
      value: '+231',
      spell: 'kebiliya'
    },
    {
      label: '利比亚',
      value: '+218',
      spell: 'libiya'
    },
    {
      label: '列支敦士登',
      value: '+423',
      spell: 'liezhidunshideng'
    },
    {
      label: '立陶宛',
      value: '+370',
      spell: 'litaowan'
    },
    {
      label: '留尼汪',
      value: '+262',
      spell: 'liuniwang'
    },
    {
      label: '罗马尼亚',
      value: '+40',
      spell: 'luomaniya'
    },
    {
      label: '卢森堡',
      value: '+352',
      spell: 'lusenbao'
    },
    {
      label: '卢旺达',
      value: '+250',
      spell: 'luwangda'
    },
    {
      label: '马达加斯加',
      value: '+261',
      spell: 'madajisijia'
    },
    {
      label: '马尔代夫',
      value: '+960',
      spell: 'maerdaifu'
    },
    {
      label: '马耳他',
      value: '+356',
      spell: 'maerta'
    },
    {
      label: '马来西亚',
      value: '+60',
      spell: 'malaxiya'
    },
    {
      label: '马拉维',
      value: '+265',
      spell: 'malawei'
    },
    {
      label: '马里',
      value: '+223',
      spell: 'mali'
    },
    {
      label: '曼岛',
      value: '+44',
      spell: 'mandao'
    },
    {
      label: '毛里求斯',
      value: '+230',
      spell: 'maoliqiusi'
    },
    {
      label: '毛里塔尼亚',
      value: '+222',
      spell: 'maolitaniya'
    },
    {
      label: '马其顿',
      value: '+389',
      spell: 'maqidun'
    },
    {
      label: '马绍尔群岛',
      value: '+692',
      spell: 'mashaoerqundao'
    },
    {
      label: '马提尼克',
      value: '+596',
      spell: 'matinike'
    },
    {
      label: '马约特',
      value: '+262',
      spell: 'mayuete'
    },
    {
      label: '美国',
      value: '+1',
      spell: 'meiguo'
    },
    {
      label: '美属萨摩亚',
      value: '+1684',
      spell: 'meishusamoya'
    },
    {
      label: '美属维京群岛',
      value: '+1340',
      spell: 'meishuweijingqundao'
    },
    {
      label: '蒙古',
      value: '+976',
      spell: 'menggu'
    },
    {
      label: '孟加拉国',
      value: '+880',
      spell: 'mengjialaguo'
    },
    {
      label: '蒙特塞拉特',
      value: '+1664',
      spell: 'mengtesailate'
    },
    {
      label: '缅甸',
      value: '+95',
      spell: 'miandian'
    },
    {
      label: '密克罗尼西亚',
      value: '+691',
      spell: 'mikeluonixiya'
    },
    {
      label: '秘鲁',
      value: '+51',
      spell: 'milu'
    },
    {
      label: '摩尔多瓦',
      value: '+373',
      spell: 'moerduowa'
    },
    {
      label: '摩洛哥',
      value: '+212',
      spell: 'moluoge'
    },
    {
      label: '摩纳哥',
      value: '+377',
      spell: 'monage'
    },
    {
      label: '莫桑比克',
      value: '+258',
      spell: 'mosangbike'
    },
    {
      label: '墨西哥',
      value: '+52',
      spell: 'moxige'
    },
    {
      label: '纳米比亚',
      value: '+264',
      spell: 'namibiya'
    },
    {
      label: '南非',
      value: '+27',
      spell: 'nanfei'
    },
    {
      label: '南苏丹',
      value: '+211',
      spell: 'nansudan'
    },
    {
      label: '瑙鲁',
      value: '+674',
      spell: 'naolu'
    },
    {
      label: '尼泊尔',
      value: '+977',
      spell: 'niboer'
    },
    {
      label: '尼加拉瓜',
      value: '+505',
      spell: 'nijialagua'
    },
    {
      label: '尼日尔',
      value: '+227',
      spell: 'nirier'
    },
    {
      label: '尼日利亚',
      value: '+234',
      spell: 'niriliya'
    },
    {
      label: '纽埃',
      value: '+683',
      spell: 'niuai'
    },
    {
      label: '诺福克岛',
      value: '+672',
      spell: 'nuofukedao'
    },
    {
      label: '挪威',
      value: '+47',
      spell: 'nuowei'
    },
    {
      label: '帕劳',
      value: '+680',
      spell: 'palao'
    },
    {
      label: '葡萄牙',
      value: '+351',
      spell: 'putaoya'
    },
    {
      label: '日本',
      value: '+81',
      spell: 'riben'
    },
    {
      label: '瑞典',
      value: '+46',
      spell: 'ruidian'
    },
    {
      label: '瑞士',
      value: '+41',
      spell: 'ruishi'
    },
    {
      label: '萨尔瓦多',
      value: '+503',
      spell: 'saerwaduo'
    },
    {
      label: '塞尔维亚',
      value: '+381',
      spell: 'saierweiya'
    },
    {
      label: '塞拉利昂',
      value: '+232',
      spell: 'sailaliang'
    },
    {
      label: '塞内加尔',
      value: '+221',
      spell: 'saineijiaer'
    },
    {
      label: '塞浦路斯',
      value: '+357',
      spell: 'saipulusi'
    },
    {
      label: '塞舌尔',
      value: '+248',
      spell: 'saisheer'
    },
    {
      label: '萨摩亚',
      value: '+685',
      spell: 'samoya'
    },
    {
      label: '沙特阿拉伯',
      value: '+966',
      spell: 'shatealabo'
    },
    {
      label: '圣多美和普林西比',
      value: '+239',
      spell: 'shengduomeihepulinxibi'
    },
    {
      label: '圣巴泰勒米',
      value: '+590',
      spell: 'shengbatailemi'
    },
    {
      label: '圣马丁岛',
      value: '+590',
      spell: 'shengmadingdao'
    },
    {
      label: '圣诞岛',
      value: '+61',
      spell: 'shengdandao'
    },
    {
      label: '圣赫勒拿',
      value: '+290',
      spell: 'shenghelena'
    },
    {
      label: '圣基茨和尼维斯',
      value: '+1869',
      spell: 'shengjiciheniweisi'
    },
    {
      label: '圣卢西亚',
      value: '+1758',
      spell: 'shengluxiya'
    },
    {
      label: '圣马力诺',
      value: '+378',
      spell: 'shengmalinuo'
    },
    {
      label: '圣皮埃尔和密克隆群岛',
      value: '+508',
      spell: 'shengpiaierhemikelongqundao'
    },
    {
      label: '圣文森特和格林纳丁斯',
      value: '+1784',
      spell: 'shengwensentehegelinnadingsi'
    },
    {
      label: '斯里兰卡',
      value: '+94',
      spell: 'sililanka'
    },
    {
      label: '斯洛伐克',
      value: '+421',
      spell: 'siluofake'
    },
    {
      label: '斯洛文尼亚',
      value: '+386',
      spell: 'siluowenniya'
    },
    {
      label: '斯瓦尔巴特和扬马延',
      value: '+47',
      spell: 'siwaerbateheyangmayan'
    },
    {
      label: '斯威士兰',
      value: '+268',
      spell: 'siweishilan'
    },
    {
      label: '苏丹',
      value: '+249',
      spell: 'sudan'
    },
    {
      label: '苏里南',
      value: '+597',
      spell: 'sulinan'
    },
    {
      label: '所罗门群岛',
      value: '+677',
      spell: 'suoluomenqundao'
    },
    {
      label: '索马里',
      value: '+252',
      spell: 'suomali'
    },
    {
      label: '泰国',
      value: '+66',
      spell: 'taiguo'
    },
    {
      label: '台湾(中国)',
      value: '+886',
      spell: 'tanwan(zhongguo)'
    },
    {
      label: '塔吉克斯坦',
      value: '+992',
      spell: 'tajikesitan'
    },
    {
      label: '汤加',
      value: '+676',
      spell: 'tangjia'
    },
    {
      label: '坦桑尼亚',
      value: '+255',
      spell: 'tansangniya'
    },
    {
      label: '特克斯和凯科斯群岛',
      value: '+1649',
      spell: 'tekesihekaikesiqundao'
    },
    {
      label: '特立尼达和多巴哥',
      value: '+1868',
      spell: 'telinidaheduobage'
    },
    {
      label: '特里斯坦-达库尼亚群岛',
      value: '+290',
      spell: 'telisitan-dakunitaqundao'
    },
    {
      label: '土耳其',
      value: '+90',
      spell: 'tuerqi'
    },
    {
      label: '土库曼斯坦',
      value: '+993',
      spell: 'tukumansitan'
    },
    {
      label: '突尼斯',
      value: '+216',
      spell: 'tunisi'
    },
    {
      label: '托克劳',
      value: '+690',
      spell: 'tuokelao'
    },
    {
      label: '图瓦卢',
      value: '+688',
      spell: 'tuwalu'
    },
    {
      label: '瓦利斯和富图纳',
      value: '+681',
      spell: 'walisihefutuna'
    },
    {
      label: '瓦努阿图',
      value: '+678',
      spell: 'wanuatu'
    },
    {
      label: '危地马拉',
      value: '+502',
      spell: 'weidimala'
    },
    {
      label: '委内瑞拉',
      value: '+58',
      spell: 'weineiruila'
    },
    {
      label: '文莱',
      value: '+673',
      spell: 'wenlai'
    },
    {
      label: '乌干达',
      value: '+256',
      spell: 'wuganda'
    },
    {
      label: '乌克兰',
      value: '+380',
      spell: 'wukelan'
    },
    {
      label: '乌拉圭',
      value: '+598',
      spell: 'wulagui'
    },
    {
      label: '乌兹别克斯坦',
      value: '+998',
      spell: 'wuzibiekesitan'
    },
    {
      label: '香港（中国）',
      value: '+852',
      spell: 'xianggang(zhongguo)'
    },
    {
      label: '西班牙',
      value: '+34',
      spell: 'xibanya'
    },
    {
      label: '希腊',
      value: '+30',
      spell: 'xila'
    },
    {
      label: '新加坡',
      value: '+65',
      spell: 'xinjiapo'
    },
    {
      label: '新喀里多尼亚',
      value: '+687',
      spell: 'xinkaliduoniya'
    },
    {
      label: '新西兰',
      value: '+64',
      spell: 'xinxilan'
    },
    {
      label: '匈牙利',
      value: '+36',
      spell: 'xiongyali'
    },
    {
      label: '西撒哈拉',
      value: '+212',
      spell: 'xisahala'
    },
    {
      label: '叙利亚',
      value: '+963',
      spell: 'xuliya'
    },
    {
      label: '牙买加',
      value: '+1876',
      spell: 'yamaijia'
    },
    {
      label: '亚美尼亚',
      value: '+374',
      spell: 'yameiniya'
    },
    {
      label: '也门',
      value: '+967',
      spell: 'yemen'
    },
    {
      label: '意大利',
      value: '+39',
      spell: 'yidali'
    },
    {
      label: '伊拉克',
      value: '+964',
      spell: 'yilake'
    },
    {
      label: '伊朗',
      value: '+98',
      spell: 'yilang'
    },
    {
      label: '印度',
      value: '+91',
      spell: 'yindu'
    },
    {
      label: '印度尼西亚',
      value: '+62',
      spell: 'yindunixiya'
    },
    {
      label: '英国',
      value: '+44',
      spell: 'yingguo'
    },
    {
      label: '英属维京群岛',
      value: '+1284',
      spell: 'zhishuweijingqundao'
    },
    {
      label: '英属印度洋领地',
      value: '+246',
      spell: 'yingshuyinduyanglingdi'
    },
    {
      label: '以色列',
      value: '+972',
      spell: 'yiselie'
    },
    {
      label: '约旦',
      value: '+962',
      spell: 'yuedan'
    },
    {
      label: '越南',
      value: '+84',
      spell: 'yuenan'
    },
    {
      label: '赞比亚',
      value: '+260',
      spell: 'zanbiya'
    },
    {
      label: '泽西岛',
      value: '+44',
      spell: 'zexidao'
    },
    {
      label: '乍得',
      value: '+235',
      spell: 'zhade'
    },
    {
      label: '直布罗陀',
      value: '+350',
      spell: 'zhibuluotuo'
    },
    {
      label: '智利',
      value: '+56',
      spell: 'zhili'
    },
    {
      label: '中非共和国',
      value: '+236',
      spell: 'zhongfeigongheguo'
    },
    {
      label: '中国',
      value: '+86',
      spell: 'zhongguo'
    }
  ]
  
  export { province };
  