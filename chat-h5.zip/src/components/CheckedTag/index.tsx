import React from 'react'
import classnames from 'classnames'

import './index.less'

interface TagPropsType {
    disabled?: boolean,
    selected?: boolean,
    closable?: boolean,
    onChange?: (selected?: boolean, value?: string) => void,
    onClose?: () => void,
    className?: string,
    style?: React.CSSProperties
}

interface Props extends TagPropsType {
    data: any[]
}

interface State {
    tags: number[],
    selected: any
}
export default class CheckedTag extends React.Component <Props, State> {
    static defaultProps = {
        disabled: false,
        selected: false,
        closable: false,
        onChange() {},
        onClose() {},
        onClick() {}
    }
    constructor (props: Props) {
        super (props)
        this.state = {
            tags: [],
            selected: props.selected
        }
    }
    componentDidMount () {
        this.setState({
            tags: this.props.data
        })
    }
    componentWillReceiveProps (nextProps: Props) {
        if (nextProps.data) {
            this.setState({
                tags: nextProps.data.map((item: any) => {
                    return item
                })
            })
        }
        // if (this.props.selected !== nextProps.selected) {
        //     this.setState({
        //         selected: nextProps.selected
        //     })
        // }
    }
    onClick = (itemData: any, bool: any, index: string | number) => {
        const { onChange } = this.props
        let newTags = this.state.tags.map((item: any) => {
            if (item.value === itemData.value) {
                item.selected = !item.selected
            }
            return item
        })
        this.setState({
            tags: newTags
        }, () => {
            if (onChange) {
                onChange(itemData.selected, itemData)
            }
        })
    }
    render () {
        return (
            <span styleName='checked-tag'>
                {this.state.tags.map((item: any, index: string | number) => {
                    return (
                        <span
                            key={index}
                            onClick={(bool: any) => { this.onClick(item, bool, index)} }
                            styleName='checked-tag-item'
                            className={classnames({
                                'checked-tag-item': true,
                                active: item.selected
                            })}
                        >{item.label}</span>
                    )
                })}
            </span>
        )
    }
}