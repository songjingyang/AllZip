import { observable, action } from 'mobx';
import request, {urlMaps} from '../common/request'
class Char {
  @observable list: number[] = [1, 2, 3];
  @action push() {
    console.log('​TodoList -> @actionpush -> push', 3333);

    this.list.push(4);

    console.log('​TodoList -> @actionpush -> this.list', this.list);
  }

  @action
  async pushAsync() {
    await request(urlMaps.home, {});
    // await new Promise(resolve => {
    //   setTimeout(() => {
    //     this.list.push(5);
    //     this.list.push(6);
    //     this.list.push(7);
    //     resolve();
    //   }, 3000);
    // });
  }
}

export default Char;
