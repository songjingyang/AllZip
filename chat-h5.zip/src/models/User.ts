import { UserInfo } from './User';
import { observable, action} from 'mobx'
import request, { urlMaps, ResData, ReqData } from '../common/request';
import { saveCache } from '../utils/utils';
import { userInfo } from 'os';
export interface UserInfo{
  id: string;
  merchid: string;
  externalid: string;
  nickname: string;
  realname: string;
  sex: string;
  avatar: string;
  status: string;
}
export interface usersMap{
  [key: string]: UserInfo
} 
export class User{
  @observable
  appid: string = '1234567890'
  @observable
  usersMap: usersMap = {}
  @observable
  usersMapReqing: {[key: string]: boolean} = {}
  @observable
   userInfo: UserInfo = {
      id: '',
      merchid: '',
      externalid: '',
      nickname: '',
      realname: '',
      sex: '',
      avatar: '',
      status: '',
   }
  @action
  async login({ data, callback }: ReqData){
    const res: ResData = await request(urlMaps.login, data, {method: 'POST'})
    if(res.code === '1'){
      const user = res.data.player;
      this.userInfo = user;
      this.usersMap[user.id] = user;
      saveCache('user', user);
      saveCache('usersMap', this.usersMap)
    }
    if(callback){
      callback(res);
    }
  }
  @action async register({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.register, data, { method: 'POST' })

    if (res.code === '1') {
      // this.register_name = res.data
    }
    if (callback) {
      callback(res);
    }
  }

  @action
  async getUser({ data, callback }: ReqData) {
    this.usersMapReqing[data.uid] = true;
    const res: ResData = await request(urlMaps.getPersonalInfo, data);
    this.usersMapReqing[data.uid] = false;
    if (res.code === '1') {
      res.data.id = res.data.uid;
      const user: UserInfo = res.data
      this.usersMap[user.id] = user;
      saveCache('usersMap', this.usersMap)
    }
    if (callback) {
      callback(res);
    }
  }

  @action
  updateUser(updateUser: Partial<UserInfo>){
    this.userInfo = {
      ...this.userInfo,
      ...updateUser
    }
  }
  
}

export default User