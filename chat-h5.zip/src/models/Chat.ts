import { ChatSessionItem } from './Chat';
import { observable, action } from 'mobx';
import meq from 'meq2';
import request, {
  urlMaps, ReqData,
ResData} from '../common/request'
import { unionWith } from 'lodash';

import store from './index';
import { saveCache, getCache } from '../utils/utils';
import { UserInfo } from './User';

export interface ChatSessionItem{
  avatar: string;
  ope: string;
  title: string;
  uid: string;
}

export default class Chat {
  m: any;
  @observable list: number[] = [1, 2, 3];

  @observable
  chatSession: ChatSessionItem[] = [];

  @action
  async getChatSession({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.getChatSession, {});
    if (res.code === '1') {
      const serverChatSession: ChatSessionItem[] = res.data.sess;
      const chatSession: ChatSessionItem[] = getCache('chatSession') || []
      const newChatSession: ChatSessionItem[] = [];
      // chatSession && chatSession.forEach(item => {
      //   if(!serverChatSession.find(severItem => item.uid === severItem.uid)){
      //     newChatSession.push(item)
      //   }
      // })
			// console.log('TCL: Chat -> getChatSession -> newChatSession', newChatSession)
				console.log('TCL: Chat -> getChatSession -> newChatSession', serverChatSession)
				console.log('TCL: Chat -> getChatSession -> chatSession', chatSession)
      this.chatSession = unionWith(
        serverChatSession,
        chatSession,
        (preItem: ChatSessionItem, nextItem: ChatSessionItem) =>
          preItem.uid === nextItem.uid
      );
      saveCache('chatSession', this.chatSession);
    }
    if (callback) {
      callback(res);
    }
  }
  @action
  addChatSession(item: ChatSessionItem){
    const chatSession: ChatSessionItem[] = this.chatSession.filter(chatSessionItem => chatSessionItem.uid !== item.uid)
    chatSession.unshift(item);
    saveCache('chatSession', chatSession);
  }

  @action
  connect(id: string, appId: string) {
    const topic = `/${appId}/11/p2p/${id}`;
    const sysTopic = `/${appId}/22/notify/sys`;
		console.log('TCL:self connect -> topic 订阅自己', topic)
  

    this.m = meq.connect({
      // host: '192.168.2.206',
      host: '223.203.221.89',
      port: 9008,
      username: id,
    });

    this.m.on('connect', () =>{
      this.m.subscribe(topic, () => {});
      this.m.subscribe(sysTopic, () => {});
    })

    
    // callback(this.m)

    this.m.on('message', (msg: any) => {
			console.log('TCL: chat->connect -> msg', msg)
      const payload = JSON.parse(msg.payload);
      const userModel = store.user;
  
      if(msg.sender !== userModel.userInfo.id && !this.chatSession.find(item => item.uid === payload.sender)){
        if(userModel.usersMap[id]){
          const user: ChatSessionItem = getChatSessionItem(userModel.usersMap[id]);
          this.chatSession.push(user);
        }else{
          userModel.getUser({
            data: {
              uid: id,
            },
            callback: res => {
              if(res.code === '1'){
                const resData = res.data;
                const user: ChatSessionItem = getChatSessionItem(resData);
                this.addChatSession(user);
              }
            }
          })
        }
      }

      function getChatSessionItem(user: UserInfo): ChatSessionItem{
        const chatSessionItem: ChatSessionItem = {
          avatar: user.avatar,
          ope: '0',
          title: user.nickname,
          uid: user.id,
        }
        return chatSessionItem;
      }

      // var l = this.state.messages.length;
      // if (l == 0) {
      //   this.setState(
      //     produce(state => {
      //       state.messages.push(msg);
      //       state.offset = msg.id;
      //     })
      //   );
      // } else if (msg.id < this.state.messages[l - 1].id) {
      //   this.setState(
      //     produce(state => {
      //       state.messages.unshift(msg);
      //       state.offset = msg.id;
      //     })
      //   );
      // } else {
      //   this.setState(
      //     produce(state => {
      //       state.messages.push(msg);
      //     })
      //   );
      // }

      // if (!this.state.loadMoreClicked) {
      //   // var chat = document.getElementById("chat-room");
      //   this.scrollToBottom();
      // }
    });

    // this.m.on('joinchat', (msg: any) => {
    //   var exist = false;
    //   var id = msg.user.toString();
    //   for (var i = 0; i < this.state.users.length; i++) {
    //     if (this.state.users[i].id == id) {
    //       this.state.users[i].status = '1';
    //       exist = true;
    //     }
    //   }

    //   if (!exist) {
    //     this.state.users.push({
    //       id: msg.user.toString(),
    //       status: '1',
    //     });
    //   }
    // });

    // this.m.on('leavechat', (msg: any) => {
    //   var id = msg.user.toString();
    //   for (var i = 0; i < this.state.users.length; i++) {
    //     if (this.state.users[i].id == id) {
    //       this.state.users.splice(i, 1);
    //     }
    //   }
    // });

    // this.m.on('online', (msg: any) => {
    //   var id = msg.user.toString();
    //   for (var i = 0; i < this.state.users.length; i++) {
    //     if (this.state.users[i].id == id) {
    //       this.state.users[i].stauts = '1';
    //     }
    //   }
    // });

    // this.m.on('offline', (msg: any) => {
    //   var id = msg.user.toString();
    //   for (var i = 0; i < this.state.users.length; i++) {
    //     if (this.state.users[i].id == id) {
    //       this.state.users[i].status = '0';
    //     }
    //   }
    // });

    // this.m.on('retrieve', (msg: any) => {
    //   console.log('msg retrieve', msg.topic.toString(), msg.msgid.toString());
    // });
  }
}
