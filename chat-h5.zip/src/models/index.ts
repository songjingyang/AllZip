// import { User } from './User';
import Global from './Global'
import Chat from './Chat'
import Concat from './Concat'
import Group from './Group'
import User from './User'
import My from './My'
export default {
  global: new Global(),
  chat: new Chat(),
  concat: new Concat(),
  group: new Group(),
  user: new User(),
  my :new My()
}