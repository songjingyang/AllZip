import { observable, action } from 'mobx';
import request, {
  urlMaps, ReqData,
ResData} from '../common/request'

export interface GroupItem{
  group_id: string;
  admin_id: string;
  topic: string;
  name: string;
  bulletin: string;
  private: number;
  invite: number;
  capacity: number;
  created: number;
  group_type: number;
}

export enum GroupMemberStatus{
  normal = 1,
  silent = 2,
  removed = 3,
}

export enum GroupMemberFromStatus {
  selfAdd = 1,
  invite = 2,
  adminAdd = 3,
}

export interface GroupMemberItem {
  player_id: string;
  topic: string;
  nickname: string;
  sex: string;
  avatar: string;
  whatsup: string;
  from: GroupMemberFromStatus;
  join_ts: string;
  status: GroupMemberStatus;
}

 class Group {
   @observable
   groupList: GroupItem[] = [];
   @observable
   groupMemberList: GroupMemberItem[] = [
   
       {
         "player_id": "成员id1",
         "topic": "成员topic",
         "nickname": "a昵称",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id2",
         "topic": "成员topic",
         "nickname": "b昵称",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id3",
         "topic": "成员topic",
         "nickname": "c有意思吗",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id4",
         "topic": "成员topic",
         "nickname": "d天凉",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id5",
         "topic": "成员topic",
         "nickname": "e天凉",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id6",
         "topic": "成员topic",
         "nickname": "f天凉",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id7",
         "topic": "成员topic",
         "nickname": "g天凉",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id8",
         "topic": "成员topic",
         "nickname": "h天凉",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id9",
         "topic": "成员topic",
         "nickname": "i天凉",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id10",
         "topic": "成员topic",
         "nickname": "j天凉",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id11",
         "topic": "成员topic",
         "nickname": "k天凉",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       },
       {
         "player_id": "成员id12",
         "topic": "成员topic",
         "nickname": "l组合",
         "sex": "性别",
         "avatar": "头像地址",
         "whatsup": "说说",
         "from": 1,
         "join_ts": "加入时间",
         "status": 1,
       }
   ];

   @action
   async getGroupList({ data, callback }: ReqData) {
     const res: ResData = await request(urlMaps.getGroupList, data, {
       method: 'post',
     });
     if (res.code === '1') {
       this.groupList = res.data.list;
     }
     if (callback) {
       callback(res);
     }
   }
   @action
   async getGroupMemberList({ data, callback }: ReqData) {
     const res: ResData = await request(urlMaps.getGroupMemberList, data, {
       method: 'post',
     });
     if (res.code === '1') {
       this.groupMemberList = res.data.list;
     }
     if (callback) {
       callback(res);
     }
   }

   // getGroupList
   // getGroupMemberList
   // createGroup
   // inviteGroupMember
   // addGroupMember
   // delGroupMember
 }

export default Group

