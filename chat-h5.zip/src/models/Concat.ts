import { observable, action } from 'mobx'
import request, { urlMaps, ReqData, ResData } from '../common/request'
interface ConcatListItem {
  add_friends: ConcatMemberItem[],
  contact: ConcatMemberItem[],
  new_friends: ConcatMemberItem[]
}
enum ConcatMemberStatus{
  normal = 1,
  silent = 2,
  removed = 3,
}

enum ConcatMemberFromStatus {
  selfAdd = 1,
  invite = 2,
  adminAdd = 3,
}
interface ConcatMemberItem {
  player_id?: string;
  topic?: string;
  nickname?: string;
  sex?: string;
  avatar?: string;
  whatsup?: string;
  from?: ConcatMemberFromStatus;
  join_ts?: string;
  status?: ConcatMemberStatus;
  created?: number;
  id?: string;
  remark?: string;
  secret?: string;
}
interface PersonalInfoItem {
  avatar: string
  nickname: string
  uid: string
  ope: string
  title: string
}
class Concat {
  @observable concatList: ConcatListItem = {
    add_friends: [
      // {
      //   avatar: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1341102525,2883257137&fm=26&gp=0.jpg",
      //   created: 1549081941475263200,
      //   from: 2,
      //   id: "1091554519369654272",
      //   nickname: "华为p88",
      //   remark: "",
      //   secret: "123456",
      //   status: 1
      // },
      // {
      //   avatar: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549882000232&di=3ba0c797f76f1aeac534622d6f589281&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201507%2F02%2F20150702193124_zrLFJ.jpeg",
      //   created: 1549081941475263201,
      //   from: 2,
      //   id: "1091554519369654273",
      //   nickname: "华为p9",
      //   remark: "",
      //   secret: "123456",
      //   status: 2
      // }
    ],
    contact: [
      // {
      //   'id': '1090136636970246144',
      //   "player_id": "成员id1",
      //   "topic": "成员topic",
      //   "nickname": "a昵称",
      //   "sex": "性别",
      //   "avatar": "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1424056970,1573747361&fm=26&gp=0.jpg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499393',
      //   "player_id": "成员id2",
      //   "topic": "成员topic",
      //   "nickname": "b昵称",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549891280112&di=81b87be8d123b734cd33fc1a961af1e6&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201507%2F02%2F20150702193124_zrLFJ.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499394',
      //   "player_id": "成员id3",
      //   "topic": "成员topic",
      //   "nickname": "c有意思吗",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549891280111&di=455a19a997db2bcaa747f49b49d37cfe&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201504%2F16%2F20150416H1153_X5Wey.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499395',
      //   "player_id": "成员id4",
      //   "topic": "成员topic",
      //   "nickname": "d天凉",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549891280111&di=2c90e4887005a589f56b165579f5ef1c&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201506%2F29%2F20150629084855_JKRQS.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499396',
      //   "player_id": "成员id5",
      //   "topic": "成员topic",
      //   "nickname": "e天凉",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b10000_10000&sec=1549881261&di=c2b89e341bdff695177a8d8ee22818ec&src=http://b-ssl.duitang.com/uploads/item/201505/29/20150529082034_f8MPt.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499397',
      //   "player_id": "成员id6",
      //   "topic": "成员topic",
      //   "nickname": "f天凉",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b10000_10000&sec=1549881261&di=cbc7c4a43c98d442b249788fb109923e&src=http://b-ssl.duitang.com/uploads/item/201512/19/20151219155900_Btz3n.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499398',
      //   "player_id": "成员id7",
      //   "topic": "成员topic",
      //   "nickname": "g天凉",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b10000_10000&sec=1549881315&di=8357cecc78bfa1a29d4342eda472fd3e&src=http://b-ssl.duitang.com/uploads/item/201504/16/20150416H2750_cB5RU.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499399',
      //   "player_id": "成员id8",
      //   "topic": "成员topic",
      //   "nickname": "h天凉",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549891434715&di=26705883f064baf4af0fcb719df7ea32&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201705%2F16%2F20170516170629_drxiH.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499310',
      //   "player_id": "成员id9",
      //   "topic": "成员topic",
      //   "nickname": "i天凉",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549891434715&di=26705883f064baf4af0fcb719df7ea32&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201705%2F16%2F20170516170629_drxiH.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499311',
      //   "player_id": "成员id10",
      //   "topic": "成员topic",
      //   "nickname": "j天凉",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549891434715&di=26705883f064baf4af0fcb719df7ea32&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201705%2F16%2F20170516170629_drxiH.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499312',
      //   "player_id": "成员id11",
      //   "topic": "成员topic",
      //   "nickname": "k天凉",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549891434715&di=26705883f064baf4af0fcb719df7ea32&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201705%2F16%2F20170516170629_drxiH.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // },
      // {
      //   'id': '1089798617117499313',
      //   "player_id": "成员id12",
      //   "topic": "成员topic",
      //   "nickname": "l组合",
      //   "sex": "性别",
      //   "avatar": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549891434715&di=26705883f064baf4af0fcb719df7ea32&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201705%2F16%2F20170516170629_drxiH.jpeg",
      //   "whatsup": "说说",
      //   "from": 1,
      //   "join_ts": "加入时间",
      //   "status": 1,
      // }
    ],
    new_friends: [
      // {
      //   avatar: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1341102525,2883257137&fm=26&gp=0.jpg",
      //   created: 1549081941475263200,
      //   from: 2,
      //   id: "1091554519369654272",
      //   nickname: "华为p30",
      //   remark: "",
      //   secret: "123456",
      //   status: 1
      // },
      // {
      //   avatar: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1549882000232&di=3ba0c797f76f1aeac534622d6f589281&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201507%2F02%2F20150702193124_zrLFJ.jpeg",
      //   created: 1549081941475263201,
      //   from: 2,
      //   id: "1091554519369654273",
      //   nickname: "华为p9",
      //   remark: "",
      //   secret: "123456",
      //   status: 2
      // }
    ]
  };
  @observable personalInfoInfo: PersonalInfoItem = {
    avatar: '',
    nickname: '',
    uid: '',
    ope: '',
    title: ''
  }
  @observable setRemarkInfo: any
  @observable setLabelInfo: any
  @observable searchfriendsList: any

  @action
  async getConcat ({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.getConcat, {...data}, { method: 'POST' });
    if (res.code === '1') {
      this.concatList = res.data
    }
    if (callback) {
      callback(res)
    }
  }
  @action
  async getPersonalInfo ({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.getPersonalInfo, {...data})
    if (res.code === '1') {
      this.personalInfoInfo = res.data
    }
    if (callback) {
      callback(res)
    }
  }
  @action
  async setRemark ({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.setremark, {...data}, {method: 'POST'})
    if (res.code === '1') {
      this.setRemarkInfo = res.data
    }
    if (callback) {
      callback(res)
    }
  }
  @action
  async searchfriends ({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.searchfriends, {...data})
    if (res.code === '1') {
      this.searchfriendsList = res.data
    }
    if (callback) {
      callback(res)
    }
  }
  @action
  async addfriends ({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.addfriends, {...data}, {method: 'POST'})
    if (res.code === '1') {

    }
    if (callback) {
      callback(res)
    }
  }
  @action
  async removefriends ({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.removefriends, {...data}, {method: 'POST'})
    if (res.code === '1') {

    }
    if (callback) {
      callback(res)
    }
  }
  @action
  async acceptapply ({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.acceptapply, {...data}, { method: 'POST' })
    if (res.code === '1') {
     
    }
    if (callback) {
      callback(res)
    }
  }
  @action
  async rejectapply ({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.rejectapply, {...data}, { method: 'POST' })
    if (res.code === '1') {
  
    }
    if (callback) {
      callback(res)
    }
  }
}

export default Concat