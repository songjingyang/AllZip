import { observable, action } from 'mobx';
import request, { urlMaps, ReqData, ResData } from '../common/request'
import { string } from 'prop-types';
import store from './index'
interface myInfo {
   uid: string;
   avatar: string;
   nickname: string;
   qrcode: string;
}
interface upDateInfo {
  uid: string;
  nickname: string;
  qrcode: string;
  avatar?: string;
}
class My {
  @observable  
  myInfo: myInfo = ({
      uid: '',
      avatar: '',
      nickname: '',
      qrcode: '',
  } )
  upDateInfo: upDateInfo =({
    uid: "",
    nickname: "",
    qrcode: "",
  })
  @action
  async getMyInfo({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.getMyInfo, {});
    if (res.code === '1') {
      this.myInfo = res.data;
    }
    if (callback) {
      callback(res);
    }
  }
  @action
  async saveUpdateInfo({ data, callback }: ReqData) {
    const res: ResData = await request(urlMaps.saveUpdateInfo, {
      ...data
    },{method:'POST'});
    if (res.code === '1') {
      this.myInfo = res.data;  
      store.user.updateUser({nickname: this.myInfo.nickname})
    }
    if (callback) {
      callback(res);
    }
  }
}
export default My;
