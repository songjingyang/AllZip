import { observable, action } from 'mobx'
import request, { urlMaps } from '../common/request';


class Global {
  @observable todos: number[] = [1, 2, 3];
  @action push() {
    console.log('​TodoList -> @actionpush -> push', 3333);

    this.todos.push(4);
    console.log('​TodoList -> @actionpush -> this.todos', this.todos);
  }

  @action
  async upload(data: any) {
    const res = await request(urlMaps.upload, data, { method: 'post' });
    console.log('TCL: Global -> upload -> res', res);
    if (res.code === '1') {
      return res.data.url;
    }
    return '';
  }

 
}

export default  Global;
