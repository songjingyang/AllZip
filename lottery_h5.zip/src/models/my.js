import http from '@/common/request'

export default {
  namespace: 'my',
  state: {
    myInfo: {
      avatar: '',
      consumable: 0,
      is_ident_set: 2,
      is_mobile_set: 2,
      is_pay_pswd_set: 2,
      nickname: '',
      withdrawable: 0
    },
    withdrawalInfo: {
      page: 1,
      page_size: 20,
      total: 0,
      ts: 0,
      list: []
    },
    withdrawalRecordInfo: {
      page: 1,
      page_size: 20,
      total: 0,
      ts: 0,
      withdraw_data: []
    },
    chaseRecordList: {
      page: 1,
      page_size: 20,
      total: 0,
      ts: 0,
      list: []
    },
    accountDetailListInfo: {
      page: 1,
      page_size: 20,
      total: 0,
      ts: 0,
      list: []
    },
    periodManageListInfo: {
      page: 1,
      page_size: 20,
      total: 0,
      ts: 0,
      list: []
    },
    accountInfo: {
      nickname: '',
      mobile: '',
      email: '',
      realname: '',
      identity: '',
      wx_qr: '',
      tip: '',
      ali_qr: ''
    },
    webkitInfoList: {
      page: 1,
      page_size: 20,
      total: 0,
      ts: 0,
      withdraw_data: []
    }
  },
  effects: {
    * getMyInfo ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getMyInfo, payload, { method: 'POST' })
      if (res.code === 200) {
        yield put({
          type: 'myInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * withdrawal ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.withdrawal, payload, { method: 'POST' })
      if (res.code === 200) {
        yield put({
          type: 'withdrawalInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * withdrawalIdentity ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.withdrawalIdentity, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
        yield put({})
      }
      if (callback) {
        callback(res)
      }
    },
    * withdrawalRecord ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.withdrawalRecord, payload, { method: 'POST' })
      if (res.code === 200) {
        yield put({
          type: 'withdrawalRecordInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getChaseRecordList ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getChaseRecordList, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
        yield put({
          type: 'chaseRecordList',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getAccountDetailList ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAccountDetailList, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
        yield put({
          type: 'accountDetailListInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getPeriodManageList ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getPeriodManageList, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
        yield put({
          type: 'periodManageListInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getAccountInfo ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAccountInfo, payload, { method: 'POST' })
      if (res.code === 200) {
        yield put({
          type: 'accountInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getWebkitInfoList ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getWebkitInfoList, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
        yield put({
          type: 'webkitInfoList',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * recharge ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.recharge, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * checkRechargeStatus ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.checkRechargeStatus, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    }
  },
  reducers: {
    myInfo (state, { payload }) {
      return {
        ...state,
        myInfo: { ...payload }
      }
    },
    withdrawalInfo (state, { payload }) {
      return {
        ...state,
        withdrawalInfo: { ...payload }
      }
    },
    withdrawalRecordInfo (state, { payload }) {
      return {
        ...state,
        withdrawalRecordInfo: { ...payload }
      }
    },
    chaseRecordList (state, { payload }) {
      return {
        ...state,
        chaseRecordList: { ...payload }
      }
    },
    accountDetailListInfo (state, { payload }) {
      return {
        ...state,
        accountDetailListInfo: { ...payload }
      }
    },
    periodManageListInfo (state, { payload }) {
      return {
        ...state,
        periodManageListInfo: { ...payload }
      }
    },
    accountInfo (state, { payload }) {
      return {
        ...state,
        accountInfo: { ...payload }
      }
    },
    webkitInfoList (state, { payload }) {
      return {
        ...state,
        webkitInfoList: { ...payload }
      }
    }
  },
  subscriptions: {
    setup ({ history }) {}
  }
}
