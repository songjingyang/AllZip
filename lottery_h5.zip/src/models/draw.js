import http from '@/common/request'
import urlMaps from '@/common/urlMaps'
import { getLotteryName } from '../utils/lottery'

export default {
  namespace: 'draw',
  state: {
    drawInfo: [],
    lastDraw: {
      page: 1,
      page_size: 20,
      total: 0,
      ts: 0,
      list: []
    }
  },

  effects: {
    * getDrawInfo ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getDrawInfo, payload)

      if (res.code === 200) {
        yield put({
          type: 'drawInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getLastDraw ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getLastDraw, payload, {
        method: 'post',
        headers: { LotteryName: payload.lotteryName }
      })

      if (res.code === 200) {
        yield put({
          type: 'lastDraw',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    }
  },

  reducers: {
    drawInfo (state, { payload }) {
      return {
        ...state,
        drawInfo: [...payload]
      }
    },
    lastDraw (state, { payload }) {
      return {
        ...state,
        lastDraw: { ...payload }
      }
    }
  },
  subscriptions: {
    setup ({ history }) {}
  }
}
