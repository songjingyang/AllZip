import http from '@/common/request'

export default {
  namespace: 'user',
  state: {
    userInfo: {
      name: 'daycool',
      email: 'qmw920@163.com'
    }
    // userList: [
    //   {
    //     name: 'daycool',
    //     email: 'qmw920@163.com'
    //   },
    //   {
    //     name: 'daycool',
    //     email: 'qmw920@163.com'
    //   },
    //   {
    //     name: 'daycool',
    //     email: 'qmw920@163.com'
    //   }
    // ]
  },
  effects: {
    // * getUserInfo ({ payload, callback }, { call, put, select }) {
    //   const res = yield call(http.getUserInfo, payload)
    //   if (res.code === 200) {
    //     localStorage.setItem('user', JSON.stringify(res.payload))
    //     yield put({
    //       type: 'userInfo',
    //       payload: res.data
    //     })
    //   }
    //   if (callback) {
    //     callback(res)
    //   }
    // },
    * login ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.login, payload, { method: 'POST' })
      if (res.code === 200) {
        localStorage.setItem('user', JSON.stringify(res.payload))
        yield put({
          type: 'userInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * logout ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.logout, payload, { method: 'POST' })
      if (res.code === 200) {
        localStorage.removeItem('user')
        yield put({
          type: 'userInfo',
          payload: {
            name: ''
          }
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getCode ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getCode, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * forgetPasswordValid ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.forgetPasswordValid, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * register ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.register, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * setPassword ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.setPassword, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * forgetPassword ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.forgetPassword, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * changePassword ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.changePassword, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * changeNickname ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.changeNickname, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * setIdentity ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.setIdentity, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * setMobile ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.setMobile, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * setPayPass ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.setPayPass, payload, { method: 'POST' })
      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    }
  },

  reducers: {
    userInfo (state, { payload }) {
      return {
        ...state,
        userInfo: payload
      }
    }
  },
  subscriptions: {
    setup ({ history }) {}
  }
}
