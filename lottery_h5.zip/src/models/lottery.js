import http from '@/common/request'
import urlMaps from '@/common/urlMaps'
import { getLotteryName, getTrendDataNormal } from '../utils/lottery'

export default {
  namespace: 'lottery',
  state: {
    // banners  轮播图   //tips  开奖小喇叭，随机展示    //lotteries  彩种列表
    banners: [],
    tips: [],
    lotteries: [],
    lotteryInfo: {
      lottery_name: '',
      cur_period: '', // 当前准备投注的期数
      draw_time_left: 0, // 倒计时时间 单位：毫秒
      last_period: '',
      last_period_status: 0,
      draw_time: 0,
      style: '',
      draw_data: [
        // {
        //   numbers: [3, 5, 5],
        //   color: '#dd3048'
        // }
      ]
    },
    fastThreePlayType: [],
    userWalletInfo: {
      nickname: '',
      avatar: '',
      wallet: '',
      balance: '',
      ident_set: ''
    },
    orderInfo: {
      order_id: '', // 订单编号
      period_start: '',
      period_end: '',
      cost: '', // 购买金额
      chase: '', // 购买期数
      chased: '', // 已追期数
      times: '', // 购买倍数
      rewards: '', // 中奖金额
      stakes_count: '', // 购买注数
      image_url: '', // 彩种图标
      created: '', // 下单时间
      periods: [],
      stakes: [],
      status: 2 // 1未付款  2 已付款
    },
    trend: {
      data: [],
      hotCold: {},
      result: ''
    }
  },

  effects: {
    * getHomeInfo ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getHomeInfo, payload)
      console.log(res)
      if (res.code === 200) {
        yield put({
          type: 'banners',
          payload: res.payload.banners
        })
        yield put({
          type: 'tips',
          payload: res.payload.tips
        })
        yield put({
          type: 'lotteries',
          payload: res.payload.lotteries
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getLotteryInfo ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getLotteryInfo, payload, {
        method: 'post',
        url: `${urlMaps.getLotteryInfo}/`,
        headers: { LotteryName: payload.lotteryName }
      })

      if (res.code === 200) {
        yield put({
          type: 'lotteryInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },

    * bet ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.bet, payload, {
        method: 'post',
        url: `${urlMaps.bet}/${getLotteryName(payload.lotteryName)}/`,
        headers: { LotteryName: payload.lotteryName }
      })

      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * getUserWalletInfo ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getUserWalletInfo, payload, {
        method: 'post'
      })

      if (res.code === 200) {
        yield put({
          type: 'userWalletInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * pay ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.pay, payload, {
        method: 'post'
      })

      if (res.code === 200) {
      }
      if (callback) {
        callback(res)
      }
    },
    * getOrderInfo ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getOrderInfo, payload, {
        method: 'post',
        // url: `${urlMaps.getOrderInfo}/${getLotteryName(payload.lotteryName)}//`,
        headers: { LotteryName: payload.lotteryName }
      })

      if (res.code === 200) {
        yield put({
          type: 'orderInfo',
          payload: res.payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getTrend ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getTrend, payload, {
        method: 'post',
        headers: { LotteryName: payload.lotteryName }
      })

      if (res.code === 200) {
        let trendData = JSON.parse(res.payload.trend)
        trendData.data = trendData.data.slice(
          0,
          payload.periodCount || trendData.data.length
        )
        if (payload.sort === 'asc') {
          trendData.data = trendData.data.reverse()
        }
        getTrendDataNormal(payload.lotteryName, trendData, payload.playType)
        yield put({
          type: 'trend',
          payload: trendData
        })
      }
      if (callback) {
        callback(res)
      }
    }
  },

  reducers: {
    banners (state, { payload }) {
      return {
        ...state,
        banners: [...payload]
      }
    },
    tips (state, { payload }) {
      return {
        ...state,
        tips: [...payload]
      }
    },
    lotteries (state, { payload }) {
      return {
        ...state,
        lotteries: [...payload]
      }
    },
    userWalletInfo (state, { payload }) {
      return {
        ...state,
        userWalletInfo: { ...payload }
      }
    },
    lotteryInfo (state, { payload }) {
      return {
        ...state,
        lotteryInfo: { ...payload }
      }
    },
    orderInfo (state, { payload }) {
      return {
        ...state,
        orderInfo: { ...payload }
      }
    },
    trend (state, { payload }) {
      return {
        ...state,
        trend: { ...payload }
      }
    }
  },
  subscriptions: {
    setup ({ history }) {}
  }
}
