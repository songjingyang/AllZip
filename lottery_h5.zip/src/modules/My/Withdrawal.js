import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  SegmentedControl,
  Modal,
  Toast,
} from 'antd-mobile'
import { createForm } from 'rc-form'
import './Withdrawal.less'
import PayPass from '../../components/PayPass/index'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class Withdrawal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isShowPass: false,
      pass: '',
      qrTypeMap: {
        100: '微信',
        200: '支付宝',
      },
    }
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'my/getMyInfo',
      payload: {},
    })
    this.props.dispatch({
      type: 'my/getAccountInfo',
      payload: {},
    })
  }
  valid = () => {
    const qrType = this.props.match.params.qrType
    const info = this.props.my.accountInfo
    if (qrType == 200) {
      if (!info.ali_qr) {
        Modal.alert('提示', '请上传二维码后在提现')
        return false
      }
    } else if (qrType == 100) {
      if (!info.wx_qr) {
        Modal.alert('提示', '请上传二维码后在提现')
        return false
      }
    }
    if (!this.props.match.params.qrType) {
      Modal.alert('提示', '请选择提现方式')
      return
    }
    if (!this.props.form.getFieldProps('amount').value) {
      Modal.alert('提示', '请输入提现金额')
      return
    }
    if (
      this.props.form.getFieldProps('amount').value >
      this.props.my.myInfo.withdrawable / 100
    ) {
      Modal.alert('提示', '请输入小于可提现金额')
      return
    }
    this.setState({ isShowPass: true })
  }
  handleSubmit = () => {
    const qrType = this.props.match.params.qrType
    const info = this.props.my.accountInfo

    this.props.form.validateFields((error, values) => {
      this.props.dispatch({
        type: 'my/withdrawal',
        payload: {
          pay_type: +this.props.match.params.qrType,
          amount: +values.amount * 100,
          pay_pswd: this.state.pass,
        },
        callback: res => {
          if (res.code === 200) {
            this.props.dispatch({
              type: 'my/getMyInfo',
              payload: {},
            })
            Modal.alert('提示', res.msg)
            this.props.dispatch(routerRedux.push('/home/my'))
          } else {
            Toast.fail(res.msg)
          }
        },
      })
    })
  }
  withdrawalAll = () => {
    this.props.form.setFieldsValue({
      amount: Math.floor(this.props.my.myInfo.withdrawable / 100),
    })
  }
  render() {
    const { getFieldProps } = this.props.form
    const info = this.props.my.myInfo
    const accountInfo = this.props.my.accountInfo
    return (
      <Fragment>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
          rightContent={[
            <Link className="withdrawal-record" to={'/my/withdrawalRecord'}>
              提现记录
            </Link>,
          ]}
        >
          提现
        </NavBar>
        <WingBlank size="sm">
          <List>
            <Link to={'/my/withdrawalType'}>
              <Item styleName="withdrawal-types" arrow="horizontal">
                <em>提现方式：</em>
                <span>
                  {this.state.qrTypeMap[this.props.match.params.qrType]}
                </span>
              </Item>
            </Link>
            <Item styleName="withdrawal-prices">
              <em>提现金额：</em>
              <span>
                可提现金额{Math.floor(this.props.my.myInfo.withdrawable / 100)}
                元
              </span>
            </Item>
            <div className="withdrawal-amount" styleName={'withdrawal-amount'}>
              <InputItem
                type="number"
                {...getFieldProps('amount', {
                  // initialValue: info.amount,
                  rules: [
                    { required: true, message: '请输入提现金额' },
                    { validator: this.validateAccount },
                  ],
                })}
                placeholder="请输入提现金额"
              >
                <i styleName={'withdrawal-money'}>¥</i>
              </InputItem>
              <span
                onClick={() => this.withdrawalAll()}
                styleName={'withdrawal-all'}
              >
                全部提现
              </span>
            </div>
          </List>
          <div styleName={'withdrawal-margin'}>
            <Button onClick={this.valid} type="primary">
              提交
            </Button>
            <span styleName="withdrawal-tip">
              提现会收取{accountInfo.tip}手续费
            </span>
          </div>
        </WingBlank>
        {this.state.isShowPass && (
          <PayPass
            onConfirm={value => {
              this.setState({ pass: value }, () => {
                this.handleSubmit()
              })
            }}
            onClose={() => this.setState({ isShowPass: false })}
          />
        )}
      </Fragment>
    )
  }
}
