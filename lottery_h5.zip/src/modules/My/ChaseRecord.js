import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  SegmentedControl,
  ListView,
} from 'antd-mobile'
import { createForm } from 'rc-form'
import { dateFormater, datesFormate } from '@/utils/utils'
import CommonList from '../../components/List'
import './ChaseRecord.less'
import { getLotteryNameLabel } from '../../utils/lottery'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class ChaseRecord extends CommonList {
  constructor(props) {
    super(props)
    this.state = {
      ...(this.state || {}),
      statusMap: {
        1: '已开奖',
        2: '未开奖',
        3: '已开奖',
      },
      currentIndex: 1,
      statusNav: [
        { id: 1, title: '全部' },
        { id: 2, title: '未开奖' },
        { id: 3, title: '已开奖' },
      ],
    }
  }
  url = 'my/getChaseRecordList'
  keys = ['my', 'chaseRecordList']
  params = {
    status: 1,
  }

  search = status => {
    this.params.status = status
    this.getData()
    this.setState(
      {
        currentIndex: status,
      },
      () => {
        console.log('currenIndex', this.state.currentIndex)
      }
    )
  }

  renderListItem = list => {
    let index = 0

    const row = (rowData, sectionID, rowID) => {
      const item = list[index++]
      return (
        <div>
          {item && (
            <Link
              to={{
                pathname: `/lottery/OrderDetail/${item.order_id}/${
                  item.lottery_name
                }`,
              }}
            >
              <div styleName={'bettingRecord-list'}>
                <Item arrow="horizontal">
                  <span className="bettingRecord-jump">
                    {getLotteryNameLabel(item.lottery_name)}
                  </span>
                  <div className="bettingRecord-div">
                    <em className="bettingRecord-time">
                      {datesFormate(item.creatd)}
                    </em>
                    <em className="bettingRecord-price">
                      金额：{item.cost / 100}元
                    </em>
                  </div>
                  <span className="bettingRecord-type">
                    {this.state.statusMap[item.status]}
                  </span>
                </Item>
              </div>
            </Link>
          )}
        </div>
      )
    }
    return row
  }

  render() {
    const { getFieldProps } = this.props.form
    const info = this.props.my.chaseRecordList

    return (
      <div className="chaseRecord-page">
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
        >
          投注记录
        </NavBar>
        <div styleName={'chansRecord-statusNav'}>
          {this.state.statusNav.map((item, index) => {
            return (
              <div
                onClick={() => this.search(item.id)}
                styleName={
                  this.state.currentIndex == item.id
                    ? 'statusNav-selected'
                    : 'statusNav-select'
                }
              >
                {item.title}
              </div>
            )
          })}
        </div>
        <div>
          {info.list && info.list.length && this.renderList()}

          {info.list.length === 0 && (
            <div className="empty-occupied">
              <em />
              <p>暂无交易记录</p>
              <p>赶紧去投注</p>
              <Link to={'/home/home'}>
                <Button className="myList-btn-primary" type="primary">
                  立即投注
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    )
  }
}
