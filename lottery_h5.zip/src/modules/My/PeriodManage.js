import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  SegmentedControl
} from 'antd-mobile'
import { createForm } from 'rc-form'
import './PeriodManage.less'
import { getLotteryNameLabel } from '../../utils/lottery'
import CommonList from '../../components/List'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class PeriodManage extends CommonList {
  constructor (props) {
    super(props)
    this.state = {
      ...(this.state || {}),
      statusMap: {
        1: '全部',
        2: '追期中',
        3: '已结束'
      },
      currentIndex: 1,
      statusNav: [
        { id: 1, title: '全部' },
        { id: 2, title: '追期中' },
        { id: 3, title: '已结束' }
      ]
    }
  }
  url = 'my/getPeriodManageList'
  keys = ['my', 'periodManageListInfo']
  params = {
    status: 1
  }

  renderListItem = list => {
    let index = 0

    const row = (rowData, sectionID, rowID) => {
      const item = list[index++]
      return (
        <div>
          {item &&
            <Link
              to={{
                pathname: `/lottery/ChaseOrderDetail/${item.order_id}/${item.lottery_name}`
              }}
            >
              <div styleName={'periodManage-list'}>
                <Item arrow='horizontal'>
                  <span styleName={'periodManage-jump'}>
                    {getLotteryNameLabel(item.lottery_name)}
                  </span>
                  <div styleName={'periodManage-div'}>
                    <em className='periodManage-time'>
                      共追{item.chase}期，已追{item.chased}期
                    </em>
                    <em className='periodManage-price'>{item.cost / 100}元</em>
                  </div>
                  <em styleName={'periodManage-type'}>
                    {item.chase === item.chased ? '已结束' : '追期中'}
                  </em>
                  {/* <em styleName={'periodManage-type'}>{this.state.statusMap[item.status]}</em> */}
                </Item>
              </div>
            </Link>}
        </div>
      )
    }
    return row
  }

  search = status => {
    this.params.status = status
    this.getData()

    this.setState({
      currentIndex: status
    })
  }

  render () {
    const { getFieldProps } = this.props.form
    const info = this.props.my.periodManageListInfo
    console.log('info', info)

    return (
      <div>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.history.goBack()}
        >
          追期管理
        </NavBar>
        <div styleName={'periodManege-statusNav'}>
          {this.state.statusNav.map((item, index) => {
            return (
              <div
                onClick={() => this.search(item.id)}
                styleName={
                  this.state.currentIndex == item.id
                    ? 'statusNav-selected'
                    : 'statusNav-select'
                }
              >
                {item.title}
              </div>
            )
          })}
        </div>
        <div>
          {info.list && info.list.length && this.renderList()}
          {info.list === null &&
            <div className='empty-occupied'>
              <em />
              <p>暂无交易记录</p>
              <p>赶紧去投注</p>
              <Link to={'/home/home'}>
                <Button className='myList-btn-primary' type='primary'>
                  立即投注
                </Button>
              </Link>
            </div>}
        </div>
      </div>
    )
  }
}
