import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  Toast,
  NavBar,
  Icon
} from 'antd-mobile'
import { createForm } from 'rc-form'
import UploadImg from '@/components/UploadImg'

import './AccountInfo.less'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class AccountInfo extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      qrCodeType: {
        100: '微信',
        200: '支付宝'
      },
      currentIndex: 100,
      statusNav: [{ id: 100, title: '微信' }, { id: 200, title: '支付宝' }]
    }
  }
  componentDidMount () {
    this.props.dispatch({
      type: 'my/getAccountInfo',
      payload: {}
    })
  }
  search = status => {
    this.setState(
      {
        currentIndex: status
      },
      () => {
        console.log('currenIndex', this.state.currentIndex)
      }
    )
  }
  upload = url => {
    this.props.dispatch({
      type: 'global/uploadQrcode',
      payload: {
        urls: [url],
        type: this.state.currentIndex === 100 ? 'wx_qr' : 'ali_qr' // 二维码类型
      },
      callback: res => {
        if (res.code === 200) {
          Toast.success('上传成功', 1)
          this.props.dispatch({
            type: 'my/getAccountInfo',
            payload: {}
          })
        }
      }
    })
  }

  render () {
    const { getFieldProps, getFieldError } = this.props.form
    const info = this.props.my.accountInfo

    return (
      <Fragment>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.history.goBack()}
        >
          账户信息
        </NavBar>
        <div styleName={'accountInfo-list-box'}>
          <span>账户信息</span>
          <div styleName={'accountInfo-list'}>
            <div styleName={'accountInfo-item'}>
              用户名：<em>{info.nickname}</em>
            </div>
            <div styleName={'accountInfo-item'}>
              邮&nbsp;&nbsp;&nbsp;箱：<em>{info.email}</em>
            </div>
            <Link
              to={'/user/changePassword'}
              styleName={'accountInfo-changePassword'}
            >
              <div styleName={'accountInfo-item'}>
                修改密码：<em>******</em>
              </div>
              <i styleName={'changePassword-right'} />
            </Link>
          </div>
          <span>实名认证</span>
          <div styleName={'accountInfo-list'}>
            {info.realname
              ? <div styleName={'accountInfo-item'}>
                  真实姓名：<em>{info.realname}</em>
              </div>
              : <Link
                to={'/my/withdrawalIdentity'}
                styleName={'accountInfo-changePassword'}
                >
                <div styleName={'accountInfo-item'}>
                    真实姓名：<span>-未设置</span>
                </div>
                <i styleName={'changePassword-right'} />
              </Link>}
            {info.identity
              ? <div styleName={'accountInfo-item'}>
                  身份证号：<em>{info.identity}</em>
              </div>
              : <Link
                to={'/my/withdrawalIdentity'}
                styleName={'accountInfo-changePassword'}
                >
                <div styleName={'accountInfo-item'}>
                    身份证号：<span>-未设置</span>
                </div>
                <i styleName={'changePassword-right'} />
              </Link>}
          </div>
          <span>提现二维码</span>
          <div styleName={'accountInfo-qrCode-list'}>
            <div styleName={'accountInfo-statusNav'}>
              {this.state.statusNav.map((item, index) => {
                return (
                  <div
                    onClick={() => this.search(item.id)}
                    styleName={
                      this.state.currentIndex == item.id
                        ? 'statusNav-selected'
                        : 'statusNav-select'
                    }
                  >
                    {item.title}
                  </div>
                )
              })}
            </div>
            <div styleName={'accountInfo-qrCode'}>
              <UploadImg
                value={
                  this.state.currentIndex === 100 ? info.wx_qr : info.ali_qr
                }
                onChange={this.upload}
              />
              {/* {this.state.currentIndex === 100
                ? <img
                  style={{ width: '100%' }}
                  src={
                      info.wx_qr ? info.wx_qr : '/static/media/uploadQrCode.png'
                    }
                  />
                : <img
                  style={{ width: '100%' }}
                  src={
                      info.ali_qr
                        ? info.ali_qr
                        : '/static/media/uploadQrCode.png'
                    }
                  />} */}
            </div>
          </div>
        </div>
        {/* <Upload /> */}
      </Fragment>
    )
  }
}
