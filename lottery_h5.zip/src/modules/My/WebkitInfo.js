import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  SegmentedControl
} from 'antd-mobile'
import { createForm } from 'rc-form'
import CommonList from '../../components/List'

import { dateFormater, saveCache, getCache } from '@/utils/utils'
import './WebkitInfo.less'

const Item = List.Item

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class WebkitInfo extends CommonList {
  constructor (props) {
    super(props)
    this.state = {
      ...(this.state || {}),
      statusMap: {
        1: '已申请',
        2: '提现完成',
        3: '被拒绝',
        4: ''
      }
    }
  }
  url = 'my/getWebkitInfoList'
  keys = ['my', 'webkitInfoList']
  params = {
    status: 1
  }

  renderListItem = list => {
    let index = 0

    const row = (rowData, sectionID, rowID) => {
      const item = list[index++]
      return (
        <div>
          {item &&
            <Link
              to={{
                pathname: `/lottery/OrderDetail/${item.order_id}/${item.lottery_name}`
              }}
              styleName={'webkitInfoList-list'}
            >
              <div styleName={'webkitInfoList-div'}>
                <em styleName={'webkitInfoList-title'}>{item.title}</em>
                <em styleName={'webkitInfoList-time'}>
                  {dateFormater(item.created)}
                </em>
              </div>
              <p>{item.body}</p>
              <div styleName={'webkitInfoList-detail'}>查看详情 &gt;&gt;</div>
            </Link>}
        </div>
      )
    }
    return row
  }

  render () {
    const { getFieldProps } = this.props.form
    const info = this.props.my.webkitInfoList

    return (
      <Fragment>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.history.goBack()}
        >
          消息
        </NavBar>
        <div>
          {this.renderList()}
          {info.list === null &&
            <div className='empty-occupied'>
              <em />
              <p>暂无内容</p>
            </div>}
        </div>
      </Fragment>
    )
  }
}
