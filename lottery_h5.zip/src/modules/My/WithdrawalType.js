import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Modal,
  Toast,
  NavBar,
  Icon
} from 'antd-mobile'
import { createForm } from 'rc-form'
import './WithdrawalType.less'
import UploadImg from '@/components/UploadImg'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class WithdrawalType extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      statusMap: {
        100: '微信',
        200: '支付宝'
      },
      currentIndex: 100,
      statusNav: [{ id: 100, title: '微信' }, { id: 200, title: '支付宝' }],
      files: [
        {
          url: 'https://zos.alipayobjects.com/rmsportal/PZUUCKTRIHWiZSY.jpeg',
          id: '2121'
        }
      ],
      multiple: false
    }
  }
  componentDidMount () {
    this.props.dispatch({
      type: 'my/getAccountInfo',
      payload: {}
    })
  }
  onChange = (files, type, index) => {
    console.log(files, type, index)
    this.setState({
      files
    })
  }
  search = status => {
    this.setState(
      {
        currentIndex: status
      },
      () => {
        console.log('currenIndex', this.state.currentIndex)
      }
    )
  }
  upload = url => {
    this.props.dispatch({
      type: 'global/uploadQrcode',
      payload: {
        urls: [url],
        type: this.state.currentIndex === 100 ? 'wx_qr' : 'ali_qr' // 二维码类型
      },
      callback: res => {
        if (res.code === 200) {
          Toast.success('上传成功', 1)
          this.props.dispatch({
            type: 'my/getAccountInfo',
            payload: {}
          })
        }
      }
    })
  }

  jumpPage = () => {
    const info = this.props.my.accountInfo
    if (this.state.currentIndex === 100 && !info.wx_qr) {
      Modal.alert('提示', '请上传微信二维码')
    }
    if (this.state.currentIndex === 200 && !info.ali_qr) {
      Modal.alert('提示', '请上传支付宝二维码')
    }

    this.props.dispatch(
      routerRedux.push(`/my/withdrawal/${this.state.currentIndex}`)
    )
  }
  render () {
    const { getFieldProps, getFieldError } = this.props.form
    const info = this.props.my.accountInfo
    return (
      <div styleName='page'>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.history.goBack()}
        >
          提现方式
        </NavBar>
        <div styleName={'withdrawalType-statusNav'}>
          {this.state.statusNav.map((item, index) => {
            return (
              <div
                onClick={() => this.search(item.id)}
                styleName={
                  this.state.currentIndex === item.id
                    ? 'statusNav-selected'
                    : 'statusNav-select'
                }
              >
                {item.title}
              </div>
            )
          })}
        </div>
        <div className='qrcode-img' styleName={'withdrawalType-qrCode'}>
          {/* {this.state.currentIndex === 100
            ? <img style={{ width: '100%' }} src={qrCode.wx_qr} />
            : <img style={{ width: '100%' }} src={qrCode.ali_qr} />} */}

          <UploadImg
            value={this.state.currentIndex === 100 ? info.wx_qr : info.ali_qr}
            onChange={this.upload}
          />
        </div>
        <div styleName={'withdrawalType-margin'}>
          <Button
            onClick={this.jumpPage}
            className='big-btn-primary'
            type='primary'
          >
            选择
          </Button>

        </div>
        <div styleName={'withdrawalType-text'}>
          <p>请打开微信／支付宝，点击右上角，选择收款，将收款码保存。 </p>
          <p>注意：二维码中请不要设置金额。 </p>
        </div>
      </div>
    )
  }
}
