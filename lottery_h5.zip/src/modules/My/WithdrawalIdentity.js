import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  Toast,
} from 'antd-mobile'
import { createForm } from 'rc-form'
import './WithdrawalIdentity.less'
import { validErrorTip } from '../../utils/utils'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class WithdrawalIdentity extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      qrCodeType: {
        100: '微信',
        200: '支付宝',
      },
      currentIndex: 100,
      statusNav: [{ id: 100, title: '微信' }, { id: 200, title: '支付宝' }],
    }
  }
  componentDidMount() {}

  withdrawalIdentity = () => {
    this.props.form.validateFields((error, values) => {
      // values.merchant_id = '5bac81ff3b7750724f13b69d'
      if (error) {
        validErrorTip(error)
        return
      }
      this.props.dispatch({
        type: 'user/setIdentity',
        payload: {
          ...values,
        },
        callback: res => {
          if (res.code === 200) {
            Toast.success(res.msg)
            this.props.dispatch(routerRedux.push('/my/accountInfo'))
          } else {
            Toast.fail(res.msg)
          }
        },
      })
    })
  }

  render() {
    const { getFieldProps, getFieldError } = this.props.form

    return (
      <div className="withdrawalIdentity-page">
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
        >
          提现身份信息
        </NavBar>
        <div styleName={'accountInfo-list-box'}>
          <span>请完善您的资料</span>
          <div styleName={'accountInfo-list'}>
            <InputItem
              styleName={'accountInfo-item'}
              {...getFieldProps('real_name', {
                initialValue: '',
                rules: [{ required: true, message: '请输入本人的真实姓名' }],
              })}
              clear
              placeholder="请输入本人的真实姓名"
              ref={el => (this.autoFocusInst = el)}
            >
              真实姓名：
            </InputItem>
            <InputItem
              styleName={'accountInfo-item'}
              {...getFieldProps('id', {
                initialValue: '',
                rules: [{ required: true, message: '请输入本人的身份证号码' }],
              })}
              clear
              placeholder="请输入本人的身份证号码"
              ref={el => (this.autoFocusInst = el)}
            >
              身份证号：
            </InputItem>
          </div>
        </div>
        <div styleName={'btn-margin'}>
          <Button onClick={this.withdrawalIdentity} type="primary">
            确认
          </Button>
        </div>
        <div styleName={'warming-tip'}>
          <span>注意事项：</span>
          <p>
            请务必如实填写“真实姓名”和“身份证号”，这两个信息必须和身份证上的内容
            一致。
          </p>
          <p>
            购买彩票是个人行为，其保证以上信息是您个人的真实信息，不要使用公司或
            他人信息。
          </p>
        </div>
      </div>
    )
  }
}
