/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-10-16 17:02:45
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import {
  NavBar,
  Icon,
  List,
  Button,
  WingBlank,
  Modal,
  Toast
} from 'antd-mobile'
import { createForm } from 'rc-form'
import RadioTag from '@/components/RadioTag'
import './PayAll.less'

const Item = List.Item

@createForm()
@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class Index extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      priceValue: '',
      payType: '',
      orderId: '',
      price: [
        { label: '10元', value: 10 },
        { label: '30元', value: 30 },
        { label: '50元', value: 50 },
        { label: '100元', value: 100 },
        { label: '300元', value: 300 },
        { label: '500元', value: 500 }
      ]
    }
  }
  componentDidMount () {
    // const lotteryName = this.props.match.params.lotteryName
    // this.props.dispatch({
    //   type: 'lottery/getLotteryInfo',
    //   payload: {
    //     lotteryName: lotteryName
    //   }
    // })
    // this.startCheck()
  }
  componentWillUnmount () {
    this.stopCheck()
  }
  onChangePrice = item => {
    this.setState({ priceValue: item.value })
  }
  onChangePayType = type => {
    this.setState({ payType: type })
  }
  payAll = () => {
    const price = this.state.priceValue
    const payType = this.state.payType

    if (!price) {
      Modal.alert('提示', '请选择充值金额')
      return
    }
    if (!payType) {
      Modal.alert('提示', '请选择支付方式')
      return
    }

    this.props.dispatch({
      type: 'my/recharge',
      payload: {
        goods_name: price + '元',
        amount: price * 100,
        paytype: +payType
      },
      callback: res => {
        if (res.code === 200) {
          this.setState({ orderId: res.payload.order_id }, () => {
            this.checkRechargeStatus()
          })
          window.location.href = res.payload.qr_url
        }
      }
    })
  }
  startCheck = () => {
    this.interval = setInterval(() => {
      this.checkRechargeStatus()
    }, 5000)
  }
  stopCheck = () => {
    if (this.interval) {
      clearInterval(this.interval)
      this.interval = null
    }
  }
  checkRechargeStatus = () => {
    if (!this.state.orderId) return

    this.props.dispatch({
      type: 'draw/checkRechargeStatus',
      payload: {
        order_id: this.state.orderId
      },
      callback: res => {
        if (res.code === 200) {
          const data = res.payload
          if (data.status === 2) {
            this.stopCheck()
            Toast.success(res.msg, 1)
          }
          if (data.status === 3) {
            this.stopCheck()
            Toast.error(res.msg, 1)
          }
        }
      }
    })
  }
  render () {
    return (
      <div>
        <Fragment>
          <NavBar
            mode='light'
            icon={<Icon type='left' />}
            onLeftClick={() => this.props.history.goBack()}
          >
            充值
          </NavBar>
          <WingBlank size='sm'>
            <div styleName='title'>请选择充值金额</div>
            <div className='price-list'>
              <RadioTag
                className='payAll-prices'
                itemClassName={'tag-item'}
                itemStyle={{ margin: 10, width: '30%' }}
                data={this.state.price}
                onChange={this.onChangePrice}
              />
            </div>
            <List renderHeader={() => '请选择支付方式'} className='my-list'>
              <div className='payAll-types'>
                <span onClick={() => this.onChangePayType('200')}>
                  <i className='payAll-weixin' />
                  微信支付
                  <em
                    className={
                      this.state.payType === '200'
                        ? 'payAll-types-selected'
                        : ''
                    }
                  />
                </span>
                <span onClick={() => this.onChangePayType('100')}>
                  <i className='payAll-alipay' />
                  支付宝支付
                  <em
                    className={
                      this.state.payType === '100'
                        ? 'payAll-types-selected'
                        : ''
                    }
                  />
                </span>
              </div>
            </List>
            <Button onClick={this.payAll} type='primary'>
              前往支付
            </Button>
            <span styleName={'payAll-tips'}>
              如充值未能及时到账，请耐心等待。
            </span>
          </WingBlank>
        </Fragment>
      </div>
    )
  }
}
