import React, { Fragment } from 'react'
import { Link } from 'dva/router'
import { connect } from 'dva'
import { Button, List, WingBlank, NavBar, Icon } from 'antd-mobile'
import CommonList from '../../components/List'
import { createForm } from 'rc-form'
import { datesFormater, dateFormate } from '@/utils/utils'

import './AccountDatail.less'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class AccountDatail extends CommonList {
  constructor (props) {
    super(props)
    this.state = {
      ...(this.state || {}),
      statusMap: { 0: '全部', 1: '充值', 2: '购彩', 3: '提现', 4: '中奖' },
      currentIndex: 0,
      statusNav: [
        { id: 0, title: '全部' },
        { id: 1, title: '充值' },
        { id: 2, title: '购彩' },
        { id: 3, title: '提现' },
        { id: 4, title: '中奖' }
      ]
    }
  }
  url = 'my/getAccountDetailList'
  keys = ['my', 'accountDetailListInfo']
  params = {
    status: 0
  }

  search = status => {
    this.params.status = status
    this.getData()

    this.setState(
      {
        currentIndex: status
      },
      () => {
        console.log('currenIndex', this.state.currentIndex)
      }
    )
  }

  renderListItem = list => {
    let index = 0

    const row = (rowData, sectionID, rowID) => {
      const item = list[index++]
      return (
        <div>
          {item &&
            <div styleName={'accountDetail-list'}>
              <Item styleName={'accountDetail-list-item'}>
                <div styleName={'accountDetail-left'}>
                  <em>时间：<i>{datesFormater(item.time)}</i></em>
                  <em>类型：<i>{this.state.statusMap[item.type]}</i></em>
                  <em>
                    金额：
                    {item.type === 1 &&
                      <i styleName={'accountDetail-price-positive'}>
                        +{item.amount / 100}元
                      </i>}
                    {item.type === 2 &&
                      <i styleName={'accountDetail-price-negative'}>
                        -{item.amount / 100}元
                      </i>}
                    {item.type === 3 &&
                      <i styleName={'accountDetail-price-negative'}>
                        -{item.amount / 100}元
                      </i>}
                    {item.type === 4 &&
                      <i styleName={'accountDetail-price-positive'}>
                        +{item.amount / 100}元
                      </i>}
                  </em>
                </div>
                <div styleName={'accountDetail-right'}>
                  <em className='accountDetail-limit'>
                    余额：{item.remain / 100}元
                  </em>
                </div>
              </Item>
            </div>}
        </div>
      )
    }
    return row
  }

  render () {
    const { getFieldProps } = this.props.form
    const info = this.props.my.accountDetailListInfo

    return (
      <div className='accountDetail-page'>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.history.goBack()}
        >
          账户明细
        </NavBar>
        <div styleName={'accountDetail-statusNav'}>
          {this.state.statusNav.map((item, index) => {
            return (
              <div
                onClick={() => this.search(item.id)}
                styleName={
                  this.state.currentIndex == item.id
                    ? 'statusNav-selected'
                    : 'statusNav-select'
                }
              >
                {item.title}
              </div>
            )
          })}
        </div>
        <WingBlank className='accountDetail-content' size='lg'>
          {info.list && info.list.length && this.renderList()}
          {info.list.length === 0 &&
            <div className='empty-occupied'>
              <em />
              <p>暂无交易记录</p>
              <p>赶紧去投注</p>
              <Link to={'/home/home'}>
                <Button className='myList-btn-primary' type='primary'>
                  立即投注
                </Button>
              </Link>
            </div>}
        </WingBlank>
        <div styleName={'accountDetail-total'}>
          <div>合计</div>
          <div>
            <em>购彩</em>
            <em>{info.pay_stakes_total / 100}元</em>
          </div>
          <div>
            <em>充值</em>
            <em>{info.charges_total / 100}元</em>
          </div>
          <div>
            <em>中奖</em>
            <em>{info.rewards_total / 100}元</em>
          </div>
          <div>
            <em>提款</em>
            <em>{info.withdraw_total / 100}元</em>
          </div>
        </div>
      </div>
    )
  }
}
