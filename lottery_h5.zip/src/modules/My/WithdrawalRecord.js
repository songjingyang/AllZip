import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  SegmentedControl
} from 'antd-mobile'
import { createForm } from 'rc-form'
import { dateFormater, saveCache, getCache } from '@/utils/utils'
import './WithdrawalRecord.less'

const Item = List.Item

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class WithdrawalRecord extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      statusMap: {
        2: '提现完成',
        3: '已申请',
        4: '被拒绝',
        '': '未知'
      }
    }
  }
  componentDidMount () {
    this.getPeriodManageList()
  }
  getPeriodManageList = () => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        if (!values.page) {
          values.page = 1
        }
        if (!values.page_size) {
          values.page_size = 20
        }
        if (values.timeRange) {
          values.start = parseInt(values.timeRange[0].valueOf() / 1000)
          values.end = parseInt(values.timeRange[1].valueOf() / 1000)
        }
        this.props.dispatch({
          type: 'my/withdrawalRecord',
          payload: {
            ...values
          }
        })
      } else {
        console.log('getProxyAccountInfo parameters error')
      }
    })
  }

  render () {
    const { getFieldProps } = this.props.form
    const info = this.props.my.withdrawalRecordInfo

    return (
      <Fragment>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.history.goBack()}
        >
          提现记录
        </NavBar>
        <div>
          {info.withdraw_data.map(item => {
            return (
              <div styleName={'withdrawalRecord-list'}>
                <Item>
                  <div styleName={'withdrawalRecord-div'}>
                    <em styleName={'withdrawalRecord-price'}>
                      ￥{item.amount / 100}
                    </em>
                    <em styleName={'withdrawalRecord-time'}>
                      {dateFormater(item.created)}
                    </em>
                  </div>
                  <em styleName={'withdrawalRecord-type'}>
                    {this.state.statusMap[item.status]}
                  </em>
                </Item>
              </div>
            )
          })}
        </div>
      </Fragment>
    )
  }
}
