import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Toast,
  Modal,
} from 'antd-mobile'
import SetPay from '../../components/SetPay/index'

import { createForm } from 'rc-form'
import './My.less'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class My extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isShowPass: false,
      isShowSetPayPass: false,
      pass: '',
      files: [
        {
          url: 'https://zos.alipayobjects.com/rmsportal/PZUUCKTRIHWiZSY.jpeg',
          id: '2121',
        },
      ],
      multiple: true,
    }
  }
  componentDidMount() {
    if (localStorage.getItem('user') !== null) {
      this.getMyInfo()
    }
  }

  getMyInfo = () => {
    this.props.dispatch({
      type: 'my/getMyInfo',
      payload: {},
    })
  }

  isLogin = () => {
    console.log('login', localStorage.getItem('user'))
    if (localStorage.getItem('user') !== null) {
      this.props.dispatch(routerRedux.push('/user/persionalInfo'))
    } else {
      this.props.dispatch(routerRedux.push('/user/userLogin'))
    }
  }

  setting = () => {
    if (localStorage.getItem('user') !== null) {
      this.props.dispatch(routerRedux.push('/user/setting'))
    } else {
      this.props.dispatch(routerRedux.push('/user/userLogin'))
    }
  }

  logout = () => {
    this.props.dispatch({
      type: 'user/logout',
      payload: {},
      callback: res => {
        if (res.code === 200) {
          Toast.success(res.msg)
          this.props.dispatch(routerRedux.push('/home/my'))
          window.location.reload()
        }
      },
    })
  }

  my_withdrawal = () => {
    const myInfo = this.props.my.myInfo
    if (myInfo.is_ident_set === 1) {
      this.props.dispatch(routerRedux.push('/my/withdrawalIdentity'))
    } else if (myInfo.is_mobile_set === 1 || myInfo.is_pay_pswd_set === 1) {
      this.setState({ isShowSetPayPass: true })
    } else {
      this.props.dispatch(routerRedux.push('/my/withdrawal'))
    }
  }

  render() {
    const { getFieldProps } = this.props.form
    const info = this.props.my.myInfo
    const alert = Modal.alert
    return (
      <div className="my-page">
        <div styleName={'my-head'}>
          <div onClick={this.isLogin} styleName={'my-head-top'}>
            <div styleName="my-head-avator">
              <img
                style={{ width: '100%' }}
                alt='图片'
                src={
                  info.avatar
                    ? info.avatar
                    : '/static/media/avator.334c416c.png'
                }
              />
            </div>
            <span>{info.nickname ? info.nickname : '未设置昵称'}</span>
          </div>
          {/* <i onClick={this.setting} styleName='my-setting' /> */}
          <span
            onClick={() =>
              alert('确定退出登录', '', [
                { text: '取消', onPress: () => console.log('cancel') },
                { text: '确定', onPress: this.logout },
              ])
            }
            type="primary"
            size="small"
            styleName={'my-logout'}
          >
            {localStorage.getItem('user') ? '退出登录' : ''}
          </span>
        </div>
        <div styleName={'my-list-box'}>
          <div styleName={'my-list-item'}>
            可用余额
            <em>{info.consumable ? info.consumable / 100 : '0.00'} 元</em>
            <Link className="my-btn-primary" to={{ pathname: '/my/payAll' }}>
              充值
            </Link>
          </div>
          <div styleName={'my-line'} />
          <div styleName={'my-list-item'}>
            提现金额
            <em>{info.withdrawable ? info.withdrawable / 100 : '0.00'} 元</em>
            <span onClick={() => this.my_withdrawal()} className="my-btn-ghost">
              提现
            </span>
          </div>
        </div>
        <WingBlank>
          <Link to={'/my/chaseRecord'}>
            <Item arrow="horizontal">
              <div className="my-item-box">
                <i styleName={'my-bettingRecord'} />
                <span className="my-margin">投注记录</span>
              </div>
            </Item>
          </Link>
          <Link className="my-margin" to={'/my/accountDatail'}>
            <Item arrow="horizontal">
              <div className="my-item-box">
                <i styleName={'my-accountDatail'} />
                <span className="my-margin">账户明细</span>
              </div>
            </Item>
          </Link>
          <Link className="my-margin" to={'/my/periodManage'}>
            <Item arrow="horizontal">
              <div className="my-item-box">
                <i styleName={'my-periodManage'} />
                <span className="my-margin">追期管理</span>
              </div>
            </Item>
          </Link>
          <Link className="my-margin" to={'/my/accountInfo'}>
            <Item arrow="horizontal">
              <div className="my-item-box">
                <i styleName={'my-accountInfo'} />
                <span className="my-margin">账户信息</span>
              </div>
            </Item>
          </Link>
          <Link className="my-margin" to={'/my/webkitInfo'}>
            <Item arrow="horizontal">
              <div className="my-item-box">
                <i styleName={'my-webkitInfo'} />
                <span className="my-margin">站内信息</span>
              </div>
            </Item>
          </Link>
        </WingBlank>
        {this.state.isShowSetPayPass && (
          <SetPay
            onFinish={value => {
              this.onBet()
            }}
            onClose={() => this.setState({ isShowSetPayPass: false })}
          />
        )}
      </div>
    )
  }
}
