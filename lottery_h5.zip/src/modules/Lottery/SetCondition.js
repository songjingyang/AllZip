/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-11-23 14:40:55
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Popover, Modal, Tabs, Badge, Radio } from 'antd-mobile'

import './SetCondition.less'

export default class SetCondition extends React.Component {
  constructor (props) {
    super(props)
    this.lines = []
    this.state = {
      periodCount: 200,
      showBrokenLine: true,
      showMiss: true,
      showStatics: true,
      sort: 'desc',
      periodCountData: [
        { value: 30, label: '近30期' },
        { value: 50, label: '近50期' },
        { value: 100, label: '近100期' },
        { value: 200, label: '近200期' }
      ],
      brokenLineData: [
        { value: true, label: '显示' },
        { value: false, label: '隐藏' }
      ],
      missData: [{ value: true, label: '显示' }, { value: false, label: '隐藏' }],
      staticsData: [
        { value: true, label: '显示' },
        { value: false, label: '隐藏' }
      ],
      sortData: [{ value: 'desc', label: '顺序' }, { value: 'asc', label: '倒序' }]
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.value) {
      this.setState({
        ...nextProps.value
      })
    }
  }

  onChange = (value, prop) => {
    this.setState({
      [prop]: value
    })
  }
  onOk = () => {
    this.props.onChange({
      periodCount: this.state.periodCount,
      showBrokenLine: this.state.showBrokenLine,
      showMiss: this.state.showMiss,
      showStatics: this.state.showStatics,
      sort: this.state.sort
    })
  }
  render () {
    return (
      <Modal
        visible={this.props.visible}
        transparent
        maskClosable={false}
        onClose={() => this.showSet(false)}
        title={
          <div>
            <span className='set2' />
            走势图设置
          </div>
        }
        footer={[
          {
            text: '取消',
            onPress: () => {
              this.props.onCancel()
            }
          },
          { text: '确定', onPress: this.onOk }
        ]}
        wrapProps={{ onTouchStart: this.onWrapTouchStart }}
      >
        <div>
          <div className='form'>
            <div className='form-item'>
              <div className='form-label'>期数：</div>
              <div className='form-con'>
                {this.state.periodCountData.map(item => (
                  <Radio
                    key={item.value}
                    checked={this.state.periodCount === item.value}
                    onChange={() => this.onChange(item.value, 'periodCount')}
                  >
                    {item.label}
                  </Radio>
                ))}
              </div>
            </div>
            <div className='form-item'>
              <div className='form-label'>排列：</div>
              <div className='form-con'>
                {this.state.sortData.map(item => (
                  <Radio
                    key={item.value}
                    checked={this.state.sort === item.value}
                    onChange={() => this.onChange(item.value, 'sort')}
                  >
                    {item.label}
                  </Radio>
                ))}
              </div>
            </div>
            <div className='form-item'>
              <div className='form-label'>折线：</div>
              <div className='form-con'>
                {this.state.brokenLineData.map(item => (
                  <Radio
                    key={item.value}
                    checked={this.state.showBrokenLine === item.value}
                    onChange={() => this.onChange(item.value, 'showBrokenLine')}
                  >
                    {item.label}
                  </Radio>
                ))}
              </div>
            </div>
            <div className='form-item'>
              <div className='form-label'>遗漏：</div>
              <div className='form-con'>
                {this.state.missData.map(item => (
                  <Radio
                    key={item.value}
                    checked={this.state.showMiss === item.value}
                    onChange={() => this.onChange(item.value, 'showMiss')}
                  >
                    {item.label}
                  </Radio>
                ))}
              </div>
            </div>
            <div className='form-item'>
              <div className='form-label'>统计：</div>
              <div className='form-con'>
                {this.state.staticsData.map(item => (
                  <Radio
                    key={item.value}
                    checked={this.state.showStatics === item.value}
                    onChange={() => this.onChange(item.value, 'showStatics')}
                  >
                    {item.label}
                  </Radio>
                ))}
                <p>（走势图底部的出现次数等统计数据）</p>
              </div>
            </div>
          </div>
        </div>
      </Modal>
    )
  }
}
