/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-12-18 18:55:12
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Popover, Modal, Tabs, Badge, Radio } from 'antd-mobile'
import Table from 'rc-table'

import RadioTag from '@/components/RadioTag'
import CheckboxTag from '@/components/CheckboxTag'
import CountDown from '@/components/CountDown'
import ConnectLine from '../../components/ConnectLine'
import SetCondition from './SetCondition'
import {
  getLotteryCount,
  randomBet,
  commonCount,
  baseNum,
  sums,
  erbutong,
  xingtai,
  waitDrawLotteryRender,
} from '../../utils/lottery'

import { getTickPlayType } from '../../utils/lotteryPlayTypeData'
import './TickTrend.less'
import { saveCache, guid } from '../../utils/utils'

@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class Tick extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      scrollY: '',
      isShowSet: false,
      visible: false,
      playTypeVisible: false,
      playType: getTickPlayType(),
      currPlayType: 'big_small_odd_even',
      count: 0,
      price: 0,
      periodCount: 30,
      showBrokenLine: true,
      showMiss: true,
      showStatics: true,
      sort: 'desc',

      tabs: [{ title: '开奖' }, { title: '基本走势' }, { title: '和值走势' }],
      sumDrawLotteryColumns: [
        {
          title: (
            <div onClick={this.sort} className={'sort'}>
              期数
            </div>
          ),
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(4),
        },
        {
          title: '和值',
          dataIndex: 'sum',
          key: 'sum',
          className: 'sum',
          render: waitDrawLotteryRender(0),
        },

        {
          title: '大小',
          dataIndex: 'size',
          key: 'size',
          className: 'size',
          render: waitDrawLotteryRender(0),
        },
        {
          title: '单双',
          dataIndex: 'odd_even',
          key: 'odd_even',
          className: 'odd-even',
          render: waitDrawLotteryRender(0),
        },
      ],
      drawLotteryColumns: [
        {
          title: '期数',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(2),
        },
        {
          title: '形态',
          dataIndex: 'xingtai',
          key: 'xingtai',
          className: 'xingtai',
          render: waitDrawLotteryRender(0, (value, row, index) => {
            return value.value
          }),
        },
      ],

      baseColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(baseNum.length + 2),
        },
        {
          title: '和值',
          dataIndex: 'sum',
          key: 'sum',
          className: 'sum',
          render: waitDrawLotteryRender(0),
        },
        {
          title: '跨度',
          dataIndex: 'span',
          key: 'span',
          className: 'span',
          render: waitDrawLotteryRender(0),
        },
      ].concat(this.getNumColumn([...baseNum], 'baseNum')),
      baseColumnsStatics: [
        {
          title: 'title',
          dataIndex: 'title',
          key: 'title',
          className: 'statics-title',
        },
      ].concat(this.getStaticsColumn([...baseNum])),
      sumColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
          fixed: 'left',
        },
      ].concat(this.getNumColumn([...sums], 'sums')),
      sumsColumnsStatics: [
        {
          title: '',
          dataIndex: 'title',
          key: 'title',
          className: 'statics-title',
          fixed: 'left',
        },
      ].concat(this.getStaticsColumn([...sums])),
      xingtaiColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(xingtai.length + 1),
        },
      ].concat(this.getXingtaiColumn([...xingtai], 'xingtai')),
      xingtaiColumnsStatics: [
        {
          title: '',
          dataIndex: 'title',
          key: 'title',
          className: 'title',
        },
      ].concat(this.getStaticsColumn([...xingtai])),
      doubleSamePluralColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(7),
        },

        this.getDoubleSamePluralColumn(1),
        this.getDoubleSamePluralColumn(2),
        this.getDoubleSamePluralColumn(3),
        this.getDoubleSamePluralColumn(4),
        this.getDoubleSamePluralColumn(5),
        this.getDoubleSamePluralColumn(6),
      ],
      doubleDifferentSingleColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
          fixed: 'left',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(erbutong.length + 1),
          fixed: 'left',
        },
      ].concat(this.getNumColumn([...erbutong], 'erbutong')),
      erbutongColumnsStatics: [
        {
          title: '',
          dataIndex: 'title',
          key: 'title',
          className: 'statics-title',
          fixed: 'left',
        },
      ].concat(this.getStaticsColumn([...erbutong])),
      xingtaiColumnsStatics: [
        {
          title: '',
          dataIndex: 'title',
          key: 'title',
          className: 'statics-title',
          fixed: 'left',
        },
      ].concat(this.getStaticsColumn([...xingtai], 'xingtai')),
    }
  }

  sort = () => {
    this.setState(
      {
        sort: this.state.sort === 'desc' ? 'asc' : 'desc',
      },
      () => {
        this.getTrendData()
      }
    )
  }
  sortClassName = () => {
    return 'sort-period' + this.state.sort === 'desc' ? 'asc' : 'desc'
  }

  getStaticsColumn = nums => {
    return nums.map((item, index) => {
      return {
        title: `${item}`,
        dataIndex: `num${index + 1}`,
        key: `num${item}`,
        className: `num num${index + 1}`,
      }
    })
  }

  getNumColumn = (nums, key) => {
    return nums.map((item, index) => {
      return {
        title: item,
        dataIndex: item,
        key: item,
        className: 'num',
        render: waitDrawLotteryRender(0, (value, row) => {
          let item = null
          if (!row[key] || !row[key][index]) return
          item = row[key][index]

          if (item.isDrawNum) {
            if (item.showCount === 1) {
              return (
                <span className="draw-lottery-num">
                  {item.showCount === 1 && item.value}
                </span>
              )
            } else {
              return (
                <span className="draw-lottery-num">
                  {item.showCount > 1 && (
                    <Badge text={item.showCount}>{item.value}</Badge>
                  )}
                </span>
              )
            }
          } else {
            if (!this.state.showMiss) return ''
            return item.value
          }
        }),
      }
    })
  }

  getDoubleSamePluralColumn = num => {
    return {
      title: `${num}${num}`,
      dataIndex: `${num}`,
      key: `${num}`,
      className: `num num${num}${num}`,
      render: waitDrawLotteryRender(0, (value, row) => {
        if (row.winnerNumber.join('').indexOf(`${num}${num}`) >= 0) {
          return <span className="draw-lottery-num">{`${num}${num}`}</span>
        } else {
          return row.missNumber.ertong[num - 1]
        }
      }),
    }
  }

  getXingtaiColumn = (nums, key) => {
    return nums.map((item, index) => {
      return {
        title: item,
        dataIndex: item,
        key: item,
        className: `xingtai xingtai${index}`,
        render: waitDrawLotteryRender(0, (value, row) => {
          let item = null
          if (!row[key] || !row[key][index]) return
          item = row[key][index]

          if (item.isDrawNum) {
            if (item.showCount === 1) {
              return (
                <span className="draw-lottery-num">
                  {item.showCount === 1 && item.value}
                </span>
              )
            } else {
              return (
                <span className="draw-lottery-num">
                  {item.showCount > 1 && (
                    <Badge text={item.showCount}>{item.value}</Badge>
                  )}
                </span>
              )
            }
          } else {
            if (!this.state.showMiss) return ''
            return item.value
          }
        }),
      }
    })
  }
  componentDidMount() {
    const lotteryName = this.props.match.params.lotteryName
    this.getTrendData()

    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  onSelect = opt => {
    // console.log(opt.props.value);
    this.setState({
      visible: false,
      currPlayType: opt.props.value,
    })
  }
  handleVisibleChange = visible => {
    this.setState({
      visible,
    })
  }
  handlePlayTypeVisibleChange = playTypeVisible => {
    this.setState({
      playTypeVisible,
    })
  }

  onChangePlayType = item => {
    setTimeout(() => {
      let currPlayType = item.value
      let tabs = this.state.tabs
      let lastTab = tabs[tabs.length - 1]
      let title = ''

      switch (currPlayType) {
        case 'sum':
          title = '和值走势'
          break
        case 'double_same_plural':
        case 'double_different_single':
          title = '号码分布'
          break
        case 'triple_different':
        case 'triple_same_each':
          title = '形态走势'
          break
        default:
          break
      }
      lastTab.title = title

      this.setState({
        playTypeVisible: false,
        currPlayType: item.value,
        tabs: tabs,
      })
    }, 200)
  }

  onChangeOption = (itemData, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    let options = playTypeInfo.options
    let options2 = playTypeInfo.options2
    let options3 = playTypeInfo.options3
    let options4 = playTypeInfo.options4
    let options5 = playTypeInfo.options5
    let selectedPlayTypeOptions =
      options && options.filter(item => item.selected)
    let selectedPlayTypeOptions2 =
      options2 && options2.filter(item => item.selected)
    let selectedPlayTypeOptions3 =
      options3 && options3.filter(item => item.selected)
    let selectedPlayTypeOptions4 =
      options4 && options4.filter(item => item.selected)
    let selectedPlayTypeOptions5 =
      options5 && options5.filter(item => item.selected)

    let count = 0

    count = getLotteryCount(
      currPlayType,
      selectedPlayTypeOptions,
      selectedPlayTypeOptions2,
      selectedPlayTypeOptions3,
      selectedPlayTypeOptions4,
      selectedPlayTypeOptions5
    )

    switch (currPlayType) {
      case 'any_two': //

      default:
    }

    this.setState({
      count: count,
      playType: [...this.state.playType],
    })
  }

  onChangeOption2 = (itemData, allSelected, all, index, setSelectedFn) => {
    this.onChangeOption(itemData, allSelected, all, index, setSelectedFn)
  }
  onChangeOption3 = (itemData, allSelected, all, index, setSelectedFn) => {
    this.onChangeOption(itemData, allSelected, all, index, setSelectedFn)
  }

  setSelectedFn = (tags, willTags, selected) => {
    tags.forEach(item => {
      let isUpdate = false
      willTags.forEach(itemData => {
        if (itemData.value === item.value) {
          isUpdate = true
        }
      })
      if (isUpdate) {
        item.selected = selected
      }
    })
  }

  onDel = () => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)

    if (this.state.count > 0) {
      playTypeInfo.options.forEach(item => (item.selected = false))
      playTypeInfo.options2 &&
        playTypeInfo.options2.forEach(item => (item.selected = false))
      playTypeInfo.options3 &&
        playTypeInfo.options3.forEach(item => (item.selected = false))
      playTypeInfo.options4 &&
        playTypeInfo.options4.forEach(item => (item.selected = false))
      playTypeInfo.options5 &&
        playTypeInfo.options5.forEach(item => (item.selected = false))
      playTypeInfo.options6 &&
        playTypeInfo.options6.forEach(item => (item.selected = false))
      playTypeInfo.options7 &&
        playTypeInfo.options7.forEach(item => (item.selected = false))

      this.setState({
        count: 0,
        playType: [...this.state.playType],
      })
    } else {
      let count = randomBet(this.props.match.params.lotteryName, playTypeInfo)

      this.setState({
        count: count,
        playType: [...this.state.playType],
      })
    }
  }

  onConfirm = () => {
    const lotteryName = this.props.match.params.lotteryName
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    const values = playTypeInfo.options
      .filter(item => item.selected)
      .map(item => item.value)
    let values2 =
      playTypeInfo.options2 &&
      playTypeInfo.options2
        .filter(item => item.selected)
        .map(item => item.value)
    let values3 =
      playTypeInfo.options3 &&
      playTypeInfo.options3
        .filter(item => item.selected)
        .map(item => item.value)
    let values4 =
      playTypeInfo.options4 &&
      playTypeInfo.options4
        .filter(item => item.selected)
        .map(item => item.value)
    let values5 =
      playTypeInfo.options5 &&
      playTypeInfo.options5
        .filter(item => item.selected)
        .map(item => item.value)

    if (values5) {
      if (
        values.length +
          values2.length +
          values3.length +
          values4.length +
          values5.length <
        playTypeInfo.selectedCount
      ) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else if (values4) {
      if (
        values.length + values2.length + values3.length + values4.length <
        playTypeInfo.selectedCount
      ) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else if (values3) {
      if (
        values.length + values2.length + values3.length <
        playTypeInfo.selectedCount
      ) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else if (values2) {
      if (values.length + values2.length < playTypeInfo.selectedCount) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else {
      if (values.length < playTypeInfo.selectedCount) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    }

    if (this.state.count === 0) {
      Modal.alert('提示', `请选择至少选择1注`)
      return
    }

    const selectNumId = guid()
    saveCache('selectNums', {
      [selectNumId]: {
        values: values,
        values2: values2,
        values3: values3,
        values4: values4,
        values5: values5,
        playType: currPlayType,
      },
    })

    // lotteryName/:playType/:playTypeName/:val/:val2
    const url = `/lottery/bet/${lotteryName}/${selectNumId}`
    this.props.dispatch(routerRedux.push(url))
  }

  getCurrPlayType = playTypeName => {
    const playTypeInfo = this.state.playType.find(
      item => item.value === playTypeName
    )
    return playTypeInfo
  }

  nextPeriodTip = () => {
    Modal.alert('提示', '当前期次结束，是否购买下一期')
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  showSet = bool => {
    this.setState({
      isShowSet: bool,
    })
  }
  onChangeCondition = value => {
    const state = { ...this.state }
    this.setState({ ...value }, () => {
      if (
        state.periodCount !== value.periodCount ||
        state.sort !== value.sort
      ) {
        this.getTrendData()
      }
    })
    this.showSet(false)
  }

  getTrendData = () => {
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getTrend',
      payload: {
        lotteryName: lotteryName,
        lottery_name: lotteryName,
        periodCount: this.state.periodCount,
        showBrokenLine: this.state.showBrokenLine,
        showMiss: this.state.showMiss,
        showStatics: this.state.showStatics,
        sort: this.state.sort,
      },
    })
  }

  render() {
    const { lotteryInfo } = this.props.lottery
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)

    const middlePop = (
      <Popover
        overlayStyle={{ color: 'currentColor' }}
        visible={this.state.playTypeVisible}
        placement="bottom"
        mask
        overlay={
          <div styleName="play-type-list">
            <RadioTag
              itemClassName={'tag-item'}
              itemStyle={{
                margin: 10,
                width: '30%',
              }}
              data={this.state.playType}
              onChange={this.onChangePlayType}
            />
          </div>
        }
        align={{
          overflow: { adjustY: 0, adjustX: 0 },
          offset: [-10, 0],
        }}
        onVisibleChange={this.handlePlayTypeVisibleChange}
        onSelect={this.onSelect}
      >
        <div
          style={{
            height: '100%',
            padding: '0 15px',
            marginRight: '-15px',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          {playTypeInfo.label}
          {this.state.playTypeVisible && <span styleName="up" />}
          {!this.state.playTypeVisible && <span styleName="down" />}
        </div>
      </Popover>
    )

    return (
      <div styleName="lottery-page">
        <NavBar
          mode="dark"
          leftContent={
            <Icon
              onClick={() => {
                this.props.history.go(-1)
              }}
              type="left"
              size="md"
            />
          }
          rightContent={
            <span className="set" onClick={() => this.showSet(true)} />
          }
        >
          {middlePop}
        </NavBar>
        <SetCondition
          value={{
            periodCount: this.state.periodCount,
            showBrokenLine: this.state.showBrokenLine,
            showMiss: this.state.showMiss,
            showStatics: this.state.showStatics,
            sort: this.state.sort,
          }}
          visible={this.state.isShowSet}
          onChange={this.onChangeCondition}
          onCancel={() => this.showSet(false)}
        />
        {/* <div className='lottery-nums-body' styleName='body'> */}
        <div className="lottery-nums-body" styleName="body">
          <Tabs
            tabs={this.state.tabs}
            initialPage={1}
            swipeable={false}
            prerenderingSiblingsNumber={false}
          >
            <div className="draw-lottery">
              {currPlayType === 'sum' && (
                <Table
                  scroll={{ y: this.state.scrollY }}
                  className="trend-data"
                  columns={this.state.sumDrawLotteryColumns}
                  data={this.props.lottery.trend.data}
                />
              )}
              {currPlayType !== 'sum' && (
                <Table
                  scroll={{ y: this.state.scrollY }}
                  className="trend-data"
                  columns={this.state.drawLotteryColumns}
                  data={this.props.lottery.trend.data}
                />
              )}
            </div>
            <div className="base-trend">
              <Table
                scroll={{ y: this.state.scrollY }}
                className="trend-data"
                columns={this.state.baseColumns}
                data={this.props.lottery.trend.data}
              />
              {this.state.showStatics && (
                <Table
                  scroll={{ y: this.state.scrollY }}
                  className="trend-statics"
                  useFixedHeader
                  columns={this.state.baseColumnsStatics}
                  data={this.props.lottery.trend.baseStaticsData}
                  showHeader={false}
                />
              )}
            </div>
            <div className="sum-trend">
              {currPlayType === 'sum' && (
                <Fragment>
                  <Table
                    scroll={{ y: this.state.scrollY, x: 1000 }}
                    className="sum-trend"
                    columns={this.state.sumColumns}
                    useFixedHeader
                    data={this.props.lottery.trend.data}
                  />
                  {this.state.showBrokenLine && (
                    <ConnectLine
                      elems={'.sum-trend .draw-lottery-num'}
                      container={'.sum-trend .rc-table'}
                      xContainer={'.sum-trend .rc-table-body'}
                    />
                  )}
                  {this.state.showStatics && (
                    <Table
                      scroll={{ y: this.state.scrollY, x: 1000 }}
                      className="trend-statics"
                      columns={this.state.sumsColumnsStatics}
                      data={this.props.lottery.trend.sumsStaticsData}
                      showHeader={false}
                    />
                  )}
                </Fragment>
              )}
              {currPlayType === 'double_same_plural' && (
                <Table
                  scroll={{ y: this.state.scrollY }}
                  className="double_same_plural-trend"
                  columns={this.state.doubleSamePluralColumns}
                  data={this.props.lottery.trend.data}
                />
              )}
              {currPlayType === 'double_different_single' && (
                <Fragment>
                  <Table
                    scroll={{ y: this.state.scrollY, x: 1040 }}
                    className="double_different_single-trend"
                    columns={this.state.doubleDifferentSingleColumns}
                    data={this.props.lottery.trend.data}
                  />
                  {this.state.showStatics && (
                    <Table
                      scroll={{ y: this.state.scrollY, x: 1040 }}
                      className="double_different_single-statics"
                      columns={this.state.erbutongColumnsStatics}
                      data={this.props.lottery.trend.erbutongStaticsData}
                      showHeader={false}
                    />
                  )}
                </Fragment>
              )}
              {(currPlayType === 'triple_different' ||
                currPlayType === 'triple_same_each') && (
                <Fragment>
                  <Table
                    scroll={{ y: this.state.scrollY }}
                    className="xingtai-trend"
                    columns={this.state.xingtaiColumns}
                    data={this.props.lottery.trend.data}
                  />
                  {this.state.showStatics && (
                    <Table
                      scroll={{ y: this.state.scrollY }}
                      className="trend-statics"
                      columns={this.state.xingtaiColumnsStatics}
                      data={this.props.lottery.trend.xingtaiStaticsData}
                      showHeader={false}
                    />
                  )}
                  }
                </Fragment>
              )}
            </div>
          </Tabs>
        </div>
        <div className="trend-footer" styleName="footer">
          <div styleName="footer-top">
            <span styleName="label">选号：</span>
            <div styleName="footer-top-scroll">
              <CheckboxTag
                itemClassName={`tag-item`}
                isShowValue
                // className={`${playTypeInfo.value}`}
                data={playTypeInfo.options}
                onChange={this.onChangeOption}
              />
            </div>
          </div>
          <div styleName="footer-bottom">
            <div styleName="time-label">
              距{lotteryInfo.last_period}
              期截止:
            </div>
            <CountDown
              styleName="time"
              onEnd={this.nextPeriodTip}
              target={new Date().getTime() + lotteryInfo.staking_countdown}
            />
            <a onClick={this.onConfirm} styleName="bet-btn">
              确定
            </a>
          </div>
        </div>
      </div>
    )
  }
}
