/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-12-18 17:47:15
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import {
  NavBar,
  Icon,
  Card,
  Button,
  WingBlank,
  WhiteSpace,
  Modal,
} from 'antd-mobile'
import { createForm } from 'rc-form'
import CheckboxTag from '@/components/CheckboxTag'
import CountDown from '@/components/CountDown'
import { getLotteryCount, getRandomDraw } from '@/utils/lottery'
import { saveCache, getCache, guid } from '@/utils/utils'
import './Pay.less'
import PayPass from '../../components/PayPass/index'

@createForm()
@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class Pay extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isShowPass: false,
      isShowSetPayPass: false,
      pass: '',
      count: 0,
    }
  }
  componentDidMount() {
    const params = this.props.match.params
    const lotteryName = params.lotteryName

    this.props.dispatch({
      type: 'lottery/getUserWalletInfo',
      payload: {
        lotteryName: lotteryName,
      },
      callback: res => {
        if (res.code === 200) {
        }
      },
    })
  }

  jumpHome = () => {
    // this.props.dispatch(routerRedux.push(`/home/home`))
    this.props.history.goBack()
  }
  valid = () => {
    const params = this.props.match.params
    const orderData = JSON.parse(params.orderData)

    if (params.price * 100 > this.props.lottery.userWalletInfo.consumable) {
      Modal.alert('提示', '余额不足请去充值', [
        { text: '取消', onPress: () => console.log('cancel') },
        {
          text: '去充值',
          onPress: () => this.props.dispatch(routerRedux.push('/my/payAll')),
        },
      ])
      return
    }

    this.setState({ isShowPass: true })
  }
  pay = () => {
    const params = this.props.match.params
    const orderData = JSON.parse(params.orderData)

    // if (params.price * 100 > this.props.lottery.userWalletInfo.consumable) {
    //   Modal.alert('提示', '余额不足请去充值', [
    //     { text: '取消', onPress: () => console.log('cancel') },
    //     {
    //       text: '去充值',
    //       onPress: () => this.props.dispatch(routerRedux.push('/my/payAll')),
    //     },
    //   ])
    //   return
    // }

    this.props.dispatch({
      type: 'lottery/bet',
      payload: {
        ...orderData,
      },
      callback: res => {
        if (res.code === 200) {
          const data = res.payload

          this.props.dispatch({
            type: 'lottery/pay',
            payload: {
              order_id: data.order_id,
              amount: +params.price * 100, // 付款金额  单位：分
              // merchant_id: '{{global.merchant_id}}'
              pay_pswd: this.state.pass,
            },
            callback: res => {
              if (res.code === 200) {
                const orderDetail =
                  params.chase > 1 ? 'ChaseOrderDetail' : 'orderDetail'

                this.props.dispatch(
                  routerRedux.push(
                    `/lottery/${orderDetail}/${data.order_id}/${
                      params.lotteryName
                    }`
                  )
                )
              }
            },
          })
        }
      },
    })
  }

  render() {
    const { lotteryInfo } = this.props.lottery
    const params = this.props.match.params

    return (
      <div styleName="pay-page">
        <NavBar
          mode="dark"
          leftContent={<Icon onClick={this.jumpHome} type="left" size="md" />}
        >
          支付
        </NavBar>
        <WingBlank size="lg">
          <WhiteSpace size="lg" />
          <Card>
            <Card.Body styleName="card-content">
              <div className="clearfix" styleName="order-price">
                <div styleName="label">订单金额：</div>
                <div styleName="price">{params.price}元</div>
              </div>
              <div className="clearfix" styleName="user-balance">
                <div styleName="label">
                  <span styleName="wallet-icon" /> 钱包快捷支付：
                </div>
                <div styleName="price">
                  余额：
                  {this.props.lottery.userWalletInfo.consumable / 100}元
                </div>
              </div>
            </Card.Body>
          </Card>
          <WhiteSpace size="lg" />
        </WingBlank>
        <Button onClick={this.valid} type="warning">
          确认付款
        </Button>
        {this.state.isShowPass && (
          <PayPass
            onConfirm={value => {
              this.setState({ pass: value }, () => {
                this.pay()
              })
            }}
            onClose={() => this.setState({ isShowPass: false })}
          />
        )}
      </div>
    )
  }
}
