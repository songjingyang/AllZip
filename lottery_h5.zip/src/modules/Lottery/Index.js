/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: 吾彦が一番美しい
 * @Last Modified time: 2019-02-25 16:36:00
 */
import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  Carousel,
  List,
  NoticeBar,
  Grid,
  WhiteSpace,
  Button,
  WingBlank,
  Toast,
} from 'antd-mobile'
import { createForm } from 'rc-form'
import CountDown from '../../components/CountDown'
import { getCache } from '../../utils/utils'
import './Index.less'
import { getLotteryName } from '../../utils/lottery'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class Index extends React.Component {
  constructor(props) {
    super(props)
    this.state = {}
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'lottery/getHomeInfo',
      payload: {},
    })
  }

  getJumpUrl = item => {
    let url = ''
    if (/fast_three/.test(item.name)) {
      url = '/lottery/fastThree/' + item.name
    } else if (/eleven_five/.test(item.name)) {
      url = '/lottery/elevenFive/' + item.name
    } else if (/tick/.test(item.name)) {
      url = '/lottery/tick/' + item.name
    }

    if (url) {
      const drawData = getCache(`${item.name}drawData`) || []
      if (drawData.length) {
        url = `/lottery/bet/${item.name}/1`
      }
    }

    // if (getLotteryName(item.tag) === 'tick_tick') {
    //   Toast.offline('敬请期待', 1)
    //   return
    // }

    this.props.dispatch(routerRedux.push(url))
  }

  render() {
    const { getFieldProps } = this.props.form
    const { banners, tips, lotteries } = this.props.lottery

    return (
      <div className="index-page" styleName="index-page">
        <Carousel styleName="banner" autoplay infinite>
          {banners.map(item => (
            <a styleName="banner-item" key={item.url} href={item.href}>
              <img src={item.url} alt="" />
            </a>
          ))}
        </Carousel>
        <WhiteSpace size="sm" style={{ background: '#F3F3F3' }} />
        <div className="clearfix" styleName="lottery">
          {lotteries.map(item => (
            <div
              key={item.tag}
              onClick={() => this.getJumpUrl(item)}
              styleName="lottery-item"
            >
              <img src={item.icon_url} alt="" />
              <div styleName="desc">
                <div styleName="title">{item.show}</div>
                {item.lottery_state === 2 && (
                  <div styleName="sub">
                    距截止:
                    <CountDown
                      target={new Date().getTime() + item.staking_countdown}
                    />
                  </div>
                )}
                {item.lottery_state === 1 && (
                  <div styleName="sub">暂停销售</div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }
}
