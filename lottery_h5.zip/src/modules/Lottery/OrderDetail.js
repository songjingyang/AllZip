/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-12-18 18:38:05
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Card, Button, WingBlank, WhiteSpace } from 'antd-mobile'
import { createForm } from 'rc-form'
import CheckboxTag from '@/components/CheckboxTag'
import CountDown from '@/components/CountDown'
import { getCurrPlayType } from '../../utils/lottery'
import { dateFormater, saveCache, getCache } from '@/utils/utils'
import './OrderDetail.less'
import {
  getLotteryNameLabel,
  buildMyBetData,
  getDrawDataKey,
  showOrderDetailNum,
} from '../../utils/lottery'

@createForm()
@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class OrderDetail extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      count: 0,
      orderStatusMap: { 1: '未付款', 2: '已付款', 3: '' },
      statusMap: { 1: '未中奖', 2: '中奖', 3: '等待开奖', '': '等待开奖' },
    }
  }
  componentDidMount() {
    const params = this.props.match.params

    this.props.dispatch({
      type: 'lottery/getOrderInfo',
      payload: {
        order_id: params.orderId,
        lotteryName: params.lotteryName,
      },
    })
  }

  jumpHome = () => {
    // this.props.dispatch(routerRedux.push(`/home/home`))
    this.props.history.goBack()
  }

  pay = () => {
    const params = this.props.match.params
    this.props.dispatch({
      type: 'lottery/pay',
      payload: {
        order_id: params.orderId,
        amount: params.price, // 付款金额  单位：分
        // merchant_id: '{{global.merchant_id}}'
      },
      callback: res => {
        if (res.code === 200) {
          this.props.dispatch(routerRedux.push('/lotter/xxx'))
        }
      },
    })
  }

  buy = item => {
    const params = this.props.match.params
    console.log(
      'TCL: OrderDetail -> this.props.orderInfo',
      this.props.lottery.orderInfo
    )
    const drawData = buildMyBetData(
      this.props.lottery.orderInfo.periods[0].stakes,
      params.lotteryName
    )
    saveCache(getDrawDataKey(params.lotteryName), drawData)

    this.props.dispatch(
      routerRedux.push(`/lottery/bet/${params.lotteryName}/0`)
    )
  }
  bet = item => {
    const params = this.props.match.params
    saveCache(`${params.lotteryName}drawData`, [])
    this.props.dispatch(
      routerRedux.push(`/lottery/fastThree/${params.lotteryName}`)
    )
  }

  render() {
    const { orderInfo } = this.props.lottery
    const params = this.props.match.params
    const currPeriod = orderInfo.periods.length && orderInfo.periods[0]

    return (
      <div styleName="order-detail-page">
        <NavBar
          mode="dark"
          leftContent={<Icon onClick={this.jumpHome} type="left" size="md" />}
        >
          订单详情
        </NavBar>
        <div styleName="header-top">
          <span styleName="name">
            {getLotteryNameLabel(this.props.match.params.lotteryName)}
          </span>
          <span styleName="period">第{currPeriod && currPeriod.period}期</span>
          <span styleName="status">
            {
              this.state.statusMap[
                orderInfo.rewards || (currPeriod && currPeriod.status) || ''
              ]
            }
          </span>
        </div>
        <div className="clearfix" styleName="header">
          <div styleName="price item">
            <div styleName="label">购买金额</div>
            <div styleName="value">{orderInfo.cost / 100}元</div>
          </div>
          <div styleName="status item">
            <div styleName="label">订单状态</div>
            <div styleName="value">
              {this.state.orderStatusMap[orderInfo.status]}
            </div>
          </div>
          <div styleName="rewards item">
            <div styleName="label">税后奖金</div>
            <div styleName="value">{orderInfo.total_rewards / 100}元</div>
          </div>
        </div>
        <div styleName="bet-detail">
          <div styleName="title">
            <span styleName="name">投注详情</span>{' '}
            <span styleName="times">
              {orderInfo.times}倍{orderInfo.stakes_count}注
            </span>
          </div>
          <table>
            <thead>
              <tr>
                <td styleName="play-type">玩法</td>
                <td styleName="play-type-num">投注号码</td>
              </tr>
            </thead>
            <tbody>
              {orderInfo &&
                orderInfo.stakes.map(item => (
                  <tr style={{ color: item.status === 2 ? 'red' : '#000' }}>
                    <td>
                      {getCurrPlayType(params.lotteryName, item.gameplay).label}
                      {item.is_dan_tuo == 2 ? '胆拖' : ''}{' '}
                    </td>
                    <td>{showOrderDetailNum(item)}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
        <div styleName="order-detail">
          <div styleName="title">
            <span styleName="name">订单详情</span>
          </div>
          <div styleName="list">
            <div className="clearfix" styleName="item">
              <div styleName="label">开奖时间：</div>
              <div styleName="value">
                {dateFormater(currPeriod && currPeriod.draw_ts)}
              </div>
            </div>
            <div className="clearfix" styleName="item">
              <div styleName="label">下单时间：</div>
              <div styleName="value">{dateFormater(orderInfo.stake_ts)}</div>
            </div>
            <div className="clearfix" styleName="item">
              <div styleName="label">订单编号：</div>
              <div styleName="value">{orderInfo.order_id}</div>
            </div>
          </div>
        </div>
        <div styleName="footer">
          <Button onClick={this.buy} type="ghost" inline styleName="buy">
            继续购买本单号码
          </Button>
          <Button onClick={this.bet} type="primary" inline styleName="bet">
            继续购买下注
          </Button>
        </div>
      </div>
    )
  }
}
