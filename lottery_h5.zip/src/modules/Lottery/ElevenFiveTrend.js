/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-12-18 18:55:01
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Popover, Modal, Tabs, Badge, Radio } from 'antd-mobile'
import Table from 'rc-table'

import RadioTag from '../../components/RadioTag'
import CheckboxTag from '../../components/CheckboxTag'
import CountDown from '../../components/CountDown'
import ConnectLine from '../../components/ConnectLine'
import SetCondition from './SetCondition'
import {
  getRandomDraw,
  getLotteryCount,
  randomBet,
  commonCount,
  baseNum,
  sums,
  erbutong,
  xingtai,
  waitDrawLotteryRender,
  eleven,
  elevenXingtai,
} from '../../utils/lottery'
import { getElevenFivePlayType } from '../../utils/lotteryPlayTypeData'
import './ElevenFiveTrend.less'
import { saveCache, guid } from '../../utils/utils'

@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class ElevenFive extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      scrollY: '',
      isShowSet: false,
      visible: false,
      playTypeVisible: false,
      playType: getElevenFivePlayType(),
      currPlayType: 'any_two',
      count: 0,
      price: 0,
      periodCount: 30,
      showBrokenLine: true,
      showMiss: true,
      showStatics: true,
      sort: 'desc',

      tabs: [{ title: '开奖' }, { title: '走势' }, { title: '形态' }],
      drawLotteryColumns: [
        {
          title: (
            <div onClick={this.sort} className={'sort'}>
              期数
            </div>
          ),
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(4),
        },
        {
          title: '和值',
          dataIndex: 'sum',
          key: 'sum',
          className: 'sum',
          render: waitDrawLotteryRender(0),
        },
        {
          title: '跨度',
          dataIndex: 'span',
          key: 'span',
          className: 'span',
          render: waitDrawLotteryRender(0),
        },
        {
          title: '重号个数',
          dataIndex: 'overNum',
          key: 'overNum',
          className: 'over-num',
          render: waitDrawLotteryRender(0),
        },
      ],
      // drawLotteryColumns: [
      //   {
      //     title: '期数',
      //     dataIndex: 'short_period',
      //     key: 'short_period',
      //     className: 'period'
      //   },
      //   {
      //     title: '开奖号',
      //     dataIndex: 'win_num',
      //     key: 'win_num',
      //     className: 'win-num',
      //     render: waitDrawLotteryRender(2)
      //   },
      //   {
      //     title: '形态',
      //     dataIndex: 'xingtai',
      //     key: 'xingtai',
      //     className: 'xingtai',
      //     render: waitDrawLotteryRender(0, (value, row, index) => {
      //       return value.value
      //     })
      //   }
      // ],

      elevenTrendColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
      ].concat(this.getNumColumn([...eleven], 'elevenTrend')),
      elevenTrendColumnsStatics: [
        {
          title: 'title',
          dataIndex: 'title',
          key: 'title',
          className: 'statics-title',
        },
      ].concat(this.getStaticsColumn([...eleven])),
      elevenHeadOneColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
      ].concat(this.getNumColumn([...eleven], 'elevenHeadOneTrend')),
      elevenHeadOneColumnsStatics: [
        {
          title: 'title',
          dataIndex: 'title',
          key: 'title',
          className: 'statics-title',
        },
      ].concat(this.getStaticsColumn([...eleven])),
      elevenHeadTwoColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
      ].concat(this.getNumColumn([...eleven], 'elevenHeadTwoTrend')),
      elevenHeadTwoColumnsStatics: [
        {
          title: 'title',
          dataIndex: 'title',
          key: 'title',
          className: 'statics-title',
        },
      ].concat(this.getStaticsColumn([...eleven])),
      elevenHeadThreeColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
      ].concat(this.getNumColumn([...eleven], 'elevenHeadThreeTrend')),
      elevenHeadThreeColumnsStatics: [
        {
          title: 'title',
          dataIndex: 'title',
          key: 'title',
          className: 'statics-title',
        },
      ].concat(this.getStaticsColumn([...eleven])),
      // sumColumns: [
      //   {
      //     title: '',
      //     dataIndex: 'short_period',
      //     key: 'short_period',
      //     className: 'period',
      //     fixed: 'left'
      //   }
      // ].concat(this.getNumColumn([...sums], 'sums')),
      // sumsColumnsStatics: [
      //   {
      //     title: '',
      //     dataIndex: 'title',
      //     key: 'title',
      //     className: 'statics-title',
      //     fixed: 'left'
      //   }
      // ].concat(this.getStaticsColumn([...sums])),
      xingtaiColumns: [
        {
          title: (
            <div onClick={this.sort} className={'sort'}>
              期数
            </div>
          ),
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(4),
        },
        {
          title: '大小比',
          dataIndex: 'sizeThan',
          key: 'sizeThan',
          className: 'sizeThan',
        },
        {
          title: '奇偶比',
          dataIndex: 'parityThan',
          key: 'parityThan',
          className: 'parityThan',
        },
        {
          title: '质合比',
          dataIndex: 'massCloseThan',
          key: 'massCloseThan',
          className: 'massCloseThan',
        },
      ],
      doubleSamePluralColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(7),
        },

        this.getDoubleSamePluralColumn(1),
        this.getDoubleSamePluralColumn(2),
        this.getDoubleSamePluralColumn(3),
        this.getDoubleSamePluralColumn(4),
        this.getDoubleSamePluralColumn(5),
        this.getDoubleSamePluralColumn(6),
      ],
      doubleDifferentSingleColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
          fixed: 'left',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(erbutong.length + 1),
          fixed: 'left',
        },
      ].concat(this.getNumColumn([...erbutong], 'erbutong')),
      erbutongColumnsStatics: [
        {
          title: '',
          dataIndex: 'title',
          key: 'title',
          className: 'statics-title',
          fixed: 'left',
        },
      ].concat(this.getStaticsColumn([...erbutong])),

      elevenXingtaiColumns: [
        {
          title: '',
          dataIndex: 'short_period',
          key: 'short_period',
          className: 'period',
        },
        {
          title: '开奖号',
          dataIndex: 'win_num',
          key: 'win_num',
          className: 'win-num',
          render: waitDrawLotteryRender(elevenXingtai.length + 1),
        },
      ].concat(this.getXingtaiColumn([...elevenXingtai], 'elevenXingtai')),
      elevenXingtaiColumnsStatics: [
        {
          title: '',
          dataIndex: 'title',
          key: 'title',
          className: 'title',
        },
      ].concat(this.getStaticsColumn([...elevenXingtai])),
    }
  }
  sort = () => {
    this.setState(
      {
        sort: this.state.sort === 'desc' ? 'asc' : 'desc',
      },
      () => {
        this.getTrendData()
      }
    )
  }
  sortClassName = () => {
    return 'sort-period' + this.state.sort === 'desc' ? 'asc' : 'desc'
  }

  getStaticsColumn = nums => {
    return nums.map((item, index) => {
      return {
        title: `${item}`,
        dataIndex: `num${index + 1}`,
        key: `num${item}`,
        className: `num num${index + 1}`,
      }
    })
  }

  getNumColumn = (nums, key) => {
    return nums.map((item, index) => {
      return {
        title: item,
        dataIndex: item,
        key: item,
        className: 'num',
        render: waitDrawLotteryRender(0, (value, row) => {
          let item = null
          if (!row[key] || !row[key][index]) return
          item = row[key][index]

          if (item.isDrawNum) {
            if (item.showCount === 1) {
              return (
                <span className="draw-lottery-num">
                  {item.showCount === 1 && item.value}
                </span>
              )
            } else {
              return (
                <span className="draw-lottery-num">
                  {item.showCount > 1 && (
                    <Badge text={item.showCount}>{item.value}</Badge>
                  )}
                </span>
              )
            }
          } else {
            if (!this.state.showMiss) return ''
            return item.value
          }
        }),
      }
    })
  }

  getDoubleSamePluralColumn = num => {
    return {
      title: `${num}${num}`,
      dataIndex: `${num}`,
      key: `${num}`,
      className: `num num${num}${num}`,
      render: waitDrawLotteryRender(0, (value, row) => {
        if (row.winnerNumber.join('').indexOf(`${num}${num}`) >= 0) {
          return <span className="draw-lottery-num">{`${num}${num}`}</span>
        } else {
          return row.missNumber.ertong[num - 1]
        }
      }),
    }
  }

  getXingtaiColumn = (nums, key) => {
    return nums.map((item, index) => {
      return {
        title: item,
        dataIndex: item,
        key: item,
        className: `xingtai xingtai${index}`,
        render: waitDrawLotteryRender(0, (value, row) => {
          let item = null
          if (!row[key] || !row[key][index]) return
          item = row[key][index]

          if (item.isDrawNum) {
            if (item.showCount === 1) {
              return (
                <span className="draw-lottery-num">
                  {item.showCount === 1 && item.value}
                </span>
              )
            } else {
              return (
                <span className="draw-lottery-num">
                  {item.showCount > 1 && (
                    <Badge text={item.showCount}>{item.value}</Badge>
                  )}
                </span>
              )
            }
          } else {
            if (!this.state.showMiss) return ''
            return item.value
          }
        }),
      }
    })
  }
  componentDidMount() {
    const lotteryName = this.props.match.params.lotteryName
    this.getTrendData()
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  onSelect = opt => {
    // console.log(opt.props.value);
    this.setState({
      visible: false,
      currPlayType: opt.props.value,
    })
  }
  handleVisibleChange = visible => {
    this.setState({
      visible,
    })
  }
  handlePlayTypeVisibleChange = playTypeVisible => {
    this.setState({
      playTypeVisible,
    })
  }

  onChangePlayType = item => {
    setTimeout(() => {
      let currPlayType = item.value
      let tabs = this.state.tabs
      tabs.length = 3
      let title = ''

      switch (currPlayType) {
        case 'head_two':
          tabs[1].title = '万位走势'
          tabs[2].title = '千位走势'
          break
        case 'head_three':
          tabs[1].title = '万位走势'
          tabs[2].title = '千位走势'
          tabs.push({
            title: '百位走势',
          })
        default:
          tabs[1].title = '走势'
          tabs[2].title = '形态'
          break
      }

      this.setState({
        playTypeVisible: false,
        currPlayType: item.value,
        tabs: tabs,
      })
    }, 200)
  }

  onChangeOption = (itemData, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    let selectedPlayTypeOptions = playTypeInfo.options.filter(
      item => item.selected
    )
    let options = playTypeInfo.options
    let options2 = playTypeInfo.options2
    let selectedPlayTypeOptions2 = null
    let selectedPlayTypeOptions3 = null
    let count = 0

    switch (currPlayType) {
      case 'any_two': //
      case 'any_three': //
      case 'any_four': //
      case 'any_five': //
      case 'any_six': //
      case 'any_seven': //
      case 'any_eight': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_one': //
        count = selectedPlayTypeOptions.length
        break
      case 'head_two': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value)
        )
        break
      case 'head_three': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        selectedPlayTypeOptions3 = playTypeInfo.options3.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value),
          selectedPlayTypeOptions3.map(item => item.value)
        )
        break
      case 'head_group_two': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_group_three': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'tuo_dan_any_two': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_three': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_four': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_five': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_six': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_seven': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_eight': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_head_group_two': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_head_group_three': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break

      default:
    }

    this.setState({
      count: count,
      playType: [...this.state.playType],
    })
  }

  onChangeOption2 = (itemData, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    let selectedPlayTypeOptions = playTypeInfo.options.filter(
      item => item.selected
    )
    let options = playTypeInfo.options
    let options2 = playTypeInfo.options2
    let selectedPlayTypeOptions2 = options2.filter(item => item.selected)
    let selectedPlayTypeOptions3 = null
    let count = 0

    switch (currPlayType) {
      case 'any_two': //
      case 'any_three': //
      case 'any_four': //
      case 'any_five': //
      case 'any_six': //
      case 'any_seven': //
      case 'any_eight': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_one': //
        count = selectedPlayTypeOptions.length
        break
      case 'head_two': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value)
        )
        break
      case 'head_three': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        selectedPlayTypeOptions3 = playTypeInfo.options3.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value),
          selectedPlayTypeOptions3.map(item => item.value)
        )
        break
      case 'head_group_two': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_group_three': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'tuo_dan_any_two': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_three': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_four': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_five': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_six': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_seven': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_eight': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_head_group_two': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_head_group_three': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break

      default:
    }

    this.setState({
      count: count,
      playType: [...this.state.playType],
    })
  }
  onChangeOption3 = (item, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    let selectedPlayTypeOptions = playTypeInfo.options.filter(
      item => item.selected
    )
    let selectedPlayTypeOptions2 = null
    let selectedPlayTypeOptions3 = null
    let count = 0

    switch (currPlayType) {
      case 'any_two': //
      case 'any_three': //
      case 'any_four': //
      case 'any_five': //
      case 'any_six': //
      case 'any_seven': //
      case 'any_eight': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_one': //
        count = selectedPlayTypeOptions.length
        break
      case 'head_two': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value)
        )
        break
      case 'head_three': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        selectedPlayTypeOptions3 = playTypeInfo.options3.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value),
          selectedPlayTypeOptions3.map(item => item.value)
        )
        break
      case 'head_group_two': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_group_three': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'tuo_dan_any_two': //
      case 'tuo_dan_any_three': //
      case 'tuo_dan_any_four': //
      case 'tuo_dan_any_five': //
      case 'tuo_dan_any_six': //
      case 'tuo_dan_any_seven': //
      case 'tuo_dan_any_eight': //
      case 'tuo_dan_head_group_two': //
      case 'tuo_dan_head_group_three': //
        break

      default:
    }

    this.setState({
      count: count,
      playType: [...this.state.playType],
    })
  }

  setSelectedFn = (tags, willTags, selected) => {
    tags.forEach(item => {
      let isUpdate = false
      willTags.forEach(itemData => {
        if (itemData.value === item.value) {
          isUpdate = true
        }
      })
      if (isUpdate) {
        item.selected = selected
      }
    })
  }

  onDel = () => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)

    if (this.state.count > 0) {
      playTypeInfo.options.forEach(item => (item.selected = false))
      playTypeInfo.options2 &&
        playTypeInfo.options2.forEach(item => (item.selected = false))
      playTypeInfo.options3 &&
        playTypeInfo.options3.forEach(item => (item.selected = false))
      playTypeInfo.options4 &&
        playTypeInfo.options4.forEach(item => (item.selected = false))
      playTypeInfo.options5 &&
        playTypeInfo.options5.forEach(item => (item.selected = false))
      playTypeInfo.options6 &&
        playTypeInfo.options6.forEach(item => (item.selected = false))
      playTypeInfo.options7 &&
        playTypeInfo.options7.forEach(item => (item.selected = false))

      this.setState({
        count: 0,
        playType: [...this.state.playType],
      })
    } else {
      let count = randomBet(this.props.match.params.lotteryName, playTypeInfo)

      this.setState({
        count: count,
        playType: [...this.state.playType],
      })
    }
  }

  onConfirm = () => {
    const lotteryName = this.props.match.params.lotteryName
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    const values = playTypeInfo.options
      .filter(item => item.selected)
      .map(item => item.value)
    let values2 = []
    let values3 = []

    if (playTypeInfo.options3 && playTypeInfo.options3.length) {
      values2 = playTypeInfo.options2
        .filter(item => item.selected)
        .map(item => item.value)
      values3 = playTypeInfo.options3
        .filter(item => item.selected)
        .map(item => item.value)
      if (
        values.length + values2.length + values3.length <
        playTypeInfo.selectedCount
      ) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else if (playTypeInfo.options2 && playTypeInfo.options2.length) {
      values2 = playTypeInfo.options2
        .filter(item => item.selected)
        .map(item => item.value)
      if (values.length + values2.length < playTypeInfo.selectedCount) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else {
      if (values.length < playTypeInfo.selectedCount) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    }

    if (this.state.count === 0) {
      Modal.alert('提示', `请选择至少选择1注`)
      return
    }

    const selectNumId = guid()
    saveCache('selectNums', {
      [selectNumId]: {
        values: values,
        values2: values2,
        values3: values3,
        playType: currPlayType,
      },
    })

    // lotteryName/:playType/:playTypeName/:val/:val2
    const url = `/lottery/bet/${lotteryName}/${selectNumId}`
    this.props.dispatch(routerRedux.push(url))
  }

  getCurrPlayType = playTypeName => {
    const playTypeInfo = this.state.playType.find(
      item => item.value === playTypeName
    )
    return playTypeInfo
  }

  nextPeriodTip = () => {
    Modal.alert('提示', '当前期次结束，是否购买下一期')
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }
  showSet = bool => {
    this.setState({
      isShowSet: bool,
    })
  }
  onChangeCondition = value => {
    const state = { ...this.state }
    this.setState({ ...value }, () => {
      if (
        state.periodCount !== value.periodCount ||
        state.sort !== value.sort
      ) {
        this.getTrendData()
      }
    })
    this.showSet(false)
  }

  getTrendData = () => {
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getTrend',
      payload: {
        lotteryName: lotteryName,
        lottery_name: lotteryName,
        playType: this.state.currPlayType,
        periodCount: this.state.periodCount,
        showBrokenLine: this.state.showBrokenLine,
        showMiss: this.state.showMiss,
        showStatics: this.state.showStatics,
        sort: this.state.sort,
      },
    })
  }

  render() {
    const { lotteryInfo } = this.props.lottery
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)

    const middlePop = (
      <Popover
        overlayStyle={{ color: 'currentColor' }}
        visible={this.state.playTypeVisible}
        placement="bottom"
        mask
        overlay={
          <div className="play-type-list" styleName="play-type-list">
            <RadioTag
              itemClassName={'tag-item'}
              itemStyle={{
                margin: 10,
                width: '30%',
              }}
              data={this.state.playType}
              onChange={this.onChangePlayType}
            />
          </div>
        }
        align={{
          overflow: { adjustY: 0, adjustX: 0 },
          offset: [-10, 0],
        }}
        onVisibleChange={this.handlePlayTypeVisibleChange}
        onSelect={this.onSelect}
      >
        <div
          style={{
            height: '100%',
            padding: '0 15px',
            marginRight: '-15px',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          {playTypeInfo.label}
          {this.state.playTypeVisible && <span styleName="up" />}
          {!this.state.playTypeVisible && <span styleName="down" />}
        </div>
      </Popover>
    )

    return (
      <div
        className="eleven-five-lottery-page"
        styleName="eleven-five-lottery-page"
      >
        <NavBar
          mode="dark"
          leftContent={
            <Icon
              onClick={() => {
                this.props.history.go(-1)
              }}
              type="left"
              size="md"
            />
          }
          rightContent={
            <span className="set" onClick={() => this.showSet(true)} />
          }
        >
          {middlePop}
        </NavBar>
        <SetCondition
          value={{
            periodCount: this.state.periodCount,
            showBrokenLine: this.state.showBrokenLine,
            showMiss: this.state.showMiss,
            showStatics: this.state.showStatics,
            sort: this.state.sort,
          }}
          visible={this.state.isShowSet}
          onChange={this.onChangeCondition}
          onCancel={() => this.showSet(false)}
        />

        <div className="lottery-nums-body" styleName="body">
          <Tabs
            tabs={this.state.tabs}
            initialPage={1}
            swipeable={false}
            prerenderingSiblingsNumber={false}
          >
            <div className="draw-lottery">
              <Table
                scroll={{ y: this.state.scrollY }}
                className="trend-data"
                columns={this.state.drawLotteryColumns}
                data={this.props.lottery.trend.data}
              />
            </div>
            <div className="head-one-trend-wrap">
              {(/any_/.test(currPlayType) ||
                /head_group/.test(currPlayType)) && (
                <Fragment>
                  <Table
                    scroll={{ y: this.state.scrollY }}
                    className="eleven-trend"
                    columns={this.state.elevenTrendColumns}
                    data={this.props.lottery.trend.data}
                  />
                  {this.state.showStatics && (
                    <Table
                      scroll={{ y: this.state.scrollY }}
                      className="trend-statics eleven-trend-statics"
                      useFixedHeader
                      columns={this.state.elevenTrendColumnsStatics}
                      data={this.props.lottery.trend.elevenTrendStaticsData}
                      showHeader={false}
                    />
                  )}
                </Fragment>
              )}
              {(currPlayType === 'head_one' ||
                currPlayType === 'head_two' ||
                currPlayType === 'head_three') && (
                <Fragment>
                  <Table
                    scroll={{ y: this.state.scrollY }}
                    className="head-one-trend"
                    columns={this.state.elevenHeadOneColumns}
                    data={this.props.lottery.trend.data}
                  />
                  {this.state.showBrokenLine && (
                    <ConnectLine
                      elems={'.head-one-trend-wrap .draw-lottery-num'}
                      container={'.head-one-trend-wrap .rc-table'}
                      xContainer={'.head-one-trend-wrap .rc-table-body'}
                    />
                  )}
                  {this.state.showStatics && (
                    <Table
                      scroll={{ y: this.state.scrollY }}
                      className="trend-statics elevenXingtai-statics"
                      columns={this.state.elevenHeadOneColumnsStatics}
                      data={
                        this.props.lottery.trend.elevenHeadOneTrendStaticsData
                      }
                      showHeader={false}
                    />
                  )}
                </Fragment>
              )}
            </div>
            <div className="head-two-trend-wrap">
              {(currPlayType === 'head_two' ||
                currPlayType === 'head_three') && (
                <Fragment>
                  <Table
                    scroll={{ y: this.state.scrollY }}
                    className="head-two-trend"
                    columns={this.state.elevenHeadTwoColumns}
                    data={this.props.lottery.trend.data}
                  />
                  {this.state.showBrokenLine && (
                    <ConnectLine
                      elems={'.head-two-trend-wrap .draw-lottery-num'}
                      container={'.head-two-trend-wrap .rc-table'}
                      xContainer={'.head-two-trend-wrap .rc-table-body'}
                    />
                  )}
                  {this.state.showStatics && (
                    <Table
                      scroll={{ y: this.state.scrollY }}
                      className="trend-statics elevenXingtai-statics"
                      columns={this.state.elevenHeadTwoColumnsStatics}
                      data={
                        this.props.lottery.trend.elevenHeadTwoTrendStaticsData
                      }
                      showHeader={false}
                    />
                  )}
                </Fragment>
              )}
              {(/any_/.test(currPlayType) ||
                /head_group/.test(currPlayType)) && (
                <Fragment>
                  <Table
                    scroll={{ y: this.state.scrollY }}
                    className="xingtai-trend"
                    columns={this.state.xingtaiColumns}
                    data={this.props.lottery.trend.data}
                  />
                </Fragment>
              )}
              {currPlayType === 'head_one' && (
                <Fragment>
                  <Table
                    scroll={{ y: this.state.scrollY }}
                    className="elevenXingtai-trend"
                    columns={this.state.elevenXingtaiColumns}
                    data={this.props.lottery.trend.data}
                  />
                  {this.state.showStatics && (
                    <Table
                      scroll={{ y: this.state.scrollY }}
                      className="trend-statics elevenXingtai-statics"
                      columns={this.state.elevenXingtaiColumnsStatics}
                      data={this.props.lottery.trend.elevenXingtaiStaticsData}
                      showHeader={false}
                    />
                  )}
                </Fragment>
              )}
            </div>
            <div className="head-three-trend-wrap">
              {currPlayType === 'head_three' && (
                <Fragment>
                  <Table
                    scroll={{ y: this.state.scrollY }}
                    className="head-three-trend"
                    columns={this.state.elevenHeadThreeColumns}
                    data={this.props.lottery.trend.data}
                  />
                  {this.state.showBrokenLine && (
                    <ConnectLine
                      elems={'.head-three-trend-wrap .draw-lottery-num'}
                      container={'.head-three-trend-wrap .rc-table'}
                      xContainer={'.head-three-trend-wrap .rc-table-body'}
                    />
                  )}
                  {this.state.showStatics && (
                    <Table
                      scroll={{ y: this.state.scrollY }}
                      className="trend-statics elevenXingtai-statics"
                      columns={this.state.elevenHeadThreeColumnsStatics}
                      data={
                        this.props.lottery.trend.elevenHeadThreeTrendStaticsData
                      }
                      showHeader={false}
                    />
                  )}
                </Fragment>
              )}
            </div>
          </Tabs>
        </div>
        <div className="trend-footer" styleName="footer">
          {!/tuo_dan/.test(currPlayType) && (
            <div styleName="footer-top">
              <span styleName="label">选号：</span>
              <div styleName="footer-top-scroll">
                <CheckboxTag
                  itemClassName={`tag-item`}
                  isShowValue
                  // className={`${playTypeInfo.value}`}
                  data={playTypeInfo.options}
                  onChange={this.onChangeOption}
                />
              </div>
            </div>
          )}
          <div styleName="footer-bottom">
            <div styleName="time-label">
              距{lotteryInfo.last_period}
              期截止:
            </div>
            <CountDown
              styleName="time"
              onEnd={this.nextPeriodTip}
              target={new Date().getTime() + lotteryInfo.staking_countdown}
            />
            {!/tuo_dan/.test(currPlayType) && (
              <a onClick={this.onConfirm} styleName="bet-btn">
                确定
              </a>
            )}
          </div>
        </div>
      </div>
    )
  }
}
