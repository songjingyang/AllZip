/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-12-18 18:53:19
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Popover, Modal } from 'antd-mobile'
import { createForm } from 'rc-form'
import RadioTag from '@/components/RadioTag'
import CheckboxTag from '@/components/CheckboxTag'
import CountDown from '@/components/CountDown'
import { getLotteryCount, commonCount } from '@/utils/lottery'
import { getTickPlayType } from '@/utils/lotteryPlayTypeData'
import './Tick.less'
import { saveCache, guid } from '../../utils/utils'
import { randomBet } from '../../utils/lottery'

@createForm()
@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class Tick extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      playTypeVisible: false,
      playType: getTickPlayType(),
      currPlayType: 'big_small_odd_even',
      count: 0,
      price: 0,
    }
  }
  componentDidMount() {
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  onSelect = opt => {
    // console.log(opt.props.value);
    this.setState({
      visible: false,
      currPlayType: opt.props.value,
    })
  }
  handleVisibleChange = visible => {
    this.setState({
      visible,
    })
  }
  handlePlayTypeVisibleChange = playTypeVisible => {
    this.setState({
      playTypeVisible,
    })
  }

  onChangePlayType = item => {
    setTimeout(() => {
      this.setState({ playTypeVisible: false, currPlayType: item.value })
    }, 200)
  }
  onChangeOption = (itemData, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    let options = playTypeInfo.options
    let options2 = playTypeInfo.options2
    let options3 = playTypeInfo.options3
    let options4 = playTypeInfo.options4
    let options5 = playTypeInfo.options5
    let selectedPlayTypeOptions =
      options && options.filter(item => item.selected)
    let selectedPlayTypeOptions2 =
      options2 && options2.filter(item => item.selected)
    let selectedPlayTypeOptions3 =
      options3 && options3.filter(item => item.selected)
    let selectedPlayTypeOptions4 =
      options4 && options4.filter(item => item.selected)
    let selectedPlayTypeOptions5 =
      options5 && options5.filter(item => item.selected)

    let count = 0

    count = getLotteryCount(
      currPlayType,
      selectedPlayTypeOptions,
      selectedPlayTypeOptions2,
      selectedPlayTypeOptions3,
      selectedPlayTypeOptions4,
      selectedPlayTypeOptions5
    )

    switch (currPlayType) {
      case 'any_two': //

      default:
    }

    this.setState({
      count: count,
      playType: [...this.state.playType],
    })
  }

  onChangeOption2 = (itemData, allSelected, all, index, setSelectedFn) => {
    this.onChangeOption(itemData, allSelected, all, index, setSelectedFn)
  }
  onChangeOption3 = (itemData, allSelected, all, index, setSelectedFn) => {
    this.onChangeOption(itemData, allSelected, all, index, setSelectedFn)
  }

  setSelectedFn = (tags, willTags, selected) => {
    tags.forEach(item => {
      let isUpdate = false
      willTags.forEach(itemData => {
        if (itemData.value === item.value) {
          isUpdate = true
        }
      })
      if (isUpdate) {
        item.selected = selected
      }
    })
  }

  onDel = () => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)

    if (this.state.count > 0) {
      playTypeInfo.options.forEach(item => (item.selected = false))
      playTypeInfo.options2 &&
        playTypeInfo.options2.forEach(item => (item.selected = false))
      playTypeInfo.options3 &&
        playTypeInfo.options3.forEach(item => (item.selected = false))
      playTypeInfo.options4 &&
        playTypeInfo.options4.forEach(item => (item.selected = false))
      playTypeInfo.options5 &&
        playTypeInfo.options5.forEach(item => (item.selected = false))
      playTypeInfo.options6 &&
        playTypeInfo.options6.forEach(item => (item.selected = false))
      playTypeInfo.options7 &&
        playTypeInfo.options7.forEach(item => (item.selected = false))

      this.setState({
        count: 0,
        playType: [...this.state.playType],
      })
    } else {
      let count = randomBet(this.props.match.params.lotteryName, playTypeInfo)

      this.setState({
        count: count,
        playType: [...this.state.playType],
      })
    }
  }

  onConfirm = () => {
    const lotteryName = this.props.match.params.lotteryName
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    const values = playTypeInfo.options
      .filter(item => item.selected)
      .map(item => item.value)
    let values2 =
      playTypeInfo.options2 &&
      playTypeInfo.options2
        .filter(item => item.selected)
        .map(item => item.value)
    let values3 =
      playTypeInfo.options3 &&
      playTypeInfo.options3
        .filter(item => item.selected)
        .map(item => item.value)
    let values4 =
      playTypeInfo.options4 &&
      playTypeInfo.options4
        .filter(item => item.selected)
        .map(item => item.value)
    let values5 =
      playTypeInfo.options5 &&
      playTypeInfo.options5
        .filter(item => item.selected)
        .map(item => item.value)

    if (values5) {
      if (
        values.length +
          values2.length +
          values3.length +
          values4.length +
          values5.length <
        playTypeInfo.selectedCount
      ) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else if (values4) {
      if (
        values.length + values2.length + values3.length + values4.length <
        playTypeInfo.selectedCount
      ) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else if (values3) {
      if (
        values.length + values2.length + values3.length <
        playTypeInfo.selectedCount
      ) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else if (values2) {
      if (values.length + values2.length < playTypeInfo.selectedCount) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else {
      if (values.length < playTypeInfo.selectedCount) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    }

    if (this.state.count === 0) {
      Modal.alert('提示', `请选择至少选择1注`)
      return
    }

    const selectNumId = guid()
    saveCache('selectNums', {
      [selectNumId]: {
        values: values,
        values2: values2,
        values3: values3,
        values4: values4,
        values5: values5,
        playType: currPlayType,
      },
    })

    // lotteryName/:playType/:playTypeName/:val/:val2
    const url = `/lottery/bet/${lotteryName}/${selectNumId}`
    this.props.dispatch(routerRedux.push(url))
  }

  getCurrPlayType = playTypeName => {
    const playTypeInfo = this.state.playType.find(
      item => item.value === playTypeName
    )
    return playTypeInfo
  }

  nextPeriodTip = () => {
    Modal.alert('提示', '当前期次结束，是否购买下一期')
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  render() {
    const { getFieldProps } = this.props.form
    const { lotteryInfo } = this.props.lottery
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    console.log('TCL: Tick -> render -> playTypeInfo', playTypeInfo)

    const middlePop = (
      <Popover
        overlayClassName="fortest"
        overlayStyle={{ color: 'currentColor' }}
        visible={this.state.playTypeVisible}
        placement="bottom"
        mask
        overlay={
          <div styleName="play-type-list">
            <RadioTag
              itemClassName={'tag-item'}
              itemStyle={{
                margin: 10,
                width: '30%',
              }}
              data={this.state.playType}
              onChange={this.onChangePlayType}
            />
          </div>
        }
        align={{
          overflow: { adjustY: 0, adjustX: 0 },
          offset: [-10, 0],
        }}
        onVisibleChange={this.handlePlayTypeVisibleChange}
        onSelect={this.onSelect}
      >
        <div
          style={{
            height: '100%',
            padding: '0 15px',
            marginRight: '-15px',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          {playTypeInfo.label}
          {this.state.playTypeVisible && <span styleName="up" />}
          {!this.state.playTypeVisible && <span styleName="down" />}
        </div>
      </Popover>
    )

    const rightPop = (
      <Popover
        overlayClassName="fortest"
        overlayStyle={{ color: 'currentColor' }}
        visible={this.state.visible}
        overlay={[
          <Popover.Item key="3" value="scan" data-seed="logId">
            <Link
              to={`/lottery/tickTrend/${this.props.match.params.lotteryName}`}
              style={{ color: '#000' }}
            >
              趋势图
            </Link>
          </Popover.Item>,
          <Popover.Item key="4" value="scan" data-seed="logId">
            <Link
              to={`/draw/lastDraw/${this.props.match.params.lotteryName}`}
              style={{ color: '#000' }}
            >
              近期开奖
            </Link>
          </Popover.Item>,
          <Popover.Item
            key="5"
            value="special"
            style={{ whiteSpace: 'nowrap' }}
          >
            <Link to="/lottery/fastThreePlayInfo" style={{ color: '#000' }}>
              玩法说明
            </Link>
          </Popover.Item>,
        ]}
        align={{
          overflow: { adjustY: 0, adjustX: 0 },
          offset: [-10, 0],
        }}
        onVisibleChange={this.handleVisibleChange}
        onSelect={this.onSelect}
      >
        <div>
          <Icon type="ellipsis" />
        </div>
      </Popover>
    )

    return (
      <div styleName="lottery-page">
        <NavBar
          mode="dark"
          leftContent={
            <Icon
              onClick={() => {
                this.props.history.go(-1)
              }}
              type="left"
              size="md"
            />
          }
          rightContent={rightPop}
        >
          {middlePop}
        </NavBar>
        <div styleName="header">
          <div styleName="time-label">
            距{lotteryInfo.last_period}
            期截
          </div>
          <CountDown
            styleName="time"
            onEnd={this.nextPeriodTip}
            target={new Date().getTime() + lotteryInfo.staking_countdown}
          />
        </div>
        <div className="lottery-nums-body" styleName="body">
          <div styleName="tip">{playTypeInfo.tip}</div>
          <div className="clearfix" styleName="options">
            <div styleName="options-label">
              {playTypeInfo.optionsLabel || '选号'}
            </div>
            {/big_small_odd_even/.test(playTypeInfo.value) && (
              <RadioTag
                itemClassName={'tag-item'}
                styleName="checkbox-wrap"
                data={playTypeInfo.options}
                onChange={this.onChangeOption}
              />
            )}
            {!/big_small_odd_even/.test(playTypeInfo.value) && (
              <CheckboxTag
                itemClassName={`tag-item`}
                maxSelectedCount={
                  playTypeInfo.maxSelectedCount ||
                  (playTypeInfo.options2 && playTypeInfo.options2.length) ||
                  undefined // isShowValue
                }
                className={`${playTypeInfo.value} `}
                styleName="checkbox-wrap"
                data={playTypeInfo.options}
                onChange={this.onChangeOption}
              />
            )}
          </div>

          {playTypeInfo.options2 && (
            <div>
              <div className="clearfix" styleName="options2">
                <div styleName="options-label">
                  {playTypeInfo.options2Label || '选号'}
                </div>
                {/big_small_odd_even/.test(playTypeInfo.value) && (
                  <RadioTag
                    itemClassName={'tag-item'}
                    styleName="checkbox-wrap"
                    data={playTypeInfo.options2}
                    onChange={this.onChangeOption2}
                  />
                )}
                {!/big_small_odd_even/.test(playTypeInfo.value) && (
                  <CheckboxTag
                    itemClassName={`tag-item`}
                    maxSelectedCount={
                      playTypeInfo.maxSelectedCount ||
                      (playTypeInfo.options2 && playTypeInfo.options2.length) ||
                      undefined // isShowValue
                    }
                    className={`${playTypeInfo.value} `}
                    styleName="checkbox-wrap"
                    data={playTypeInfo.options2}
                    onChange={this.onChangeOption2}
                  />
                )}
              </div>
            </div>
          )}
          {playTypeInfo.options3 && (
            <div className="clearfix" styleName="options3">
              <div styleName="options-label">
                {playTypeInfo.options3Label || '选号'}
              </div>
              <CheckboxTag
                itemClassName={'tag-item'}
                isShowValue={playTypeInfo.value === 'double_same_each '}
                className={`${playTypeInfo.value}`}
                styleName="checkbox-wrap"
                data={playTypeInfo.options3}
                onChange={this.onChangeOption}
              />
            </div>
          )}
          {playTypeInfo.options4 && (
            <div className="clearfix" styleName="options3">
              <div styleName="options-label">
                {playTypeInfo.options4Label || '选号'}
              </div>
              <CheckboxTag
                itemClassName={'tag-item'}
                isShowValue={playTypeInfo.value === 'double_same_each '}
                className={`${playTypeInfo.value}`}
                styleName="checkbox-wrap"
                data={playTypeInfo.options4}
                onChange={this.onChangeOption}
              />
            </div>
          )}
          {playTypeInfo.options5 && (
            <div className="clearfix" styleName="options3">
              <div styleName="options-label">
                {playTypeInfo.options5Label || '选号'}
              </div>
              <CheckboxTag
                itemClassName={'tag-item'}
                isShowValue={playTypeInfo.value === 'double_same_each '}
                className={`${playTypeInfo.value}`}
                styleName="checkbox-wrap"
                data={playTypeInfo.options5}
                onChange={this.onChangeOption}
              />
            </div>
          )}
        </div>
        <div styleName="footer">
          <span
            onClick={this.onDel}
            styleName={this.state.count > 0 ? 'del' : 'random-select'}
          >
            {this.state.count > 0 ? '' : '机选'}
          </span>
          共{this.state.count}注 {this.state.count * 2}元
          <a onClick={this.onConfirm} styleName="bet-btn">
            确定
          </a>
        </div>
      </div>
    )
  }
}
