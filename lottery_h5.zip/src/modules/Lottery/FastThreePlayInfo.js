/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-10-12 11:20:49
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import {
  NavBar,
  Icon,
  Card,
  Button,
  WingBlank,
  WhiteSpace,
  List,
  ListView
} from 'antd-mobile'

import './FastThreePlayInfo.less'

@connect(({ user, global, draw }) => ({ user, global, draw }))
export default class FastThreePlayInfo extends React.Component {
  constructor (props) {
    super(props)
  }

  componentDidMount () {}

  render () {
    return (
      <div>
        <NavBar
          mode='dark'
          leftContent={
            <Icon
              onClick={() => this.props.history.go(-1)}
              type='left'
              size='md'
            />
          }
        >
          玩法说明
        </NavBar>
        <div styleName='desc' />
      </div>
    )
  }
}

const data = [
  {
    img: 'https://zos.alipayobjects.com/rmsportal/dKbkpPXKfvZzWCM.png',
    title: 'Meet hotel',
    des: '不是所有的兼职汪都需要风吹日晒'
  },
  {
    img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
    title: "McDonald's invites you",
    des: '不是所有的兼职汪都需要风吹日晒'
  },
  {
    img: 'https://zos.alipayobjects.com/rmsportal/hfVtzEhPzTUewPm.png',
    title: 'Eat the week',
    des: '不是所有的兼职汪都需要风吹日晒'
  }
]
const NUM_ROWS = 20
let pageIndex = 0

function genData (pIndex = 0) {
  const dataBlob = {}
  for (let i = 0; i < NUM_ROWS; i++) {
    const ii = pIndex * NUM_ROWS + i
    dataBlob[`${ii}`] = `row - ${ii}`
  }
  return dataBlob
}
