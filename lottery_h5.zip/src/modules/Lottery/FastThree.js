/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-12-18 11:17:08
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Popover, Modal } from 'antd-mobile'
import { createForm } from 'rc-form'
import RadioTag from '@/components/RadioTag'
import CheckboxTag from '@/components/CheckboxTag'
import CountDown from '@/components/CountDown'
import { getLotteryCount, commonCount } from '@/utils/lottery'
import { getFastThreePlayType } from '@/utils/lotteryPlayTypeData'
import './FastThree.less'
import { saveCache, guid } from '../../utils/utils'
import { randomBet } from '../../utils/lottery'

@createForm()
@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class Index extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      playTypeVisible: false,
      playType: getFastThreePlayType(),
      currPlayType: 'sum',
      count: 0,
      price: 0,
    }
  }
  componentDidMount() {
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  onSelect = opt => {
    // console.log(opt.props.value);
    this.setState({
      visible: false,
      currPlayType: opt.props.value,
    })
  }
  handleVisibleChange = visible => {
    this.setState({
      visible,
    })
  }
  handlePlayTypeVisibleChange = playTypeVisible => {
    this.setState({
      playTypeVisible,
    })
  }

  onChangePlayType = item => {
    setTimeout(() => {
      this.setState({ playTypeVisible: false, currPlayType: item.value })
    }, 200)
  }
  onChangeOption = (item, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    let selectedPlayTypeOptions = playTypeInfo.options.filter(
      item => item.selected
    )
    let count = getLotteryCount(currPlayType, selectedPlayTypeOptions)

    switch (currPlayType) {
      case 'sum': // 和值
        playTypeInfo.options2.forEach(item => {
          item.selected = false
        })

      case 'triple_same_each': // 三同号单选
      case 'triple_same_all': // 三同号通选
      case 'triple_consecutive_all': // 三连号通选
      case 'double_same_plural': // 二同号复选
        break
      case 'double_same_each': // 二同号单选
        playTypeInfo.options2[index].selected = false
        let selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'triple_different': // 三不同号
        break
      case 'double_different_single': // 二不同号
        break
      default:
    }

    this.setState({
      count: count,
      playType: [...this.state.playType],
    })
  }

  onChangeOption2 = (item, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    const options = playTypeInfo.options
    const options2 = playTypeInfo.options2

    let selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
      item => item.selected
    )

    switch (currPlayType) {
      case 'sum': // 和值
        this.sum(item)

        break
      case 'double_same_each': // 二同号单选
        playTypeInfo.options[index].selected = false
        let selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )

        this.setState({
          count: getLotteryCount(
            currPlayType,
            selectedPlayTypeOptions,
            selectedPlayTypeOptions2
          ),
          playType: [...this.state.playType],
        })
        break
      default:
    }
  }

  sum = item => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    const options = playTypeInfo.options
    const options2 = playTypeInfo.options2

    // 和值
    let selectedPlayTypeOptions = playTypeInfo.options.filter(
      item => item.selected
    )
    // 8 4 2 1
    if (item.selected) {
      if (item.value === 8) {
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === 4),
          false
        )
      }
      if (item.value === 4) {
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === 8),
          false
        )
      }
      if (item.value === 2) {
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === 1),
          false
        )
      }
      if (item.value === 1) {
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === 2),
          false
        )
      }
    }

    const currOptions2TotalValue = options2.reduce((total, item) => {
      if (item.selected) {
        return total + item.value
      }
      return total
    }, 0)
    this.setSelectedFn(options, options, false)

    switch (currOptions2TotalValue) {
      case 1: // 双
        this.setSelectedFn(
          options,
          options.filter(item => item.value % 2 === 0),
          true
        )
        break
      case 5: // 双 小
        this.setSelectedFn(
          options,
          options.filter(item => item.value % 2 === 0 && item.value <= 10),
          true
        )

        break
      case 9: // 双 大
        this.setSelectedFn(
          options,
          options.filter(item => item.value % 2 === 0 && item.value > 10),
          true
        )
        break
      case 2: // 单
        this.setSelectedFn(
          options,
          options.filter(item => item.value % 2 === 1),
          true
        )
        break
      case 6: // 单小
        this.setSelectedFn(
          options,
          options.filter(item => item.value % 2 === 1 && item.value <= 10),
          true
        )
        break
      case 10: // 单 大
        this.setSelectedFn(
          options,
          options.filter(item => item.value % 2 === 1 && item.value > 10),
          true
        )
        break
      case 4: // 小
        this.setSelectedFn(
          options,
          options.filter(item => item.value <= 10),
          true
        )
        break
      case 8: // 大
        this.setSelectedFn(
          options,
          options.filter(item => item.value > 10),
          true
        )
        break
      default:
    }

    // playTypeInfo.options2.forEach(item => {
    //   item.selected = false
    // })

    selectedPlayTypeOptions = playTypeInfo.options.filter(item => item.selected)

    this.setState({
      count: getLotteryCount(currPlayType, selectedPlayTypeOptions),
      playType: [...this.state.playType],
    })
  }

  setSelectedFn = (tags, willTags, selected) => {
    tags.forEach(item => {
      let isUpdate = false
      willTags.forEach(itemData => {
        if (itemData.value === item.value) {
          isUpdate = true
        }
      })
      if (isUpdate) {
        item.selected = selected
      }
    })
  }

  onDel = () => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)

    if (this.state.count > 0) {
      playTypeInfo.options.forEach(item => (item.selected = false))
      playTypeInfo.options2 &&
        playTypeInfo.options2.forEach(item => (item.selected = false))
      playTypeInfo.options3 &&
        playTypeInfo.options3.forEach(item => (item.selected = false))
      playTypeInfo.options4 &&
        playTypeInfo.options4.forEach(item => (item.selected = false))
      playTypeInfo.options5 &&
        playTypeInfo.options5.forEach(item => (item.selected = false))
      playTypeInfo.options6 &&
        playTypeInfo.options6.forEach(item => (item.selected = false))
      playTypeInfo.options7 &&
        playTypeInfo.options7.forEach(item => (item.selected = false))

      this.setState({
        count: 0,
        playType: [...this.state.playType],
      })
    } else {
      let count = randomBet(this.props.match.params.lotteryName, playTypeInfo)

      this.setState({
        count: count,
        playType: [...this.state.playType],
      })
    }
  }

  onConfirm = () => {
    const lotteryName = this.props.match.params.lotteryName
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    const values = playTypeInfo.options
      .filter(item => item.selected)
      .map(item => item.value)
    let values2 = 0
    if (currPlayType === 'double_same_each') {
      values2 = playTypeInfo.options2
        .filter(item => item.selected)
        .map(item => item.value)
      if (values2.length === 0) {
        Modal.alert('提示', '请选择投注号')
        return
      }
    }

    if (values.length === 0) {
      Modal.alert('提示', '请选择投注号')
      return
    }
    const selectNumId = guid()
    saveCache('selectNums', {
      [selectNumId]: {
        values: values,
        values2: values2,
        playType: currPlayType,
      },
    })

    if (this.state.count === 0) {
      Modal.alert('提示', `请选择至少选择1注`)
      return
    }

    // lotteryName/:playType/:playTypeName/:val/:val2
    const url = `/lottery/bet/${lotteryName}/${selectNumId}`
    this.props.dispatch(routerRedux.push(url))
  }

  getCurrPlayType = playTypeName => {
    const playTypeInfo = this.state.playType.find(
      item => item.value === playTypeName
    )
    return playTypeInfo
  }

  nextPeriodTip = () => {
    Modal.alert('提示', '当前期次结束，是否购买下一期')
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  render() {
    const { getFieldProps } = this.props.form
    const { lotteryInfo } = this.props.lottery
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)

    const middlePop = (
      <Popover
        overlayStyle={{ color: 'currentColor' }}
        visible={this.state.playTypeVisible}
        placement="bottom"
        mask
        overlay={
          <div styleName="play-type-list">
            <RadioTag
              itemClassName={'tag-item'}
              itemStyle={{
                margin: 10,
                width: '30%',
              }}
              data={this.state.playType}
              onChange={this.onChangePlayType}
            />
          </div>
        }
        align={{
          overflow: { adjustY: 0, adjustX: 0 },
          offset: [-10, 0],
        }}
        onVisibleChange={this.handlePlayTypeVisibleChange}
        onSelect={this.onSelect}
      >
        <div
          style={{
            height: '100%',
            padding: '0 15px',
            marginRight: '-15px',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          {playTypeInfo.label}
          {this.state.playTypeVisible && <span styleName="up" />}
          {!this.state.playTypeVisible && <span styleName="down" />}
        </div>
      </Popover>
    )

    const rightPop = (
      <Popover
        overlayStyle={{ color: 'currentColor' }}
        visible={this.state.visible}
        overlay={[
          <Popover.Item key="3" value="scan" data-seed="logId">
            <Link
              to={`/lottery/trend/${this.props.match.params.lotteryName}`}
              style={{ color: '#000' }}
            >
              趋势图
            </Link>
          </Popover.Item>,
          <Popover.Item key="4" value="scan" data-seed="logId">
            <Link
              to={`/draw/lastDraw/${this.props.match.params.lotteryName}`}
              style={{ color: '#000' }}
            >
              近期开奖
            </Link>
          </Popover.Item>,
          <Popover.Item
            key="5"
            value="special"
            style={{ whiteSpace: 'nowrap' }}
          >
            <Link to="/lottery/fastThreePlayInfo" style={{ color: '#000' }}>
              玩法说明
            </Link>
          </Popover.Item>,
        ]}
        align={{
          overflow: { adjustY: 0, adjustX: 0 },
          offset: [-10, 0],
        }}
        onVisibleChange={this.handleVisibleChange}
        onSelect={this.onSelect}
      >
        <div>
          <Icon type="ellipsis" />
        </div>
      </Popover>
    )

    return (
      <div styleName="lottery-page">
        <NavBar
          mode="dark"
          leftContent={
            <Icon
              onClick={() => {
                this.props.history.go(-1)
              }}
              type="left"
              size="md"
            />
          }
          rightContent={rightPop}
        >
          {middlePop}
        </NavBar>
        <div styleName="header">
          <div styleName="time-label">
            距{lotteryInfo.staking_period}
            期截
          </div>
          <CountDown
            styleName="time"
            onEnd={this.nextPeriodTip}
            target={new Date().getTime() + lotteryInfo.staking_countdown}
          />
        </div>
        <div styleName="body">
          <div styleName="tip">{playTypeInfo.tip}</div>
          <div>
            <CheckboxTag
              itemClassName={`tag-item`}
              isShowValue
              className={`${playTypeInfo.value}`}
              data={playTypeInfo.options}
              onChange={this.onChangeOption}
            />
          </div>

          {playTypeInfo.options2 && (
            <div className="option2">
              {playTypeInfo.options2Label && (
                <div styleName="tip2">{playTypeInfo.options2Label}</div>
              )}
              <CheckboxTag
                itemClassName={'tag-item'}
                isShowValue={playTypeInfo.value === 'double_same_each '}
                className={`${playTypeInfo.value}`}
                data={playTypeInfo.options2}
                onChange={this.onChangeOption2}
              />
            </div>
          )}
        </div>
        <div styleName="footer">
          <span
            onClick={this.onDel}
            styleName={this.state.count > 0 ? 'del' : 'random-select'}
          >
            {this.state.count > 0 ? '' : '机选'}
          </span>
          共{this.state.count}注 {this.state.count * 2}元
          <a onClick={this.onConfirm} styleName="bet-btn">
            确定
          </a>
        </div>
      </div>
    )
  }
}
