/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-11-20 11:48:47
 */
export default (columns = {
  drawLotteryColumns: [
    {
      title: '期数',
      dataIndex: 'short_period',
      key: 'short_period',
      className: 'period'
    },
    {
      title: '开奖号',
      dataIndex: 'win_num',
      key: 'win_num',
      className: 'win-num'
    },
    {
      title: '和值',
      dataIndex: 'sum',
      key: 'sum',
      className: 'sum'
    },

    {
      title: '大小',
      dataIndex: 'size',
      key: 'size',
      className: 'size'
    },
    {
      title: '单双',
      dataIndex: 'odd_even',
      key: 'odd_even',
      className: 'odd-even'
    }
  ],

  baseColumns: [
    {
      title: '',
      dataIndex: 'short_period',
      key: 'short_period',
      className: 'period'
    },
    {
      title: '开奖号',
      dataIndex: 'win_num',
      key: 'win_num',
      className: 'win-num'
    },
    {
      title: '和值',
      dataIndex: 'sum',
      key: 'sum',
      className: 'sum'
    },
    {
      title: '跨度',
      dataIndex: 'span',
      key: 'span',
      className: 'span'
    },
    this.getBaseColumn(1),
    this.getBaseColumn(2),
    this.getBaseColumn(3),
    this.getBaseColumn(4),
    this.getBaseColumn(5),
    this.getBaseColumn(6)
  ],
  baseColumnsStatics: [
    {
      title: 'title',
      dataIndex: 'title',
      key: 'title',
      className: 'title'
    },
    {
      title: 'num1',
      dataIndex: 'num1',
      key: 'num1',
      className: 'num1'
    },
    {
      title: 'num2',
      dataIndex: 'num2',
      key: 'num2',
      className: 'num2'
    },
    {
      title: 'num3',
      dataIndex: 'num3',
      key: 'num3',
      className: 'num3'
    },
    {
      title: 'num4',
      dataIndex: 'num4',
      key: 'num4',
      className: 'num4'
    },
    {
      title: 'num5',
      dataIndex: 'num5',
      key: 'num5',
      className: 'num5'
    },
    {
      title: 'num6',
      dataIndex: 'num6',
      key: 'num6',
      className: 'num6'
    }
  ],
  sumColumns: [
    {
      title: '',
      dataIndex: 'short_period',
      key: 'short_period',
      className: 'period',
      fixed: 'left'
    },
    this.getSumColumn(3),
    this.getSumColumn(4),
    this.getSumColumn(5),
    this.getSumColumn(6),
    this.getSumColumn(7),
    this.getSumColumn(8),
    this.getSumColumn(9),
    this.getSumColumn(10),
    this.getSumColumn(11),
    this.getSumColumn(12),
    this.getSumColumn(13),
    this.getSumColumn(14),
    this.getSumColumn(15),
    this.getSumColumn(16),
    this.getSumColumn(17),
    this.getSumColumn(18)
  ]
})

function getBaseColumn (num) {
  return {
    title: `${num}`,
    dataIndex: `${num}`,
    key: `${num}`,
    className: `num num${num}`,
    render: (value, row, index) => {
      return this.getNum(value, row, num)
    }
  }
}
function getSumColumn (num) {
  return {
    title: `${num}`,
    dataIndex: `${num}`,
    key: `${num}`,
    className: `num num${num}`,
    render: (value, row, index) => {
      return this.getSumNum(value, row, num)
      // const sum = row.sum
      // return sum === num
      //   ? <span className={'win-num-single'}>{sum}</span>
      //   : row.missNumber.sum[num - 3]
    }
  }
}

function getNum (value, row, num) {
  const len = row.winnerNumber.filter(item => item === num).length

  if (len === 1) {
    return <span className='draw-lottery-num'>{num}</span>
  } else if (len > 1) {
    return (
      <span className='draw-lottery-num'>
        <Badge text={len}>{num}</Badge>
      </span>
    )
  } else {
    if (!this.state.showMiss) return ''
    return row.missNumber.shuzi[num - 1]
  }
}
function getSumNum (value, row, num) {
  const sum = row.sum
  if (sum === num) {
    return <span className={'draw-lottery-num win-num-single'}>{sum}</span>
  } else {
    if (!this.state.showMiss) return ''
    return row.missNumber.sum[num - 3]
  }
}
