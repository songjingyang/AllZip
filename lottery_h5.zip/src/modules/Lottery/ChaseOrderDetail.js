/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-12-18 16:06:04
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Card, Button, WingBlank, WhiteSpace } from 'antd-mobile'
import { createForm } from 'rc-form'
import CheckboxTag from '@/components/CheckboxTag'
import CountDown from '@/components/CountDown'
import { getCurrPlayType } from '@/utils/lottery'
import { dateFormater, saveCache, getCache } from '@/utils/utils'
import './ChaseOrderDetail.less'
import { getLotteryNameLabel, showOrderDetailNum } from '../../utils/lottery'

@createForm()
@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class ChaseOrderDetail extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      count: 0,
      orderStatusMap: { 1: '未付款', 2: '已付款' },
      statusMap: {
        1: '未中奖',
        2: '中奖',
        3: '等待开奖',
        '': '等待开奖',
      },
    }
  }
  componentDidMount() {
    const params = this.props.match.params

    this.props.dispatch({
      type: 'lottery/getOrderInfo',
      payload: {
        order_id: params.orderId,
        lotteryName: params.lotteryName,
      },
    })
  }

  jumpHome = () => {
    // this.props.dispatch(routerRedux.push(`/home/home`))
    this.props.history.goBack()
  }

  pay = () => {
    const params = this.props.match.params
    this.props.dispatch({
      type: 'lottery/pay',
      payload: {
        order_id: params.orderId,
        amount: params.price, // 付款金额  单位：分
        // merchant_id: '{{global.merchant_id}}'
      },
      callback: res => {
        if (res.code === 200) {
          this.props.dispatch(routerRedux.push('/lotter/xxx'))
        }
      },
    })
  }

  showBetNum = item => {
    let isTuoDan = item.is_dan_tuo === 2
    if (isTuoDan) {
      return `(${item.dan.join(' ')}) ${item.tuo.join(' ')}`
    } else {
      if (/head_group/.test(item.gameplay)) {
        return `${item.numbers.join(' ')}`
      } else if (/head/.test(item.gameplay)) {
        return `${item.numbers.join('|')}`
      }
    }

    if (item.gameplay === 'sum') {
      return item.Sum
    } else if (item.gameplay === 'double_same_each') {
      return `(${item.numbers[1]}${item.numbers[2]})${item.numbers[0]}`
    } else if (
      item.gameplay === 'triple_same_all' ||
      item.gameplay === 'triple_consecutive_all'
    ) {
      return getCurrPlayType('fast_three', item.gameplay).options[0].label
    }

    return item.numbers.join('')
  }
  buy = item => {
    const params = this.props.match.params
    this.props.dispatch(
      routerRedux.push(`/lottery/bet/${params.lotteryName}/0`)
    )
  }
  bet = item => {
    const params = this.props.match.params
    saveCache(`${params.lotteryName}drawData`, [])
    this.props.dispatch(
      routerRedux.push(`/lottery/fastThree/${params.lotteryName}`)
    )
  }

  getOrderStatus = item => {
    return item.status === 3 ? '未追期' : '已追期'
  }

  getPrizeStatus = item => {
    let status = '未中奖'
    status = item.status === 2 ? '已中奖' : status
    status = item.status === 3 ? '未开奖' : status
    return status
  }

  render() {
    const { orderInfo } = this.props.lottery
    const params = this.props.match.params
    const currPeriod = orderInfo.periods.length && orderInfo.periods[0]

    return (
      <div styleName="chase-detail-page">
        <NavBar
          mode="dark"
          leftContent={<Icon onClick={this.jumpHome} type="left" size="md" />}
        >
          订单详情
        </NavBar>
        <WingBlank size="sm">
          <Card styleName="chase-detail">
            <div styleName="title">
              <span styleName="lottery-icon" />
              {getLotteryNameLabel(params.lotteryName)}
              <span styleName="name">追期详情</span>
            </div>
            <div styleName="list">
              <div className="clearfix" styleName="item">
                <div styleName="label">方案金额：</div>
                <div styleName="value" style={{ color: '#DD3048' }}>
                  {orderInfo.cost / 100}元
                </div>
              </div>
              <div className="clearfix" styleName="item">
                <div styleName="label">追期期次：</div>
                <div styleName="value">
                  {orderInfo.period_start}-{orderInfo.period_end}
                  <span style={{ color: '#999' }}>
                    (共追
                    {orderInfo.chase}
                    期,已追
                    {orderInfo.chased}
                    期)
                  </span>
                </div>
              </div>
              <div className="clearfix" styleName="item">
                <div styleName="label">已中奖：</div>
                <div styleName="value">{orderInfo.total_rewards / 100}元</div>
              </div>
              <div className="clearfix" styleName="item">
                <div styleName="label">投注时间：</div>
                <div styleName="value">{dateFormater(orderInfo.stake_ts)}</div>
              </div>
            </div>
          </Card>
        </WingBlank>
        <WingBlank size="sm">
          <Card styleName="bet-detail">
            <div styleName="title">
              <span styleName="name">选号详情</span>{' '}
              <span styleName="times">
                {orderInfo.times}倍{orderInfo.stakes_count}注
              </span>
            </div>
            <table>
              <thead>
                <tr>
                  <td styleName="play-type">玩法</td>
                  <td styleName="play-type-num">投注号码</td>
                </tr>
              </thead>
              <tbody>
                {orderInfo &&
                  orderInfo.stakes.map(item => (
                    <tr style={{ color: item.status === 2 ? 'red' : '#000' }}>
                      <td>
                        {
                          getCurrPlayType(params.lotteryName, item.gameplay)
                            .label
                        }
                        {item.is_dan_tuo == 2 ? '胆拖' : ''}{' '}
                      </td>
                      <td>{showOrderDetailNum(item)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
            <table styleName="period-list">
              <thead>
                <tr>
                  <td styleName="period">期次</td>
                  <td styleName="order-status">订单状态</td>
                  <td styleName="draw-numbers">开奖号码</td>
                  <td styleName="prize-status">中奖状态</td>
                </tr>
              </thead>
              <tbody>
                {orderInfo.periods.map(item => (
                  <tr style={{ color: item.status === 2 ? 'red' : '#000' }}>
                    <td> {item.period} </td>
                    <td> {this.getOrderStatus(item)} </td>
                    <td> {item.draw_numbers} </td>
                    <td> {this.getPrizeStatus(item)} </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </WingBlank>

        {/* <div styleName='footer'>
          <Button onClick={this.buy} type='ghost' inline styleName='buy'>
            继续购买本单号码
          </Button>
          <Button onClick={this.bet} type='primary' inline styleName='bet'>
            继续购买下注
          </Button>
        </div> */}
      </div>
    )
  }
}
