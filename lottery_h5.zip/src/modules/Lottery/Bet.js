/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool

 * @Last Modified time: 2018-12-18 18:43:05
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Popover, Modal, Toast } from 'antd-mobile'
import { createForm } from 'rc-form'
import CheckboxTag from '@/components/CheckboxTag'
import CountDown from '@/components/CountDown'
import SetPay from '../../components/SetPay/index'

import {
  getLotteryCount,
  getRandomDraw,
  getCurrPlayType,
  getLotteryNameLabel,
  buildBackEndBetData,
  getDrawDataKey,
  showNum,
} from '../../utils/lottery'
import { saveCache, getCache, guid } from '@/utils/utils'
import './Bet.less'

@createForm()
@connect(({ user, global, lottery, my }) => ({ user, global, lottery, my }))
export default class Index extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isShowPass: false,
      isShowSetPayPass: false,
      pass: '',
      count: 0,
      price: 0,
      times: 0,
      chase: 0,
      drawData: [],
    }
  }
  componentDidMount() {
    const params = this.props.match.params
    const lotteryName = params.lotteryName
    const selectNumId = params.selectNumId
    const selectNums = getCache('selectNums')

    if (selectNumId === '1') {
      Toast.success('这是您上次选择的号码', 1)
    }

    if (selectNums && selectNums[selectNumId]) {
      const selectNum = selectNums[selectNumId]
      const values = selectNum.values
      const values2 = selectNum.values2
      const values3 = selectNum.values3
      const values4 = selectNum.values4
      const values5 = selectNum.values5
      const playType = selectNum.playType
      saveCache('selectNums', {})

      const count = getLotteryCount(
        playType,
        values,
        values2,
        values3,
        values4,
        values5
      )
      const price = count * 2

      this.addDraw({
        id: guid(),
        lotteryName: lotteryName,
        playType: playType,
        playTypeName: params.playTypeName,
        values: values,
        values2: values2,
        values3: values3,
        values4: values4,
        values5: values5,
        count: count,
        price: price,
      })
    } else {
      this.initDraw()
    }

    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })

    if (localStorage.getItem('user') !== null) {
      this.props.dispatch({
        type: 'my/getMyInfo',
        payload: {},
      })
    }
  }

  // getDrawDataKey = lotteryName => {
  //   lotteryName = lotteryName || this.props.match.params.lotteryName
  //   return `${lotteryName}drawData`
  // }

  jumpHome = () => {
    if (this.state.drawData.length === 0) {
      const params = this.props.match.params
      this.props.dispatch(routerRedux.push(`/home/home}`))
      return
    }

    Modal.alert('温馨提示', '是否清除本次选号？', [
      {
        text: '保存',
        onPress: () => {
          this.updateDrawData()
          Toast.success('已保存！再次点击彩种直接进入当前页面', 1)
          this.props.dispatch(routerRedux.push(`/home/home`))
        },
      },
      {
        text: '清除',
        onPress: () => {
          saveCache(getDrawDataKey(this.props.match.params.lotteryName), [])
          this.props.dispatch(routerRedux.push(`/home/home`))
        },
      },
    ])
  }
  jumpPlusNum = () => {
    const params = this.props.match.params
    let lotteryComponentName = 'fastThree'
    if (/eleven_five/.test(params.lotteryName)) {
      lotteryComponentName = 'elevenFive'
    } else if (/tick_tick/.test(params.lotteryName)) {
      lotteryComponentName = 'tick'
    }

    this.props.dispatch(
      routerRedux.push(`/lottery/${lotteryComponentName}/${params.lotteryName}`)
    )
  }
  randomPlusNum = () => {
    const params = this.props.match.params
    const lotteryName = params.lotteryName
    const drawData = this.state.drawData
    const playType = drawData.length
      ? drawData[0].playType
      : getCache('lastPlayType')
    const drawItem = getRandomDraw(lotteryName, playType)
    this.addDraw(drawItem)
  }
  initDraw = () => {
    const drawData =
      getCache(getDrawDataKey(this.props.match.params.lotteryName)) || []

    this.setState(
      {
        drawData,
      },
      () => {
        this.updateDrawData()
      }
    )
  }
  addDraw = draw => {
    const drawData =
      getCache(getDrawDataKey(this.props.match.params.lotteryName)) || []

    drawData.unshift(draw)

    this.setState(
      {
        drawData,
      },
      () => {
        this.updateDrawData()
      }
    )
  }
  delDraw = itemData => {
    if (this.state.drawData.length == 1) {
      saveCache('lastPlayType', this.state.drawData[0].playType)
    }

    const drawData = this.state.drawData.filter(item => item.id !== itemData.id)

    this.setState(
      {
        drawData: this.state.drawData.filter(item => item.id !== itemData.id),
      },
      () => {
        this.updateDrawData()
      }
    )
  }
  changeChase = e => {
    this.setState(
      {
        chase: e.target.value < 1 ? '' : e.target.value,
      },
      () => {
        this.updateDrawData()
      }
    )
  }
  changeTimes = e => {
    this.setState(
      {
        times: e.target.value < 1 ? '' : e.target.value,
      },
      () => {
        this.updateDrawData()
      }
    )
  }
  valid = () => {
    const myInfo = this.props.my.myInfo

    if (myInfo.is_mobile_set === 1 || myInfo.is_pay_pswd_set === 1) {
      this.setState({ isShowSetPayPass: true })
    } else {
      this.onBet()
    }
  }

  onBet = () => {
    const params = this.props.match.params
    const lotteryName = params.lotteryName
    let reqData = {
      lotteryName: lotteryName,
      chase: +this.state.chase || 1, // 期数
      period: this.props.lottery.lotteryInfo.staking_period,
      times: +this.state.times || 1, // 倍数
      // merchant_id: '{{global.merchant_id}}',
      stakes: buildBackEndBetData(this.state.drawData),
    }

    if (reqData.stakes.length === 0) {
      Modal.alert('提示', '请选择投注号')
      return
    }

    this.props.dispatch(
      routerRedux.push(
        `/lottery/pay/${this.state.price}/${params.lotteryName}/${
          reqData.chase
        }/${JSON.stringify(reqData)}`
      )
    )
    // this.props.dispatch({
    //   type: 'lottery/bet',
    //   payload: reqData,
    //   callback: res => {
    //     if (res.code === 200) {
    //       const data = res.payload
    //       this.props.dispatch(
    //         routerRedux.push(
    //           `/lottery/pay/${data.order_id}/${this.state.price}/${params.lotteryName}/${reqData.chase}`
    //         )
    //       )
    //     }
    //   }
    // })
  }

  getBetData = drawData => {
    const arr = []
    drawData.forEach(item => {
      var newItem = {
        gameplay: item.playType,
      }
      switch (item.playType) {
        // 快三
        case 'sum': // 和值
          newItem.numbers = item.values
          break
        case 'triple_same_each': // 三同号单选
          newItem.triple = item.values.map(item => item.substring(0, 1))
          break
        case 'triple_same_all': // 三同号通选
          break
        case 'triple_consecutive_all': // 三连号通选
          break
        case 'double_same_each': // 二同号单选
          newItem.double = item.values.map(item => item.substring(0, 1))
          newItem.numbers = item.values2
          break
        case 'double_same_plural': // 二同号复选
          newItem.double = item.values.map(item => item.substring(0, 1))
          break
        case 'triple_different': // 三不同号
          newItem.numbers = item.values
          break
        case 'double_different_single': // 二不同号
          newItem.numbers = item.values
          break
        // 11选5

        default:
      }

      arr.push(newItem)
    })

    return arr
  }

  updateDrawData = () => {
    saveCache(
      getDrawDataKey(this.props.match.params.lotteryName),
      this.state.drawData
    )
    this.cal()
  }

  cal = () => {
    const drawData = this.state.drawData
    const count = drawData.reduce((total, item) => total + item.count, 0)

    this.setState({
      count: count,
      price: count * 2 * (this.state.chase || 1) * (this.state.times || 1),
    })
  }

  nextPeriodTip = () => {
    Modal.alert('提示', '当前期次结束，是否购买下一期')
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  render() {
    const { lotteryInfo } = this.props.lottery
    const params = this.props.match.params

    return (
      <div styleName="lottery-page">
        <NavBar
          mode="dark"
          leftContent={<Icon onClick={this.jumpHome} type="left" size="md" />}
        >
          {getLotteryNameLabel(params.lotteryName)}
        </NavBar>
        <div styleName="header">
          <div styleName="time-label">
            距{lotteryInfo.staking_period}
            期截
          </div>
          <CountDown
            styleName="time"
            onEnd={this.nextPeriodTip}
            target={new Date().getTime() + lotteryInfo.staking_countdown}
          />
        </div>
        <div styleName="body">
          <span onClick={this.jumpPlusNum} styleName="hand-plus-num-btn">
            手动加号
          </span>
          <span onClick={this.randomPlusNum} styleName="random-plus-num-btn">
            机选加号
          </span>

          <div styleName="card">
            <div styleName="card-header" />
            <div styleName="card-body">
              <div styleName="count-list">
                {this.state.drawData.map(item => (
                  <div key={item.id} styleName="count-item">
                    <div styleName="num">{showNum(item)}</div>
                    <div styleName="desc">
                      {getCurrPlayType(item.lotteryName, item.playType).label}
                      {/tuo_dan/.test(item.playType) ? '胆拖' : ''}{' '}
                      {item.count > 1 ? '复式' : '单式'} {item.count}注
                      {item.price}元
                    </div>
                    <div
                      onClick={() => {
                        this.delDraw(item)
                      }}
                      styleName="del-btn"
                    />
                  </div>
                ))}
              </div>
            </div>
            <div styleName="card-footer" />
          </div>
        </div>
        <div styleName="footer">
          <div styleName="footer-top">
            <div styleName="chase">
              追{' '}
              <input
                onChange={this.changeChase}
                type="number"
                min={1}
                max={10000}
                value={this.state.chase || ''}
                placeholder="1"
              />{' '}
              期
            </div>
            <div styleName="times">
              买{' '}
              <input
                onChange={this.changeTimes}
                type="number"
                min={1}
                max={10000}
                value={this.state.times || ''}
                placeholder="1"
              />{' '}
              倍
            </div>
          </div>
          <div styleName="footer-bottom">
            <div styleName="price">共{this.state.price}元</div>
            <div styleName="desc">
              {this.state.count}注 {this.state.chase || 1}期
              {this.state.times || 1}倍
            </div>

            <a onClick={this.valid} styleName="bet-btn">
              投注
            </a>
          </div>
        </div>

        {this.state.isShowSetPayPass && (
          <SetPay
            onFinish={value => {
              this.onBet()
            }}
            onClose={() => this.setState({ isShowSetPayPass: false })}
          />
        )}
      </div>
    )
  }
}
