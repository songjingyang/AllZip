/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-12-18 18:53:06
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Popover, Modal } from 'antd-mobile'
import { createForm } from 'rc-form'
import RadioTag from '@/components/RadioTag'
import CheckboxTag from '@/components/CheckboxTag'
import CountDown from '@/components/CountDown'
import { getLotteryCount, commonCount } from '@/utils/lottery'
import { getElevenFivePlayType } from '@/utils/lotteryPlayTypeData'
import './ElevenFive.less'
import { saveCache, guid } from '../../utils/utils'
import { getRandomDraw, randomBet } from '../../utils/lottery'

@createForm()
@connect(({ user, global, lottery }) => ({ user, global, lottery }))
export default class ElevenFive extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      playTypeVisible: false,
      playType: getElevenFivePlayType(),
      currPlayType: 'any_two',
      count: 0,
      price: 0,
    }
  }
  componentDidMount() {
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  onSelect = opt => {
    // console.log(opt.props.value);
    this.setState({
      visible: false,
      currPlayType: opt.props.value,
    })
  }
  handleVisibleChange = visible => {
    this.setState({
      visible,
    })
  }
  handlePlayTypeVisibleChange = playTypeVisible => {
    this.setState({
      playTypeVisible,
    })
  }

  onChangePlayType = item => {
    setTimeout(() => {
      this.setState({ playTypeVisible: false, currPlayType: item.value })
    }, 200)
  }
  onChangeOption = (itemData, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    let selectedPlayTypeOptions = playTypeInfo.options.filter(
      item => item.selected
    )
    let options = playTypeInfo.options
    let options2 = playTypeInfo.options2
    let selectedPlayTypeOptions2 = null
    let selectedPlayTypeOptions3 = null
    let count = 0

    switch (currPlayType) {
      case 'any_two': //
      case 'any_three': //
      case 'any_four': //
      case 'any_five': //
      case 'any_six': //
      case 'any_seven': //
      case 'any_eight': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_one': //
        count = selectedPlayTypeOptions.length
        break
      case 'head_two': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value)
        )
        break
      case 'head_three': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        selectedPlayTypeOptions3 = playTypeInfo.options3.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value),
          selectedPlayTypeOptions3.map(item => item.value)
        )
        break
      case 'head_group_two': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_group_three': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'tuo_dan_any_two': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_three': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_four': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_five': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_six': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_seven': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_eight': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_head_group_two': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_head_group_three': //
        this.setSelectedFn(
          options2,
          options2.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break

      default:
    }

    this.setState({
      count: count,
      playType: [...this.state.playType],
    })
  }

  onChangeOption2 = (itemData, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    let selectedPlayTypeOptions = playTypeInfo.options.filter(
      item => item.selected
    )
    let options = playTypeInfo.options
    let options2 = playTypeInfo.options2
    let selectedPlayTypeOptions2 = options2.filter(item => item.selected)
    let selectedPlayTypeOptions3 = null
    let count = 0

    switch (currPlayType) {
      case 'any_two': //
      case 'any_three': //
      case 'any_four': //
      case 'any_five': //
      case 'any_six': //
      case 'any_seven': //
      case 'any_eight': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_one': //
        count = selectedPlayTypeOptions.length
        break
      case 'head_two': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value)
        )
        break
      case 'head_three': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        selectedPlayTypeOptions3 = playTypeInfo.options3.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value),
          selectedPlayTypeOptions3.map(item => item.value)
        )
        break
      case 'head_group_two': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_group_three': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'tuo_dan_any_two': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_three': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_four': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_five': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_six': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_seven': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_any_eight': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_head_group_two': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break
      case 'tuo_dan_head_group_three': //
        this.setSelectedFn(
          options,
          options.filter(item => item.value === itemData.value),
          false
        )
        selectedPlayTypeOptions = playTypeInfo.options.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions,
          selectedPlayTypeOptions2
        )
        break

      default:
    }

    this.setState({
      count: count,
      playType: [...this.state.playType],
    })
  }
  onChangeOption3 = (item, allSelected, all, index, setSelectedFn) => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    let selectedPlayTypeOptions = playTypeInfo.options.filter(
      item => item.selected
    )
    let selectedPlayTypeOptions2 = null
    let selectedPlayTypeOptions3 = null
    let count = 0

    switch (currPlayType) {
      case 'any_two': //
      case 'any_three': //
      case 'any_four': //
      case 'any_five': //
      case 'any_six': //
      case 'any_seven': //
      case 'any_eight': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_one': //
        count = selectedPlayTypeOptions.length
        break
      case 'head_two': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value)
        )
        break
      case 'head_three': //
        selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
          item => item.selected
        )
        selectedPlayTypeOptions3 = playTypeInfo.options3.filter(
          item => item.selected
        )
        count = getLotteryCount(
          currPlayType,
          selectedPlayTypeOptions.map(item => item.value),
          selectedPlayTypeOptions2.map(item => item.value),
          selectedPlayTypeOptions3.map(item => item.value)
        )
        break
      case 'head_group_two': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'head_group_three': //
        count = getLotteryCount(currPlayType, selectedPlayTypeOptions)
        break
      case 'tuo_dan_any_two': //
      case 'tuo_dan_any_three': //
      case 'tuo_dan_any_four': //
      case 'tuo_dan_any_five': //
      case 'tuo_dan_any_six': //
      case 'tuo_dan_any_seven': //
      case 'tuo_dan_any_eight': //
      case 'tuo_dan_head_group_two': //
      case 'tuo_dan_head_group_three': //
        break

      default:
    }

    this.setState({
      count: count,
      playType: [...this.state.playType],
    })
  }

  setSelectedFn = (tags, willTags, selected) => {
    tags.forEach(item => {
      let isUpdate = false
      willTags.forEach(itemData => {
        if (itemData.value === item.value) {
          isUpdate = true
        }
      })
      if (isUpdate) {
        item.selected = selected
      }
    })
  }

  onDel = () => {
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)

    if (this.state.count > 0) {
      playTypeInfo.options.forEach(item => (item.selected = false))
      playTypeInfo.options2 &&
        playTypeInfo.options2.forEach(item => (item.selected = false))
      playTypeInfo.options3 &&
        playTypeInfo.options3.forEach(item => (item.selected = false))
      playTypeInfo.options4 &&
        playTypeInfo.options4.forEach(item => (item.selected = false))
      playTypeInfo.options5 &&
        playTypeInfo.options5.forEach(item => (item.selected = false))
      playTypeInfo.options6 &&
        playTypeInfo.options6.forEach(item => (item.selected = false))
      playTypeInfo.options7 &&
        playTypeInfo.options7.forEach(item => (item.selected = false))

      this.setState({
        count: 0,
        playType: [...this.state.playType],
      })
    } else {
      let count = randomBet(this.props.match.params.lotteryName, playTypeInfo)

      this.setState({
        count: count,
        playType: [...this.state.playType],
      })
    }
  }

  onConfirm = () => {
    const lotteryName = this.props.match.params.lotteryName
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)
    const values = playTypeInfo.options
      .filter(item => item.selected)
      .map(item => item.value)
    let values2 = []
    let values3 = []

    if (playTypeInfo.options3 && playTypeInfo.options3.length) {
      values2 = playTypeInfo.options2
        .filter(item => item.selected)
        .map(item => item.value)
      values3 = playTypeInfo.options3
        .filter(item => item.selected)
        .map(item => item.value)
      if (
        values.length + values2.length + values3.length <
        playTypeInfo.selectedCount
      ) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else if (playTypeInfo.options2 && playTypeInfo.options2.length) {
      values2 = playTypeInfo.options2
        .filter(item => item.selected)
        .map(item => item.value)
      if (values.length + values2.length < playTypeInfo.selectedCount) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    } else {
      if (values.length < playTypeInfo.selectedCount) {
        Modal.alert(
          '提示',
          `请选择至少选择${playTypeInfo.selectedCount}个投注号`
        )
        return
      }
    }

    if (this.state.count === 0) {
      Modal.alert('提示', `请选择至少选择1注`)
      return
    }

    const selectNumId = guid()
    saveCache('selectNums', {
      [selectNumId]: {
        values: values,
        values2: values2,
        values3: values3,
        playType: currPlayType,
      },
    })

    // lotteryName/:playType/:playTypeName/:val/:val2
    const url = `/lottery/bet/${lotteryName}/${selectNumId}`
    this.props.dispatch(routerRedux.push(url))
  }

  getCurrPlayType = playTypeName => {
    const playTypeInfo = this.state.playType.find(
      item => item.value === playTypeName
    )
    return playTypeInfo
  }

  nextPeriodTip = () => {
    Modal.alert('提示', '当前期次结束，是否购买下一期')
    const lotteryName = this.props.match.params.lotteryName
    this.props.dispatch({
      type: 'lottery/getLotteryInfo',
      payload: {
        lotteryName: lotteryName,
      },
    })
  }

  render() {
    const { getFieldProps } = this.props.form
    const { lotteryInfo } = this.props.lottery
    const currPlayType = this.state.currPlayType
    const playTypeInfo = this.getCurrPlayType(currPlayType)

    const middlePop = (
      <Popover
        overlayClassName="fortest"
        overlayStyle={{ color: 'currentColor' }}
        visible={this.state.playTypeVisible}
        placement="bottom"
        mask
        overlay={
          <div className="play-type-list" styleName="play-type-list">
            <RadioTag
              itemClassName={'tag-item'}
              itemStyle={{
                margin: 10,
                width: '30%',
              }}
              data={this.state.playType}
              onChange={this.onChangePlayType}
            />
          </div>
        }
        align={{
          overflow: { adjustY: 0, adjustX: 0 },
          offset: [-10, 0],
        }}
        onVisibleChange={this.handlePlayTypeVisibleChange}
        onSelect={this.onSelect}
      >
        <div
          style={{
            height: '100%',
            padding: '0 15px',
            marginRight: '-15px',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          {playTypeInfo.label}
          {this.state.playTypeVisible && <span styleName="up" />}
          {!this.state.playTypeVisible && <span styleName="down" />}
        </div>
      </Popover>
    )

    const rightPop = (
      <Popover
        overlayStyle={{ color: 'currentColor' }}
        visible={this.state.visible}
        overlay={[
          <Popover.Item key="3" value="scan" data-seed="logId">
            <Link
              to={`/lottery/elevenFiveTrend/${
                this.props.match.params.lotteryName
              }`}
              style={{ color: '#000' }}
            >
              趋势图
            </Link>
          </Popover.Item>,
          <Popover.Item key="4" value="scan" data-seed="logId">
            <Link
              to={`/draw/lastDraw/${this.props.match.params.lotteryName}`}
              style={{ color: '#000' }}
            >
              近期开奖
            </Link>
          </Popover.Item>,
          <Popover.Item
            key="5"
            value="special"
            style={{ whiteSpace: 'nowrap' }}
          >
            <Link to="/lottery/fastThreePlayInfo" style={{ color: '#000' }}>
              玩法说明
            </Link>
          </Popover.Item>,
        ]}
        align={{
          overflow: { adjustY: 0, adjustX: 0 },
          offset: [-10, 0],
        }}
        onVisibleChange={this.handleVisibleChange}
        onSelect={this.onSelect}
      >
        <div>
          <Icon type="ellipsis" />
        </div>
      </Popover>
    )

    return (
      <div styleName="lottery-page">
        <NavBar
          mode="dark"
          leftContent={
            <Icon
              onClick={() => {
                this.props.history.go(-1)
              }}
              type="left"
              size="md"
            />
          }
          rightContent={rightPop}
        >
          {middlePop}
        </NavBar>
        <div styleName="header">
          <div styleName="time-label">
            距{lotteryInfo.last_period}
            期截
          </div>
          <CountDown
            styleName="time"
            onEnd={this.nextPeriodTip}
            target={new Date().getTime() + lotteryInfo.staking_countdown}
          />
        </div>
        <div className="lottery-nums-body" styleName="body">
          <div styleName="tip">{playTypeInfo.tip}</div>
          {/tuo_dan/.test(playTypeInfo.value) && (
            <div styleName="tip2">{playTypeInfo.optionsLabel}</div>
          )}
          <div className="clearfix" styleName="options">
            <div styleName="options-label">
              {/tuo_dan/.test(playTypeInfo.value)
                ? '胆码'
                : playTypeInfo.optionsLabel || '选号'}
            </div>
            <CheckboxTag
              itemClassName={`tag-item`}
              // isShowValue
              maxSelectedCount={
                playTypeInfo.maxSelectedCount ||
                (playTypeInfo.options2 && playTypeInfo.options2.length) ||
                undefined
              }
              className={`${playTypeInfo.value} `}
              styleName="checkbox-wrap"
              data={playTypeInfo.options}
              onChange={this.onChangeOption}
            />
          </div>

          {playTypeInfo.options2 && (
            <div>
              {/tuo_dan/.test(playTypeInfo.value) && (
                <div styleName="tip2">{playTypeInfo.options2Label}</div>
              )}
              <div className="clearfix" styleName="options2">
                <div styleName="options-label">
                  {/tuo_dan/.test(playTypeInfo.value)
                    ? '拖码'
                    : playTypeInfo.options2Label || '选号'}
                </div>
                <CheckboxTag
                  itemClassName={'tag-item'}
                  isShowValue={playTypeInfo.value === 'double_same_each '}
                  className={`${playTypeInfo.value}`}
                  styleName="checkbox-wrap"
                  data={playTypeInfo.options2}
                  onChange={this.onChangeOption2}
                />
              </div>
            </div>
          )}
          {playTypeInfo.options3 && (
            <div className="clearfix" styleName="options3">
              <div styleName="options-label">
                {playTypeInfo.options3Label || '选号'}
              </div>
              <CheckboxTag
                itemClassName={'tag-item'}
                isShowValue={playTypeInfo.value === 'double_same_each '}
                className={`${playTypeInfo.value}`}
                styleName="checkbox-wrap"
                data={playTypeInfo.options3}
                onChange={this.onChangeOption3}
              />
            </div>
          )}
        </div>
        <div styleName="footer">
          <span
            onClick={this.onDel}
            styleName={this.state.count > 0 ? 'del' : 'random-select'}
          >
            {this.state.count > 0 ? '' : '机选'}
          </span>
          共{this.state.count}注 {this.state.count * 2}元
          <a onClick={this.onConfirm} styleName="bet-btn">
            确定
          </a>
        </div>
      </div>
    )
  }
}
