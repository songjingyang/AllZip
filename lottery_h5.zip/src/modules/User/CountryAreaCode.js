import React, { Fragment } from 'react';
import { routerRedux, Link } from 'dva/router';
import { connect } from 'dva';
import { createForm } from 'rc-form'

import { StickyContainer, Sticky } from 'react-sticky';
import { NavBar, Icon, ListView, List, SearchBar } from 'antd-mobile';

import { province } from './data';
import './CountryAreaCode.less'

const { Item } = List;

function genData(ds, provinceData) {
  const dataBlob = {};
  const sectionIDs = [];
  const rowIDs = [];
  Object.keys(provinceData).forEach((item, index) => {
    sectionIDs.push(item);
    dataBlob[item] = item;
    rowIDs[index] = [];

    provinceData[item].forEach((jj) => {
      rowIDs[index].push(jj.value);
      dataBlob[jj.value] = jj.label;
    });
  });
  return ds.cloneWithRowsAndSections(dataBlob, sectionIDs, rowIDs);
}

@createForm()
@connect(({ user }) => ({ user }))

export default class CountryAreaCode extends React.Component {
  constructor(props) {
    super(props);
    const getSectionData = (dataBlob, sectionID) => dataBlob[sectionID];
    const getRowData = (dataBlob, sectionID, rowID) => dataBlob[rowID];

    const dataSource = new ListView.DataSource({
      getRowData,
      getSectionHeaderData: getSectionData,
      rowHasChanged: (row1, row2) => row1 !== row2,
      sectionHeaderHasChanged: (s1, s2) => s1 !== s2,
    });

    this.state = {
      inputValue: '',
      dataSource,
      isLoading: true,
      goback_data: ''
    };
  }

  componentDidMount() {
    // simulate initial Ajax
    setTimeout(() => {
      this.setState({
        dataSource: genData(this.state.dataSource, province),
        isLoading: false,
      });
    }, 600);
  }

  onSearch = (val) => {
    const pd = { ...province };
    Object.keys(pd).forEach((item) => {
      const arr = pd[item].filter(jj => jj.spell.toLocaleLowerCase().indexOf(val) > -1);
      if (!arr.length) {
        delete pd[item];
      } else {
        pd[item] = arr;
      }
    });
    this.setState({
      inputValue: val,
      dataSource: genData(this.state.dataSource, pd),
    });
  }

  goback = rowID => {
    if (this.props.match.params.title === 'login') {
      this.props.dispatch(routerRedux.push(`/user/userLogin/${rowID}`))
    } else {
      this.props.dispatch(routerRedux.push(`/user/userRegister/${rowID}`))
    }
  }

  render() {
    return (
      <div className='CountryAreaCode-page'>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.dispatch(routerRedux.push('/user/userLogin'))}
        >
          选择国家和地区
        </NavBar>
        <div style={{ paddingTop: '90px', position: 'relative' }}>
          <div style={{ height: '90px', position: 'absolute', top: '0px', left: 0, right: 0 }}>
            <SearchBar
              value={this.state.inputValue}
              placeholder="搜索"
              onChange={this.onSearch}
              onClear={() => { console.log('onClear'); }}
              onCancel={() => { console.log('onCancel'); }}
            />
          </div>
          <ListView.IndexedList
            dataSource={this.state.dataSource}
            className="am-list sticky-list"
            useBodyScroll
            renderSectionWrapper={sectionID => (
              <StickyContainer
                key={`s_${sectionID}_c`}
                className="sticky-container"
                style={{ zIndex: 4 }}
              />
            )}
            renderSectionHeader={sectionData => {
              return (
                <Sticky>
                  {({
                    style,
                  }) => {
                    // style.top = '90px'
                    return (
                      <div
                        className="sticky"
                        style={{
                          ...style,
                          zIndex: 3,
                          color: '#333',
                          fontWeight: 900
                        }}
                      >{sectionData}</div>
                    )
                  }}
                </Sticky>
              )
            }}
            // renderHeader={() => <span>custom header</span>}
            // renderFooter={() => <span>custom footer</span>}
            // item
            renderRow={(rowData, sectionID, rowID) => (<Item onClick={() => this.goback(rowID)}>
              <span>{rowData}</span>
              <span style={{float: 'right', marginRight: '20px', color: '#a5a5a5'}}>{rowID}</span>
            </Item>)}
            quickSearchBarStyle={{
              top: '30%',
            }}
            delayTime={10}
            // delayActivityIndicator={<div style={{ padding: 25, textAlign: 'center' }}>rendering...</div>}
          />
        </div>
      </div>
    )
  }
}