import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  Toast,
  WhiteSpace,
  WingBlank,
  NavBar,
  Icon,
  List,
  InputItem,
  Switch,
  Stepper,
  Range,
  Button,
  Input
} from 'antd-mobile'
import { createForm } from 'rc-form'

import './UserLogin.less'
import { validErrorTip } from '../../utils/utils'

const Item = List.Item

@createForm()
@connect(({ user }) => ({ user }))
export default class UserLogin extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      currentIndex: 1,
      loginType: [
        {id: 1, title: '手机登录'},
        {id: 2, title: '邮箱登录'}
      ]
    }
  }
  componentDidMount () {
    // this.autoFocusInst.focus();
    // this.setState({
    //   currentIndex: 2
    // })
  }
  handleClick = () => {
    this.inputRef.focus()
  }
  login = () => {
    this.props.form.validateFields((error, values) => {
      if (error) {
        validErrorTip(error)
        return
      }
      values.email = values.email
      values.mobile = {
        code: (this.props.match.params.rowID ? this.props.match.params.rowID : '+86').substring(1),
        numbers: values.numbers
      }
      values.password = values.password
      this.props.dispatch({
        type: 'user/login',
        payload: {
          email: values.email,
          mobile: values.mobile,
          password: values.password
        },
        callback: res => {
          if (res.code === 200) {
            this.props.dispatch(routerRedux.push('/home/my'))
          } else {
            Toast.fail(res.msg)
          }
        }
      })
    })
  }

  changeSelect = status => {
    this.setState({
      currentIndex: status
    })
    this.props.form.setFieldsValue({
      password: ''
    })
  }

  showCountryAreaCode = bool => {
    this.setState({isShow: bool})
    let title = 'login'
    this.props.dispatch(routerRedux.push(`/user/countryAreacode/${title}`))
  }

  render () {
    const { getFieldProps, getFieldError } = this.props.form
    return (
      <Fragment>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() =>
            this.props.dispatch(routerRedux.push('/user/userLogin'))}
        >
          用户登录
        </NavBar>
        <div styleName={'statusNav'}>
          {this.state.loginType.map( item => {
            return (
              <a
                onClick={() => this.changeSelect(item.id)}
                styleName={this.state.currentIndex == item.id ? 'statusNav-selected': 'statusNav-select'}
                href='javascript:;'
                key = {item.id}
              >{item.title}</a>
            )
          })}
        </div>
        <WingBlank size='md'>
          <form className='form-margin'>
            <InputItem
              className={'userLogin-Listitem'}
              {...getFieldProps(this.state.currentIndex === 1 ? 'numbers' : 'email', {
                initialValue: '',
                rules: this.state.currentIndex === 1 ? [
                  {
                    required: true, 
                    message: '请输入你的手机号',
                  },
                  // { validator: this.validateAccount }
                ] : [
                  {
                    required: true,
                    message: '请输入你的邮箱',
                  },
                  // { validator: this.validateAccount }
                ]
              })}
              clear
              error={!!getFieldError(this.state.currentIndex === 1 ? 'numbers' : 'email')}
              placeholder={this.state.currentIndex === 1 ? '请输入你的手机号' : '请输入你的邮箱'}
              // type={this.state.currentIndex === 1 ? 'phone' : ''}
              style={this.state.currentIndex === 1 ? {paddingLeft: '124px'} : {paddingLeft: '0px'}}
            >
              <span styleName={this.state.currentIndex === 1 ? 'login-form-phone' : 'login-form-email'} />
              {this.state.currentIndex === 1 ? 
              <input value={this.props.match.params.rowID ? this.props.match.params.rowID :'+86'} onClick={() => this.showCountryAreaCode(true)} styleName={'country_areaCode'} />
              : ''}
            </InputItem>
            <InputItem
              className={'userLogin-item'}
              {...getFieldProps('password', {
                initialValue: '',
                rules: [
                  { 
                    required: true,
                    message: '请输入你的密码'
                  },
                ]
              })}
              clear
              error={!!getFieldError('password')}
              placeholder='请输入你的密码'
              type='password'
            >
              <span styleName={'login-form-password'} />
            </InputItem>
            <div styleName={'btn-form-login'}>
              <Button onClick={this.login} type='primary'>登录</Button>
            </div>
            <div styleName={'btn-form-control'}>
              <Link to={{ pathname: '/user/userRegister' }}>快速注册</Link>
              <Link
                to={{ pathname: '/user/forgetPassword' }}
                styleName={'login-form-forget'}
              >
                忘记密码？
              </Link>
            </div>
          </form>
        </WingBlank>
      </Fragment>
    )
  }
}
