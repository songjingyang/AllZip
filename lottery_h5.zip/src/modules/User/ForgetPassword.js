import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  Toast,
  WhiteSpace,
  WingBlank,
  NavBar,
  Icon,
  List,
  InputItem,
  Switch,
  Stepper,
  Range,
  Button,
  Checkbox
} from 'antd-mobile'
import { createForm } from 'rc-form'

import './ForgetPassword.less'
import { validErrorTip } from '../../utils/utils'

const Item = List.Item
const CheckboxItem = Checkbox.CheckboxItem

@createForm()
@connect(({ user }) => ({ user }))
export default class UserRegister extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      isAgree: true,
      count: 60,
      liked: true
    }
  }
  componentDidMount () {}
  handleClick = () => {
    this.inputRef.focus()
  }
  forgetPassword = () => {
    if (
      this.refs.email.state.value !== null &&
      this.refs.captcha.state.value !== null
    ) {
      this.props.form.validateFields((error, values) => {
        if (error) {
          validErrorTip(error)
          return
        }
        this.props.dispatch({
          type: 'user/forgetPasswordValid',
          payload: {
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              Toast.success(res.msg)
              this.props.dispatch(
                routerRedux.push(
                  `/user/resetPassword/${values.email}/${values.captcha}`
                )
              )
            } else {
              Toast.fail(res.msg)
            }
          }
        })
      })
    } else {
      Toast.fail('请输入注册邮箱')
    }
    // return
  }
  getCode = () => {
    if (this.refs.email.state.value.length !== 0) {
      if (!this.state.liked) {
        return
      }
      let count = this.state.count
      const timer = setInterval(() => {
        this.setState(
          {
            count: count--,
            liked: false
          },
          () => {
            if (count === 0) {
              clearInterval(timer)
              this.setState({
                liked: true,
                count: 60
              })
            }
          }
        )
      }, 1000)
      this.props.form.validateFields((error, values) => {
        values.type = 1
        this.props.dispatch({
          type: 'user/getCode',
          payload: {
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              Toast.success(res.msg)
            }
          }
        })
      })
    } else {
      Toast.fail('请输入邮箱')
    }
  }
  isAgree = () => {
    this.setState({
      isAgree: !this.state.isAgree
    })
  }
  render () {
    const { getFieldProps, getFieldError } = this.props.form
    return (
      <Fragment>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.history.goBack()}
        >
          找回密码
        </NavBar>
        <WingBlank size='md'>
          <form styleName={'form-margin'}>
            <InputItem
              className={'forgetPwd-item'}
              {...getFieldProps('email', {
                initialValue: '',
                rules: [
                  { required: true, message: '请输入注册邮箱' },
                  { validator: this.validateAccount }
                ]
              })}
              clear
              error={!!getFieldError('email')}
              onErrorClick={() => {
                alert(getFieldError('email').join('、'))
              }}
              placeholder='请输入注册邮箱'
              ref='email'
            >
              <span styleName={'forgetPwd-form-email'} />
            </InputItem>
            <InputItem
              className={'userRegister-item'}
              {...getFieldProps('captcha', {
                initialValue: '',
                rules: [
                  { required: true, message: '请输入验证码' },
                  { validator: this.validateAccount }
                ]
              })}
              placeholder='请输入验证码'
              ref='captcha'
            >
              <span styleName={'forgetPwd-form-code'} />
            </InputItem>
            <div styleName={'forgetPwd-getcode'}>
              {this.state.liked
                ? <Button
                  onClick={this.getCode}
                  type='primary'
                  inline
                  size='small'
                  >
                    获取验证码
                  </Button>
                : <Button disabled type='ghost' inline size='small'>
                    重新获取({this.state.count})
                  </Button>}
            </div>
            <div styleName={'btn-form-forgetPwd'}>
              <Button onClick={this.forgetPassword} type='primary'>下一步</Button>
            </div>
          </form>
        </WingBlank>
      </Fragment>
    )
  }
}
