import React, {Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import { List, Button, NavBar, Icon, TextareaItem, Toast, Modal } from 'antd-mobile'
import { createForm } from 'rc-form'
import RadioTag from '@/components/RadioTag'
import { getLotteryNameLabel } from '../../utils/lottery'

import './Feedback.less'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class Setting extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      feedbackType: ''
    }
  }
  componentDidMount () {}

  onChangeType = type => {
    this.setState({ feedbackType: type })
  }

  handleSubmit = () => {
    if (!this.state.feedbackType) {
      Modal.alert('提示', '请选择问题类型')
      return
    }
    this.props.dispatch({
      type: 'my/recharge',
      payload: {
        feedbackType: +this.state.feedbackType
      },
      callback: res => {
        if (res.code === 200) {
          Toast.success(res.msg)
          this.props.dispatch(routerRedux.push(''))
        }
      }
    })
  }

  render () {
    const { getFieldProps, getFieldError } = this.props.form;
    
    return (
      <Fragment>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
        >意见反馈</NavBar>
        <div styleName={'feedback-title'}>选择问题类型</div>
        <div styleName={'feedback-content'}>
          <div styleName={'feedback-type'}>
            <p onClick={() => this.feedbackType('1')}>1.提交失败</p>
            <p onClick={() => this.feedbackType('2')}>2.充值未到账</p>
            <p onClick={() => this.feedbackType('3')}>3.身份修改失败</p>
            <p onClick={() => this.feedbackType('4')}>4.拍讲数额错误</p>
          </div>
          <div styleName={'feedback-textArea'}>
            <div>描述遇到的问题及建议</div>
            <TextareaItem
              {...getFieldProps('count', {
                initialValue: '',
              })}
              rows={5}
              count={300}
            />
          </div>
          <div styleName='setting-margin'>
            <Button type='primary'>提交</Button>
          </div>
        </div>
      </Fragment>
    )
  }
}