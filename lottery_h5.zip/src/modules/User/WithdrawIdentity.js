import React, {Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  SegmentedControl,
  ListView
} from 'antd-mobile'
import { createForm } from 'rc-form'
import './aaa.less'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class BettingRecord extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      statusMap: {
        0: '全部',
        1: '充值',
        2: '购彩',
        3: '提现',
        4: '中奖'
      },
      currentIndex: 0,
      statusNav: [
        {id: 0, title: '全部'},
        {id: 1, title: '充值'},
        {id: 2, title: '购彩'},
        {id: 3, title: '提现'},
        {id: 4, title: '中奖'}
      ]
    };
  }
  componentDidMount () {
    this.props.dispatch({
      type: 'merchant/getMerchantStat',
      payload: {}
    })
  }

  search = (status) => {
    this.setState({
      currentIndex: status
    }, () => {
      console.log('currenIndex', this.state.currentIndex)
    })
    this.getAccountDetailList(status)
  }

  render () {
    const { getFieldProps, getFieldError } = this.props.form;
    
    return (
      <Fragment>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
        >充值</NavBar>
        <div styleName={'common-statusNav'}>
          {this.state.statusNav.map((item, index) => {
            return (
              <div
                onClick={()=> this.search(item.id)}
                styleName={this.state.currentIndex == item.id ? 'statusNav-selected' : 'statusNav-select'}
              >{item.title}</div>
            )
          })}
        </div>
      </Fragment>
    )
  }
}