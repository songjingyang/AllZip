import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  Toast,
  WingBlank,
  NavBar,
  Icon,
  List,
  InputItem,
  Button,
  Modal,
} from 'antd-mobile'
import { createForm } from 'rc-form'

import './SetMobile.less'
import { validErrorTip } from '../../utils/utils'

const Item = List.Item

@createForm()
@connect(({ user }) => ({ user }))
export default class UserRegister extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isAgree: false,
      count: 60,
      liked: true,
      currentIndex: 1,
      registerType: [
        { id: 1, title: '手机注册' },
        { id: 2, title: '邮箱注册' },
      ],
    }
  }
  componentDidMount() {}
  handleClick = () => {
    this.inputRef.focus()
  }
  register = () => {
    this.props.form.validateFields((error, values) => {
      if (error) {
        validErrorTip(error)
        return
      }

      values.email = values.email
      values.mobile = {
        // code: (this.props.match.params.rowID
        //   ? this.props.match.params.rowID
        //   : '+86'
        // ).substring(1),
        code: '86',
        numbers: values.numbers,
      }
      this.props.dispatch({
        type: 'user/setPayPass',
        payload: {
          pay_pswd: this.props.pass,
          captcha: values.captcha,
        },
        callback: res => {
          if (res.code === 200) {
            this.props.onConfirm && this.props.onConfirm()
          } else {
            this.props.onConfirm && this.props.onConfirm()
            Toast.fail(res.msg)
          }
        },
      })
    })
  }
  // 倒计时
  countDown = () => {
    if (!this.state.liked) {
      return
    }
    let count = this.state.count
    const timer = setInterval(() => {
      this.setState(
        {
          count: count--,
          liked: false,
        },
        () => {
          if (count === 0) {
            clearInterval(timer)
            this.setState({
              liked: true,
              count: 60,
            })
          }
        }
      )
    }, 1000)
  }
  // 获取验证码
  getCode = () => {
    if (this.state.currentIndex === 1) {
      if (this.props.form.getFieldsValue().numbers) {
        this.countDown()
        this.props.form.validateFields((error, values) => {
          values.type = 1
          values.mobile = {
            // code: (this.props.match.params.rowID
            //   ? this.props.match.params.rowID
            //   : '+86'
            // ).substring(1),
            code: '86',
            numbers: values.numbers,
          }
          this.props.dispatch({
            type: 'user/getCode',
            payload: {
              type: values.type,
              mobile: values.mobile,
            },
            callback: res => {
              if (res.code === 200) {
                Toast.success(res.msg)
              }
            },
          })
        })
      } else {
        Toast.fail('请输入手机号')
      }
    } else {
      if (this.props.form.getFieldsValue().email) {
        this.countDown()
        this.props.form.validateFields((error, values) => {
          values.type = 1
          this.props.dispatch({
            type: 'user/getCode',
            payload: {
              ...values,
            },
            callback: res => {
              if (res.code === 200) {
                Toast.success(res.msg)
              }
            },
          })
        })
      } else {
        Toast.fail('请输入邮箱')
      }
    }
  }
  isAgree = () => {
    this.setState({
      isAgree: !this.state.isAgree,
    })
  }
  changeSelect = status => {
    this.setState({
      currentIndex: status,
      isAgree: false,
    })
    this.props.form.setFieldsValue({
      captcha: '',
      code: '',
    })
  }
  showCountryAreaCode = bool => {
    this.setState({ isShow: bool })
    let title = 'register'
    this.props.dispatch(routerRedux.push(`/user/countryAreacode/${title}`))
  }
  render() {
    const { getFieldProps, getFieldError } = this.props.form
    return (
      <Fragment>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.onClose()}
        >
          验证手机号
        </NavBar>
        <WingBlank size="md">
          <form className="form-margin">
            <InputItem
              className={'userRegister-Listitem'}
              {...getFieldProps(
                this.state.currentIndex === 1 ? 'numbers' : 'email',
                {
                  initialValue: '',
                  rules:
                    this.state.currentIndex === 1
                      ? [
                          { required: true, message: '请输入注册手机号' },
                          { validator: this.validateAccount },
                        ]
                      : [
                          { required: true, message: '请输入注册邮箱' },
                          { validator: this.validateAccount },
                        ],
                }
              )}
              clear
              error={
                !!getFieldError(
                  this.state.currentIndex === 1 ? 'numbers' : 'email'
                )
              }
              placeholder={
                this.state.currentIndex === 1
                  ? '请输入注册手机号'
                  : '请输入注册邮箱'
              }
              // type={this.state.currentIndex === 1 ? 'phone' : ''}
              style={
                this.state.currentIndex === 1
                  ? { paddingLeft: '124px' }
                  : { paddingLeft: '0px' }
              }
            >
              <span
                styleName={
                  this.state.currentIndex === 1
                    ? 'register-form-phone'
                    : 'register-form-email'
                }
              />
              {this.state.currentIndex === 1 ? (
                <input
                  value={
                    // this.props.match.params.rowID
                    //   ? this.props.match.params.rowID
                    //   : '+86'
                    '+86'
                  }
                  onClick={() => this.showCountryAreaCode(true)}
                  styleName={'country_areaCode'}
                />
              ) : (
                ''
              )}
            </InputItem>
            <InputItem
              className={'userRegister-item'}
              {...getFieldProps('captcha', {
                initialValue: '',
                rules: [
                  { required: true, message: '请输入验证码' },
                  { validator: this.validateAccount },
                ],
              })}
              // error={!!getFieldError('captcha')}
              placeholder="请输入验证码"
              ref="get_code"
            >
              <span styleName={'register-form-code'} />
              <div styleName={'register-getcode'}>
                {this.state.liked ? (
                  <Button
                    onClick={this.getCode}
                    type="primary"
                    inline
                    size="small"
                  >
                    获取验证码
                  </Button>
                ) : (
                  <Button disabled type="ghost" inline size="small">
                    重新获取({this.state.count})
                  </Button>
                )}
              </div>
            </InputItem>
            <div styleName={'btn-form-register'}>
              <Button onClick={this.register} type="primary">
                下一步
              </Button>
            </div>
          </form>
        </WingBlank>
      </Fragment>
    )
  }
}
