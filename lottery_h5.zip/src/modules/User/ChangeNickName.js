import React, { Fragment } from 'react';
import { routerRedux, Link } from 'dva/router';
import { connect } from 'dva';
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  Toast,
  Modal,
} from 'antd-mobile';
import { createForm } from 'rc-form';
import './ChangeNickName.less';
import { validErrorTip } from '../../utils/utils';

const Item = List.Item;
const Brief = Item.Brief;

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class ChangeNickName extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'my/getAccountInfo',
      payload: {},
    });
  }
  changeNickName = () => {
    if (this.props.my.accountInfo.nickname) {
      Modal.alert('提示', '用户昵称只能修改一次');
      return;
    }

    this.props.form.validateFields((error, values) => {
      if (error) {
        validErrorTip(error);
        return;
      }
      this.props.dispatch({
        type: 'user/changeNickname',
        payload: {
          ...values,
        },
        callback: res => {
          if (res.code === 200) {
            Toast.success(res.msg);
            this.props.dispatch(routerRedux.push('/user/persionalInfo'));
          } else {
            Toast.fail(res.msg);
          }
        },
      });
    });
  };

  render() {
    const { getFieldProps, getFieldError } = this.props.form;

    return (
      <Fragment>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
        >
          修改昵称
        </NavBar>
        <div>
          <div styleName={'nickName-input'}>
            <InputItem
              {...getFieldProps('nickname', {
                initialValue: this.props.my.accountInfo.nickname,
                rules: [
                  { required: true, message: '请输入昵称' },
                  { validator: this.validateAccount },
                ],
              })}
              clear
              error={!!getFieldError('nickname')}
              onErrorClick={() => {
                alert(getFieldError('nickname').join('、'));
              }}
              placeholder="请输入昵称"
            >
              <span>新昵称</span>
            </InputItem>
          </div>
          <div styleName={'nickName-margin'}>
            <Button onClick={this.changeNickName} type="primary">
              立即修改
            </Button>
          </div>
          <div styleName={'nickName-tip'}>
            <span>温馨提示</span>
            <p>
              为保障平台秩序
              <br />
              昵称唯一且只能修改一次。{' '}
            </p>
          </div>
        </div>
      </Fragment>
    );
  }
}
