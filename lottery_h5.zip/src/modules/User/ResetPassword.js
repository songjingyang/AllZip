import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  Toast,
  WhiteSpace,
  WingBlank,
  NavBar,
  Icon,
  List,
  InputItem,
  Switch,
  Stepper,
  Range,
  Button
} from 'antd-mobile'
import { createForm } from 'rc-form'

import './SetPassword.less'
import { validErrorTip } from '../../utils/utils'

const Item = List.Item

@createForm()
@connect(({ user }) => ({ user }))
export default class ResetPassword extends React.Component {
  componentDidMount () {
    console.log('refs', this.refs.first_pwd.state.value)
  }
  handleClick = () => {
    this.inputRef.focus()
  }
  setPassword = () => {
    if (this.refs.first_pwd.state.value === this.refs.last_pwd.state.value) {
      this.props.form.validateFields((error, values) => {
        if (error) {
          validErrorTip(error)
          return
        }
        // values.merchant_id = JSON.parse(window.localStorage.getItem('user')).merchant_id
        values.email = this.props.match.params.email
        const params = this.props.match.params
        this.props.dispatch({
          type: 'user/forgetPassword',
          payload: {
            new_password: values.pwd,
            email: params.email,
            captcha: params.code
          },
          callback: res => {
            if (res.code === 200) {
              Toast.success(res.msg)
              this.props.dispatch(routerRedux.push('/home/my'))
            } else {
              Toast.fail(res.msg)
            }
          }
        })
      })
    } else {
      Toast.fail('俩次输入密码不同')
    }
  }

  render () {
    const { getFieldProps, getFieldError } = this.props.form
    return (
      <Fragment>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.history.goBack()}
        >
          重置密码
        </NavBar>
        <WingBlank size='md'>
          <form styleName={'form-margin'}>
            <InputItem
              className={'userLogin-item'}
              {...getFieldProps('pwd', {
                initialValue: '',
                rules: [
                  { required: true, message: '请输入密码' },
                  { validator: this.validateAccount }
                ]
              })}
              clear
              error={!!getFieldError('pwd')}
              onErrorClick={() => {
                alert(getFieldError('pwd').join('、'))
              }}
              placeholder='输入密码'
              type='password'
              ref='first_pwd'
            >
              <span styleName={'login-form-password'} />
            </InputItem>
            <InputItem
              className={'userLogin-item'}
              {...getFieldProps('password', {
                initialValue: '',
                rules: [
                  { required: true, message: '请再次输入密码' },
                  { validator: this.validateAccount }
                ]
              })}
              clear
              error={!!getFieldError('password')}
              onErrorClick={() => {
                alert(getFieldError('password').join('、'))
              }}
              placeholder='再次输入密码'
              type='password'
              ref='last_pwd'
            >
              <span styleName={'login-form-password'} />
            </InputItem>
            <div styleName={'btn-form-login'}>
              <Button onClick={this.setPassword} type='primary'>重置</Button>
            </div>
          </form>
        </WingBlank>
      </Fragment>
    )
  }
}
