import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Toast } from 'antd-mobile'
import { createForm } from 'rc-form'
import './PersionalInfo.less'
import UploadImg from '../../components/UploadImg'

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class PersionalInfo extends React.Component {
  constructor(props) {
    super(props)
    this.state = {}
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'my/getMyInfo',
      payload: {},
    })
  }

  upload = url => {
    this.props.dispatch({
      type: 'global/uploadQrcode',
      payload: {
        urls: [url],
        type: 'avatar', // 二维码类型
      },
      callback: res => {
        if (res.code === 200) {
          Toast.success('上传成功', 1)
          this.props.dispatch({
            type: 'my/getAccountInfo',
            payload: {},
          })
        }
      },
    })
  }

  render() {
    const { getFieldProps, getFieldError } = this.props.form
    const info = this.props.my.myInfo

    return (
      <Fragment>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.dispatch(routerRedux.push('/home/my'))}
        >
          个人信息
        </NavBar>
        <div>
          <div to={''} styleName={'persional-list'}>
            <span>头像</span>

            <div styleName={'persional-item'}>
              <div className="persional-avator" styleName={'persional-avator'}>
                <UploadImg
                  value={
                    info.avatar ? info.avatar : '/static/media/small-avator.png'
                  }
                  onChange={this.upload}
                />
              </div>
              <i />
            </div>
          </div>
          <Link to={'/user/changeNickName'} styleName={'persional-list'}>
            <span>昵称</span>
            <div styleName={'persional-item'}>
              <em styleName={'persional-nickName'}>
                {info.nickname ? info.nickname : '待补全'}
              </em>
              <i />
            </div>
          </Link>
        </div>
      </Fragment>
    )
  }
}
