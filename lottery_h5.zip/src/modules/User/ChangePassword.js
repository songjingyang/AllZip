import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  SegmentedControl,
  ListView,
  Toast
} from 'antd-mobile'
import { createForm } from 'rc-form'
import './ChangePassword.less'
import { validErrorTip } from '../../utils/utils'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global }) => ({ user, global }))
export default class ChangePassword extends React.Component {
  constructor (props) {
    super(props)
    this.state = {}
  }
  componentDidMount () {}
  changePassword = () => {
    if (
      this.refs.new_password.state.value ===
      this.refs.confirm_password.state.value
    ) {
      this.props.form.validateFields((error, values) => {
        if (error) {
          validErrorTip(error)
          return
        }
        // values.merchant_id = JSON.parse(window.localStorage.getItem('user')).merchant_id
        this.props.dispatch({
          type: 'user/changePassword',
          payload: {
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              Toast.success(res.msg)
              this.props.dispatch(routerRedux.push('/my/accountInfo'))
            } else {
              Toast.fail(res.msg)
            }
          }
        })
      })
    } else {
      Toast.fail('俩次输入密码不同')
    }
  }
  render () {
    const { getFieldProps, getFieldError } = this.props.form

    return (
      <div className='changePassword-page'>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.history.goBack()}
        >
          修改密码
        </NavBar>
        <WingBlank size='md'>
          <form>
            <InputItem
              className='forgetPassword-item'
              {...getFieldProps('old_password', {
                initialValue: '',
                rules: [
                  { required: true, message: '请输入原始密码' },
                  { validator: this.validateAccount }
                ]
              })}
              clear
              error={!!getFieldError('old_password')}
              onErrorClick={() => {
                alert(getFieldError('old_password').join('、'))
              }}
              placeholder='请输入原始密码'
              type='password'
            >
              原始密码：
            </InputItem>
            <InputItem
              className='forgetPassword-item'
              clear
              {...getFieldProps('new_password')}
              placeholder='密码由6-16位字母、数字组成'
              type='password'
              ref='new_password'
            >
              新密码：
            </InputItem>
            <InputItem
              className='forgetPassword-item'
              // {...getFieldProps('confirm-pwd')}
              clear
              placeholder='请再次输入新密码'
              type='password'
              ref='confirm_password'
            >
              确认密码：
            </InputItem>
            <div styleName={'form-margin'}>
              <Button onClick={this.changePassword} type='primary'>确定</Button>
            </div>
          </form>
        </WingBlank>
      </div>
    )
  }
}
