import React, { Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import { List, Button, NavBar, Icon, Toast, Modal } from 'antd-mobile'
import { createForm } from 'rc-form'
import './Setting.less'
import { getLotteryNameLabel } from '../../utils/lottery'

const Item = List.Item
const Brief = Item.Brief
const alert = Modal.alert

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class Setting extends React.Component {
  constructor (props) {
    super(props)
    this.state = {}
  }
  componentDidMount () {}

  logout = () => {
    this.props.dispatch({
      type: 'user/logout',
      payload: {},
      callback: res => {
        if (res.code === 200) {
          Toast.success(res.msg)
          this.props.dispatch(routerRedux.push('/home/my'))
          window.location.reload()
        }
      }
    })
  }

  render () {
    const { getFieldProps, getFieldError } = this.props.form

    return (
      <Fragment>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.props.dispatch(routerRedux.push('/home/my'))}
        >
          设置
        </NavBar>
        <List>
          <Link to={''}>
            <Item className='setting-list' arrow='horizontal'>通知中心</Item>
          </Link>
          {/* <Link to={'/user/aboutUs'}>
            <Item className='setting-list' arrow='horizontal'>关于我们</Item>
          </Link>
          <Link to={'/user/feedback'}>
            <Item className='setting-list' arrow='horizontal'>意见反馈</Item>
          </Link> */}
        </List>
        <div styleName='setting-margin'>
          <Button
            onClick={() =>
              alert('确定退出登录', '', [
                { text: '取消', onPress: () => console.log('cancel') },
                { text: '确定', onPress: this.logout }
              ])}
            type='primary'
          >
            退出登录
          </Button>
        </div>
      </Fragment>
    )
  }
}
