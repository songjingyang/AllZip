import React, {Fragment } from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
  Card,
  ImagePicker,
  NavBar,
  Icon,
  SegmentedControl,
  ListView
} from 'antd-mobile'
import { createForm } from 'rc-form'
import './AboutUs.less'
import { getLotteryNameLabel } from '../../utils/lottery'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, global, my }) => ({ user, global, my }))
export default class Setting extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

    }
  }
  componentDidMount () {
    this.props.dispatch({
      type: 'merchant/getMerchantStat',
      payload: {}
    })
  }

  search = (status) => {
    this.setState({
      currentIndex: status
    }, () => {
      console.log('currenIndex', this.state.currentIndex)
    })
    this.getAccountDetailList(status)
  }

  render () {
    const { getFieldProps, getFieldError } = this.props.form;
    
    return (
      <div className='aboutUs-page'>
        <NavBar
          mode="light"
          icon={<Icon type="left" />}
          onLeftClick={() => this.props.history.goBack()}
        >关于我们</NavBar>
        <List>
          <Item className='setting-list'>版本号<span>V1.0.0</span></Item>
          <Item className='setting-list'>网址<span>Http：//www.youcai1000.com</span></Item>
          <Item className='setting-list'>公司<span>北京恶化的示范点建设公司</span></Item>
        </List>
      </div>
    )
  }
}