/*
 * @Author: daycool
 * @Date: 2018-08-24 14:18:44
 * @Last Modified by: daycool
 * @Last Modified time: 2018-09-29 11:53:09
 */
import React from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  List,
  InputItem,
  WhiteSpace,
  Button,
  Calendar,
  SearchBar,
  Icon,
  Modal
} from 'antd-mobile'
import { createForm } from 'rc-form'
import { toSecond } from '../../utils/utils'
import { spawn } from 'child_process'

const Item = List.Item
const Brief = Item.Brief

const extra = {
  '2017/07/15': { info: 'Disable', disable: true }
}
const now = new Date()
extra[+new Date(now.getFullYear(), now.getMonth(), now.getDate() + 5)] = {
  info: 'Disable',
  disable: true
}
extra[+new Date(now.getFullYear(), now.getMonth(), now.getDate() + 6)] = {
  info: 'Disable',
  disable: true
}
extra[+new Date(now.getFullYear(), now.getMonth(), now.getDate() + 7)] = {
  info: 'Disable',
  disable: true
}
extra[+new Date(now.getFullYear(), now.getMonth(), now.getDate() + 8)] = {
  info: 'Disable',
  disable: true
}

Object.keys(extra).forEach(key => {
  const info = extra[key]
  const date = new Date(key)
  if (!Number.isNaN(+date) && !extra[+date]) {
    extra[+date] = info
  }
})

function closest (el, selector) {
  const matchesSelector =
    el.matches ||
    el.webkitMatchesSelector ||
    el.mozMatchesSelector ||
    el.msMatchesSelector
  while (el) {
    if (matchesSelector.call(el, selector)) {
      return el
    }
    el = el.parentElement
  }
  return null
}

@createForm()
@connect(({ user, merchant }) => ({ user, merchant }))
export default class UserLogin extends React.Component {
  originbodyScrollY = document.getElementsByTagName('body')[0].style.overflowY
  constructor (props) {
    super(props)
    this.state = {
      value: '',
      startTime: '',
      endTime: '',
      en: false,
      show: false,
      config: { showShortcut: true },
      currItem: {}
    }
  }

  componentDidMount () {
    this.getData()
  }

  changeLanguage = () => {
    this.setState({
      en: !this.state.en
    })
  }

  onSelectHasDisableDate = dates => {
    console.warn('onSelectHasDisableDate', dates)
  }

  onConfirm = (startTime, endTime) => {
    document.getElementsByTagName('body')[
      0
    ].style.overflowY = this.originbodyScrollY
    this.setState(
      {
        show: false,
        startTime,
        endTime
      },
      () => {
        // this.getData()
      }
    )
  }

  onCancel = () => {
    document.getElementsByTagName('body')[
      0
    ].style.overflowY = this.originbodyScrollY
    this.setState({
      isShowModal: false,
      show: false,
      startTime: undefined,
      endTime: undefined
    })
  }

  getDateExtra = date => extra[+date]
  selectDate = () => {
    this.setState({ show: true })
  }
  onChangeDate = value => {2
    this.setState({ value })
  }
  jumpMerchantEdit = item => {
    // this.props.dispatch(routerRedux.push(`/merchant/edit/${item.account}`))
    this.props.dispatch(
      routerRedux.push(`/merchant/edit/${item.account}/${item.amount}`)
    )
    // this.setState({
    //   isShowModal: true
    // })
  }
  del = item => e => {
    e.preventDefault() // 修复 Android 上点击穿透
    // alert(333)
    e.isPropagationStopped = true
    e.isDefaultPrevented()

    this.props.dispatch({
      type: 'merchant/delAccount',
      payload: item,
      callback: res => {
        if (res.code === '1') {
          this.getData()
        }
      }
    })
  }
  jumpMerchant = (e, item) => {
    e.isPropagationStopped = true
    e.isDefaultPrevented()
    this.props.dispatch(
      routerRedux.push(`/merchant/info/${item.account}/${item.amount}`)
    )
  }

  showMore = item => e => {
    e.preventDefault() // 修复 Android 上点击穿透
    // e.isPropagationStopped = true
    // e.isDefaultPrevented()
    this.setState({
      currItem: item
    })
  }
  onClose = key => () => {
    this.setState({
      [key]: false
    })
  }

  onWrapTouchStart = e => {
    // fix touch to scroll background page on iOS
    if (!/iPhone|iPod|iPad/i.test(navigator.userAgent)) {
      return
    }
    const pNode = closest(e.target, '.am-modal-content')
    if (!pNode) {
      e.preventDefault()
    }
  }

  getData = () => {
    this.props.dispatch({
      type: 'merchant/getAccountList',
      payload: {
        startTime: toSecond(this.state.startTime),
        endTime: toSecond(this.state.endTime)
      }
    })
  }

  render () {
    const { getFieldProps } = this.props.form
    const { accountListInfo: { list } } = this.props.merchant
    console.log('​UserLogin -> render -> list', list)

    return (
      <div>
        <Button
          onClick={() =>
            this.props.dispatch(routerRedux.push('/merchant/stat'))}
          type='ghost'
          inline
          size='large'
          style={{ float: 'left', marginLeft: 10, marginTop: 5 }}
        >
          商户收入
        </Button>
        <Button
          onClick={() =>
            this.props.dispatch(routerRedux.push('/merchant/merchantStat'))}
          type='ghost'
          inline
          size='small'
          style={{ float: 'left', marginLeft: 10, marginTop: 5 }}
        >
          QR使用量
        </Button>
        <Button
          onClick={() =>
            this.props.dispatch(routerRedux.push('/merchant/incomeStat'))}
          type='ghost'
          inline
          size='small'
          style={{ float: 'left', marginLeft: 10, marginTop: 5 }}
        >
          代理收入
        </Button>
        <Button
          onClick={() =>
            this.props.dispatch(routerRedux.push('/merchant/edit/0/0'))}
          type='primary'
          inline
          size='small'
          style={{ float: 'right', marginRight: 10, marginTop: 5 }}
        >
          添加
        </Button>
        <WhiteSpace size='lg' />
        {/* <InputItem
          value={
            this.state.startTime
              ? this.state.startTime.toLocaleDateString() +
                  '~' +
                  this.state.endTime.toLocaleDateString()
              : ''
          }
          placeholder='请选择日期范围'
          onFocus={this.selectDate}
        /> */}
        <List renderHeader={() => ''}>
          {list.map(item => (
            <Item
              key={item.id}
              // arrow='horizontal'
              multipleLine
              extra={
                <span>
                  <Button
                    style={{ marginBottom: '0.5rem' }}
                    size='small'
                    onClick={() => this.jumpMerchantEdit(item)}
                  >
                    编辑
                  </Button>
                  <span style={{ display: 'block', height: '10' }} />
                  <Button
                    onClick={this.del(item)}
                    size='small'
                    style={{ marignTop: 15, color: 'red' }}
                  >
                    删除
                  </Button>
                </span>
              }
              onClick={this.showMore(item)}
            >
              <Brief>账号：{item.account} </Brief>
              <Brief>金额(分)：{item.amount}</Brief>
              <Brief>开关：{item.switch === '1' ? '开' : '关'}</Brief>
              {this.state.currItem.account == item.account
                ? <div>
                  <Brief>工作(时): {item.hour_start} ~ {item.hour_end}</Brief>
                  <Brief>
                      工作(分): {item.minute_start} ~ {item.minute_end}
                  </Brief>
                  <Brief>阀值: {item.safe_time}</Brief>
                  <Brief>下限: {item.floor}</Brief>
                  <Brief>接口版本: {item.api_vers}</Brief>
                  {/* <Brief>商户: {item.mchs}</Brief> */}
                  {/* {item.mchs && '商户信息'} */}
                  {/* {item.mchs} */}
                  <Brief>商户: </Brief>
                  {item.mchs.split(',') &&
                      item.mchs.split(',').map(item => (
                        <span>
                          <Brief>- {item}</Brief>
                        </span>
                      ))}
                </div>
                : <Brief>更多...</Brief>}
            </Item>
          ))}

        </List>

        <Modal
          visible={this.state.isShowModal}
          transparent
          maskClosable={false}
          onClose={this.onClose('isShowModal')}
          title='Title'
          footer={[
            {
              text: 'Ok',
              onPress: () => {
                console.log('ok')
                this.onClose('isShowModal')()
              }
            }
          ]}
          wrapProps={{ onTouchStart: this.onWrapTouchStart }}
        >
          <div style={{ height: 100, overflow: 'scroll' }}>
            <p>开始时间：{this.state.currItem.startTime}</p>
            <p>结束时间{this.state.currItem.endTime}</p>
            <p>阀值：{this.state.currItem.thresholdVal}</p>
            <p>通道：{this.state.currItem.channel}</p>
            <p>接口版本：{this.state.currItem.interfaceVersion}</p>
            {this.state.currItem.merchant &&
              this.state.currItem.merchant.map(item => (
                <span>
                  <p>Id：{item.id}</p>
                  <p>名称：{item.name}</p>
                </span>
              ))}
          </div>
        </Modal>

        <Calendar
          {...this.state.config}
          visible={this.state.show}
          onCancel={this.onCancel}
          onConfirm={this.onConfirm}
          onSelectHasDisableDate={this.onSelectHasDisableDate}
          getDateExtra={this.getDateExtra}
          defaultDate={now}
          minDate={new Date(+now - 5184000000)}
          maxDate={new Date(+now + 31536000000)}
        />

      </div>
    )
  }
}
