/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-09-01 13:43:40
 */
import React from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import { List, InputItem, WhiteSpace, Button, WingBlank } from 'antd-mobile'
import { createForm } from 'rc-form'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, merchant }) => ({ user, merchant }))
export default class MerchantStat extends React.Component {
  componentDidMount () {
    this.props.dispatch({
      type: 'merchant/getMerchantList'
    })
  }
  handleClick = () => {
    this.inputRef.focus()
  }
  render () {
    const { getFieldProps } = this.props.form
    const { merchant: { listInfo } } = this.props

    return (
      <div>

        <List renderHeader={() => 'QR使用量'}>
          {listInfo.list.map(item => (
            <Item key={item.mch_id} arrow='horizontal' multipleLine extra={''}>

              商户id: {item.mch_id}
              <Brief>单价：{item.amount}</Brief>
              <Brief>使用量：{item.count}</Brief>
              {/* <Brief>订单数量：{item.orderCount}</Brief> */}
            </Item>
          ))}
        </List>

      </div>
    )
  }
}
