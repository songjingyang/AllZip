import React from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import {
  List,
  InputItem,
  WhiteSpace,
  WingBlank,
  DatePicker,
  Button,
  Switch,
  Icon,
  NavBar,
  Drawer,
} from 'antd-mobile'
import { createForm } from 'rc-form'
import { config } from 'rx'
import classnames from 'classnames'
import './Edit.css'
const Item = List.Item
const Brief = Item.Brief
@createForm()
@connect(({ user, merchant }) => ({ user, merchant }))
export default class UserLogin extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isShowMerchantList: false,
      accountInfo: {
        id: '',
        account: '',
        amount: '',
        switch: '',
        hour_start: '',
        hour_end: '',
        minute_start: '',
        minute_end: '',
        floor: '',
        safe_time: '',
        pay_types: '',
        api_vers: '',
        mchs: [],
      },
    }
  }
  componentWillReceiveProps(nextProps) {}
  componentDidMount() {
    const account = this.props.match.params.account
    const amount = this.props.match.params.amount
    account != 0 &&
      this.props.dispatch({
        type: 'merchant/getAccount',
        payload: {
          account: account,
          amount: amount,
        },
        callback: res => {
          if (res.code === '1') {
            this.setState({
              accountInfo: {
                ...res.data.info,
                mchs: res.data.info.mchs
                  .split(',')
                  .map(item => ({ mch_id: item })),
              },
            })
          }
        },
      })

    this.props.dispatch({
      type: 'merchant/getMerchantList',
    })
  }
  handleClick = () => {
    this.inputRef.focus()
  }
  change = (field, val) => {
    const accountInfo = this.state.accountInfo
    if (val === '') return
    this.setState(
      {
        accountInfo: {
          ...accountInfo,
          [field]: [...accountInfo[field], val],
        },
      },
      () => {
        this.props.form.setFieldsValue({
          [field]: '',
        })
      }
    )
  }
  onOpenChange = () => {
    this.setState({
      isShowMerchantList: !this.state.isShowMerchantList,
    })
  }
  delete = (field, val) => {
    const accountInfo = this.state.accountInfo
    this.setState({
      accountInfo: {
        ...accountInfo,
        [field]: accountInfo[field].filter(item => item !== val),
      },
    })
  }
  addMerchant = item => {
    const accountInfo = this.state.accountInfo
    this.setState({
      isShowMerchantList: false,
      accountInfo: {
        ...accountInfo,
        mchs: [...accountInfo.mchs, item],
      },
    })
  }
  formatDate = date => {
    if (date instanceof Date) {
      const pad = n => (n < 10 ? `0${n}` : n)
      const timeStr = `${pad(date.getHours())}:${pad(date.getMinutes())}`
      return `${timeStr}`
    } else {
      return date
    }
  }

  changeTime = field => time => {
    this.setState({
      accountInfo: {
        ...this.state.accountInfo,
        [field]: time,
      },
    })
  }
  saveAccount = () => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'merchant/saveAccount',
          payload: {
            ...this.state.accountInfo,
            ...values,
            // switch: '1',
            // hour_start: values.startTime.split(':')[0],
            // hour_end: values.endTime.split(':')[0],
            // minute_start: values.startTime.split(':')[1],
            // minute_end: values.endTime.split(':')[1],
            // floor: '100',
            // safe_time: '12',
            // pay_types: '100,200',
            // api_vers: '0,2',
            mchs: this.state.accountInfo.mchs
              .map(item => item.mch_id)
              .join(','),
          },
          callback: res => {
            if (res.code === '1') {
              this.props.dispatch(routerRedux.push('/merchant/list'))
            }
          },
        })
      } else {
        console.log(err, 'err')
      }
    })
  }
  render() {
    const { getFieldProps, getFieldError } = this.props.form
    const {
      merchant: { listInfo },
    } = this.props
    const accountInfo = this.state.accountInfo

    return (
      <div>
        <List renderHeader={() => ''}>
          <InputItem
            {...getFieldProps('account', {
              initialValue: accountInfo.account,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="手机号"
            error={
              getFieldError('account') && getFieldError('account').length > 0
            }
          >
            账户
          </InputItem>
          <InputItem
            {...getFieldProps('amount', {
              initialValue: accountInfo.amount,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="1000"
            error={
              getFieldError('amount') && getFieldError('amount').length > 0
            }
          >
            金额(分)
          </InputItem>
          <InputItem
            {...getFieldProps('switch', {
              initialValue: accountInfo.switch,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="1开 0关"
            error={
              getFieldError('amount') && getFieldError('amount').length > 0
            }
          >
            开关
          </InputItem>
          <InputItem
            {...getFieldProps('floor', {
              initialValue: accountInfo.floor,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="100"
            error={getFieldError('floor') && getFieldError('floor').length > 0}
          >
            下限
          </InputItem>
          <InputItem
            {...getFieldProps('safe_time', {
              initialValue: accountInfo.safe_time,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="10"
            error={
              getFieldError('safe_time') &&
              getFieldError('safe_time').length > 0
            }
          >
            响应时间(秒)
          </InputItem>
          <InputItem
            {...getFieldProps('pay_types', {
              initialValue: accountInfo.pay_types,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="100,200"
            error={
              getFieldError('pay_types') &&
              getFieldError('pay_types').length > 0
            }
          >
            支付类型
          </InputItem>
          <InputItem
            {...getFieldProps('api_vers', {
              initialValue: accountInfo.api_vers,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="0,2"
            error={
              getFieldError('api_vers') && getFieldError('api_vers').length > 0
            }
          >
            接口版本
          </InputItem>

          <InputItem
            {...getFieldProps('hour_start', {
              initialValue: accountInfo.hour_start,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="10"
            error={
              getFieldError('hour_start') &&
              getFieldError('hour_start').length > 0
            }
          >
            开始(时)
          </InputItem>
          <InputItem
            {...getFieldProps('hour_end', {
              initialValue: accountInfo.hour_end,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="10"
            error={
              getFieldError('hour_end') && getFieldError('hour_end').length > 0
            }
          >
            结束(时)
          </InputItem>
          <InputItem
            {...getFieldProps('minute_start', {
              initialValue: accountInfo.minute_start,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="10"
            error={
              getFieldError('minute_start') &&
              getFieldError('minute_start').length > 0
            }
          >
            开始(分)
          </InputItem>
          <InputItem
            {...getFieldProps('minute_end', {
              initialValue: accountInfo.minute_end,
              rules: [{ required: true, message: '必填项' }],
            })}
            placeholder="10"
            error={
              getFieldError('minute_end') &&
              getFieldError('minute_end').length > 0
            }
          >
            结束(分)
          </InputItem>
          {/* <DatePicker
            mode='time'
            extra=' '
            onChange={this.changeTime('startTime')}
          >
            <InputItem
              {...getFieldProps('startTime', {
                initialValue: this.formatDate(accountInfo.startTime),
                rules: [{ required: true, message: '必填项' }]
              })}
              placeholder='请输入开始上班时间'
              error={
                getFieldError('startTime') &&
                  getFieldError('startTime').length > 0
              }
            >
              上班时间
            </InputItem>
          </DatePicker>
          <DatePicker
            mode='time'
            extra=' '
            minDate={this.state.accountInfo.startTime}
            onChange={this.changeTime('endTime')}
          >
            <InputItem
              {...getFieldProps('endTime', {
                initialValue: this.formatDate(accountInfo.endTime),
                rules: [{ required: true, message: '必填项' }]
              })}
              placeholder='请输入开始下班时间'
              error={
                getFieldError('endTime') && getFieldError('endTime').length > 0
              }
            >
              下班时间
            </InputItem>
          </DatePicker> */}
          {/* <DatePicker
            mode='time'
            minDate={this.state.accountInfo.startTime}
            {...getFieldProps('endTime', {
              initialValue: this.state.accountInfo.endTime,
              rules: [{ required: true, message: '请选择开始下载班时间' }]
            })}
          >
            <List.Item arrow='horizontal'>下班时间</List.Item>
          </DatePicker> */}
          {/* <InputItem
            {...getFieldProps('time', {
              initialValue: accountInfo.time,
              rules: [{ required: true, message: '必填项' }]
            })}
            placeholder='请输入时间'
            error={getFieldError('time') && getFieldError('time').length > 0}
          >
            时间
          </InputItem> */}
        </List>

        <List renderHeader={() => '商户'}>
          {accountInfo.mchs.map(item => (
            <List.Item
              key={item.mch_id}
              extra={
                <Icon
                  type="cross-circle-o"
                  onClick={() => {
                    this.delete('mchs', item)
                  }}
                />
              }
            >
              {item.mch_id}
            </List.Item>
          ))}
        </List>
        <Button type="ghost" onClick={this.onOpenChange}>
          添加商户
        </Button>
        <WhiteSpace size="xl" />
        <Button onClick={this.saveAccount} type="primary" icon="check-circle-o">
          保存
        </Button>

        <Drawer
          className={classnames({
            'my-drawer': true,
            'my-drawer-open': this.state.isShowMerchantList,
          })}
          style={{ minHeight: document.documentElement.clientHeight }}
          contentStyle={{
            backgroundColor: '#fff',
            color: '#A6A6A6',
            textAlign: 'center',
            paddingTop: 42,
          }}
          enableDragHandle
          open={this.state.isShowMerchantList}
          onOpenChange={this.onOpenChange}
          sidebarStyle={{ border: '1px solid #ddd' }}
          sidebar={
            <List renderHeader={() => 'QR使用量'}>
              {listInfo.list.map(item => (
                <Item
                  key={item.mch_id}
                  arrow="horizontal"
                  multipleLine
                  extra={<div onClick={() => this.addMerchant(item)}>添加</div>}
                >
                  商户id: {item.mch_id}
                  <Brief>单价：{item.amount}</Brief>
                  <Brief>总数：{item.count}</Brief>
                  {/* <Brief>订单数量：{item.orderCount}</Brief> */}
                </Item>
              ))}
            </List>
          }
        >
          商户
        </Drawer>
      </div>
    )
  }
}
