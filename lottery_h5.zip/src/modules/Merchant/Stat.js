/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-08-31 14:19:10
 */
import React from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import { List, InputItem, WhiteSpace, Button, WingBlank } from 'antd-mobile'
import { createForm } from 'rc-form'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, merchant }) => ({ user, merchant }))
export default class Stat extends React.Component {
  componentDidMount () {
    this.props.dispatch({
      type: 'merchant/getMerchantStat',
      payload: {}
    })
  }
  handleClick = () => {
    this.inputRef.focus()
  }
  render () {
    const { getFieldProps } = this.props.form
    const { statInfo: { list} } = this.props.merchant

    return (
      <div>

        <List renderHeader={() => '收入统计'}>
          {list.map(item => <Item extra=''>
            <span>
              <Brief>商户：{item.mch_id}</Brief>
              <Brief>收入：{item.amount}</Brief>
              <Brief>订单：{item.count}</Brief>
            </span>
          </Item>)}
        </List>

      </div>
    )
  }
}
