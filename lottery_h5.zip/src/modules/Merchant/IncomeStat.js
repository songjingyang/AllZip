/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-09-01 13:43:02
 */
import React from 'react'
import { routerRedux, Link } from 'dva/router'
import { connect } from 'dva'
import { List, InputItem, WhiteSpace, Button, WingBlank } from 'antd-mobile'
import { createForm } from 'rc-form'

const Item = List.Item
const Brief = Item.Brief

@createForm()
@connect(({ user, merchant }) => ({ user, merchant }))
export default class IncomeStat extends React.Component {
  componentDidMount () {
    this.props.dispatch({
      type: 'merchant/getTodayStat',
      payload: {}
    })
  }
  handleClick = () => {
    this.inputRef.focus()
  }
  render () {
    const { getFieldProps } = this.props.form
    const { todayStatInfo: { list } } = this.props.merchant

    return (
      <div>

        <List renderHeader={() => '今日收入'}>
          {list.map(item => (
            <Item extra=''>
              <span>
                <Brief>时间：{item.created}</Brief>
                <Brief>代理：{item.account}</Brief>
                <Brief>订单号：{item.order_id}</Brief>
                <Brief>商户：{item.ach_id}</Brief>
                <Brief>金额：{item.amount}</Brief>
              </span>
            </Item>
          ))}
        </List>

      </div>
    )
  }
}
