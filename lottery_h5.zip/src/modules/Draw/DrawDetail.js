/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-10-26 11:57:09
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import {
  NavBar,
  Icon,
  Card,
  Button,
  WingBlank,
  WhiteSpace,
  List,
  ListView
} from 'antd-mobile'
import { createForm } from 'rc-form'

import { saveCache, getCache, guid, dateFormater } from '@/utils/utils'
import { getLotteryName } from '../../utils/lottery'
import './DrawDetail.less'

@createForm()
@connect(({ user, global, draw }) => ({ user, global, draw }))
export default class DrawDetail extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      lotteryName: '',
      period: '',
      time: '',
      numbers: [],
      sum: ''
    }
  }

  componentDidMount () {
    const params = this.props.match.params
    this.setState({
      ...params,
      numbers: (params.numbers && params.numbers.split(',')) || []
    })
  }

  jumpDrawDetail = item => {
    this.props.dispatch(
      routerRedux.push(`/draw/lastDraw/${item.lott_inner_name}`)
    )
  }

  buy = () => {
    const params = this.props.match.params
    let lotteryComponentName = 'fastThree'
    if (/eleven_five/.test(params.lotteryName)) {
      lotteryComponentName = 'elevenFive'
    } else if (/tick_tick/.test(params.lotteryName)) {
      lotteryComponentName = 'tick'
    }
    let url = `/lottery/${lotteryComponentName}/${params.lotteryName}`

    this.props.dispatch(routerRedux.push(url))
  }

  render () {
    const data = this.state
    let lotteryName = this.props.match.params.lotteryName
    lotteryName = getLotteryName(lotteryName)

    return (
      <div styleName='draw-detail-page'>
        <NavBar
          mode='dark'
          leftContent={
            <Icon
              onClick={() => this.props.history.go(-1)}
              type='left'
              size='md'
            />
          }
        >
          开奖详情
        </NavBar>
        <Card>
          <div styleName='item'>
            <div>
              <div styleName='title'>
                第{data.period}期 &nbsp; &nbsp; &nbsp;
                {dateFormater(data.time)}
              </div>
              {lotteryName == 'fast_three' &&
                <div styleName='desc'>
                  {data.numbers.map(num => (
                    <span className={`dice dice${num}`} />
                  ))}
                  &nbsp;&nbsp;
                  <span styleName='sum'>
                    和值:
                    {data.sum}
                  </span>
                </div>}
              {lotteryName == 'eleven_five' &&
                <div styleName='desc'>
                  {data.numbers.map(num => (
                    <span
                      key={num}
                      className={`ball`}
                      style={{ background: '' }}
                    >
                      {num}
                    </span>
                  ))}
                </div>}
            </div>
          </div>
        </Card>
        <WhiteSpace size='md' />
        {lotteryName == 'fast_three' &&
          <table styleName='prize-desc'>
            <thead>
              <tr>
                <td>奖项</td>
                <td>每注金额(元)</td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>和值</td>
                <td>9~240</td>
              </tr>
              <tr>
                <td>三同号通选</td>
                <td>40</td>
              </tr>
              <tr>
                <td>三同号单选</td>
                <td>240</td>
              </tr>
              <tr>
                <td>二同号复选</td>
                <td>15</td>
              </tr>
              <tr>
                <td>二同号单选</td>
                <td>80</td>
              </tr>
              <tr>
                <td>三不同号</td>
                <td>40</td>
              </tr>
              <tr>
                <td>二不同号</td>
                <td>8</td>
              </tr>
              <tr>
                <td>三连号通选</td>
                <td>10</td>
              </tr>
            </tbody>
          </table>}
        {lotteryName == 'eleven_five' &&
          <table styleName='prize-desc'>
            <thead>
              <tr>
                <td>奖项</td>
                <td>每注金额(元)</td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>任选二</td>
                <td>6</td>
              </tr>
              <tr>
                <td>任选三</td>
                <td>19</td>
              </tr>
              <tr>
                <td>任选四</td>
                <td>78</td>
              </tr>
              <tr>
                <td>任选五</td>
                <td>540</td>
              </tr>
              <tr>
                <td>任选六</td>
                <td>90</td>
              </tr>
              <tr>
                <td>任选七</td>
                <td>26</td>
              </tr>
              <tr>
                <td>任选八</td>
                <td>9</td>
              </tr>
              <tr>
                <td>前一直选</td>
                <td>13</td>
              </tr>
              <tr>
                <td>前二直选</td>
                <td>130</td>
              </tr>
              <tr>
                <td>前二组选</td>
                <td>65</td>
              </tr>
              <tr>
                <td>前三直选</td>
                <td>1170</td>
              </tr>
              <tr>
                <td>前三组选</td>
                <td>195</td>
              </tr>
            </tbody>
          </table>}
        {lotteryName == 'tick_tick' &&
          <table styleName='prize-desc'>
            <thead>
              <tr>
                <td>奖项</td>
                <td>每注金额(元)</td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>五星直选</td>
                <td>100000</td>
              </tr>
              <tr>
                <td>五星通选</td>
                <td>20440</td>
              </tr>
              <tr>
                <td>三星</td>
                <td>1000</td>
              </tr>
              <tr>
                <td>三星组六</td>
                <td>160</td>
              </tr>
              <tr>
                <td>二星直选</td>
                <td>100</td>
              </tr>
              <tr>
                <td>二星组选</td>
                <td>50</td>
              </tr>
              <tr>
                <td>一星</td>
                <td>10</td>
              </tr>
              <tr>
                <td>大小单双</td>
                <td>4</td>
              </tr>
              <tr>
                <td>三星组三</td>
                <td>320</td>
              </tr>

            </tbody>
          </table>}
        <div onClick={this.buy} styleName='footer'>
          <Button onClick={this.bet} type='primary' style={{ borderRadius: 0 }}>
            购彩投注
          </Button>
        </div>
      </div>
    )
  }
}
