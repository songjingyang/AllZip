/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-10-23 16:23:49
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import {
  NavBar,
  Icon,
  Card,
  Button,
  WingBlank,
  WhiteSpace,
  List,
  ListView,
  Toast
} from 'antd-mobile'
import { createForm } from 'rc-form'
import CheckboxTag from '@/components/CheckboxTag'
import CountDown from '@/components/CountDown'
import { getLotteryCount, getRandomDraw } from '@/utils/lottery'
import { saveCache, getCache, guid, dateFormater } from '@/utils/utils'
import './DrawInfo.less'
import { getLotteryName } from '../../utils/lottery'

@createForm()
@connect(({ user, global, draw }) => ({ user, global, draw }))
export default class DrawInfo extends React.Component {
  constructor (props) {
    super(props)
    const dataSource = new ListView.DataSource({
      rowHasChanged: (row1, row2) => row1 !== row2
    })

    this.state = {
      dataSource,
      isLoading: true
    }
  }

  componentDidMount () {
    // you can scroll to the specified position
    // setTimeout(() => this.lv.scrollTo(0, 120), 800);

    // simulate initial Ajax

    this.props.dispatch({
      type: 'draw/getDrawInfo',
      payload: {},
      callback: res => {
        if (res.code === 200) {
          setTimeout(() => {
            this.rData = genData()
            this.setState({
              dataSource: this.state.dataSource.cloneWithRows(this.rData),
              isLoading: false
            })
          }, 600)
        }
      }
    })
  }

  // If you use redux, the data maybe at props, you need use `componentWillReceiveProps`
  // componentWillReceiveProps(nextProps) {
  //   if (nextProps.dataSource !== this.props.dataSource) {
  //     this.setState({
  //       dataSource: this.state.dataSource.cloneWithRows(nextProps.dataSource),
  //     });
  //   }
  // }

  onEndReached = event => {
    // load new data
    // hasMore: from backend data, indicates whether it is the last page, here is false
    if (this.state.isLoading && !this.state.hasMore) {
      return
    }
    console.log('reach end', event)
    this.setState({ isLoading: true })
    setTimeout(() => {
      this.rData = { ...this.rData, ...genData(++pageIndex) }
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(this.rData),
        isLoading: false
      })
    }, 1000)
  }

  jumpHome = () => {
    this.props.dispatch(routerRedux.push(`/home/home`))
  }

  getNumInfo = item => {
    const arr = []
    item.draw_numbers &&
      item.draw_numbers.forEach(itemData => {
        itemData.numbers &&
          itemData.numbers.forEach((num, index) => {
            if (/fast_three/.test(item.lott_inner_name)) {
              arr.push(
                <span
                  key={item.lott_inner_name + num + index}
                  className={`dice dice${num}`}
                  style={{ color: itemData.color }}
                />
              )
            } else {
              arr.push(
                <span
                  key={item.lott_inner_name + num + index}
                  className={`ball`}
                  style={{ background: itemData.color }}
                >
                  {num}
                </span>
              )
            }
          })
      })

    if (/fast_three/.test(item.lott_inner_name)) {
      arr.push(
        <span key={item.lott_inner_name} styleName='sum'>
          和值:
          {item.draw_numbers[0].numbers.reduce(
            (total, item) => total + item,
            0
          )}
        </span>
      )
    }

    return arr
  }

  jumpLastDraw = item => {
    let lotteryName = getLotteryName(item.lott_inner_name)
    if (
      lotteryName !== 'fast_three' &&
      lotteryName !== 'eleven_five' &&
      lotteryName !== 'tick_tick'
    ) {
      Toast.offline('敬请期待', 1)
      return
    }
    this.props.dispatch(
      routerRedux.push(`/draw/lastDraw/${item.lott_inner_name}`)
    )
  }

  render () {
    const { drawInfo } = this.props.draw

    let index = 0
    const row = (rowData, sectionID, rowID) => {
      // console.log('TCL: DrawInfo -> row -> rowData', rowData)
      // if (index < 0) {
      //   index = list.length - 1
      // }
      const item = drawInfo[index++]
      return (
        <div key={rowID} styleName='item'>
          {item &&
            <div onClick={() => this.jumpLastDraw(item)}>
              <div styleName='title'>
                <span styleName='name'>{item.name}</span>第{item.period}期
                {dateFormater(item.draw_datetime)}
              </div>
              <div styleName='desc'>{this.getNumInfo(item)}</div>
              <div styleName='right-icon'>
                <Icon type='right' size={'md'} />
              </div>
            </div>}
        </div>
      )
    }
    // rightContent={
    //   <Link to='/draw/notice' style={{ color: '#fff' }}>开奖通知</Link>
    // }
    return (
      <div styleName='pay-page'>
        <NavBar mode='dark'>开奖信息</NavBar>
        <ListView
          ref={el => (this.lv = el)}
          dataSource={this.state.dataSource}
          // renderHeader={() => <span>header</span>}
          // renderFooter={() => (
          //   <div style={{ padding: 30, textAlign: 'center' }}>
          //     {this.state.isLoading ? 'Loading...' : 'Loaded'}
          //   </div>
          // )}
          renderRow={row}
          // renderSeparator={separator}
          className='am-list'
          initialListSize={drawInfo.length}
          pageSize={4}
          useBodyScroll
          onScroll={() => {
            console.log('scroll')
          }}
          scrollRenderAheadDistance={500}
          // onEndReached={this.onEndReached}
          onEndReachedThreshold={10}
        />
      </div>
    )
  }
}

const data = [
  {
    img: 'https://zos.alipayobjects.com/rmsportal/dKbkpPXKfvZzWCM.png',
    title: 'Meet hotel',
    des: '不是所有的兼职汪都需要风吹日晒'
  },
  {
    img: 'https://zos.alipayobjects.com/rmsportal/XmwCzSeJiqpkuMB.png',
    title: "McDonald's invites you",
    des: '不是所有的兼职汪都需要风吹日晒'
  },
  {
    img: 'https://zos.alipayobjects.com/rmsportal/hfVtzEhPzTUewPm.png',
    title: 'Eat the week',
    des: '不是所有的兼职汪都需要风吹日晒'
  }
]
const NUM_ROWS = 20
let pageIndex = 0

function genData (pIndex = 0) {
  const dataBlob = {}
  for (let i = 0; i < NUM_ROWS; i++) {
    const ii = pIndex * NUM_ROWS + i
    dataBlob[`${ii}`] = `row - ${ii}`
  }
  return dataBlob
}
