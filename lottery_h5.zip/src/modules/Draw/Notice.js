/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-10-13 16:01:54
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import {
  NavBar,
  Icon,
  Card,
  Button,
  WingBlank,
  WhiteSpace,
  List,
  Switch
} from 'antd-mobile'
import { createForm } from 'rc-form'

import './Notice.less'

@createForm()
@connect(({ user, global, draw, lottery }) => ({ user, global, draw, lottery }))
export default class Notice extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      lotteryList: [
        {
          name: '',
          label: ''
        }
      ]
    }
  }

  componentDidMount () {
    this.props.dispatch({
      type: 'lottery/getHomeInfo',
      payload: {}
    })
  }

  render () {
    const { getFieldProps } = this.props.form
    const { banners, tips, lotteries } = this.props.lottery

    return (
      <div className='notice-page' styleName='page'>
        <NavBar
          mode='dark'
          leftContent={
            <Icon
              onClick={() => this.props.history.go(-1)}
              type='left'
              size='md'
            />
          }
        >
          通知中心+
        </NavBar>
        <List renderHeader={() => <div styleName='list-header'>中奖通知</div>}>
          <List.Item
            extra={
              <Switch
                {...getFieldProps('notice', {
                  initialValue: true,
                  valuePropName: 'checked'
                })}
                onClick={checked => {
                  console.log(checked)
                }}
              />
            }
          >
            中奖通知
          </List.Item>
        </List>
        <List renderHeader={() => <div styleName='list-header'>开奖通知</div>}>
          {lotteries.map(item => (
            <List.Item
              extra={
                <Switch
                  {...getFieldProps(item.tag, {
                    initialValue: false,
                    valuePropName: 'checked'
                  })}
                  onClick={checked => {
                    console.log(checked)
                  }}
                />
              }
            >
              {item.name}
            </List.Item>
          ))
          // <div
          //   key={item.tag}
          //   onClick={() => this.getJumpUrl(item)}
          //   styleName='lottery-item'
          // >
          //   <img src={item.url} alt='' />
          //   <div styleName='desc'>
          //     <div styleName='title'>{item.name}</div>
          //     {/* <div styleName='sub'>暂停销售</div> */}
          //   </div>
          // </div>
          }

        </List>
      </div>
    )
  }
}
