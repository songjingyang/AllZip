/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: daycool
 * @Last Modified time: 2018-10-26 11:48:11
 */
import React, { Fragment } from 'react'
import { Link, routerRedux } from 'dva/router'
import { connect } from 'dva'
import { NavBar, Icon, Card, Button, ListView, Toast } from 'antd-mobile'
import { createForm } from 'rc-form'
import { dateFormater } from '@/utils/utils'
import { getLotteryNameLabel } from '../../utils/lottery'
import List from '../../components/List'
import './LastDraw.less'

@createForm()
@connect(({ user, global, draw, loading }) => ({
  user,
  global,
  draw,
  loading: loading.effects['draw/getLastDraw']
}))
export default class LastDraw extends List {
  constructor (props) {
    super(props)
    this.state = {
      ...(this.state || {}),
      name: 'daycool'
    }
  }
  url = 'draw/getLastDraw'
  keys = ['draw', 'lastDraw']
  params = {
    lotteryName: this.props.match.params.lotteryName
  }
  jumpPrevPage = () => {
    this.props.history.go(-1)
  }

  getNumInfo = item => {
    const arr = []
    if (item.style === 'dice') {
      item.numbers.forEach(num => {
        arr.push(<span key={num} className={`dice dice${num}`} />)
      })

      arr.push(
        <span styleName='sum'>
          和值:
          {item.sum}
        </span>
      )
    } else if (item.style === 'ball') {
      item.numbers.forEach(num => {
        arr.push(
          <span key={num} className={`ball`} style={{ background: item.color }}>
            {num}
          </span>
        )
      })
    }

    return arr
  }

  jumpDrawDetail = item => {
    const lotteryName = this.props.match.params.lotteryName

    this.props.dispatch(
      routerRedux.push(
        `/draw/drawDetail/${lotteryName}/${item.period}/${item.draw_time}/${item.numbers}/${item.sum || 0}`
      )
    )
  }

  buy = () => {
    const params = this.props.match.params
    let lotteryComponentName = 'fastThree'
    if (/eleven_five/.test(params.lotteryName)) {
      lotteryComponentName = 'elevenFive'
    } else if (/tick_tick/.test(params.lotteryName)) {
      lotteryComponentName = 'tick'
    }
    let url = `/lottery/${lotteryComponentName}/${params.lotteryName}`

    this.props.dispatch(routerRedux.push(url))
  }

  renderListItem = list => {
    let index = 0

    const row = (rowData, sectionID, rowID) => {
      const item = list[index++]
      return (
        <div>
          {item &&
            <div
              onClick={() => {
                this.jumpDrawDetail(item)
              }}
              key={rowID}
              styleName='item'
            >
              <div styleName='title'>
                {/* <span styleName='name'>{item.name}</span> */}第{' '}
                {item.period} 期{dateFormater(item.draw_time)}
              </div>
              <div styleName='desc'>{this.getNumInfo(item)}</div>
              <div styleName='right-icon'>
                <Icon type='right' size={'md'} />
              </div>
            </div>}
        </div>
      )
    }
    return row
  }

  render () {
    return (
      <div styleName='pay-page'>
        <NavBar
          mode='dark'
          leftContent={
            <Icon onClick={this.jumpPrevPage} type='left' size='md' />
          }
        >
          {getLotteryNameLabel(this.props.match.params.lotteryName)}
          近期开奖
        </NavBar>
        {this.renderList()}
        <div onClick={this.buy} styleName='footer'>
          <Button onClick={this.bet} type='primary' style={{ borderRadius: 0 }}>
            购买
            {getLotteryNameLabel(this.props.match.params.lotteryName)}
          </Button>
        </div>
      </div>
    )
  }
}
