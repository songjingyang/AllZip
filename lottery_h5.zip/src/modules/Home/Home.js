import React, { Fragment } from 'react';
import { routerRedux, Link } from 'dva/router';
import { connect } from 'dva';
import {
  TabBar,
  List,
  InputItem,
  WhiteSpace,
  Button,
  WingBlank,
} from 'antd-mobile';
import { createForm } from 'rc-form';
import Lottery from '../Lottery/Index';
import DrawInfo from '../Draw/DrawInfo';
import My from '../My/My';
import './Home.less';

const Item = List.Item;
const Brief = Item.Brief;

@createForm()
@connect(({ user, global }) => ({ user, global }))
export default class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedTab: 'home',
      fullScreen: true,
    };
  }
  componentDidMount() {
    const params = this.props.match.params;
    this.setState({
      selectedTab: params.tab,
    });
  }

  jumpTab = tab => {
    this.setState({
      selectedTab: tab,
    });
    this.props.dispatch(routerRedux.push(`/home/${tab}`));
  };
  render() {
    return (
      <Fragment>
        <div
          style={
            this.state.fullScreen
              ? {
                  position: 'fixed',
                  height: '100%',
                  width: '100%',
                  top: 0,
                  background: '#fff',
                }
              : { height: 400 }
          }
        >
          <TabBar
            unselectedTintColor="#999999"
            tintColor="#DBCE3C"
            barTintColor="#171717"
            hidden={this.state.hidden}
          >
            <TabBar.Item
              title="购彩"
              key="home"
              icon={<div styleName="tab home" />}
              selectedIcon={<div styleName="tab home-on" />}
              selected={this.state.selectedTab === 'home'}
              onPress={() => this.jumpTab('home')}
              data-seed="logId"
            >
              <Lottery />
            </TabBar.Item>
            <TabBar.Item
              icon={<div styleName="tab draw" />}
              selectedIcon={<div styleName="tab draw-on" />}
              title="开奖"
              key="draw"
              selected={this.state.selectedTab === 'draw'}
              onPress={() => this.jumpTab('draw')}
            >
              <DrawInfo />
            </TabBar.Item>
            <TabBar.Item
              icon={<div styleName="tab my" />}
              selectedIcon={<div styleName="tab my-on" />}
              title="我的"
              key="my"
              selected={this.state.selectedTab === 'my'}
              onPress={() => this.jumpTab('my')}
            >
              <My />
            </TabBar.Item>
          </TabBar>
        </div>
      </Fragment>
    );
  }
}
