import React from 'react'
import ReactDOM from 'react-dom'
import './assets/common.less'
import 'rc-table/assets/index.css'
import App from './App'
// import registerServiceWorker, {unregister} from './registerServiceWorker'
import { hot } from 'react-hot-loader'

import dva from 'dva'
import createHistory from 'history/createHashHistory'
// user BrowserHistory
// import createHistory from 'history/createBrowserHistory';
import createLoading from 'dva-loading'
import 'moment/locale/zh-cn'
import { createLogger } from 'redux-logger'
// console.log(process.env)
if (
  process.env.NODE_ENV === 'development' &&
  process.env.REACT_APP_MOCK === 'true'
) {
  require('./mock')
}
// 1. Initialize
const app = dva({
  history: createHistory(),
  onAction: createLogger({ level: 'log' })
})

// 2. Plugins
app.use(createLoading())
// app.use(createLogger())
// 3. Register global model
app.model(require('./models/global').default)
app.model(require('./models/user').default)
app.model(require('./models/lottery').default)
app.model(require('./models/draw').default)

app.model(require('./models/my').default)

// 4. Router
// app.router(require('./router').default)

// app.router(App)

hot(module)(<div />)
// 注册视图
app.router(App)
// 启动应用
app.start('#root')

// class App2 extends React.Component {
//   render () {
//     return <div />
//   }
// }

const store = app._store

const user = localStorage.getItem('user')
if (user) {
  try {
    store.dispatch({
      type: 'user/userInfo',
      payload: JSON.parse(user)
    })
  } catch (error) {}
}

export default store
// ajax请求使用dispatch

// registerServiceWorker()
// unregister();
