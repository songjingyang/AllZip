import { Toast } from 'antd-mobile'

import moment from 'moment'
import { parse, stringify } from 'qs'

export function fixedZero (val) {
  return val * 1 < 10 ? `0${val}` : val
}

export function getTimeDistance (type) {
  const now = new Date()
  const oneDay = 1000 * 60 * 60 * 24

  if (type === 'today') {
    now.setHours(0)
    now.setMinutes(0)
    now.setSeconds(0)
    return [moment(now), moment(now.getTime() + (oneDay - 1000))]
  }

  if (type === 'week') {
    let day = now.getDay()
    now.setHours(0)
    now.setMinutes(0)
    now.setSeconds(0)

    if (day === 0) {
      day = 6
    } else {
      day -= 1
    }

    const beginTime = now.getTime() - day * oneDay

    return [moment(beginTime), moment(beginTime + (7 * oneDay - 1000))]
  }

  if (type === 'month') {
    const year = now.getFullYear()
    const month = now.getMonth()
    const nextDate = moment(now).add(1, 'months')
    const nextYear = nextDate.year()
    const nextMonth = nextDate.month()

    return [
      moment(`${year}-${fixedZero(month + 1)}-01 00:00:00`),
      moment(
        moment(
          `${nextYear}-${fixedZero(nextMonth + 1)}-01 00:00:00`
        ).valueOf() - 1000
      )
    ]
  }

  if (type === 'year') {
    const year = now.getFullYear()

    return [moment(`${year}-01-01 00:00:00`), moment(`${year}-12-31 23:59:59`)]
  }
}

export function getPlainNode (nodeList, parentPath = '') {
  const arr = []
  nodeList.forEach(node => {
    const item = node
    item.path = `${parentPath}/${item.path || ''}`.replace(/\/+/g, '/')
    item.exact = true
    if (item.children && !item.component) {
      arr.push(...getPlainNode(item.children, item.path))
    } else {
      if (item.children && item.component) {
        item.exact = false
      }
      arr.push(item)
    }
  })
  return arr
}

function accMul (arg1, arg2) {
  let m = 0
  const s1 = arg1.toString()
  const s2 = arg2.toString()
  m += s1.split('.').length > 1 ? s1.split('.')[1].length : 0
  m += s2.split('.').length > 1 ? s2.split('.')[1].length : 0
  return Number(s1.replace('.', '')) * Number(s2.replace('.', '')) / 10 ** m
}

export function digitUppercase (n) {
  const fraction = ['角', '分']
  const digit = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖']
  const unit = [['元', '万', '亿'], ['', '拾', '佰', '仟', '万']]
  let num = Math.abs(n)
  let s = ''
  fraction.forEach((item, index) => {
    s += (digit[Math.floor(accMul(num, 10 * 10 ** index)) % 10] + item).replace(
      /零./,
      ''
    )
  })
  s = s || '整'
  num = Math.floor(num)
  for (let i = 0; i < unit[0].length && num > 0; i += 1) {
    let p = ''
    for (let j = 0; j < unit[1].length && num > 0; j += 1) {
      p = digit[num % 10] + unit[1][j] + p
      num = Math.floor(num / 10)
    }
    s = p.replace(/(零.)*零$/, '').replace(/^$/, '零') + unit[0][i] + s
  }

  return s.replace(/(零.)*零元/, '元').replace(/(零.)+/g, '零').replace(/^整$/, '零元整')
}

function getRelation (str1, str2) {
  if (str1 === str2) {
    console.warn('Two path are equal!') // eslint-disable-line
  }
  const arr1 = str1.split('/')
  const arr2 = str2.split('/')
  if (arr2.every((item, index) => item === arr1[index])) {
    return 1
  } else if (arr1.every((item, index) => item === arr2[index])) {
    return 2
  }
  return 3
}

function getRenderArr (routes) {
  let renderArr = []
  renderArr.push(routes[0])
  for (let i = 1; i < routes.length; i += 1) {
    // 去重
    renderArr = renderArr.filter(item => getRelation(item, routes[i]) !== 1)
    // 是否包含
    const isAdd = renderArr.every(item => getRelation(item, routes[i]) === 3)
    if (isAdd) {
      renderArr.push(routes[i])
    }
  }
  return renderArr
}

/**
 * Get router routing configuration
 * { path:{name,...param}}=>Array<{name,path ...param}>
 * @param {string} path
 * @param {routerData} routerData
 */
export function getRoutes (path, routerData) {
  let routes = Object.keys(routerData).filter(
    routePath => routePath.indexOf(path) === 0 && routePath !== path
  )
  // Replace path to '' eg. path='user' /user/name => name
  routes = routes.map(item => item.replace(path, ''))
  // Get the route to be rendered to remove the deep rendering
  const renderArr = getRenderArr(routes)
  // Conversion and stitching parameters
  const renderRoutes = renderArr.map(item => {
    const exact = !routes.some(
      route => route !== item && getRelation(route, item) === 1
    )
    return {
      exact,
      ...routerData[`${path}${item}`],
      key: `${path}${item}`,
      path: `${path}${item}`
    }
  })
  return renderRoutes
}

export function getPageQuery () {
  return parse(window.location.href.split('?')[1])
}

export function getQueryPath (path = '', query = {}) {
  const search = stringify(query)
  if (search.length) {
    return `${path}?${search}`
  }
  return path
}

export function getQueryString (name, url) {
  url = url || window.location.search
  var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i')
  var r = url.substr(1).match(reg)
  if (r != null) {
    return unescape(r[2])
  }
  return null
}

/* eslint no-useless-escape:0 */
const reg = /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+(?::\d+)?|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/

export function isUrl (path) {
  return reg.test(path)
}

export function dateFormater (time) {
  time = '' + time
  if (time.length === 10) {
    time = time * 1000
  }
  return moment(+time).format('YYYY-MM-DD HH:mm:ss')
}

export function datesFormater (time) {
  return moment(time).format('YYYY-MM-DD HH:mm:ss')
}

export function datesFormate (time) {
  return moment(time).format('MMMDo HH:mm')
}

export function toSecond (time) {
  if (moment.isMoment(time)) {
    time = time.valueOf()
  } else if (time instanceof Date) {
    time = time.getTime()
  }
  time = '' + time
  if (time.length === 13) {
    time = Math.ceil(time / 1000)
  }

  return '' + time
}

export function random (start, end) {
  return Math.floor(Math.random() * (end - start) + start)
}
export function randomArr (arr, count) {
  const newArr = []
  const len = arr.length
  const tmpArr = []

  for (let i = 0; i < len; i++) {
    tmpArr.push(i)
  }

  tmpArr.sort(() => 0.5 - Math.random())

  for (let i = 0; i < count; i++) {
    newArr.push(arr[tmpArr[i]])
  }

  return newArr
}

export function randomArrTwo (arr, count, count1Min, count1Max) {
  const newArr = []
  const newArr2 = []
  const len = arr.length
  const tmpArr = []
  let count1 = random(count1Min || 1, count1Max || count)
  let count2 = count - count1

  for (let i = 0; i < len; i++) {
    tmpArr.push(i)
  }

  tmpArr.sort(() => 0.5 - Math.random())

  for (let i = 0; i < count1; i++) {
    newArr.push(arr[tmpArr.shift()])
  }
  for (let i = 0; i < count2; i++) {
    newArr2.push(arr[tmpArr.shift()])
  }

  return [newArr, newArr2]
}

export function randomTwoArr (arr, arr2, count) {
  const newArr = []
  const newArr2 = []
  const len = arr.length
  const tmpArr = []
  const count1 = random(1, count)
  const count2 = count - count1

  for (let i = 0; i < len; i++) {
    tmpArr.push(i)
  }

  tmpArr.sort(() => 0.5 - Math.random())

  for (let i = 0; i < count1; i++) {
    newArr.push(arr[tmpArr.shift()])
  }
  for (let i = 0; i < count2; i++) {
    newArr2.push(arr2[tmpArr.shift()])
  }

  return [newArr, newArr2]
}

export function guid () {
  function S4 () {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1)
  }
  return (
    S4() +
    S4() +
    '-' +
    S4() +
    '-' +
    S4() +
    '-' +
    S4() +
    '-' +
    S4() +
    S4() +
    S4()
  )
}

export function saveCache (key, val) {
  localStorage.setItem(key, JSON.stringify(val))
}

export function getCache (key) {
  let cacheData = localStorage.getItem(key)
  try {
    return JSON.parse(cacheData)
  } catch (e) {
    console.log(e, '解析json错误')
  }
}

export function validErrorTip (error) {
  const keys = Object.keys(error)
  Toast.fail(error[keys[0]].errors[0].message)
}

function getElementPageLeft (element) {
  var actualLeft = element.offsetLeft
  var parent = element.offsetParent
  while (parent != null) {
    actualLeft +=
      parent.offsetLeft + (parent.offsetWidth - parent.clientWidth) / 2
    parent = parent.offsetParent
  }
  return actualLeft
}

function getElementPageTop (element) {
  var actualTop = element.offsetTop
  var parent = element.offsetParent
  while (parent != null) {
    actualTop +=
      parent.offsetTop + (parent.offsetHeight - parent.clientHeight) / 2
    parent = parent.offsetParent
  }
  return actualTop
}

function getOffset (node, offset) {
  if (!offset) {
    offset = {}
    offset.top = 0
    offset.left = 0
  }
  if (node == document.body) {
    // 当该节点为body节点时，结束递归
    return offset
  }

  offset.top += node.offsetTop
  offset.left += node.offsetLeft

  return getOffset(node.parentNode, offset) // 向上累加offset里的值
  // let info = node.getBoundingClientRect()
  // console.log('​getOffset -> info', info)
  // return info
}

export function drawLine (startNode, endNode, color) {
  // 确定两个span的中心点坐标
  var SX = getOffset(startNode).left + startNode.width / 2
  var SY = getOffset(startNode).top + startNode.height / 2
  var EX = getOffset(endNode).left + endNode.width / 2
  var EY = getOffset(endNode).top + endNode.height / 2

  // //组装起始坐标
  var start_max = Math.max.apply(null, [SX, EX])
  var start_min = Math.min.apply(null, [SX, EX])
  var end_max = Math.max.apply(null, [SY, EY])
  var end_min = Math.min.apply(null, [SY, EY])
  // canvas的宽高
  let canvas_width = Math.abs(SX - EX) > 0
    ? Math.abs(SX - EX)
    : startNode.offsetWidth
  let canvas_height = Math.abs(SY - EY) > 0
    ? Math.abs(SY - EY)
    : startNode.offsetHeight
  // 创建canvas
  var canvas = document.createElement('canvas')
  // canvas.style.border = 'solid 2px red'
  document.body.appendChild(canvas)
  // console.log(canvas.parentNode)
  canvas.id = Date.now() // 以时间戳来区分不同的id
  canvas.width = canvas_width
  canvas.height = canvas_height
  // canvas.border = '1px solid #ccc'
  var canvas_real = document.getElementById(canvas.id)
  // console.log(canvas_real.style)
  canvas_real.style.left = getOffset(startNode).left
  canvas_real.style.top = getOffset(startNode).top
  canvas_real.style.position = 'absolute'
  canvas_real.style.top = end_min + 'px'
  canvas_real.style.left = start_min + 'px'
  canvas_real.style.zIndex = '999'
  let ctx = canvas_real.getContext('2d')
  ctx.beginPath()
  ctx.moveTo(0, 0)
  ctx.lineTo(canvas_width, canvas_height)
  ctx.lineWidth = 1
  ctx.strokeStyle = color
  ctx.stroke()
  ctx.closePath()
}
