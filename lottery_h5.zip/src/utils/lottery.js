import React, { Fragment } from 'react'
import {
  getFastThreePlayType,
  getElevenFivePlayType,
  getTickPlayType
} from './lotteryPlayTypeData'
import { random, randomArr, randomArrTwo, randomTwoArr, guid } from './utils'

const lotteryNameLabelMap = {
  fast_three: '快3',
  jiangsu_fast_three: '江苏快3',
  new_fast_three: '新快3',
  hubei_fast_three: '湖北快3',
  eleven_five: '11选5',
  old_eleven_five: '老11选5',
  yue_eleven_five: '粤11选5',
  luck_eleven_five: '好运11选5',
  chongqing_tick_tick: '重庆时时彩'
}

// 获取彩票注数
export function getLotteryCount (playType, arr, arr2, arr3, arr4, arr5) {
  let count = 0
  let size = arr.length
  let size2 = arr2 && arr2.length
  let size3 = arr3 && arr3.length
  let size4 = arr4 && arr4.length
  let size5 = arr5 && arr5.length

  switch (playType) {
    // 快三
    case 'sum': // 和值
      count = commonCount(size)
      break
    case 'triple_same_each': // 三同号单选
      count = commonCount(size)
      break
    case 'triple_same_all': // 三同号通选
      count = commonCount(size)
      break
    case 'triple_consecutive_all': // 三连号通选
      count = commonCount(size)
      break
    case 'double_same_each': // 二同号单选
      count = twoSameSingleCount(size, size2)
      break
    case 'double_same_plural': // 二同号复选
      count = commonCount(size)
      break
    case 'triple_different': // 三不同号
      count = threeDifferentCount(size)
      break
    case 'double_different_single': // 二不同号
      count = twoDifferentCount(size)
      break
    // 11选5
    case 'any_two': //
      count = combination(size, 2)
      break
    case 'any_three': //
      count = combination(size, 3)
      break
    case 'any_four': //
      count = combination(size, 4)
      break
    case 'any_five': //
      count = combination(size, 5)
      break
    case 'any_six': //
      count = combination(size, 6)
      break
    case 'any_seven': //
      count = combination(size, 7)
      break
    case 'any_eight': //
      count = combination(size, 8)
      break
    case 'head_one': //
      count = size
      break
    case 'head_two': //
      count = headTwo(arr, arr2)
      break
    case 'head_three': //
      count = headThree(arr, arr2, arr3)

      break
    case 'head_group_two': //
      count = combination(size, 2)
      break
    case 'head_group_three': //
      count = combination(size, 3)
      break
    case 'tuo_dan_any_two': //
      // count = size * size2;
      if (size > 0 && size2 > 0 && size + size2 >= 2) {
        count = combination(size2, 1)
      }
      break
    case 'tuo_dan_any_three': //
      if (size > 0 && size2 > 0 && size + size2 >= 3) {
        count = combination(size2, 3 - size)
      }
      break
    case 'tuo_dan_any_four': //
      if (size > 0 && size2 > 0 && size + size2 >= 4) {
        count = combination(size2, 4 - size)
      }
      break
    case 'tuo_dan_any_five': //
      if (size > 0 && size2 > 0 && size + size2 >= 5) {
        count = combination(size2, 5 - size)
      }
      break
    case 'tuo_dan_any_six': //
      if (size > 0 && size2 > 0 && size + size2 >= 6) {
        count = combination(size2, 6 - size)
      }
      break
    case 'tuo_dan_any_seven': //
      if (size > 0 && size2 > 0 && size + size2 >= 7) {
        count = combination(size2, 7 - size)
      }
      break
    case 'tuo_dan_any_eight': //
      if (size > 0 && size2 > 0 && size + size2 >= 8) {
        count = combination(size2, 8 - size)
      }
      break
    case 'tuo_dan_head_group_two': //
      if (size > 0 && size2 > 0 && size + size2 >= 2) {
        count = combination(size2, 1)
      }
      break
    case 'tuo_dan_head_group_three': //
      if (size > 0 && size2 > 0 && size + size2 >= 3) {
        count = combination(size2, 3 - size)
      }
      break
    // 时时彩
    case 'big_small_odd_even': //
      count = 1
      break
    case 'one_star': //
      count = size
      break
    case 'two_star_group': //
      count = size * (size - 1) / 2
      break
    case 'two_star': //
      count = size * size2
      break
    case 'three_star_group_six': //
      count = combination(size, 3)
      break
    case 'three_star_group_multiple': //
      count = size * (size - 1)
      break
    case 'three_star': //
      count = size * size2 * size3
      break
    case 'five_star': //
      count = size * size2 * size3 * size4 * size5
      break
    case 'five_star_all': //
      count = size * size2 * size3 * size4 * size5
      break

    default:
  }

  return count
}

/*
* 随机获取一注
*/
export function getRandomDraw (lotteryType, playType) {
  const playTypeInfo = getCurrPlayType(lotteryType, playType)
  let total = playTypeInfo.options.length
  let values = []
  let values2 = []
  let values3 = []
  let values4 = []
  let values5 = []
  let arr = []
  switch (playType) {
    // 快三
    case 'sum': // 和值
    // break;
    case 'triple_same_each': // 三同号单选
    // break;
    case 'triple_same_all': // 三同号通选
    // break;
    case 'triple_consecutive_all': // 三连号通选
    // break;
    // case 'double_same_each': // 二同号单选
    //   let arr = randomTwoArr(
    //     playTypeInfo.options,
    //     playTypeInfo.options2,
    //     random(2, total)
    //   );
    //   values = arr[0];
    //   values2 = arr[1];
    //   break;
    case 'double_same_plural': // 二同号复选
      values = randomArr(playTypeInfo.options, random(1, total > 6 ? 4 : total))
      break
    case 'triple_different': // 三不同号
      values = randomArr(playTypeInfo.options, random(3, total))
      break
    case 'double_different_single': // 二不同号
      values = randomArr(playTypeInfo.options, random(2, total))
      break
    case 'double_same_each': // 二同号单选
      arr = randomTwoArr(
        playTypeInfo.options,
        playTypeInfo.options2,
        random(2, total)
      )
      values = arr[0]
      values2 = arr[1]
      break
    // 11选5
    case 'any_two': //
      values = randomArr(playTypeInfo.options, random(2, 11))
      break
    case 'any_three': //
      values = randomArr(playTypeInfo.options, random(3, 11))
      break
    case 'any_four': //
      values = randomArr(playTypeInfo.options, random(4, 11))
      break
    case 'any_five': //
      values = randomArr(playTypeInfo.options, random(5, 11))
      break
    case 'any_six': //
      values = randomArr(playTypeInfo.options, random(6, 11))
      break
    case 'any_seven': //
      values = randomArr(playTypeInfo.options, random(7, 11))
      break
    case 'any_eight': //
      values = randomArr(playTypeInfo.options, random(8, 11))
      break
    case 'head_one': //
      values = randomArr(playTypeInfo.options, random(1, 11))
      break
    case 'head_two': //
      arr = randomArrTwo(playTypeInfo.options, random(3, 6))
      values = arr[0]
      values2 = arr[1]
      break
    case 'head_three': //
      arr = randomArrTwo(playTypeInfo.options, random(3, 6))
      values = arr[0]
      values2 = arr[1]
      values3 = randomArr(playTypeInfo.options3, random(1, 3))
      break
    case 'head_group_two': //
      values = randomArr(playTypeInfo.options, random(2, 11))
      break
    case 'head_group_three': //
      values = randomArr(playTypeInfo.options, random(3, 11))
      break

    case 'tuo_dan_any_two': //
      arr = randomArrTwo(playTypeInfo.options, random(2, total), 1, 1)
      values = arr[0]
      values2 = arr[1]
      break
    case 'tuo_dan_any_three': //
      arr = randomArrTwo(playTypeInfo.options, random(3, total), 1, 2)
      values = arr[0]
      values2 = arr[1]
      break
    case 'tuo_dan_any_four': //
      arr = randomArrTwo(playTypeInfo.options, random(4, total), 1, 3)
      values = arr[0]
      values2 = arr[1]
      break
    case 'tuo_dan_any_five': //
      arr = randomArrTwo(playTypeInfo.options, random(5, total), 1, 4)
      values = arr[0]
      values2 = arr[1]
      break
    case 'tuo_dan_any_six': //
      arr = randomArrTwo(playTypeInfo.options, random(6, total), 1, 5)
      values = arr[0]
      values2 = arr[1]
      break
    case 'tuo_dan_any_seven': //
      arr = randomArrTwo(playTypeInfo.options, random(7, total), 1, 6)
      values = arr[0]
      values2 = arr[1]
      break
    case 'tuo_dan_any_eight': //
      arr = randomArrTwo(playTypeInfo.options, random(8, total), 1, 7)
      values = arr[0]
      values2 = arr[1]
      break
    case 'tuo_dan_head_group_two': //
      arr = randomArrTwo(playTypeInfo.options, random(2, total), 1, 1)
      values = arr[0]
      values2 = arr[1]
      break
    case 'tuo_dan_head_group_three': //
      arr = randomArrTwo(playTypeInfo.options, random(3, total), 1, 2)
      values = arr[0]
      values2 = arr[1]
      break
    // 时时彩
    case 'big_small_odd_even':
      values = randomArr(playTypeInfo.options, 1)
      values2 = randomArr(playTypeInfo.options2, 1)
      break
    case 'one_star':
      values = randomArr(playTypeInfo.options, random(1, total))
      break
    case 'two_star_group':
      values = randomArr(playTypeInfo.options, random(2, total))
      break
    case 'two_star':
      values = randomArr(playTypeInfo.options, random(1, 3))
      values2 = randomArr(playTypeInfo.options2, random(1, 4))
      break
    case 'three_star_group_six':
      values = randomArr(playTypeInfo.options, random(3, total))
      break
    case 'three_star_group_multiple':
      values = randomArr(playTypeInfo.options, random(3, total))
      break
    case 'three_star':
      values = randomArr(playTypeInfo.options, random(1, 2))
      values2 = randomArr(playTypeInfo.options2, random(1, 3))
      values3 = randomArr(playTypeInfo.options3, random(1, 2))
      break
    case 'five_star':
    case 'five_star_all':
      values = randomArr(playTypeInfo.options, random(1, 2))
      values2 = randomArr(playTypeInfo.options2, random(1, 3))
      values3 = randomArr(playTypeInfo.options3, random(1, 3))
      values4 = randomArr(playTypeInfo.options4, random(1, 2))
      values5 = randomArr(playTypeInfo.options5, random(1, 2))

      break

    default:
  }

  let count = getLotteryCount(
    playType,
    values,
    values2,
    values3,
    values4,
    values5
  )

  return {
    id: guid(),
    lotteryName: lotteryType,
    playType: playTypeInfo.value,
    playTypeName: playTypeInfo.label,
    values: values.map(item => item.value),
    values2: values2.map(item => item.value),
    values3: values3.map(item => item.value),
    values4: values4.map(item => item.value),
    values5: values5.map(item => item.value),
    count: count,
    price: count * 2
  }
}

// 选号页随机一注
export function randomBet (lotteryName, playTypeInfo) {
  const currPlayType = playTypeInfo.value
  const drawItem = getRandomDraw(lotteryName, currPlayType)
  let selectedPlayTypeOptions = []
  let selectedPlayTypeOptions2 = []
  let selectedPlayTypeOptions3 = []
  let selectedPlayTypeOptions4 = []
  let selectedPlayTypeOptions5 = []
  let selectedPlayTypeOptions6 = []
  if (drawItem.values) {
    playTypeInfo.options.forEach(item => {
      if (drawItem.values.some(value => item.value === value)) {
        item.selected = true
      }
    })
    selectedPlayTypeOptions = playTypeInfo.options.filter(item => item.selected)
  }
  if (playTypeInfo.options2) {
    playTypeInfo.options2.forEach(item => {
      if (drawItem.values2.some(value => item.value === value)) {
        item.selected = true
      }
    })
    selectedPlayTypeOptions2 = playTypeInfo.options2.filter(
      item => item.selected
    )
  }
  if (playTypeInfo.options3) {
    playTypeInfo.options3.forEach(item => {
      if (drawItem.values3.some(value => item.value === value)) {
        item.selected = true
      }
    })
    selectedPlayTypeOptions3 = playTypeInfo.options3.filter(
      item => item.selected
    )
  }
  if (playTypeInfo.options4) {
    playTypeInfo.options4.forEach(item => {
      if (drawItem.values4.some(value => item.value === value)) {
        item.selected = true
      }
    })
    selectedPlayTypeOptions4 = playTypeInfo.options4.filter(
      item => item.selected
    )
  }
  if (playTypeInfo.options5) {
    playTypeInfo.options5.forEach(item => {
      if (drawItem.values5.some(value => item.value === value)) {
        item.selected = true
      }
    })
    selectedPlayTypeOptions5 = playTypeInfo.options5.filter(
      item => item.selected
    )
  }
  if (playTypeInfo.options6) {
    playTypeInfo.options6.forEach(item => {
      if (drawItem.values6.some(value => item.value === value)) {
        item.selected = true
      }
    })
    selectedPlayTypeOptions6 = playTypeInfo.options6.filter(
      item => item.selected
    )
  }

  let count = getLotteryCount(
    currPlayType,
    selectedPlayTypeOptions.map(item => item.value),
    selectedPlayTypeOptions2.map(item => item.value),
    selectedPlayTypeOptions3.map(item => item.value),
    selectedPlayTypeOptions4.map(item => item.value),
    selectedPlayTypeOptions5.map(item => item.value),
    selectedPlayTypeOptions6.map(item => item.value)
  )

  return count
}

// 下注显示号码
export function showNum (item) {
  let count = 0
  let values = item.values
  let values2 = item.values2
  let values3 = item.values3
  let values4 = item.values4
  let values5 = item.values5

  let playType = item.playType
  let text = ''

  switch (playType) {
    case 'sum': // 和值
    case 'triple_same_each': // 三同号单选
    case 'triple_same_all': // 三同号通选
    case 'triple_consecutive_all': // 三连号通选
    case 'double_same_each': // 二同号单选
    case 'double_same_plural': // 二同号复选
    case 'triple_different': // 三不同号
    case 'double_different_single': // 二不同号
      text = item.values.join(',')
      if (playType === 'double_same_each') {
        text += `(${values2.join(',')})`
      }

      break
    // 11选5
    case 'any_two': //
    case 'any_three': //
    case 'any_four': //
    case 'any_five': //
    case 'any_six': //
    case 'any_seven': //
    case 'any_eight': //
    case 'head_one': //
    case 'head_two': //
    case 'head_three': //
    case 'head_group_two': //
    case 'head_group_three': //
    case 'tuo_dan_any_two': //
    case 'tuo_dan_any_three': //
    case 'tuo_dan_any_four': //
    case 'tuo_dan_any_five': //
    case 'tuo_dan_any_six': //
    case 'tuo_dan_any_seven': //
    case 'tuo_dan_any_eight': //
    case 'tuo_dan_head_group_two': //
    case 'tuo_dan_head_group_three': //
      let isTuoDan = /tuo_dan/.test(playType)
      if (isTuoDan) {
        if (values3 && values3.length) {
          text = `(${values.join(' ')}) (${values2.join(' ')}) ${values3.join(' ')}`
        } else if (values2 && values2.length) {
          text = `(${values.join(' ')}) ${values2.join(' ')}`
        } else {
          text = values.join(' ')
        }
      } else {
        if (values3 && values3.length) {
          text = `${values.join(' ')} | ${values2.join(' ')} | ${values3.join(' ')}`
        } else if (values2 && values2.length) {
          text = `${values.join(' ')} | ${values2.join(' ')}`
        } else {
          text = values.join(' ')
        }
      }
      break
    // 时时彩
    case 'big_small_odd_even':
      const map = {
        1: '大',
        2: '小',
        3: '单',
        4: '双'
      }
      text = `${map[values.join('')]} ${map[values2.join('')]}`
      break
    case 'one_star':
      text = `____${values.join('')}`
      break
    case 'two_star_group':
      text = `${values.join(' ')}`
      break
    case 'two_star':
      text = `___${values.join('')} ${values2.join('')}`
      break
    case 'three_star_group_six':
      text = `${values.join(' ')}`
      break
    case 'three_star_group_multiple':
      text = `${values.join(' ')}`
      break
    case 'three_star':
      text = `__${values.join('')} ${values2.join('')} ${values3.join('')}`
      break
    case 'five_star':
      text = `${values.join('')} ${values2.join('')} ${values3.join('')} ${values4.join('')} ${values5.join('')}`
      break
    case 'five_star_all':
      text = `${values.join('')} ${values2.join('')} ${values3.join('')} ${values4.join('')} ${values5.join('')}`
      break
  }

  return text
}
// 详情页显示号码
export function showOrderDetailNum (item) {
  let count = 0
  let playType = item.gameplay
  let numbers = item.numbers
  let text = ''

  if (item.is_dan_tuo === 2) {
    playType = 'tuo_dan_' + playType
  }

  switch (playType) {
    case 'sum': // 和值
    case 'triple_same_each': // 三同号单选
    case 'triple_same_all': // 三同号通选
    case 'triple_consecutive_all': // 三连号通选
    case 'double_same_each': // 二同号单选
    case 'double_same_plural': // 二同号复选
    case 'triple_different': // 三不同号
    case 'double_different_single': // 二不同号
      if (playType === 'sum') {
        text = item.sum
      } else if (playType === 'double_same_each') {
        text = `(${numbers[1]}${numbers[2]})${numbers[0]}`
      } else if (
        playType === 'triple_same_all' ||
        playType === 'triple_consecutive_all'
      ) {
        text = getCurrPlayType('fast_three', playType).options[0].label
      } else {
        return `${item.numbers.join(' ')}`
      }

      break
    // 11选5
    case 'any_two': //
    case 'any_three': //
    case 'any_four': //
    case 'any_five': //
    case 'any_six': //
    case 'any_seven': //
    case 'any_eight': //
    case 'head_one': //
    case 'head_two': //
    case 'head_three': //
    case 'head_group_two': //
    case 'head_group_three': //
    case 'tuo_dan_any_two': //
    case 'tuo_dan_any_three': //
    case 'tuo_dan_any_four': //
    case 'tuo_dan_any_five': //
    case 'tuo_dan_any_six': //
    case 'tuo_dan_any_seven': //
    case 'tuo_dan_any_eight': //
    case 'tuo_dan_head_group_two': //
    case 'tuo_dan_head_group_three': //
      let isTuoDan = item.is_dan_tuo === 2
      if (isTuoDan) {
        if (/head_group/.test(playType)) {
          return `${numbers.join(' ')}`
        } else if (/head/.test(playType)) {
          return `(${item.dan.join(' ')}) ${item.tuo.join(' ')}`
        } else {
          return `${item.numbers.join(' ')}`
        }
      } else {
        if (/head_group/.test(playType)) {
          return `${numbers.join(' ')}`
        } else if (/head/.test(playType)) {
          return `${numbers.join('|')}`
        } else {
          return `${item.numbers.join(' ')}`
        }
      }
      break
    // 时时彩
    case 'big_small_odd_even':
      const map = {
        1: '大',
        2: '小',
        3: '单',
        4: '双'
      }
      text = `${map[numbers[0]]} ${map[numbers[1]]}`
      break
    case 'one_star':
      text = `____${numbers.join(' ')}`
      break
    case 'two_star_group':
      text = `${numbers.join(' ')}`
      break
    case 'two_star':
      text = `___${numbers.join(' ')}`
      break
    case 'three_star_group_six':
      text = `${numbers.join(' ')}`
      break
    case 'three_star_group_multiple':
      text = `${numbers.join(' ')}`
      break
    case 'three_star':
      text = `__${numbers.join(' ')}`
      break
    case 'five_star':
      text = `${numbers.join(' ')}`
      break
    case 'five_star_all':
      text = `${numbers.join(' ')}`
      break
  }

  return text
}

export function getCurrPlayType (lotteryType, playTypeName) {
  let playTypeData = null

  if (/fast_three/.test(lotteryType)) {
    playTypeData = getFastThreePlayType()
  } else if (/eleven_five/.test(lotteryType)) {
    playTypeData = getElevenFivePlayType()
  } else if (/tick_tick/.test(lotteryType)) {
    playTypeData = getTickPlayType()
  }

  const playTypeInfo = playTypeData.find(item => item.value === playTypeName)

  return playTypeInfo || {}
}

export function getLotteryName (lotteryName) {
  if (/fast_three/.test(lotteryName)) {
    return 'fast_three'
  }
  if (/eleven_five/.test(lotteryName)) {
    return 'eleven_five'
  }
  if (/tick_tick/.test(lotteryName)) {
    return 'tick_tick'
  }
}

export function getLotteryNameLabel (lotteryName) {
  return lotteryNameLabelMap[lotteryName]
}

export function getDrawDataKey (lotteryName) {
  return `${lotteryName}drawData`
}
export function isTuoDan (item) {
  return !!item.options2.length
}

export function buildMyBetData (drawData, lotteryName) {
  const arr = []
  drawData.forEach(item => {
    let playType = item.gameplay
    var newItem = {
      id: guid(),
      lotteryName: lotteryName,
      playType: playType,
      playTypeName: getCurrPlayType(lotteryName, playType),
      values: [],
      values2: [],
      count: 0,
      price: 0
    }

    switch (playType) {
      // 快三
      case 'sum': // 和值
        newItem.values = [`${item.Sum}`]
        break
      case 'triple_same_each': // 三同号单选
        newItem.values = item.numbers.map(item => `${item}${item}${item}`)
        break
      case 'triple_same_all': // 三同号通选
        newItem.values.push('三同号通选')
        break
      case 'triple_consecutive_all': // 三连号通选
        newItem.values.push('三连号通选')
        break
      case 'double_same_each': // 二同号单选
        newItem.values2 = [`${item.numbers[0]}`]
        newItem.values = [`${item.numbers[1]}${item.numbers[2]}`]
        break
      case 'double_same_plural': // 二同号复选
        newItem.values = item.numbers.map(item => `${item}${item}`)
        break
      case 'triple_different': // 三不同号
        newItem.values = item.numbers.map(item => `${item}`)
        break
      case 'double_different_single': // 二不同号
        newItem.values = item.numbers.map(item => `${item}`)
        break
      // 11选5
      case 'head_two': //
        newItem.values = [`${item.numbers[0]}`]
        newItem.values2 = [`${item.numbers[1]}`]
        break
      case 'head_three': //
        newItem.values = [`${item.numbers[0]}`]
        newItem.values2 = [`${item.numbers[1]}`]
        newItem.values3 = [`${item.numbers[2]}`]
        break
      case 'any_two': //
      case 'any_three': //
      case 'any_four': //
      case 'any_five': //
      case 'any_six': //
      case 'any_seven': //
      case 'any_eight': //
      case 'head_one': //
      // if (item.is_dan_tuo == 2) {
      //   playType = newItem.playType = `tuo_dan_${playType}`;
      //   newItem.values2 = item.numbers
      //     .filter(num => !new Set([...item.dan]).has(num))
      //     .map(item => `${item}`);
      //   newItem.values = item.dan.map(item => `${item}`);
      // } else {
      //   newItem.values = item.numbers.map(item => `${item}`);
      // }
      // break;
      case 'head_group_two': //
      // if (item.is_dan_tuo == 2) {
      //   playType = newItem.playType = `tuo_dan_${playType}`;
      //   newItem.values2 = item.numbers
      //     .filter(num => !new Set([...item.dan]).has(num))
      //     .map(item => `${item}`);
      //   newItem.values = item.dan.map(item => `${item}`);
      // } else {
      //   newItem.values = item.numbers.map(item => `${item}`);
      // }
      // break;
      case 'head_group_three': //
        if (item.is_dan_tuo == 2) {
          playType = newItem.playType = `tuo_dan_${playType}`
          newItem.values2 = item.numbers
            .filter(num => !new Set([...item.dan]).has(num))
            .map(item => `${item}`)
          newItem.values = item.dan.map(item => `${item}`)
        } else {
          newItem.values = item.numbers.map(item => `${item}`)
        }
        // case 'tuo_dan_any_two': //
        // case 'tuo_dan_any_three': //
        // case 'tuo_dan_any_four': //
        // case 'tuo_dan_any_five': //
        // case 'tuo_dan_any_six': //
        // case 'tuo_dan_any_seven': //
        // case 'tuo_dan_any_eight': //
        // case 'tuo_dan_head_group_two': //
        // case 'tuo_dan_head_group_three': //
        // if (item.is_dan_tuo == 2) {
        //   newItem.playType = `tuo_dan_${playType}`;
        //   newItem.values = item.tuo.map(item => `${item}`);
        //   newItem.values2 = item.dan.map(item => `${item}`);
        // } else {
        //   newItem.values = item.numbers.map(item => `${item}`);
        // }
        break
      // 时时彩
      case 'big_small_odd_even':
        newItem.values = [`${item.numbers[0]}`]
        newItem.values2 = [`${item.numbers[1]}`]

        break
      case 'one_star':
        newItem.values = item.numbers.map((item = `${item}`))
        break
      case 'two_star_group':
        newItem.values = item.numbers.map((item = `${item}`))
        break
      case 'two_star':
        newItem.values = [`${item.numbers[0]}`]
        newItem.values2 = [`${item.numbers[1]}`]
        break
      case 'three_star_group_six':
        newItem.values = item.numbers.map((item = `${item}`))
        break
      case 'three_star_group_multiple':
        newItem.values = item.numbers.map((item = `${item}`))
        break
      case 'three_star':
        newItem.values = [`${item.numbers[0]}`]
        newItem.values2 = [`${item.numbers[1]}`]
        newItem.values3 = [`${item.numbers[2]}`]

        break
      case 'five_star':
        newItem.values = [`${item.numbers[0]}`]
        newItem.values2 = [`${item.numbers[1]}`]
        newItem.values3 = [`${item.numbers[2]}`]
        newItem.values4 = [`${item.numbers[3]}`]
        newItem.values5 = [`${item.numbers[4]}`]
        break
      case 'five_star_all':
        newItem.values = [`${item.numbers[0]}`]
        newItem.values2 = [`${item.numbers[1]}`]
        newItem.values3 = [`${item.numbers[2]}`]
        newItem.values4 = [`${item.numbers[3]}`]
        newItem.values5 = [`${item.numbers[4]}`]

      default:
    }

    const count = getLotteryCount(
      playType,
      newItem.values,
      newItem.values2,
      newItem.values3
    )
    const price = count * 2

    newItem.count = count
    newItem.price = price

    arr.push(newItem)
  })

  return arr
}
export function buildBackEndBetData (drawData) {
  const arr = []
  drawData.forEach(item => {
    var newItem = {
      gameplay: item.playType
    }

    switch (item.playType) {
      // 快三
      case 'sum': // 和值
        newItem.numbers = item.values
        break
      case 'triple_same_each': // 三同号单选
        newItem.triple = item.values.map(item => item.substring(0, 1))
        break
      case 'triple_same_all': // 三同号通选
        break
      case 'triple_consecutive_all': // 三连号通选
        break
      case 'double_same_each': // 二同号单选
        newItem.double = item.values.map(item => item.substring(0, 1))
        newItem.numbers = item.values2
        break
      case 'double_same_plural': // 二同号复选
        newItem.double = item.values.map(item => item.substring(0, 1))
        break
      case 'triple_different': // 三不同号
        newItem.numbers = item.values
        break
      case 'double_different_single': // 二不同号
        newItem.numbers = item.values
        break
      // 11选5
      case 'any_two': //
      case 'any_three': //
      case 'any_four': //
      case 'any_five': //
      case 'any_six': //
      case 'any_seven': //
      case 'any_eight': //
      case 'head_one': //
      case 'head_two': //
      case 'head_three': //
      case 'head_group_two': //
      case 'head_group_three': //
      case 'tuo_dan_any_two': //
      case 'tuo_dan_any_three': //
      case 'tuo_dan_any_four': //
      case 'tuo_dan_any_five': //
      case 'tuo_dan_any_six': //
      case 'tuo_dan_any_seven': //
      case 'tuo_dan_any_eight': //
      case 'tuo_dan_head_group_two': //
      case 'tuo_dan_head_group_three': //
        if (newItem.is_dan_tuo == 2) {
          newItem.numbers_a = item.values
          newItem.numbers_b = item.values2
        } else {
          if (item.values3 && item.values3.length) {
            newItem.numbers_a = item.values
            newItem.numbers_b = item.values2
            newItem.numbers_c = item.values3
          } else if (item.values2 && item.values2.length) {
            newItem.numbers_a = item.values
            newItem.numbers_b = item.values2
          } else {
            newItem.numbers_c = item.values
          }
        }
        break
      // 时时彩
      case 'big_small_odd_even': //
      case 'one_star': //
      case 'two_star_group': //
      case 'two_star': //
      case 'three_star_group_six': //
      case 'three_star_group_multiple': //
      case 'three_star': //
      case 'five_star': //
      case 'five_star_all': //
        if (item.values5) {
          newItem.numbers_a = item.values5
        }
        if (item.values4) {
          newItem.numbers_b = item.values4
        }
        if (item.values3) {
          newItem.numbers_c = item.values3
        }
        if (item.values2) {
          newItem.numbers_d = item.values2
        }
        if (item.values) {
          newItem.numbers_e = item.values
        }
        break

      default:
    }

    // 11选5
    if (/tuo_dan/.test(item.playType)) {
      newItem.is_dan_tuo = 2 // 是托胆
      newItem.gameplay = newItem.gameplay.replace(/tuo_dan_/, '')
    } else {
      newItem.is_dan_tuo = 1
    }
    arr.push(newItem)
  })

  return arr
}

function getStaticsItemData () {
  return {
    showTimes: 0,
    maxMiss: 0,
    maxContinue: 0,
    avgMiss: 0,
    currMiss: 0,
    currContinue: 0,
    totalMiss: 0
  }
}

let map = {
  showTimes: '出现次数',
  avgMiss: '平均遗漏',
  maxMiss: '最大遗漏',
  maxContinue: '最大连出'
}

export const erbutong = [12, 13, 14, 15, 16, 23, 24, 25, 26, 34, 35, 36, 45, 46, 56] // 二不同
export const baseNum = [1, 2, 3, 4, 5, 6] // sum
export const sums = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18] // sum
export const xingtai = ['三同号', '三不同', '二同号', '二不同'] // 形态

export const eleven = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]; //11选5
export const elevenXingtai = ['奇', '偶', '质', '合', '0路', '1路', '2路']; //11选5 前一直选 形态

//时时彩
export const tickXingtai = ['大', '小', '单', '双', '大', '小', '单', '双'];
export const tick = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

/*
  获取处理后趋势数据
 */

export function getTrendDataNormal (lotteryName, trendData, playType) {
  // let staticsData = [
  //   getStaticsItemData(),
  //   getStaticsItemData(),
  //   getStaticsItemData(),
  //   getStaticsItemData(),
  //   getStaticsItemData(),
  //   getStaticsItemData()
  // ]
  const origiPlayType = playType;
  playType = getTrendPlayType(playType)
  lotteryName = getLotteryName(lotteryName)

  trendData.data.forEach(item => {
    let winnerNumber = item.winnerNumber
    let missNumber = item.missNumber

    //公共
    item.win_num = winnerNumber.map(num => <span className={'win-num' + num}>{num}</span>)
    item.short_period = item.period.substr(-2, item.period.length) + '期'
    item.sum = winnerNumber.reduce((prev, curr) => prev + curr, 0)
    let sortWinnerNumber = winnerNumber.sort((a, b) => a - b)
    item.span = sortWinnerNumber[sortWinnerNumber.length - 1] - sortWinnerNumber[0]

    switch(lotteryName){
      case 'fast_three':
        item.size = winnerNumber.reduce((num, pre) => num + pre, 0) > 10 ? '大' : '小'
        item.odd_even = winnerNumber.reduce((num, pre) => num + pre, 0) % 2 === 0
          ? '双'
          : '单'
          item.xingtai = getXingtaiText(winnerNumber, missNumber.xingtai) // 形态
        item.baseNum = []
        baseNum.forEach((num, index) => {
          const missNum = item.missNumber[index]
          const len = winnerNumber.filter(item => item === num).length
          const numObj = {
            value: len > 0 ? num : missNum,
            showCount: len,
            isDrawNum: len > 0 ? true : false
          }

          item.baseNum.push(numObj)
        })

        item.sums = []
        sums.forEach((itemData, index) => {
          let isInclude = true
          let currSum = item.sum
          let numObj = null
          if(currSum === itemData){
            numObj = {
              value: itemData,
              showCount: 1,
              isDrawNum: true
            }
          }else{
            numObj = {
              value: item.missNumber.sum[index],
              showCount: 0,
              isDrawNum: false
            }
          }
          item.sums.push(numObj)

        })

        item.erbutong = []
        erbutong.forEach((itemData, index) => {
          let isInclude = true
          let numObj = null
          ;(itemData + '').split('').forEach(num => {
            if (winnerNumber.indexOf(+num) === -1) {
              isInclude = false
            }
          })
          if (isInclude) {
            numObj = {
              value: itemData,
              showCount: 1,
              isDrawNum: true
            }
          } else {
            numObj = {
              value: item.missNumber.erbutong[index],
              showCount: 0,
              isDrawNum: false
            }
          }
          item.erbutong.push(numObj)

        })


      break;
      case 'eleven_five':

        item.overNum = item.overNumber[playType][0]
        item.sizeThan = getSizeThan(winnerNumber)
        item.parityThan = getParityThan(winnerNumber)
        item.massCloseThan = getMassCloseThan(winnerNumber)

        item.elevenTrend = []
        eleven.forEach((num, index) => {
          const missNum = item.missNumber[playType][index]
          const len = winnerNumber.filter(item => item === num).length
          const numObj = {
            value: len > 0 ? num : missNum,
            showCount: len,
            isDrawNum: len > 0 ? true : false
          }
          item.elevenTrend.push(numObj)
        })
        item.elevenHeadOneTrend = []
        eleven.forEach((num, index) => {
          const missNum = item.missNumber['qian3_zhixuan'][index]
          const numObj = {
            value: missNum === 0 ? num : missNum,
            showCount: 1,
            isDrawNum: missNum === 0 ? true : false
          }
          item.elevenHeadOneTrend.push(numObj)
        })
        item.elevenHeadTwoTrend = []
        eleven.forEach((num, index) => {
          const missNum = item.missNumber['qian3_zhixuan'][11 + index]
          const numObj = {
            value: missNum === 0 ? num : missNum,
            showCount: 1,
            isDrawNum: missNum === 0 ? true : false
          }
          item.elevenHeadTwoTrend.push(numObj)
        })
        item.elevenHeadThreeTrend = []
        eleven.forEach((num, index) => {
          const missNum = item.missNumber['qian3_zhixuan'][ 22 + index]
          const numObj = {
            value: missNum === 0 ? num : missNum,
            showCount: 1,
            isDrawNum: missNum === 0 ? true : false
          }
          item.elevenHeadThreeTrend.push(numObj)
        })


        item.elevenXingtai = []
        elevenXingtai.forEach((num, index) => {
          const missNum = item.missNumber['qian1_danshi_xingtai'][index]
          // const len = winnerNumber.filter(item => item === num).length
          const numObj = {
            value: missNum === 0 ? num : missNum,
            showCount: 1,
            isDrawNum: missNum === 0 ? true : false
          }
          item.elevenXingtai.push(numObj)
        })


        break;
      case 'tick_tick':
        let shi = winnerNumber[winnerNumber.length - 2]
        let ge = winnerNumber[winnerNumber.length - 1]

        item.shi = getBigSmallText(shi) + getDoubleSingleText(shi)
        item.ge = getBigSmallText(ge) + getDoubleSingleText(ge)
        item.houSan = getHouSan(winnerNumber)
        let winNumShort = winnerNumber.slice(winnerNumber.length - 2)
        item.win_num_short = winNumShort.map(num => (
  <span className={'win-num' + num}>{num}</span>
))


        item.xingtai = buildItemStaticsData(tickXingtai, 'daxiaodanshuang', item.missNumber)
        item.wanTrend = buildItemStaticsData(tickXingtai, 'wuxing_tongxuan', item.missNumber)
        item.qianTrend = buildItemStaticsData(tickXingtai, 'wuxing_tongxuan', item.missNumber, 9)
        item.baiTrend = buildItemStaticsData(tickXingtai, 'wuxing_tongxuan', item.missNumber, 18)
        item.shiTrend = buildItemStaticsData(tickXingtai, 'wuxing_tongxuan', item.missNumber, 27)
        item.geTrend = buildItemStaticsData(tickXingtai, 'wuxing_tongxuan', item.missNumber, 36)
        item.geZhenfuTrend = buildItemStaticsData(tickXingtai, 'yixing_zhixuan_swing', item.missNumber)
        item.erxingZuxuanTrend = buildItemStaticsData(tickXingtai, 'erxing_zuxuan', item.missNumber)
        item.erxingZuxuanSpanTrend = buildItemStaticsData(tickXingtai, 'erxing_zuxuan_span', item.missNumber)
        item.sanxingZusanTrend = buildItemStaticsData(tickXingtai, 'sanxing_zusan', item.missNumber)
        item.sanxingZusanSpanTrend = buildItemStaticsData(tickXingtai, 'sanxing_zuxuan_span', item.missNumber)
        item.sanxingZuliuTrend = buildItemStaticsData(tickXingtai, 'sanxing_zuliu', item.missNumber)
        item.sanxingZuliuSpanTrend = buildItemStaticsData(tickXingtai, 'sanxing_zuxuan_span', item.missNumber)
      

      default:
      ;
    }

  })

  switch (lotteryName) {
    case 'fast_three':
      trendData.baseStaticsData = getStaticsData(lotteryName, trendData, 'baseNum')
      trendData.sumsStaticsData = getStaticsData(lotteryName, trendData, 'sums')
      trendData.erbutongStaticsData = getStaticsData(lotteryName, trendData, 'erbutong')
      trendData.xingtaiStaticsData = getStaticsData(lotteryName, trendData, 'xingtai')

      break;
    case 'eleven_five':


      trendData.elevenTrendStaticsData = getStaticsData(lotteryName, trendData, 'elevenTrend')
      trendData.elevenHeadOneTrendStaticsData = getStaticsData(lotteryName, trendData, 'elevenHeadOneTrend')
      trendData.elevenHeadTwoTrendStaticsData = getStaticsData(lotteryName, trendData, 'elevenHeadTwoTrend')
      trendData.elevenHeadThreeTrendStaticsData = getStaticsData(lotteryName, trendData, 'elevenHeadThreeTrend')
      trendData.elevenXingtaiStaticsData = getStaticsData(lotteryName, trendData, 'elevenXingtai')
      break;
    case 'tick_tick':

      trendData.xingtaiStaticsData = getStaticsData(lotteryName, trendData, 'xingtai')
      trendData.wanTrendStaticsData = getStaticsData(lotteryName, trendData, 'wanTrend')
      trendData.qianTrendStaticsData = getStaticsData(lotteryName, trendData, 'qianTrend' )
      trendData.baiTrendStaticsData = getStaticsData(lotteryName, trendData, 'baiTrend' )
      trendData.shiTrendStaticsData = getStaticsData(lotteryName, trendData, 'shiTrend' )
      trendData.geTrendStaticsData = getStaticsData(lotteryName, trendData, 'geTrend')
      trendData.geZhenfuTrendStaticsData = getStaticsData(lotteryName, trendData, 'geZhenfuTrend')
      trendData.erxingZuxuanTrendStaticsData = getStaticsData(lotteryName, trendData, 'erxingZuxuanTrend')
      trendData.erxingZuxuanSpanTrendStaticsData = getStaticsData(lotteryName, trendData, 'erxingZuxuanSpanTrend')
      trendData.sanxingZusanTrendStaticsData = getStaticsData(lotteryName, trendData, 'sanxingZusanTrend')
      trendData.sanxingZusanSpanTrendStaticsData = getStaticsData(lotteryName, trendData, 'sanxingZusanSpanTrend')
      trendData.sanxingZuliuTrendStaticsData = getStaticsData(lotteryName, trendData, 'sanxingZuliuTrend')
      trendData.sanxingZuliuSpanTrendStaticsData = getStaticsData(lotteryName, trendData, 'sanxingZuliuSpanTrend')
    break;
    default:
      ;
  }


}

function getBigSmallText(num){
  return num > 4 ? '大' : '小'
}
function getDoubleSingleText(num){
  return num % 2 === 0 ? '双' : '单'
}
function getHouSan(bai, shi, ge){
  if (ge === shi && ge === bai) {//组三
      return "豹子"
  } else if (ge == shi || ge == bai || shi == bai) {//组三
      return "组三"
  } else {//组六
      return "组六"
  }
}

function buildItemStaticsData(arr, key, missNumber, start){
  const newArr = []
  start = start || 0
  tick.forEach((num, index) => {
    const missNum = missNumber[start + index]
    const numObj = {
      value: missNum <= 0 ? num : missNum,
      showCount: Math.abs(missNum) || 1,
      isDrawNum: missNum <= 0 ? true : false
    }
    newArr.push(numObj)
  })
  return newArr;
}

function getTrendPlayType(playType){
  let playTypeMap = {
    //  '任选二',
    'any_two': 'renxuan_general',
//  '任选三',
    'any_three': 'renxuan_general',
//  '任选四',
    'any_four': 'renxuan_general',
//  '任选五',
    'any_five': 'renxuan_general',
//  '任选六',
    'any_six': 'renxuan_general',
//  '任选七',
    'any_seven': 'renxuan_general',
//  '任选八',
    'any_eight': 'renxuan_general',
//  '前一直选',
    'head_one': 'qian3_zhixuan',
//  '前二直选',
    'head_two': 'qian3_zhixuan',
//  '前三直选',
    'head_three': 'qian3_zhixuan',
//  '前二组选',
    'head_group_two': 'qian2_zuxuan',
//  '前三组选',
    'head_group_three': 'qian3_zuxuan',
//  '任选二',
    'tuo_dan_any_two': '',
//  '任选三',
    'tuo_dan_any_three': '',
//  '任选四',
    'tuo_dan_any_four': '',
//  '任选五',
    'tuo_dan_any_five': '',
//  '任选六',
    'tuo_dan_any_six': '',
//  '任选七',
    'tuo_dan_any_seven': '',
//  '任选八',
    'tuo_dan_any_eight': '',
//  '前二组选',
    'tuo_dan_head_group_two': '',
//  '前三组选',
    'tuo_dan_head_group_three': '',
  };
  return playTypeMap[playType]
}

function getSizeThan(nums){
  let left = nums.filter(num => num >= 6).length
  let right = nums.length - left;
  return `${left}:${right}`

}
function getParityThan(nums){
  let left = nums.filter(num => num % 2 !== 0).length
  let right = nums.length - left;
  return `${left}:${right}`

}
function getMassCloseThan(nums){
  let left = nums.filter(num => [1, 2, 3, 5, 7, 11].indexOf(num) >= 0).length
  let right = nums.length - left;
  return `${left}:${right}`
}


function getStaticsData (lotteryName, trendData, key) {
  let staticsData = []
  if (!trendData.data || trendData.data.length === 0 || trendData.data[0][key].length === 0) return []
  trendData.data[0][key].forEach(item => {
    staticsData.push(getStaticsItemData())
  })

  trendData.data.forEach(item => {
		console.log("​getStaticsData -> trendData.data", trendData.data, item)
    let winnerNumber = item.winnerNumber

    staticsData.forEach((itemData, index) => {
      let numObj = item[key][index]
      if (!numObj.isDrawNum) {
        itemData.currMiss++
        itemData.totalMiss++
        itemData.currContinue = 0
      } else {
        itemData.currContinue++
        itemData.showTimes++
        itemData.currMiss = 0
      }

      if (itemData.currContinue > itemData.maxContinue) {
        itemData.maxContinue = itemData.currContinue
      }

      if (itemData.currMiss > itemData.maxMiss) {
        itemData.maxMiss = itemData.currMiss
      }
    })
  })
  staticsData.forEach(item => {
    item.avgMiss = Math.floor(item.totalMiss / (item.showTimes + 1))
  })
  const newStaticsData = []
  Object.keys(map).forEach(key => {
    const newItem = {
      title: map[key]
    }
    staticsData.map((item, index) => {
      newItem[`num${index + 1}`] = item[key]
    })
    newStaticsData.push(newItem)
  })

  return newStaticsData
}

/* 快三形态 */
function getXingtaiText (nums, defaultNums) {
  let sameCount = 0
  let seqNum = 0
  let prevNum = null
  nums.forEach(num => {
    if (prevNum) {
      if (num === prevNum) {
        sameCount++
      }
      if (prevNum + 1 === num) {
        seqNum++
      }
    }
    prevNum = num
  })
  let xingtaiArr = [
    sameCount === 2 ? '三同号' : defaultNums[0],
    sameCount === 0 ? '三不同' : defaultNums[1],
    sameCount >= 1 ? '二同号' : defaultNums[3],
    sameCount <= 1 ? '二不同' : defaultNums[4],
    sameCount === 2 ? '三连号' : defaultNums[2]
  ]

  let newXingtaiArr = xingtaiArr.map(item => {
    let isDrawNum = !Number.isInteger(item)

    let numObj = {
      value: item,
      showCount: isDrawNum ? 1 : 0,
      isDrawNum: isDrawNum
    }
    return numObj
  })

  if (!Number.isInteger(xingtaiArr[4])) {
    newXingtaiArr.value = xingtaiArr[4]
  } else if (!Number.isInteger(xingtaiArr[0])) {
    newXingtaiArr.value = xingtaiArr[0]
  } else if (!Number.isInteger(xingtaiArr[1])) {
    newXingtaiArr.value = xingtaiArr[1]
  } else if (!Number.isInteger(xingtaiArr[2])) {
    newXingtaiArr.value = xingtaiArr[2]
  } else if (!Number.isInteger(xingtaiArr[3])) {
    newXingtaiArr.value = xingtaiArr[3]
  }



  return newXingtaiArr
}


export function waitDrawLotteryRender(colSpan, fn){

  if (colSpan){
    return (value, row, index) => {
      if (row.win_num) {
        if (typeof fn === 'function'){
          return fn(value, row, index)
        }else{
          return value
        }
      } else {
        return {
          children: '等待开奖',
          props: { colSpan: colSpan }
        }
      }
    }

  }else{
    return (value, row, index) => {
      if (row.win_num) {
        if (typeof fn === 'function') {
          return fn(value, row, index)
        } else {
          return value
        }
      } else {
        return { children: '', props: { colSpan: 0 } }
      }
    }
  }
}

/**
 * 通用
 *
 * @param size 选中号码的个数
 * @return
 */
export function commonCount (size) {
  return size
}

/**
 * 快三：三不同
 *
 * @param size 选中号码的个数
 * @return
 */
export function threeDifferentCount (size) {
  let a = size * (size - 1) * (size - 2)
  return a / 6
}

/**
 * 快三：二不同
 *
 * @param size 选中号码的个数
 * @return
 */
export function twoDifferentCount (size) {
  let a = size * (size - 1)
  return a / 2
}
/**
 * 快三：二同号单选
 *
 * @param size 选中号码的个数
 * @return
 */
export function twoSameSingleCount (size, size2) {
  return size * size2
}

/**
 * 11选5组合的计算公式
 *
 * @return
 */

function headTwo (arr, arr2) {
  return arr.length * arr2.length - intersect(arr, arr2).length
}
function headThree (arr, arr2, arr3) {
  let oneSize = arr.length
  let twoSize = arr2.length
  let threeSize = arr3.length
  let count = oneSize * twoSize * threeSize
  if (count > 0) {
    for (let i = 0; i < oneSize; i++) {
      let iNum = arr[i]
      for (let j = 0; j < twoSize; j++) {
        let jNum = arr2[j]
        for (let k = 0; k < threeSize; k++) {
          let kNum = arr3[k]
          if (iNum === kNum || jNum === iNum || kNum === jNum) {
            count--
          } else {
            console.log('11选5组合注数 ', '11选5组合 ' + iNum + ',' + jNum + ',' + kNum)
          }
        }
      }
    }
  }
  return count
  // return arr.length * arr2.length * arr3.length - intersect(arr, arr2).length - intersect(arr, arr3).length - intersect(arr2, arr3).length
}
/**
 * 11选5组合的计算公式
 *
 * @param n
 * @param m
 * @return
 */
// 自定义组合函数(就是数学排列组合里的C)
function combination (m, n) {
  if (m < n) {
    return 0
  }

  return factorial(m, n) / factorial(n, n) // 就是Cmn(上面是n，下面是m) = Amn(上面是n，下面是m)/Ann(上下都是n)
}

// 自定义排列函数(就是数学排列组合里的A)
function arrangement (m, n) {
  return factorial(m, n) // 就是数学里的Amn,上面是n，下面是m
}

// 自定义一个阶乘函数，就是有n个数相乘，从m开始，每个数减1，如factorial(5,4)就是5*(5-1)*(5-2)*(5-3),相乘的数有4个
function factorial (m, n) {
  var num = 1
  var count = 0
  for (var i = m; i > 0; i--) {
    if (count == n) {
      // 当循环次数等于指定的相乘个数时，即跳出for循环
      break
    }
    num = num * i
    count++
  }
  return num
}

function union (arr1, arr2) {
  return [...new Set([...arr1, ...arr2])]
}

function intersect (arr1, arr2) {
  const set1 = new Set(arr1)
  const set2 = new Set(arr2)
  return [...new Set([...set1].filter(item => set2.has(item)))]
}

function difference (arr1, arr2) {
  const set1 = new Set(arr1)
  const set2 = new Set(arr2)
  return [...new Set([...set1].filter(item => !set2.has(item)))]
}
