export const fastThreePlayType = [
  {
    selectedCount: 0,
    label: '和值',
    value: 'sum',
    tip: '猜对开奖号码相加的和',
    options: [
      { value: '3', label: '奖金240' },
      { value: '4', label: '奖金80' },
      { value: '5', label: '奖金40' },
      { value: '6', label: '奖金25' },
      { value: '7', label: '奖金16' },
      { value: '8', label: '奖金12' },
      { value: '9', label: '奖金10' },
      { value: '10', label: '奖金9' },
      { value: '11', label: '奖金11' },
      { value: '12', label: '奖金10' },
      { value: '13', label: '奖金12' },
      { value: '14', label: '奖金16' },
      { value: '15', label: '奖金25' },
      { value: '16', label: '奖金40' },
      { value: '17', label: '奖金80' },
      { value: '18', label: '奖金240' }
    ],
    options2Label: '快速选号',
    options2: [
      { value: 8, label: '大' },
      { value: 4, label: '小' },
      { value: 2, label: '单' },
      { value: 1, label: '双' }
    ]
  },
  {
    selectedCount: 1,
    label: '三同号单选',
    value: 'triple_same_each',
    tip: '猜豹子号与开奖号码一致即中奖',
    options: [
      { value: '111', label: '奖金240' },
      { value: '222', label: '奖金240' },
      { value: '333', label: '奖金240' },
      { value: '444', label: '奖金240' },
      { value: '555', label: '奖金240' },
      { value: '666', label: '奖金240' }
    ]
  },
  {
    selectedCount: 2,
    label: '三同号通选',
    value: 'triple_same_all',
    tip: '猜出一豹子号即中40元',
    options: [{ value: '三同号通选', label: '(111、222、333、444、555、666)' }]
  },
  {
    selectedCount: 3,
    label: '三连号通选',
    value: 'triple_consecutive_all',
    tip: '猜出任意顺子号即中奖',
    options: [{ value: '三连号通选', label: '(123、234、345、456)' }]
  },
  {
    selectedCount: 4,
    label: '二同号单选',
    value: 'double_same_each',
    tip: '猜中同号与不同号的组合即中80元',
    optionsLabel: '同号',
    options2Label: '不同号',
    options: [
      { value: '11', label: '' },
      { value: '22', label: '' },
      { value: '33', label: '' },
      { value: '44', label: '' },
      { value: '55', label: '' },
      { value: '66', label: '' }
    ],
    options2: [
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' }
    ]
  },
  {
    selectedCount: 5,
    label: '二同号复选',
    value: 'double_same_plural',
    tip: '猜出对子号与开奖号码一致即中15元',
    options: [
      { value: '11', label: '' },
      { value: '22', label: '' },
      { value: '33', label: '' },
      { value: '44', label: '' },
      { value: '55', label: '' },
      { value: '66', label: '' }
    ]
  },
  {
    selectedCount: 6,
    label: '三不同号',
    value: 'triple_different',
    tip: '猜中开奖号码中任意3个即中40元',
    options: [
      { value: '1', label: '' },
      { value: '2', label: '' },
      { value: '3', label: '' },
      { value: '4', label: '' },
      { value: '5', label: '' },
      { value: '6', label: '' }
    ]
  },
  {
    selectedCount: 7,
    label: '二不同号',
    value: 'double_different_single',
    tip: '猜中开奖号码中任意2个即中8元',
    options: [
      { value: '1', label: '' },
      { value: '2', label: '' },
      { value: '3', label: '' },
      { value: '4', label: '' },
      { value: '5', label: '' },
      { value: '6', label: '' }
    ]
  }
]

export const elevenFivePlayType = [
  {
    selectedCount: 2,
    label: '任选二',
    value: 'any_two',
    tip: '至少选2个号，猜对任意2个开奖号即中6元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 3,
    label: '任选三',
    value: 'any_three',
    tip: '至少选3个号，猜对任意3个开奖号即中19元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 4,
    label: '任选四',
    value: 'any_four',
    tip: '至少选4个号，猜对任意4个开奖号即中78元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 5,
    label: '任选五',
    value: 'any_five',
    tip: '至少选5个号，猜对任意5个开奖号即中540元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 6,
    label: '任选六',
    value: 'any_six',
    tip: '至少选6个号，猜对任意5个开奖号即中90元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 7,
    label: '任选七',
    value: 'any_seven',
    tip: '至少选7个号，猜对任意5个开奖号即中26元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 8,
    label: '任选八',
    value: 'any_eight',
    tip: '至少选8个号，猜对任意5个开奖号即中9元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 1,
    label: '前一直选',
    value: 'head_one',
    tip: '至少选1个号，猜对第1个开奖号即中13元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 2,
    label: '前二直选',
    value: 'head_two',
    tip: '每位至少选1个号，按位猜对开奖前2位即中130元',
    optionsLabel: '万位',
    options2Label: '千位',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 3,
    label: '前三直选',
    value: 'head_three',
    tip: '每位至少选1个号，按位猜对开奖前3位即中1170元',
    optionsLabel: '万位',
    options2Label: '千位',
    options3Label: '百位',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options3: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 2,
    label: '前二组选',
    value: 'head_group_two',
    tip: '至少选2个号，猜对前2个开奖号即中65元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 3,
    label: '前三组选',
    value: 'head_group_three',
    tip: '至少选3个号，猜对前3个开奖号即中195元',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },

  // 托胆
  {
    selectedCount: 2,
    maxSelectedCount: 1,
    label: '任选二',
    value: 'tuo_dan_any_two',
    tip: '猜对任意2个开奖号即中6元',
    optionsLabel: '我认为必出的号码，至少选1个，最多1个',
    options2Label: '我认为可能出的号码',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 3,
    maxSelectedCount: 2,
    label: '任选三',
    value: 'tuo_dan_any_three',
    tip: '猜对任意3个开奖号即中19元',
    optionsLabel: '我认为必出的号码，至少选1个，最多2个',
    options2Label: '我认为可能出的号码',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 4,
    maxSelectedCount: 3,
    label: '任选四',
    value: 'tuo_dan_any_four',
    tip: '猜对任意4个开奖号即中78元',
    optionsLabel: '我认为必出的号码，至少选1个，最多3个',
    options2Label: '我认为可能出的号码',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 5,
    maxSelectedCount: 4,
    label: '任选五',
    value: 'tuo_dan_any_five',
    tip: '猜对任意5个开奖号即中540元',
    optionsLabel: '我认为必出的号码，至少选1个，最多4个',
    options2Label: '我认为可能出的号码',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 6,
    maxSelectedCount: 5,
    label: '任选六',
    value: 'tuo_dan_any_six',
    tip: '猜对任意5个开奖号即中90元',
    optionsLabel: '我认为必出的号码，至少选1个，最多5个',
    options2Label: '我认为可能出的号码',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 7,
    maxSelectedCount: 6,
    label: '任选七',
    value: 'tuo_dan_any_seven',
    tip: '猜对任意5个开奖号即中26元',
    optionsLabel: '我认为必出的号码，至少选1个，最多6个',
    options2Label: '我认为可能出的号码',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 8,
    maxSelectedCount: 7,
    label: '任选八',
    value: 'tuo_dan_any_eight',
    tip: '猜对任意5个开奖号即中9元',
    optionsLabel: '我认为必出的号码，至少选1个，最多7个',
    options2Label: '我认为可能出的号码',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 2,
    maxSelectedCount: 1,
    label: '前二组选',
    value: 'tuo_dan_head_group_two',
    tip: '猜对前2个开奖号即中65元',
    optionsLabel: '我认为必出的号码，至少选1个，最多1个',
    options2Label: '我认为可能出的号码',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  },
  {
    selectedCount: 3,
    maxSelectedCount: 2,
    label: '前三组选',
    value: 'tuo_dan_head_group_three',
    tip: '猜对前3个开奖号即中9元',
    optionsLabel: '我认为必出的号码，至少选1个，最多2个',
    options2Label: '我认为可能出的号码',
    options: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ],
    options2: [
      { value: '01', label: '01' },
      { value: '02', label: '02' },
      { value: '03', label: '03' },
      { value: '04', label: '04' },
      { value: '05', label: '05' },
      { value: '06', label: '06' },
      { value: '07', label: '07' },
      { value: '08', label: '08' },
      { value: '09', label: '09' },
      { value: '10', label: '10' },
      { value: '11', label: '11' }
    ]
  }
]

export const tickPlayType = [
  {
    selectedCount: 2,
    label: '大小单双',
    value: 'big_small_odd_even',
    tip: '每位至少选1个号，猜对开奖后2位的属性即中6元',
    optionsLabel: '十位',
    options2Label: '个位',
    options: [
      { value: '1', label: '大' },
      { value: '2', label: '小' },
      { value: '3', label: '单' },
      { value: '4', label: '双' }
    ],
    options2: [
      { value: '1', label: '大' },
      { value: '2', label: '小' },
      { value: '3', label: '单' },
      { value: '4', label: '双' }
    ]
  },
  {
    selectedCount: 1,
    label: '一星直选',
    value: 'one_star',
    tip: '至少选1个号，猜对开奖最后1位即中10元',
    optionsLabel: '个位',
    options: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ]
  },
  {
    selectedCount: 2,
    label: '二星组选',
    value: 'two_star_group',
    tip: '至少选2个号，猜对开奖最后2位(顺序不限)即中10元',
    optionsLabel: '选号',
    options: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ]
  },
  {
    selectedCount: 2,
    label: '二星直选',
    value: 'two_star',
    tip: '每位至少选1个号，按位猜对开奖后2位即中100元',
    optionsLabel: '十位',
    options2Label: '个位',
    options: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options2: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ]
  },
  {
    selectedCount: 3,
    label: '三星组六',
    value: 'three_star_group_six',
    tip: '至少选3个号，猜对开奖最后3位(顺序不限)即中160元',
    optionsLabel: '选号',
    options: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ]
  },
  {
    selectedCount: 2,
    label: '三星组三',
    value: 'three_star_group_multiple',
    tip: '至少选2个号，猜对开奖最后3位(顺序不限)即中320元',
    optionsLabel: '选号',
    options: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ]
  },
  {
    selectedCount: 3,
    label: '三星直选',
    value: 'three_star',
    tip: '每位至少选1个号，按位猜对开奖后3位即中1000元',
    optionsLabel: '百位',
    options2Label: '十位',
    options3Label: '个位',
    options: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options2: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options3: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ]
  },
  {
    selectedCount: 5,
    label: '五星直选',
    value: 'five_star',
    tip: '每位至少选1个号，按位猜对开奖号即中100000元',
    optionsLabel: '万位',
    options2Label: '千位',
    options3Label: '百位',
    options4Label: '十位',
    options5Label: '个位',
    options: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options2: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options3: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options4: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options5: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ]
  },
  {
    selectedCount: 5,
    label: '五星通选',
    value: 'five_star_all',
    tip: '每位至少选1个号，按位猜对开奖号即中20440元',
    optionsLabel: '万位',
    options2Label: '千位',
    options3Label: '百位',
    options4Label: '十位',
    options5Label: '个位',
    options: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options2: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options3: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options4: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ],
    options5: [
      { value: '0', label: '0' },
      { value: '1', label: '1' },
      { value: '2', label: '2' },
      { value: '3', label: '3' },
      { value: '4', label: '4' },
      { value: '5', label: '5' },
      { value: '6', label: '6' },
      { value: '7', label: '7' },
      { value: '8', label: '8' },
      { value: '9', label: '9' }
    ]
  }
]

export function getFastThreePlayType () {
  return JSON.parse(JSON.stringify(fastThreePlayType))
}

export function getElevenFivePlayType () {
  return JSON.parse(JSON.stringify(elevenFivePlayType))
}

export function getTickPlayType () {
  return JSON.parse(JSON.stringify(tickPlayType))
}
