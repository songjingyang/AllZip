import React, { Fragment } from 'react'
import { connect } from 'dva'
import { routerRedux, Route, Switch, Link } from 'dva/router'

import classnames from 'classnames'
import pathToRegexp from 'path-to-regexp'

// import { Layout, Icon } from 'antd'
import { getRouterData } from '@/common/router'

import './BasicLayout.css'

@connect(({ global }) => ({
  global
}))
export default class BasicLayout extends React.Component {
  state = {}

  componentDidMount () {}

  componentWillUnmount () {}

  toggle = () => {}
  // 获取当前路由对应name
  // getPageTitle () {
  //   let title = window.appName || ''

  //   return title
  // }

  onCollapse = collapsed => {
    this.setState({
      collapsed
    })
  }

  render () {
    return (
      <Switch>
        {this.props.children}
      </Switch>
    )
  }
}
