import React from 'react'
import { routerRedux, Route, Switch, Link, Redirect } from 'dva/router'
// import { LocaleProvider } from 'antd-mobile'
// import zhCN from 'antd-mobile/lib/locale-provider'

import Layout from './layouts/Layout'

// import Authorized from './utils/Authorized'
// import { getQueryPath } from './utils/utils'

const { ConnectedRouter } = routerRedux
// const { AuthorizedRoute } = Authorized

function RouterConfig ({ history, app }) {
  return (
    <ConnectedRouter history={history}>
      <Switch>
        <Layout app={app} />
      </Switch>
    </ConnectedRouter>
  )
}

export default RouterConfig
