import mockjs from 'mockjs'
import urlMaps from '../common/urlMaps'

let mockData = {
  [`GET ${urlMaps.getUserInfo}`]: () => {
    return success({
      name: 'daycool',
      email: 'qmw920@163.com'
    })
  },
  [`POST ${urlMaps.login}`]: () => {
    return success({
      name: 'daycool',
      email: 'qmw920@163.com'
    })
  },
  [`POST ${urlMaps.register}`]: () => {
    return success({
      name: 'daycool',
      email: 'qmw920@163.com'
    })
  },
  [`POST ${urlMaps.logout}`]: () => {
    return success({
      name: 'daycool',
      email: 'qmw920@163.com'
    })
  },
  [`GET ${urlMaps.getMerchantList}`]: () => {
    return success({
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          name: 'daycool',
          total: '11111',
          price: '11111',
          orderCount: '11111'
        }
      ]
    })
  },
  [`GET ${urlMaps.getAccountList}`]: () => {
    return success({
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          isOpen: false,
          account: 'daycool',
          amount: 20,
          startTime: 9,
          endTime: 9,
          thresholdVal: 200,
          channel: 200,
          interfaceVersion: 2,
          merchant: [{ name: 'daycool', id: 1111 }],
          income: '11111',
          orderCount: '11111',
          status: '结算完成'
        }
      ]
    })
  },
  [`GET ${urlMaps.getAccount}`]: () => {
    return success({
      'id|+1': 100,
      isOpen: false,
      account: 'daycool',
      amount: 20,
      startTime: '09:20',
      endTime: '18:20',
      thresholdVal: 200,
      channel: 200,
      interfaceVersion: 2,
      merchant: [{ name: 'daycool', id: 1111 }],
      income: '11111',
      orderCount: '11111',
      status: '结算完成'
    })
  },
  [`POST ${urlMaps.saveAccount}`]: () => {
    return success({
      'id|+1': 100,
      isOpen: false,
      account: 'daycool',
      amount: 20,
      startTime: 9,
      endTime: 9,
      thresholdVal: 200,
      channel: 200,
      interfaceVersion: 2,
      merchant: [{ name: 'daycool', id: 1111 }],
      income: '11111',
      orderCount: '11111',
      status: '结算完成'
    })
  }
}

export default mockData

function success (data, msg, code) {
  return {
    code: code || 200,
    msg: msg || '请求成功',
    data: mockjs.mock(data || {})
  }
}

function fail (code, msg, data) {
  return {
    code: code || 10001,
    msg: msg || '请求失败',
    data: mockjs.mock(data || {})
  }
}
