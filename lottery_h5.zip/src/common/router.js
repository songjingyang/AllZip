import React from 'react'

import Home from '@/modules/Home/Home'

// 用户
import UserLogin from '@/modules/User/UserLogin'
import UserRegister from '@/modules/User/UserRegister'
import ResetPassword from '@/modules/User/ResetPassword'
import SetPassword from '@/modules/User/SetPassword'
import Setting from '@/modules/User/Setting'
import AboutUs from '@/modules/User/AboutUs'
import Feedback from '@/modules/User/Feedback'
import PersionalInfo from '@/modules/User/PersionalInfo'
import ChangeNickName from '@/modules/User/ChangeNickName'
import ForgetPassword from '@/modules/User/ForgetPassword'
import ChangePassword from '@/modules/User/ChangePassword'
import UserAgreement from '@/modules/User/UserAgreement'
import CountryAreaCode from '@/modules/User/CountryAreaCode'
import SetMobile from '@/modules/User/SetMobile'

// import MerchantList from '@/modules/Merchant/List'
import FastThree from '@/modules/Lottery/FastThree'
import FastThreePlayInfo from '@/modules/Lottery/FastThreePlayInfo'
import Bet from '@/modules/Lottery/Bet'
import Pay from '@/modules/Lottery/Pay'
import OrderDetail from '@/modules/Lottery/OrderDetail'
import ChaseOrderDetail from '@/modules/Lottery/ChaseOrderDetail'
import ElevenFive from '@/modules/Lottery/ElevenFive'
import Tick from '@/modules/Lottery/Tick'

// 开奖
import DrawInfo from '@/modules/Draw/DrawInfo'
import LastDraw from '@/modules/Draw/LastDraw'
import DrawDetail from '@/modules/Draw/DrawDetail'
import Notice from '@/modules/Draw/Notice'

// import Dashboard from '@/modules/Dashboard'

// 我的
import ChaseRecord from '@/modules/My/ChaseRecord'
import PayAll from '@/modules/My/PayAll'
import Withdrawal from '@/modules/My/Withdrawal'
import WithdrawalIdentity from '@/modules/My/WithdrawalIdentity'
import WithdrawalType from '@/modules/My/WithdrawalType'
import WithdrawalRecord from '@/modules/My/WithdrawalRecord'
import AccountDatail from '@/modules/My/AccountDatail'
import PeriodManage from '@/modules/My/PeriodManage'
import AccountInfo from '@/modules/My/AccountInfo'
import WebkitInfo from '@/modules/My/WebkitInfo'
import Trend from '../modules/Lottery/Trend'
import ElevenFiveTrend from '../modules/Lottery/ElevenFiveTrend'
import TickTrend from '../modules/Lottery/TickTrend'

const NoMatch = props => <h2>404</h2>

const routerData = [
  {
    path: '/home/:tab',
    component: Home,
    meta: {
      title: '首页'
    }
  },
  {
    path: '/user/userLogin/:rowID',
    component: UserLogin,
    meta: {
      title: '登录'
    }
  },
  {
    path: '/user/userLogin',
    component: UserLogin,
    meta: {
      title: '登录'
    }
  },
  {
    path: '/user/countryAreaCode/:title',
    component: CountryAreaCode,
    meta: {
      title: '国家区号'
    }
  },
  {
    path: '/user/userRegister/:rowID',
    component: UserRegister,
    meta: {
      title: '注册'
    },
    isshow: false
  },
  {
    path: '/user/userRegister',
    component: UserRegister,
    meta: {
      title: '注册'
    },
    isshow: false
  },
  {
    path: '/user/resetPassword/:email/:code',
    component: ResetPassword,
    meta: {
      title: '重置密码'
    },
    isshow: false
  },
  {
    path: '/user/setPassword/:email/:code',
    component: SetPassword,
    meta: {
      title: '填写密码'
    },
    isshow: false
  },
  {
    path: '/user/setting',
    component: Setting,
    meta: {
      title: '设置'
    },
    isshow: false
  },
  {
    path: '/user/setMobile',
    component: SetMobile,
    meta: {
      title: '绑定手机号'
    },
    isshow: false
  },
  {
    path: '/user/aboutUs',
    component: AboutUs,
    meta: {
      title: '关于我们'
    },
    isshow: false
  },
  {
    path: '/user/feedback',
    component: Feedback,
    meta: {
      title: '意见反馈'
    },
    isshow: false
  },
  {
    path: '/user/persionalInfo',
    component: PersionalInfo,
    meta: {
      title: '个人信息'
    },
    isshow: false
  },
  {
    path: '/user/changeNickName',
    component: ChangeNickName,
    meta: {
      title: '修改昵称'
    },
    isshow: false
  },
  {
    path: '/user/forgetPassword',
    component: ForgetPassword,
    meta: {
      title: '忘记密码'
    },
    isshow: false
  },
  {
    path: '/user/changePassword',
    component: ChangePassword,
    meta: {
      title: '修改密码'
    },
    isshow: false
  },
  {
    path: '/user/userAgreement',
    component: UserAgreement,
    meta: {
      title: '用户协议'
    },
    isshow: false
  },
  {
    path: '/lottery/fastThree/:lotteryName',
    component: FastThree,
    meta: {
      title: '快三'
    },
    isshow: false
  },
  {
    path: '/lottery/trend/:lotteryName',
    component: Trend,
    meta: {
      title: '趋势图'
    },
    isshow: false
  },
  {
    path: '/lottery/elevenFiveTrend/:lotteryName',
    component: ElevenFiveTrend,
    meta: {
      title: '趋势图'
    },
    isshow: false
  },
  {
    path: '/lottery/tickTrend/:lotteryName',
    component: TickTrend,
    meta: {
      title: '趋势图'
    },
    isshow: false
  },
  {
    path: '/lottery/fastThreePlayInfo',
    component: FastThreePlayInfo,
    meta: {
      title: '快三玩法说明'
    },
    isshow: false
  },
  {
    path: '/lottery/elevenFive/:lotteryName',
    component: ElevenFive,
    meta: {
      title: '11选5'
    },
    isshow: false
  },
  {
    path: '/lottery/tick/:lotteryName',
    component: Tick,
    meta: {
      title: '时时彩'
    },
    isshow: false
  },
  {
    path: '/lottery/bet/:lotteryName/:selectNumId',
    component: Bet,
    meta: {
      title: '下注页'
    },
    isshow: false
  },
  {
    path: '/lottery/pay/:price/:lotteryName/:chase/:orderData',
    component: Pay,
    meta: {
      title: '支付页'
    },
    isshow: false
  },
  {
    path: '/lottery/orderDetail/:orderId/:lotteryName',
    component: OrderDetail,
    meta: {
      title: '订单详情'
    },
    isshow: false
  },
  // 开奖信息
  {
    path: '/draw/drawInfo',
    component: DrawInfo,
    meta: {
      title: '开奖信息'
    },
    isshow: false
  },
  {
    path: '/draw/lastDraw/:lotteryName',
    component: LastDraw,
    meta: {
      title: '近期开奖'
    },
    isshow: false
  },
  {
    path: '/draw/drawDetail/:lotteryName/:period/:time/:numbers/:sum',
    component: DrawDetail,
    meta: {
      title: '开奖详情'
    },
    isshow: false
  },
  {
    path: '/draw/notice',
    component: Notice,
    meta: {
      title: '通知中心'
    },
    isshow: false
  },

  // my
  {
    path: '/lottery/ChaseOrderDetail/:orderId/:lotteryName',
    component: ChaseOrderDetail,
    meta: {
      title: '追期'
    },
    isshow: false
  },

  {
    path: '/my/payAll',
    component: PayAll,
    meta: {
      title: '充值'
    },
    isshow: false
  },
  {
    path: '/my/withdrawal/:qrType',
    component: Withdrawal,
    meta: {
      title: '提现'
    },
    isshow: false
  },
  {
    path: '/my/withdrawal',
    component: Withdrawal,
    meta: {
      title: '提现'
    },
    isshow: false
  },
  {
    path: '/my/withdrawalIdentity',
    component: WithdrawalIdentity,
    meta: {
      title: '提现身份信息'
    }
  },
  {
    path: '/my/withdrawalType',
    component: WithdrawalType,
    meta: {
      title: '提现方式'
    },
    isshow: false
  },
  {
    path: '/my/withdrawalRecord',
    component: WithdrawalRecord,
    meta: {
      title: '提现记录'
    },
    isshow: false
  },
  {
    path: '/my/chaseRecord',
    component: ChaseRecord,
    meta: {
      title: '投注记录'
    },
    isshow: false
  },
  {
    path: '/my/accountDatail',
    component: AccountDatail,
    meta: {
      title: '账户明细'
    },
    isshow: false
  },
  {
    path: '/my/periodManage',
    component: PeriodManage,
    meta: {
      title: '追期管理'
    },
    isshow: false
  },
  {
    path: '/my/accountInfo',
    component: AccountInfo,
    meta: {
      title: '账户信息'
    },
    isshow: false
  },
  {
    path: '/my/webkitInfo',
    component: WebkitInfo,
    meta: {
      title: '站内信息'
    },
    isshow: false
  }
]

export function getRouterData () {
  return routerData
}

export default getRouterData
