import { isUrl } from '../utils/utils'

const menuData = [
  {
    name: '首页',
    icon: 'dashboard',
    path: 'home',
    children: [
      {
        name: '统计',
        path: 'home'
      },
      // {
      //   name: '订单列表',
      //   path: 'orderList'
      // },
      // {
      //   name: '查看收款',
      //   path: 'incomeList'
      // }
    ]
  },
  {
    name: '登录',
    icon: '',
    path: 'user',
    children: [
      {
        name: '登录',
        path: 'userLogin'
      }
    ]
  },
  {
    name: '注册',
    icon: '',
    path: 'user',
    children: [
      {
        name: '注册',
        path: 'userRegister'
      }
    ]
  },
  {
    name: '忘记密码',
    icon: '',
    path: 'user',
    children: [
      {
        name: '忘记密码',
        path: 'forgetPassword'
      }
    ]
  },
  {
    name: '修改密码',
    icon: '',
    path: 'user',
    children: [
      {
        name: '修改密码',
        path: 'changePassword'
      }
    ]
  },
  {
    name: '用户协议',
    icon: '',
    path: 'user',
    children: [
      {
        name: '用户协议',
        path: 'userAgreement'
      }
    ]
  },
  {
    name: '我的',
    icon: '',
    path: 'my',
    children: [
      {
        name: '充值',
        path: 'payAll'
      },
      {
        name: '提现',
        path: 'withdrawal'
      },
      {
        name: '提现记录',
        path: 'withdrawalRecord'
      },
      {
        name: '投注记录',
        path: 'bettingRecord'
      },
      {
        name: '账户明细',
        path: 'accountDatail'
      },
      {
        name: '追期管理',
        path: 'periodManage'
      },
      {
        name: '账户信息',
        path: 'accountInfo'
      },
      {
        name: '站内信息',
        path: 'webkitInfo'
      }
    ]
  }
]

function formatter (data, parentPath = '/', parentAuthority) {
  return data.map(item => {
    let { path } = item
    if (!isUrl(path)) {
      path = parentPath + item.path
    }
    const result = {
      ...item,
      path,
      authority: item.authority || parentAuthority
    }
    if (item.children) {
      result.children = formatter(
        item.children,
        `${parentPath}${item.path}/`,
        item.authority
      )
    }
    return result
  })
}

export const getMenuData = () => formatter(menuData)
