const urlMaps = {
  login: '/api/player/login/',
  logout: '/api/player/logout/',
  register: '/api/player/register/',
  setPassword: '/api/player/set_password/',
  getCode: '/api/player/send_auth_code/',
  forgetPassword: '/api/player/reset_password/',
  changePassword: '/api/player/change_password/',
  forgetPasswordValid: '/api/player/verify_auth_code/',
  changeNickname: '/api/player/set_nickname/',
  setIdentity: '/api/player/set_identity/',
  setMobile: '/api/player/set_mobile/',
  setPayPass: '/api/player/set_pay_password/',

  // 首页
  getHomeInfo: '/api/platform/home_page/',
  getLotteryInfo: '/api/lottery/staking_period',
  bet: '/api/stake',
  getUserWalletInfo: '/api/player/get_mine_info/',
  pay: '/api/wallet/pay_stake_order/',
  getOrderInfo: '/api/lottery/stake_order/',

  getTrend: '/api/crawler/trend/',
  getDrawInfo: '/api/platform/draw_info/',
  getLastDraw: '/api/lottery/draw_list/',

  // 我的
  getMyInfo: '/api/player/get_mine_info/',
  withdrawal: '/api/wallet/withdraw/',
  withdrawalIdentity: '',
  // withdrawalType: '/api/player/get_userinfo/',
  withdrawalRecord: '/api/wallet/withdraw_list/',
  getChaseRecordList: '/api/player/stakes_list/',
  getAccountDetailList: '/api/wallet/detail/',
  getPeriodManageList: '/api/player/chase_list/',
  getAccountInfo: '/api/player/get_user_info/',
  getWebkitInfoList: '/api/platform/system_message/',

  recharge: '/api/wallet/ccpay/charge/',
  checkRechargeStatus: '/wallet/ccpay/query/',
  upload: '/api/player/upload/',
  uploadQrcode: '/api/player/send_file/'
}

// export const baseUrl = 'http://share.axingxing.com/proxy'
export const baseUrl = ''

export const loginWhiteList = [urlMaps.getUserInfo, urlMaps.getBannerList]

export default urlMaps
