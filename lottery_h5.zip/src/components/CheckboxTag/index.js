import React, { Fragment } from 'react'

import { Tag, Modal } from 'antd-mobile'
import classnames from 'classnames'
import './index.less'

export default class CheckboxTag extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      tags: []
    }
  }
  componentWillReceiveProps (nextProps) {
    if (nextProps.data) {
      this.setState({
        tags: nextProps.data.map(item => {
          item.selected = item.selected || false
          return item
        })
      })
    }
  }
  hidePreview = () => {
    this.setState({
      previewVisible: false
    })
  }
  onChange = (itemData, bool, index) => {
    const selectedTags = this.state.tags.filter(item => item.selected)
    if (this.props.maxSelectedCount !== undefined) {
      if (selectedTags.length < this.props.maxSelectedCount) {
      } else {
        if (selectedTags.indexOf(itemData) !== -1) {
        } else {
          Modal.alert('提示', `最多选择${this.props.maxSelectedCount}个`)
          return
        }
      }
    }
    let tags = this.state.tags.map(item => {
      if (item.value === itemData.value) {
        item.selected = !item.selected
      }
      return item
    })

    this.setState(
      {
        tags: tags
      },
      () => {
        console.log(tags)
        this.props.onChange(
          itemData,
          this.state.tags.filter(item => item.selected),
          this.state.tags,
          index,
          this.setTagSelected
        )
      }
    )
  }
  setTagSelected = (tags, selected) => {
    const newTags = this.state.tags.map(item => {
      let isUpdate = false
      tags.forEach(itemData => {
        if (itemData.value === item.value) {
          isUpdate = true
        }
      })
      if (isUpdate) {
        item.selected = selected
      }
      return item
    })

    this.setState({
      tags: newTags
    })
  }
  render () {
    return (
      <span
        styleName='checkbox-tag'
        className={`checkbox-tag ${this.props.className}`}
      >
        {this.state.tags.map((item, index) => (
          <span
            key={item.value}
            selected={item.selected}
            onClick={bool => {
              this.onChange(item, bool, index)
            }}
            styleName='checkbox-tag-item'
            className={classnames({
              'checkbox-tag-item': true,
              active: item.selected
            })}
            style={this.props.itemStyle || {}}
          >
            {this.props.isShowValue &&
              <span className='value'>{item.value}</span>}
            {item.label}
          </span>
        ))}
      </span>
    )
  }
}
