import React from 'react'

import { ImagePicker, Icon, message } from 'antd-mobile'
import { connect } from 'dva'
import './index.less'

@connect(({ user, global }) => ({ user, global }))
export default class UploadImg extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      uploadUrl: '/api/v1/feedback/upload',
      loading: false,
      imgUrl: '',
      file: props.value || '',
      multiple: false
    }
  }
  componentWillReceiveProps (nextProps) {
    if ('value' in nextProps) {
      if (nextProps.value) {
        this.setState({
          file: nextProps.value
        })
      } else {
        this.setState({
          file: ''
        })
      }
    }
    if ('uploadUrl' in nextProps) {
      this.setState({
        uploadUrl: nextProps.uploadUrl
      })
    }
  }

  onChange = e => {
    const files = e.target.files
    this.upload(files[files.length - 1])
  }

  upload = file => {
    const formData = new FormData()
    formData.append('file', file)

    this.props.dispatch({
      type: 'global/upload',
      payload: formData,
      callback: res => {
        if (res.code === 200) {
          this.setState({
            file: res.payload.url
          })
          this.props.onChange && this.props.onChange(res.payload.url)
        }
      }
    })
  }

  render () {
    // const uploadButton = (
    //   <div>
    //     <Icon type={this.state.loading ? 'loading' : 'plus'} />
    //     <div className='ant-upload-text'>上传</div>
    //   </div>
    // )
    // <ImagePicker
    //   files={files}
    //   onChange={this.onChange}
    //   onImageClick={(index, fs) => console.log(index, fs)}
    //   onAddImageClick={(index, fs) => console.log(index, fs, 55555555)}
    //   selectable={false}
    // />
    return (
      <div
        style={{
          backgroundImage: `url(${this.state.file})`,
          backgroundSize: '100% 100%',
          backgroundRepeat: 'no-repeat'
        }}
        className='upload-btn'
        role='button'
        aria-label='Choose and add image'
      >
        <input type='file' onChange={this.onChange} accept='image/*' />
        {!this.state.file &&
          <div className='upload-label'>{this.props.label}请上传收款二维码</div>}
      </div>
    )
  }
}
