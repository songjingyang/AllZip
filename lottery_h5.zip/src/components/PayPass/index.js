import React, { Fragment } from 'react'
import { NavBar, Icon, Modal } from 'antd-mobile'
import './index.less'
export default class Index extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      num: [],
      num1: '',
      num2: '',
      num3: '',
      num4: ''
    }
  }
  componentWillReceiveProps (nextProps) {}
  onChange = (value, prop) => {
    this.setState({
      num: value.substring(0, 4).split('')
    })
  }
  onConfirm = () => {
    if (this.state.num.length < 4) {
      Modal.alert('提示', '请输入正确密码')
      return
    }
    this.props.onConfirm && this.props.onConfirm(this.state.num.join(''))
    this.props.onClose && this.props.onClose()
  }
  goBack = () => {
    this.props.onClose && this.props.onClose()
  }

  render () {
    return (
      <div styleName='pay-pass'>
        <NavBar
          mode='light'
          icon={<Icon type='left' />}
          onLeftClick={() => this.goBack()}
        >
          支付密码
        </NavBar>
        <div styleName='pass'>
          <span styleName='num' value={this.state.num1}>
            {this.state.num[0]}
          </span>
          <span styleName='num' value={this.state.num2}>
            {this.state.num[1]}
          </span>
          <span styleName='num' value={this.state.num3}>
            {this.state.num[2]}
          </span>
          <span styleName='num' value={this.state.num4}>
            {this.state.num[3]}
          </span>
          <input
            type='number'
            value={this.state.num.join('')}
            onChange={e => this.onChange(e.target.value)}
          />
        </div>
        <div styleName='confirm' onClick={this.onConfirm}>
          确定
        </div>
        <div styleName='tip'>设置支付密码，支付密码将保护您的账户安全</div>
      </div>
    )
  }
}
