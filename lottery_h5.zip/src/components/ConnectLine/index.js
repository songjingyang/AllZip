import React, { Fragment } from 'react'
// import Debounce from 'lodash-decorators/debounce'

import LINES from './html-lines'

import './index.less'

export default class ConnectLine extends React.Component {
  constructor (props) {
    super(props)
    this.lines = []
    this.state = { tags: [] }
  }
  componentWillReceiveProps (nextProps) {
    if (nextProps.elems) {
      setTimeout(() => {
        console.log(
          '​ConnectLine -> componentWillReceiveProps -> nextProps',
          nextProps
        )
        this.connect()
      }, 20)
    }
  }

  componentDidMount () {
    LINES.setOptions({
      container: document.querySelector(this.props.container)
    })

    // window.addEventListener('resize', this.reConnect)
    let container = document.querySelector(this.props.container)
    let xContainer = document.querySelector(this.props.xContainer)

    container.addEventListener('scroll', this.reConnect)
    xContainer.addEventListener('scroll', this.reConnect)
  }
  componentWillUnmount () {
    window.removeEventListener('resize', this.reConnect)
    let container = document.querySelector(this.props.container)
    let xContainer = document.querySelector(this.props.xContainer)

    container.removeEventListener('scroll', this.reConnect)
    xContainer.removeEventListener('scroll', this.reConnect)
    LINES.destroyAll()
  }

  // @Debounce(10)
  reConnect = () => {
    this.lines.forEach(function (line) {
      line.state('active')
    })
    LINES.redraw()
  }
  // @Debounce(400)
  connect = () => {
    let prevAnchor = null
    let num = 0
    let elems = document.querySelectorAll(this.props.elems)
    Array.prototype.slice.call(elems, 0).forEach(elem => {
      // if (num > 3) return
      num++
      let anchor = LINES.createAnchor({
        el: elem,
        // xOrigin: 'right',
        yOrigin: 'center'
      })
      if (prevAnchor) {
        // drawLine(prevAnchor, elem, 'red');
        let line = LINES.createLine(prevAnchor, anchor, {
          name: 'line' + num,
          state: 'active',
          bleed: true
        })
        this.lines.push(line)
      }
      prevAnchor = anchor
    })
  }

  render () {
    return <span />
  }
}
