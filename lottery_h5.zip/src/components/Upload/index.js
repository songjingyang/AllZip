import React from 'react'
import { ImagePicker, Icon } from 'antd-mobile'
export default class Upload extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      uploadUrl: '/api/v1/feedback/upload',
      loading: false,
      imgUrl: ''
    }
  }
  onChange = ({ file }) => {
    console.log('files', file)
    // this.setState({
    //   files,
    // });
  }
  onSegChange = e => {
    const index = e.nativeEvent.selectedSegmentIndex
    this.setState({
      multiple: index === 1
    })
  }
  render () {
    const { files } = this.state
    const uploadButton = (
      <div>
        <Icon type={this.state.loading ? 'cross' : 'check'} />
        <div className='ant-upload-text'>上传</div>
      </div>
    )
    return (
      <ImagePicker
        // files={files}
        // onChange={this.onChange}
        // onImageClick={(index, fs) => console.log(index, fs)}
        // selectable={files.length < 7}
        // multiple={this.state.multiple}
        {...this.props}
        name='file'
        listType='picture-card'
        // className='avatar-uploader'
        showUploadList={false}
        action={this.state.uploadUrl}
        beforeUpload={this.beforeUpload}
        onChange={this.onChange}
      >
        {this.state.imgUrl ? (
          <img
            src={this.state.imgUrl}
            alt='avatar'
            style={{ maxHeight: '150px' }}
          />
        ) : (
          uploadButton
        )}
      </ImagePicker>
    )
  }
}
