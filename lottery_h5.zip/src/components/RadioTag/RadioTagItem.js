import React, { Fragment } from 'react'

import { Tag } from 'antd-mobile'

export default class RadioTagItem extends React.Component {
  constructor (props) {
    super(props)
    this.state = {}
  }

  render () {
    return (
      <Tag {...this.props}>
        {this.props.children}
      </Tag>
    )
  }
}
