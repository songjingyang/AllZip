import React, { Fragment } from 'react'
import { Tag } from 'antd-mobile'
import classnames from 'classnames'
import './index.less'
export default class RadioTag extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      tags: props.data || []
    }
  }
  componentWillReceiveProps (nextProps) {
    if (nextProps.data) {
      this.setState({
        tags: nextProps.data.map(item => {
          item.selected = item.selected || false
          return item
        })
      })
    }
  }
  hidePreview = () => {
    this.setState({
      previewVisible: false
    })
  }
  onChange = (itemData, bool) => {
    let tags = this.state.tags.map(item => {
      if (item.value !== itemData.value) {
        item.selected = false
      } else {
        item.selected = true
      }
      return item
    })
    this.setState(
      {
        tags: tags
      },
      () => {
        // console.log(tags)
      }
    )
    this.props.onChange(itemData)
  }
  render () {
    return (
      <span styleName='radio-tag'>
        {this.state.tags.map(item => (
          <span
            key={item.value + item.label}
            selected={item.selected}
            onClick={bool => {
              this.onChange(item, bool)
            }}
            styleName='radio-tag-item'
            className={classnames({
              'radio-tag-item': true,
              active: item.selected
            })}
            style={this.props.itemStyle || {}}
          >
            {item.label}
          </span>
        ))}
      </span>
    )
  }
}
