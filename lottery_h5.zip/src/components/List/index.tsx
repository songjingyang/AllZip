import React, { Fragment } from 'react';
import { StickyContainer, Sticky } from 'react-sticky';
import {  ListView, List, SearchBar } from 'antd-mobile';
import pinyin from 'pinyin';


import './index.less';
import { Link } from 'react-router-dom';

interface Props {
  // history: History,
  className: string;
  listViewClassName: string;
  renderItem(item: any): React.ReactElement<any>;
  data: any[];
  keyMap: {
    label: string;
    value: string;
    spell?: string;
  }
}

interface State {
  inputValue: string;
  dataSource: any;
  isLoading: boolean;
  data: any[];
  targetMap: object;
}

function genData(ds: any, data: any) {
  const dataBlob: any = {};
  const sectionIDs: any = [];
  const rowIDs: any = [];
  Object.keys(data).forEach((item, index) => {
    sectionIDs.push(item);
    dataBlob[item] = item;
    rowIDs[index] = [];

    data[item].forEach((jj: any) => {
      rowIDs[index].push(jj.value);
      dataBlob[jj.value] = jj.label;
    });
  });
  return ds.cloneWithRowsAndSections(dataBlob, sectionIDs, rowIDs);
}


export default class Index extends React.Component<Props, State> {
  constructor(props: Props, context: any) {
    super(props, context);
    const getSectionData = (dataBlob: any, sectionID: any) =>
      dataBlob[sectionID];
    const getRowData = (dataBlob: any, sectionID: any, rowID: any) =>
      dataBlob[rowID];

    const dataSource = new ListView.DataSource({
      getRowData,
      getSectionHeaderData: getSectionData,
      rowHasChanged: (row1: any, row2: any) => row1 !== row2,
      sectionHeaderHasChanged: (s1: any, s2: any) => s1 !== s2,
    });

    this.state = {
      inputValue: '',
      dataSource,
      isLoading: true,
      data: [],
      targetMap: {},
    };
  }

  // static getDerivedStateFromProps
  static getDerivedStateFromProps(nextProps: Props, prevState: State){
    if(nextProps.data !== prevState.data){
      const newData = nextProps.data.map(item => {
        const label = item[nextProps.keyMap.label]
        const value = item[nextProps.keyMap.value]
        const spell = pinyin(label, { style: pinyin.STYLE_NORMAL }).join('')
        return {
          ...item,
          label,
          value,
          spell,
        }
      })
      const targetMap: any = {};
      newData.forEach((item: any) => {
        const firstChar = item.spell[0].toUpperCase();
        targetMap[firstChar] = targetMap[firstChar] || []
        targetMap[firstChar].push(item)
      })

				console.log('TCL: Index -> staticgetDerivedStateFromProps -> targetMap', targetMap)
      return {
        dataSource: genData(prevState.dataSource, targetMap),
        targetMap: targetMap,
        data: nextProps.data,
        isLoading: false,
      };
    }
    return null
  }

  componentDidMount() {
    console.log('this:', this.props)
  }

  onSearch = (val: string) => {
    const pd: any = { ...this.state.targetMap };
    Object.keys(pd).forEach((item: any) => {
      const arr = pd[item].filter(
        (jj: any) => jj.spell.toLocaleLowerCase().indexOf(val) > -1 || jj.label.indexOf(val) > -1
      );
      if (!arr.length) {
        delete pd[item];
      } else {
        pd[item] = arr;
      }
    });
		console.log('TCL: Index -> onSearch -> pd', pd)
    
    this.setState({
      inputValue: val,
      dataSource: genData(this.state.dataSource, pd),
    });
  };

  render() {
    return (
      <div className={this.props.className}>
        <div>
          <SearchBar
            value={this.state.inputValue}
            placeholder="搜索"
            onChange={this.onSearch}
            onClear={() => {
              console.log('onClear');
            }}
            onCancel={() => {
              console.log('onCancel');
            }}
          />
        </div>
        <ListView.IndexedList
          dataSource={this.state.dataSource}
          className={this.props.listViewClassName}
          // useBodyScroll
          renderSectionWrapper={sectionID => (
            <StickyContainer
              key={`s_${sectionID}_c`}
              className="sticky-container"
              style={{ zIndex: 4 }}
            />
          )}
          renderSectionHeader={sectionData => (
            <Sticky>
              {({ style }) => (
                <div
                  className="sticky"
                  style={{
                    // ...style,
                    // zIndex: 3,
                    backgroundColor: '#F4F4F4',
                  }}
                >
                  {sectionData}
                </div>
              )}
            </Sticky>
          )}
          renderHeader={() => (
            <div styleName="cate">
              <Link styleName="cate-item" to={{pathname: '/concat/newfriends'}}>新朋友</Link>
              <Link styleName="cate-item" to={{pathname: '/concat/groupchat'}}>群聊</Link>
              <Link styleName="cate-item" to={{pathname: '/concat/addfriends'}}>添加好友</Link>
            </div>
          )}
          // renderFooter={() => <span>custom footer</span>}
          renderRow={rowData => this.props.renderItem(rowData)}
          quickSearchBarStyle={{
            top: 185,
          }}
          delayTime={10}
          delayActivityIndicator={
            <div style={{ padding: 25, textAlign: 'center' }}>
              加载中...
            </div>
          }
        />
      </div>
    );
  }
}
