/*
 * @Author: daycool
 * @Date: 2018-08-24 14:36:27
 * @Last Modified by: 吾彦が一番美しい
 * @Last Modified time: 2019-01-17 11:10:07
 */
import React, { Fragment } from 'react'
import { ListView } from 'antd-mobile'
import './index.less'
export default class List extends React.Component {
  constructor (props) {
    super(props)
    const dataSource = new ListView.DataSource({
      rowHasChanged: (row1, row2) => row1 !== row2
    })
    this.state = {
      dataSource,
      pagination: {
        page: 1,
        page_size: 20,
        total: 0
      },
      ...this.initState
    }
    this.url = ''
    this.keys = []
    this.params = {}
  }
  getKeysValue = data => {
    let newData = data
    this.keys.forEach(item => {
      newData = newData[item]
    })
    return newData
  }
  componentDidMount () {
    this.getData()
  }
  componentWillReceiveProps (nextProps) {
    if (this.getKeysValue(nextProps) !== this.getKeysValue(this.props)) {
      this.rData = {
        ...(this.rData || {}),
        ...this.genData()
      }
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(this.rData)
      })
    }
  }
  onEndReached = event => {
    if (this.props.loading) {
      return
    }
    if (
      this.getKeysValue(this.props).total <
      this.state.pagination.page * this.state.pagination.page_size
    ) {
      return
    }
    this.setState(
      {
        pagination: {
          ...this.state.pagination,
          page: this.state.pagination.page + 1
        }
      },
      () => {
        this.getData()
      }
    )
  }
  getData () {
    const reqData = {
      ...this.params,
      ...this.state.pagination
    }
    if (this.state.pagination.page === 1) {
      reqData.ts = 1
    }
    this.props.dispatch({
      type: this.url,
      payload: {
        ...reqData
      },
      callback: res => {
        if (res.code === 200) {
        }
      }
    })
  }
  genData = () => {
    const pagination = this.state.pagination
    const page_size = pagination.page_size
    const page = pagination.page
    const dataBlob = {}

    for (let i = 0; i < page_size; i++) {
      const ii = (page - 1) * page_size + i
      dataBlob[`${ii}`] = `row - ${ii}`
    }
    return dataBlob
  }

  renderListItem = list => {
    let index = 0

    const row = (rowData, sectionID, rowID) => {
      const item = list[index++]
      return <div>请实现item方法</div>
    }
    return row
  }

  renderList = () => {
    const list = this.getKeysValue(this.props).list
    return (
      <ListView
        ref={el => (this.lv = el)}
        dataSource={this.state.dataSource}
        // renderHeader={() => <span>header</span>}
        renderFooter={() => (
          <div styleName={'footer-loading'}>
            {this.props.loading ? '加载中...' : '加载完成'}
          </div>
        )}
        renderRow={this.renderListItem(list)}
        // renderSeparator={separator}
        className='am-list'
        initialListSize={20}
        page_size={4}
        useBodyScroll
        onScroll={() => {
          // console.log('scroll')
        }}
        scrollRenderAheadDistance={500}
        onEndReached={this.onEndReached}
        onEndReachedThreshold={10}
      />
    )
  }

  render () {
    return <div>请实现这个方法</div>
  }
}
