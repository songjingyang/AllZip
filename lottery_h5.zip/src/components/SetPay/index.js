import React, { Fragment } from 'react'
import { NavBar, Icon, Modal } from 'antd-mobile'
import { connect } from 'dva'
import { createForm } from 'rc-form'
import './index.less'
import PayPass from '../../components/PayPass/index'
import SetMobile from '../../modules/User/SetMobile'
import ValidMobile from '../../modules/User/ValidMobile'
@createForm()
@connect(({ user }) => ({ user }))
export default class Index extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isSetMobile: false,
      isShowPass: false,
      pass: '',
      isShowConfirmPass: false,
      confirmPass: '',
      isValidMobile: false,
      validPass: '',
    }
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'my/getMyInfo',
      payload: {},
      callback: res => {
        if (res.code === 200) {
          const myInfo = res.payload
          if (myInfo.is_mobile_set === 1) {
            this.setState({
              isSetMobile: true,
            })
          } else if (myInfo.is_pay_pswd_set === 1) {
            this.setState({
              isShowPass: true,
            })
          }
        }
      },
    })
  }
  componentWillReceiveProps(nextProps) {}
  onChange = (value, prop) => {}
  onConfirm = () => {}
  onClose = () => {
    this.props.onClose && this.props.onClose()
  }
  render() {
    return (
      <div styleName="set-pass">
        {this.state.isSetMobile && (
          <SetMobile
            onConfirm={value => {
              this.setState({ isSetMobile: false })
              this.setState({ isShowPass: true })
            }}
            onClose={() => {
              this.setState({ isSetMobile: false })
              this.onClose()
            }}
          />
        )}
        {this.state.isShowPass && (
          <PayPass
            onConfirm={value => {
              this.setState(
                { pass: value, isShowConfirmPass: true, isSetMobile: false },
                () => {
                  // this.handleSubmit()
                }
              )
            }}
            onClose={() => this.setState({ isShowPass: false })}
          />
        )}
        {this.state.isShowConfirmPass && (
          <PayPass
            onConfirm={value => {
              this.setState(
                {
                  confirmPass: value,
                  isShowConfirmPass: false,
                  isValidMobile: true,
                },
                () => {
                  if (this.state.pass !== this.state.confirmPass) {
                    Modal.alert('提示', '两次输入密码不一致请重新输入')
                    this.setState({ isShowPass: true, isValidMobile: false })
                  }
                }
              )
            }}
            onClose={() => this.setState({ isShowConfirmPass: false })}
          />
        )}
        {this.state.isValidMobile && (
          <ValidMobile
            pass={this.state.pass}
            onConfirm={value => {
              this.props.onFinish()
            }}
            onClose={() => this.setState({ isValidMobile: false })}
          />
        )}
      </div>
    )
  }
}
