
项目名：支付运营后台管理系统，git仓库地址：http://223.203.221.87:8088/qianmingwei/lottery-h5 。本项目第一负责人为 `钱明卫`。


## 安装node, git， 

 - node版本 `v8.11.3`
- 更换为淘宝源

`npm config set registry https://registry.npm.taobao.org `


### 开发环境配置

vscode

## 开发

- mockData模式
`npm run start:mock`
## 联调

- 真接口模式
`npm start`

## 打包

`npm build`

- 打包并上传服务器，请务必配置正确服务器目标地址
`build:product`

- 修改服务器目标地址config/deploy.js

` deployTo: '/home/share/lottery-h5/',`
## 单独部署
`npm run deploy`

## 打tag 生成changelog
`npm run changelog`

## 打tag
`git tag`  查看tag
`git tag v0.1.1` 添加tag
`git push origin tag v0.1.1`  推送tag


####  代理配置

本地代理：
-   package.json  proxy: http://127.0.0.1/


`Fiddler` 线上代理：

- `regex:^https?:\/\/xx\.com/(.*\.map.*)$` `d:/my/build/$1`
  代理静态资源访问本地map。使用说明https://blog.csdn.net/hahavslinb/article/details/78791219


### 发布

| 发布产品 | 发布模块 |
| --- | --- |
| `[xxx]` | `[xxx]` |

> 发布时的备注

### 错误告警及监控
使用sentry错误日志上报http://223.203.221.89:9000/sentry/lottery-h5/


### 相关人员

| 角色 | 人员 |
| --- | --- |
| 产品经理 | 老宋 |
| 前端开发 | 钱明卫，吴宇 |
| 后台开发 | 腾飞 |
| 交互设计 | 刘曦 |
| ui设计 | 段占涛 |


### 其他

- [原型](https://pro.modao.cc/app/YJsMPJK0elHDuK4U68xzRuS7PTyOkO7?#screen=s0AC6994AE01537166098686)
- [ui](https://pro.modao.cc/app/d7334f4efc86cf137ea25ff9ef78c871c86c83b5?#screen=sa6e15ba8f3153545227700)
- [ui蓝湖切图用这个](https://lanhuapp.com/web/#/item/board?pid=52d3c42a-7e97-42a7-a867-ea22908c9452)
- [接口文档](http://223.203.221.49:3100/project/14/interface/api)



> 项目备注
