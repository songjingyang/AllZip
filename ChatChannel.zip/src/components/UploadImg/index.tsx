import React from 'react'

import { Upload, Icon } from 'antd'
// import './index.less'
import { string } from 'prop-types';
import { inject, observer } from 'mobx-react';
// import Global from '../../models/Global';

interface Props {
  value: string;
  label: string;
  onChange?(url: string): void;
  onUpload(formData: any): string | Promise<any>;
}
interface State {
  uploadUrl: string;
  loading: boolean;
  imgUrl: string;
  file: string;
  multiple: boolean;
}
@observer
export default class UploadImg extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = {
      uploadUrl: '/upload/images',
      loading: false,
      imgUrl: '',
      file: props.value || '',
      multiple: false
    }
  }
  componentDidMount() {

  }
  static getDerivedStateFromProps(nextProps: any, prevState: any) {
    console.log(
      'TCL: Upload -> staticgetDerivedStateFromProps -> nextProps, prevState',
      nextProps,
      prevState
    )
    const state: {
      file?: string;
      uploadUrl?: string;
    } = {}

    if (nextProps.value !== prevState.file) {
      state.file = nextProps.value;
    }

    if (nextProps.uploadUrl !== prevState.file) {
      state.uploadUrl = nextProps.uploadUrl;
    }

    if (state.file || state.uploadUrl) {
      return state
    }

    return null;
  }

  // componentWillReceiveProps (nextProps: any) {
  //   if ('value' in nextProps) {
  //     if (nextProps.value) {
  //       this.setState({
  //         file: nextProps.value
  //       })
  //     } else {
  //       this.setState({
  //         file: ''
  //       })
  //     }
  //   }
  //   if ('uploadUrl' in nextProps) {
  //     this.setState({
  //       uploadUrl: nextProps.uploadUrl
  //     })
  //   }
  // }

  onChange = (e: any) => {
    const files = e.target.files
    this.upload(files[files.length - 1])

  }

  upload = async (file: File) => {
    console.log('TCL: upload -> File', File)
    const formData = new FormData()
    formData.append('file', file)
    const url = await this.props.onUpload(formData);
    if (url) {
      this.setState({ file: url });
      this.props.onChange && this.props.onChange(url);
    }
  }

  render() {
    console.log('uploading:', this.state.file);
    return (
      <div
        className='upload-btn'
        role='button'
      >
        <input type='file' onChange={this.onChange} accept='image/*' />
        {!this.state.file && (
          <div className='upload-label'>{this.props.label}</div>
        )}
       {this.state.file&& <img src={this.state.file} alt="Loading..." />}
      </div>
    )
  }
}
