import React from 'react';
import { Upload, Icon, message } from 'antd';
import { inject, observer } from 'mobx-react';
import { string, any } from 'prop-types';
interface Props {
  // value: string;
  // label: string;
  // onChange?(url: string): void;
  // onUpload(formData: any): string | Promise<any>;
}
interface State {
  // uploadUrl: string;
  // loading: boolean;
  // imgUrl: string;
  // file: any;
}
export default class UploadImg extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = {
      // uploadUrl: '/api/channeles/Uploadfile/index',
      // loading: false,
      // imgUrl: '',
      // file: string,
    };
  }
  // componentWillReceiveProps(nextProps:any) {
  //   console.log('nextProps', nextProps);
  //   if ('value' in nextProps) {
  //     this.setState({
  //       imgUrl: nextProps.value,
  //     });
  //   }
  //   if ('uploadUrl' in nextProps) {
  //     this.setState({
  //       uploadUrl: nextProps.uploadUrl,
  //     });
  //   }
  // }
  //  beforeUpload=(file:any)=> {
  //    this.setState({
  //      file: this.state.file,
  //    });
  // }
  // handleChange = ({ file:any }) => {
  //   console.log(7897987987, file);
  //   if (file.status === 'uploading') {
  //     this.setState({ loading: true });
  //     return;
  //   }
  //   if (file.status === 'done') {
  //     // Get this url from response in real world.
  //     if (file.response[0].code == 200) {
  //       const imgUrl = file.response[0].img_url_es;
  //       const baseUrl =
  //         window.location.protocol + '//' + document.domain + '/api';

  //       this.setState(
  //         {
  //           // imgUrl: "http://channel.669lottery.com/api/" + imgUrl,
  //           imgUrl: baseUrl + imgUrl,
  //           loading: false,
  //         },
  //         () => {
  //           this.props.onChange(baseUrl + imgUrl);
  //         }
  //       );
  //     }

  //     // getBase64(file.originFileObj, imgUrl =>
  //     //   this.setState(
  //     //     {
  //     //       imgUrl,
  //     //       loading: false
  //     //     },
  //     //     () => {
  //     //       this.props.onChange(imgUrl)
  //     //     }
  //     //   )
  //     // )
  //   }
  // };

  
  render() {
    const uploadButton = (
      <div>
        <Icon
         type={
          //  this.state.loading 
          0 ? 'loading' : 'plus'} 
         />
        <div className="ant-upload-text">上传</div>
      </div>
    );
    // console.log('channle', this.state.imgUrl);
    return (
      <Upload
        {...this.props}
        name="upload_file0"
        listType="picture-card"
        className="avatar-uploader"
        showUploadList={false}
        // action={this.state.uploadUrl}
        // beforeUpload={this.beforeUpload}
        // onChange={this.handleChange}
      >
        {
          // this.state.imgUrl
          0 ? (
          <img
            // src={this.state.imgUrl}
            src="https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3039807029,4092165540&fm=58&bpow=256&bpoh=256"
            alt="avatar"
            style={{ maxHeight: '150px' }}
          />
        ) : (
            uploadButton
          )}
      </Upload>
    );
  }
}