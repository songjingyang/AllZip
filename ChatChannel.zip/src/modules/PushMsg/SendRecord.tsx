import React from 'react'
import { Link } from 'react-router-dom';
import { History } from 'history';
import { match } from 'react-router';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Popconfirm,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Checkbox,
  Tabs 
} from 'antd'
import moment from 'moment'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const CheckboxGroup = Checkbox.Group
const RadioGroup = Radio.Group
const { TextArea } = Input
const TabPane = Tabs.TabPane;
interface Props extends FormComponentProps {
  form: WrappedFormUtils,

}

interface State {
  columns: any,

}
@Form.create()
export default class SendRecord extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {
      columns: [
        {
          title: '发送内容',
          dataIndex: 'today_add_user',
        },
        {
          title: '发送时间',
          dataIndex: 'created',
        },
        {
          title: '发送数量',
          dataIndex: 'yesterday_add_user',
        },
        {
          title: '送达数量',
          dataIndex: 'yesterday_active_user',
        },
        {
          title: '发送账号',
          dataIndex: 'yesterday_prize_win',
        },
        
      ],
    }
  }
  handleSubmit = (e: KeyboardEvent) => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('values :', values);
      }
    })
  }
  render() {
    const { getFieldDecorator } = this.props.form
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    }
    const list = [{
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=816022733,2864533631&fm=58&s=6B318A461B73081709D11A970300D094&bpow=121&bpoh=75",
      real_name: "",
      status: 2,
      today_active_user: 4123,
      today_add_user: "大狗打二狗",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 895,
      yesterday_active_user: 2,
      yesterday_add_user: 211,
      yesterday_best_gold: 0,
      yesterday_prize_win: "A,B",
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
    {
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=830518863,2608787117&fm=58&s=45F6AC720C61BB112F2A5CEE0300E02B&bpow=121&bpoh=75",
      real_name: "",
      status: 2,
      today_active_user: 7841,
      today_add_user: "二狗打三狗",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 7844.5,
      yesterday_active_user: 1,
      yesterday_add_user: 985,
      yesterday_best_gold: 0,
      yesterday_prize_win: 'C',
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
    {
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss1.baidu.com/70cFfyinKgQFm2e88IuM_a/forum/pic/item/7a899e510fb30f24d4d19dd2c595d143ac4b0393.jpg",
      real_name: "",
      status: 2,
      today_active_user: 1256,
      today_add_user: "三狗打四狗",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 100.8,
      yesterday_active_user: 3,
      yesterday_add_user:81,
      yesterday_best_gold: 0,
      yesterday_prize_win: 'D,E,F',
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
    {
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3039807029,4092165540&fm=58&bpow=256&bpoh=256",
      real_name: "",
      status: 2,
      today_active_user: 8532,
      today_add_user: "四狗挨打",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 741.1,
      yesterday_active_user: 8,
      yesterday_add_user: 79,
      yesterday_best_gold: 0,
      yesterday_prize_win: 'Q,W,E,R,T,Y,U,I',
      yesterday_start_up: "停用",
      created: "2019/02/14"
    }
    ]
    return (
      <Card bordered={false} title={'发送记录'}>
        <div className="tableList">
          <Table
            columns={this.state.columns}
            // rowKey={record=> record.id}
            dataSource={list}
            pagination={false}
          // onChange={this.handleTableChange}
          />
        </div>
      </Card>
    )
  }
}
