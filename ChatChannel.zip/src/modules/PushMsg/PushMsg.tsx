import React from 'react'
import { Link } from 'react-router-dom';
import { History } from 'history';
import { match } from 'react-router';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Popconfirm,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Checkbox,
  Tabs,
  Avatar

} from 'antd'
import moment from 'moment'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const CheckboxGroup = Checkbox.Group
const RadioGroup = Radio.Group
const { TextArea } = Input
const TabPane = Tabs.TabPane;
const defaultCheckedList = ['Apple', 'Orange'];
interface Props extends FormComponentProps {
  form: WrappedFormUtils,

}

interface State {
  columns: any,
  plainOptions: any,
  checkedList: any,
  indeterminate: boolean,
  checkAll: boolean
}
@Form.create()
export default class PushMsg extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {
      plainOptions: ['Pear', 'Orange', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
      checkedList: ['Orange', 'A'],
      indeterminate: true,
      checkAll: false,
      columns: [
        {
          title: '发送内容',
          dataIndex: 'nickname',
        },
        {
          title: '发送时间',
          dataIndex: 'today_add_user',
        },
        {
          title: '发送数量',
          dataIndex: 'yesterday_add_user',
        },
        {
          title: '送达数量',
          dataIndex: 'today_active_user',
        },
        {
          title: '发送账号',
          dataIndex: 'yesterday_active_user',
        },

      ],
    }
  }
  handleSubmit = (e: KeyboardEvent) => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('values :', values);
      }
    })
  }
  onChange = (checkedList: any) => {
    this.setState({
      checkedList,
      indeterminate: !!checkedList.length && (checkedList.length < this.state.plainOptions.length),
      checkAll: checkedList.length === this.state.plainOptions.length,
    });
  }

  onCheckAllChange = (e: any) => {
    this.setState({
      checkedList: e.target.checked ? this.state.plainOptions : [],
      indeterminate: false,
      checkAll: e.target.checked,
    });
  }
  Submit = (e: any) => {
    message.success('发送成功')
  }
  render() {
    const { getFieldDecorator } = this.props.form
    const formItemLayout = {
      labelCol: { span: 2 },
      wrapperCol: { span: 14, offset:1},
    }
    return (
      <Card bordered={false} title={'推送消息'}>
        {/* <Col xl={4} md={24} sm={24}>
          <Link to={{ pathname: '/pushmsg/sendrecord' }}>发送记录</Link>
        </Col>  */}
        <div className="tableList">
          <Form>
          <Tabs defaultActiveKey="1"

          // onChange={callback}
          >
            <TabPane tab="选择接收者" key="1">
           
                <Row gutter={{ xs: 8, sm: 16, md: 24 }} style={{ paddingBottom: "20px" }}>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label="搜索成员" {...formItemLayout} >
                      {getFieldDecorator('qwe')(
                        <Input />
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={24} md={24} sm={24}>
                    <FormItem label="" >
                      {getFieldDecorator('name')(
                        <div>
                          <div style={{ borderBottom: '1px solid #E9E9E9' }}>
                            <Checkbox
                              indeterminate={this.state.indeterminate}
                              onChange={this.onCheckAllChange}
                              checked={this.state.checkAll}
                            >
                              全选
                          </Checkbox>
                          </div>
                          <br />
                          <CheckboxGroup
                            options={['Pear', 'Orange', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']}
                            value={this.state.checkedList}
                            onChange={this.onChange}
                          />
                        </div>
                      )}
                    </FormItem>
                  </Col>
                </Row>
          
            </TabPane>
            <TabPane tab="发送内容" key="2">
              <Row gutter={{ xs: 8, sm: 16, md: 24 }} style={{ paddingBottom: "20px" }}>

                <Col xl={24} md={24} sm={24}>
                  <FormItem label="" >
                    {getFieldDecorator('1')(
                      <TextArea rows={4} />
                    )}
                  </FormItem>
                </Col>
              </Row>

            </TabPane>
          </Tabs>

          <div className='submitButtons'>
            <Button type="primary" htmlType="submit" onClick={this.Submit}>
              发送
            </Button>
          </div>
          </Form>
        </div>
            
      </Card>
    )
  }
}