import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Popconfirm,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Transfer
} from 'antd'
import moment from 'moment'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const { TextArea } = Input

interface Props {

}

interface State {
  targetKeys:any;
  mockData:any;
}
// @Form.create()

export default class CreateCharRoom extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {
      mockData: [],
      targetKeys: [],
    }
  }
  componentDidMount() {
    this.getMock();
  }

  getMock = () => {
    const targetKeys = [];
    const mockData = [];
    for (let i = 0; i < 20; i++) {
      const data = {
        key: i.toString(),
        title: <div style={{display: 'inline-block', width: '25px', height: '25px'}}>
          <img style={{width: '100%'}} src='https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2801675522,4203732689&fm=26&gp=0.jpg'/>
          {`content${i + 1}`}
          </div>,
        description: `description of content${i + 1}`,
        chosen: Math.random() * 2 > 1,
      };
      if (data.chosen) {
        targetKeys.push(data.key);
      }
      mockData.push(data);
    }
    this.setState({ mockData, targetKeys });
  }

  filterOption = (inputValue:any, option:any) => option.description.indexOf(inputValue) > -1

  handleChange = (targetKeys:any) => {
    this.setState({ targetKeys });
  }

  handleSearch = (dir:any, value:any) => {
    console.log('search:', dir, value);
  };
  render() {
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    }
    
    return (
      
      <Card   bordered={false} title={'创建聊天室'}>
        <Form>
        <Row gutter={{ xs: 8, sm: 16, md: 24 }}>
          <Col xl={24} md={24} sm={24}>
            <FormItem label="聊天室名称" {...formItemLayout} className="form-inline-item">
              {/* {getFieldDecorator('app')(
                <Input />
              )} */}
              <Input />
            </FormItem>
          </Col>
          <Col xl={24} md={24} sm={24}>
              <FormItem label="成员操作"   {...formItemLayout} className="form-inline-item">
              <Transfer
                className="atob"
                titles={['用户列表', '聊天室成员']}
                dataSource={this.state.mockData}
                showSearch
                filterOption={this.filterOption}
                targetKeys={this.state.targetKeys}
                onChange={this.handleChange}
                onSearch={this.handleSearch}
                render={(item:any) => item.title}
              />
            </FormItem>
          </Col>
          <Col xl={12} md={24} sm={24} offset={6}>
            <div className='submitButtons'>
              <Button type="primary" htmlType="submit" className='listsearch'>
                确定
                </Button>
            </div>
          </Col>
        </Row>
        </Form>
      </Card>
    )
  }
}
