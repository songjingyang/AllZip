import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Popconfirm,
  Row,
  Col,
  Modal,
  message,
  Divider
} from 'antd'
import classNames from 'classnames'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
// import SwitchConfirm from '@/components/SwitchConfirm'
// import { dateFormater } from '@/utils/utils'
// import UploadImg from '@/components/UploadImg'
// import { inject } from 'mobx-react';
// import './Dashed.css'
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const RangePicker = DatePicker.RangePicker
interface Props extends FormComponentProps {
  form: WrappedFormUtils
}

interface State {
  columns: any,
  isAddApp: boolean,
}
@Form.create()
// @inject('dashed')
export default class Account extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {
      isAddApp: false,
      columns: [
        {
          title: '操作人',
          dataIndex: 'nickname',
        },
        {
          title: '操作模块',
          dataIndex: 'today_add_user',
        },
        {
          title: '操作内容',
          dataIndex: 'yesterday_add_user',
        },
        {
          title: '操作时间',
          dataIndex: 'yesterday_start_up',
        },
 
      ],
    }
  }
  componentDidMount() {
    // this.getDashedInfo()
  }

  AddApp = (e: any) => {
 
    // this.setState({
    //   currItem: item,
    // })
  }
 
  render() {
    // const global = this.props.global
    // const info = this.props.dashed.DashedInfo
    return (
      <Card title="账号操作记录">
        <div className="tableList">
          <Form >
            <Row
              gutter={{ md: 8, lg: 24, xl: 48 }}
              style={{ marginTop: '20px' }}
            >
              <Col xl={24} md={24} sm={24}>
                <FormItem label="搜索账号" className="form-inline-item">
                  {/* {getFieldDecorator('name')(
                    <Input />
                  )} */}
                  <Input />
                </FormItem>
              </Col>
              <Col xl={24} md={24} sm={24}>
                <div className='submitButtons'>
                  <Button type="primary" htmlType="submit" className='listsearch'>
                    查询
                  </Button>
                </div>
              </Col>
            </Row>
          </Form>
          <Table
            columns={this.state.columns}
            // rowKey={record=> record.id}
            dataSource={[{
              account: "qudaozu2",
              capital: "Q",
              created: 1548331766175,
              id: "5c49aaf69dc6d6354f44ad9e",
              nickname: "渠道组二",
              real_name: "",
              status: 2,
              today_active_user: 0,
              today_add_user: 0,
              today_best_gold: 0,
              today_prize_win: 0,
              today_start_up: 0,
              yesterday_active_user: 0,
              yesterday_add_user: 0,
              yesterday_best_gold: 0,
              yesterday_prize_win: 0,
              yesterday_start_up: 0
            }]}
            pagination={false}
          // onChange={this.handleTableChange}
          />
        </div>
      </Card>
    )
  }
}
