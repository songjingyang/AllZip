import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Row,
  Col,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Card,
  Tree,
  DatePicker,
  message,
} from 'antd'
import moment from 'moment'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
import UploadImg from '../../components/UploadImg';
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const { TreeNode } = Tree;
const { TextArea } = Input
interface Props {
  // form: WrappedFormUtils,


}

interface State {

}
@Form.create()
export default class AddApp extends React.Component<Props, State>{
  upload = async (formData: any) => {
    // const url = await this.props.global.upload(formData)
    // this.props.my.saveUpdateInfo({
    //   data: {
    //     nickname: this.props.my.myInfo.nickname,
    //     avatar: url
    //   },
    //   callback: res => {
    //     if (res.code === '1') {
    //       this.props.my.getMyInfo({
    //         data: {
    //         },
    //         //   callback:res=>{
    //         //     if (res.code === '1') {
    //         //      Toast.success(
    //         //     '上传成功',
    //         //     2,
    //         //     (onclose = () => {
    //         //       this.props.history.goBack()
    //         //     })
    //         // );}
    //         //   }
    //       })

    //     }
    //   }
    // },
    // )
    // return url;
  }
  onSelect = (selectedKeys:any, info:any) => {
    console.log('selected', selectedKeys, info);
  }

  onCheck = (checkedKeys:any, info:any) => {
    console.log('onCheck', checkedKeys, info);
  }
  render() {
    // const { getFieldDecorator } = this.props.form
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    }
    return (
      <Card bordered={false} title={'创建角色'} className='addApp'>
        <Row gutter={{ xs: 8, sm: 16, md: 24 }} >
          <Col xl={24} md={24} sm={24} offset={4} >
            <FormItem label="角色名称" className="form-inline-item">
              {/* {getFieldDecorator('name')(
                <Input />
              )} */}
              <Input />
            </FormItem>
          </Col>
          <Col xl={24} md={24} sm={24} offset={4}>
            <FormItem label="别名" className="form-inline-item">
              <Input />
            </FormItem>
          </Col>
          <Col xl={24} md={24} sm={24} offset={4} >
            <FormItem label="权限" >
              <Tree
                checkable
                defaultExpandedKeys={['0-0-0', '0-0-1']}
                defaultSelectedKeys={['0-0-0', '0-0-1']}
                defaultCheckedKeys={['0-0-0', '0-0-1']}
                onSelect={this.onSelect}
                onCheck={this.onCheck}
              >
                <TreeNode title="parent 1" key="0-0">
                  <TreeNode title="parent 1-0" key="0-0-0" disabled>
                    <TreeNode title="leaf" key="0-0-0-0" disableCheckbox />
                    <TreeNode title="leaf" key="0-0-0-1" />
                  </TreeNode>
                  <TreeNode title="parent 1-1" key="0-0-1">
                    <TreeNode title={<span style={{ color: '#1890ff' }}>sss</span>} key="0-0-1-0" />
                  </TreeNode>
                </TreeNode>
              </Tree>
            </FormItem>
          </Col>
          <Col xl={12} md={24} sm={24} offset={4}>
            <div className='submitButtons'>
              <Button type="primary" htmlType="submit" className='listsearch'>
                确定
              </Button>
            </div>
          </Col>
        </Row>
      </Card>
    )
  }
}
