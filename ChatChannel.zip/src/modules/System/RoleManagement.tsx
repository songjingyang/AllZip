import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Popconfirm,
  Row,
  Col,
  Modal,
  message,
  Divider
} from 'antd'
import classNames from 'classnames'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
import AddRole from './AddRole'
// import SwitchConfirm from '@/components/SwitchConfirm'
// import { dateFormater } from '@/utils/utils'
// import UploadImg from '@/components/UploadImg'
// import { inject } from 'mobx-react';
// import './Dashed.css'
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const RangePicker = DatePicker.RangePicker
interface Props extends FormComponentProps {
  form: WrappedFormUtils
}

interface State {
  columns: any,
  isAddRole: boolean,
}
@Form.create()
// @inject('dashed')
export default class RoleManagement extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {
      isAddRole: false,
      columns: [
        {
          title: '角色名称',
          dataIndex: 'nickname',
        },
        {
          title: '别名',
          dataIndex: 'today_add_user',
        },
        {
          title: '状态',
          dataIndex: 'yesterday_add_user',
        },
        {
          title: '操作',
          dataIndex: 'play',
          render: (text: any, record: any) => (
            <span>
              {/* <SwitchConfirm
                title="确认操作吗？"
                // onConfirm={() => this.getPlayerStatus(record)}
                checkedChildren="启动"
                unCheckedChildren="禁用"
                // checked={[record.status] == 3}
                style={{ marginRight: 16, marginTop: -5 }}
              /> */}
              <Switch defaultChecked onChange={this.onChange} />
              <Divider type="vertical" />
              <a onClick={() => this.AddRole(record)} href="javascript:;">
                编辑角色
              </a>
            </span>
          ),
        },
      ],
    }
  }
  componentDidMount() {
    // this.getDashedInfo()
  }
  onChange = () => {
    console.log('开关 :');
  }
  isAddRole = (bool: boolean) => {
    this.setState({
      isAddRole: bool,
    })
  }
  AddRole = (item: any) => {
    this.isAddRole(true)
    // this.setState({
    //   currItem: item,
    // })
  }
  AddRoleInfo = () => {
    this.isAddRole(false)
    // this.saveOpenManagementInfo()
  }
  render() {
    // const global = this.props.global
    // const info = this.props.dashed.DashedInfo
    return (
      <Card title="角色管理">
        {this.state.isAddRole && (
          <Modal
            visible={this.state.isAddRole}
            width={700}
            onCancel={() => this.isAddRole(false)}
            footer={null}
          >
            <AddRole
            // data={this.state.currItem}
            // onClose={() => {
            //   this.isCreateCharRoom(false)
            //   // this.saveOpenManagementInfo({
            //   //   pageSize: this.state.pagination.pageSize,
            //   //   page: this.state.pagination.current,
            //   // })
            // }}
            />
          </Modal>
        )}
        <div className="tableList">
          <Form >
            <Row
              gutter={{ md: 8, lg: 24, xl: 48 }}
              style={{ marginTop: '20px' }}
            >
              <Col span={24}>
                <Button
                  onClick={this.AddRole}
                  style={{ height: "32px", width: "128px", fontSize: '14px', lineHeight: "32px", marginBottom: '10px' }}
                  type="primary"
                  htmlType="button"
                >
                  创建角色
                    </Button>
              </Col>
            </Row>
          </Form>
          <Table
            columns={this.state.columns}
            // rowKey={record=> record.id}
            dataSource={[{
              account: "qudaozu2",
              capital: "Q",
              created: 1548331766175,
              id: "5c49aaf69dc6d6354f44ad9e",
              nickname: "渠道组二",
              real_name: "",
              status: 2,
              today_active_user: 0,
              today_add_user: 0,
              today_best_gold: 0,
              today_prize_win: 0,
              today_start_up: 0,
              yesterday_active_user: 0,
              yesterday_add_user: 0,
              yesterday_best_gold: 0,
              yesterday_prize_win: 0,
              yesterday_start_up: 0
            }]}
            pagination={false}
          // onChange={this.handleTableChange}
          />
        </div>
      </Card>
    )
  }
}
