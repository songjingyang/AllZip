import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Statistic
} from 'antd'
import classNames from 'classnames'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
// import { dateFormater } from '@/utils/utils'
import PreviewImg from '../../components/PreviewImg'
// import { inject } from 'mobx-react';
// import './Dashed.css'
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const RangePicker = DatePicker.RangePicker
interface Props extends FormComponentProps {
  form: WrappedFormUtils
}

interface State {
columns:any
}
@Form.create()
// @inject('dashed')
export default class Login extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {
      columns: [
        {
          title: '图标',
          dataIndex: 'nickname',
          render:(text:any)=>
            <PreviewImg src={text} alt="" />
          
        },
        {
          title: '名称',
          dataIndex: 'today_add_user',
        },
        {
          title: '昨日新增用户(人)',
          dataIndex: 'yesterday_add_user',
        },  
        {
          title: '累计用户(人)',
          dataIndex: 'today_active_user',
        },
        {
          title: '昨日活跃用户(人)',
          dataIndex: 'yesterday_active_user',
        },
        {
          title: '昨日消耗流量（K）',
          dataIndex: 'today_start_up',
        },
        {
          title: '状态',
          dataIndex: 'yesterday_start_up',
        },
        {
          title: '创建时间',
          dataIndex: 'created',
        },
      ],
    }
  }
  componentDidMount() {
    // this.getDashedInfo()
  }
  render() {
    // const global = this.props.global
    // const info = this.props.dashed.DashedInfo
    const list = [{
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=816022733,2864533631&fm=58&s=6B318A461B73081709D11A970300D094&bpow=121&bpoh=75",
      real_name: "",
      status: 2,
      today_active_user: 4123,
      today_add_user: "陌陌",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 895,
      yesterday_active_user:532,
      yesterday_add_user: 100,
      yesterday_best_gold: 0,
      yesterday_prize_win: 0,
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
      {
        account: "qudaozu2",
        capital: "Q",
        id: "5c49aaf69dc6d6354f44ad9e",
        nickname: "https://ss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=830518863,2608787117&fm=58&s=45F6AC720C61BB112F2A5CEE0300E02B&bpow=121&bpoh=75",
        real_name: "",
        status: 2,
        today_active_user: 7841,
        today_add_user: "探探",
        today_best_gold: 0,
        today_prize_win: 0,
        today_start_up: 7844.5,
        yesterday_active_user: 451,
        yesterday_add_user: 200,
        yesterday_best_gold: 0,
        yesterday_prize_win: 0,
        yesterday_start_up: "启用",
        created: "2019/02/14"
      } ,
      {
        account: "qudaozu2",
        capital: "Q",
        id: "5c49aaf69dc6d6354f44ad9e",
        nickname: "https://ss1.baidu.com/70cFfyinKgQFm2e88IuM_a/forum/pic/item/7a899e510fb30f24d4d19dd2c595d143ac4b0393.jpg",
        real_name: "",
        status: 2,
        today_active_user: 1256,
        today_add_user: "Soul",
        today_best_gold: 0,
        today_prize_win: 0,
        today_start_up: 100.8,
        yesterday_active_user: 623,
        yesterday_add_user: 310,
        yesterday_best_gold: 0,
        yesterday_prize_win: 0,
        yesterday_start_up: "启用",
        created: "2019/02/14"
      } ,
      {
        account: "qudaozu2",
        capital: "Q",
        id: "5c49aaf69dc6d6354f44ad9e",
        nickname: "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3039807029,4092165540&fm=58&bpow=256&bpoh=256",
        real_name: "",
        status: 2,
        today_active_user: 8532,
        today_add_user: "QQ",
        today_best_gold: 0,
        today_prize_win: 0,
        today_start_up: 741.1,
        yesterday_active_user: 778,
        yesterday_add_user: 750,
        yesterday_best_gold: 0,
        yesterday_prize_win: 0,
        yesterday_start_up: "停用",
        created: "2019/02/14"
      }  
  ]
    return (
      <Card title="首页">
        <div className="tableList">
          <Form >
            <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
              <Col xl={4} md={24} sm={24}  offset={2}>
                <Statistic
                  title="App数量"
                  value={11}
                  valueStyle={{ color: '#3f8600' }}
                  prefix={<Icon type="appstore" />}
                  suffix="个"
                />
              </Col>
              <Col xl={4} md={24} sm={24}>
                <Statistic
                  title="昨日新增用户"
                  value={538}
                  valueStyle={{ color: '#3f8600' }}
                  prefix={<Icon type="user-add" />}
                  suffix="人"
                />
              </Col>
              <Col xl={4} md={24} sm={24}>
                <Statistic
                  title="昨日活跃用户"
                  value={752}
                  valueStyle={{ color: '#3f8600' }}
                  prefix={<Icon type="thunderbolt" />}
                  suffix="人"
                />
              </Col>
              <Col xl={4} md={24} sm={24}>
                <Statistic
                  title="昨日活跃用户"
                  value={7222}
                  valueStyle={{ color: '#3f8600' }}
                  prefix={<Icon type="team" />}
                  suffix="人"
                />
              </Col>
              <Col xl={4} md={24} sm={24}>
                <Statistic
                  title="昨日消耗流量"
                  value={11.28}
                  precision={2}
                  valueStyle={{ color: '#3f8600' }}
                  prefix={<Icon type="wifi" />}
                  suffix="K"
                />
              </Col>
            </Row>
            <Row
              gutter={{ md: 8, lg: 24, xl: 48 }}
              style={{ marginTop: '20px' }}
            >
              <Col span={24}>
                <h3>汇总</h3>
                <Table
                  columns={this.state.columns}
                  // rowKey={record=> record.id}
                  dataSource={list}
                pagination={false}
                // onChange={this.handleTableChange}
                />
              </Col>
            </Row>
          </Form>
         </div>
      </Card>
    )
  }
}
