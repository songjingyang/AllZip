import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Popconfirm,
  Row,
  Col,
  Modal,
  message,
  Divider
} from 'antd'
import classNames from 'classnames'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
import AddApp from './AddApp'
import PreviewImg from '../../components/PreviewImg'
// import SwitchConfirm from '@/components/SwitchConfirm'
// import { dateFormater } from '@/utils/utils'
// import UploadImg from '@/components/UploadImg'
// import { inject } from 'mobx-react';
// import './Dashed.css'
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const RangePicker = DatePicker.RangePicker
interface Props extends FormComponentProps {
  form: WrappedFormUtils;
}
interface State {
  columns: any;
  isAddApp: boolean;
  statusMap:any
}
@Form.create()
// @inject('dashed')
export default class App extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {
      isAddApp: false,
      statusMap: { 1: '开奖', 2: '开奖', 3: '未开奖' },
      columns: [
        {
          title: '图标',
          dataIndex: 'nickname',
          render: (text: any) =>
            <PreviewImg src={text} alt="" />

        },
        {
          title: '名称',
          dataIndex: 'today_add_user',
        },
        {
          title: '首页URL',
          dataIndex: 'yesterday_add_user',
        },
        {
          title: '用户数',
          dataIndex: 'today_active_user',
        },
        {
          title: '在线用户',
          dataIndex: 'yesterday_active_user',
        },
        {
          title: '聊天室数量',
          dataIndex: 'today_start_up',
        },
        {
          title: '状态',
          dataIndex: 'yesterday_start_up',
        },
        {
          title: '创建时间',
          dataIndex: 'created',
        },
        {
          title: '操作',
          dataIndex: 'play',
          render: (text:any, record:any) => (
            <span>
              {/* <SwitchConfirm
                title="确认操作吗？"
                // onConfirm={() => this.getPlayerStatus(record)}
                checkedChildren="启动"
                unCheckedChildren="禁用"
                // checked={[record.status] == 3}
                style={{ marginRight: 16, marginTop: -5 }}
              /> */}
              <Popconfirm
                title="确定吗？"
                okText='确定'
                cancelText="取消"
              // onConfirm={() => this.refuse(record)}
              >
                <a
                  // onClick={() => this.CreateCharRoom(record)}
                  href="javascript:;">
                  停用
              </a>
              </Popconfirm>
              <Divider type="vertical" />

              <Popconfirm
                title="确定吗？"
                okText='确定'
                cancelText="取消"
              // onConfirm={() => this.refuse(record)}
              >
                <a
                  // onClick={() => this.CreateCharRoom(record)}
                  href="javascript:;">
                  启用
              </a>
              </Popconfirm>
              <Divider type="vertical" />
              <a
                href="http://downapp.baidu.com/baidusearch/AndroidPhone/11.3.6.11/1/757p/20190125021943/baidusearch_AndroidPhone_11-3-6-11_757p.apk?responseContentDisposition=attachment%3Bfilename%3D%22baidusearch_AndroidPhone_757p.apk%22&responseContentType=application%2Fvnd.android.package-archive&request_id=1550125889_6093643543&type=static"
                style={{
                  marginRight: '5px',
                }}
              >
                下载包
              </a>
              <Divider type="vertical" />
              <a onClick={() => this.AddApp(record)}  href="javascript:;">
                编辑
              </a>
            </span>
          ),
        },
      ],
    }
  }
  componentDidMount() {
    // this.getDashedInfo()
  }
  onChange=()=>{
      console.log('开关 :');
  }
  isAddApp = (bool: boolean) => {
    this.setState({
      isAddApp: bool,
    })
  }
  AddApp = (item: any) => {
    this.isAddApp(true)
    // this.setState({
    //   currItem: item,
    // })
  }
  AddAppInfo = () => {
    this.isAddApp(false)
    // this.saveOpenManagementInfo()
  }
  render() {
    // const global = this.props.global
    // const info = this.props.dashed.DashedInfo
    const list = [{
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=816022733,2864533631&fm=58&s=6B318A461B73081709D11A970300D094&bpow=121&bpoh=75",
      real_name: "",
      status: 2,
      today_active_user: 4123,
      today_add_user: "陌陌",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 895,
      yesterday_active_user: 532,
      yesterday_add_user: "http://www.immomo.com/",
      yesterday_best_gold: 0,
      yesterday_prize_win: 0,
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
    {
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=830518863,2608787117&fm=58&s=45F6AC720C61BB112F2A5CEE0300E02B&bpow=121&bpoh=75",
      real_name: "",
      status: 2,
      today_active_user: 7841,
      today_add_user: "探探",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 7844.5,
      yesterday_active_user: 451,
      yesterday_add_user: "http://tantanapp.com/",
      yesterday_best_gold: 0,
      yesterday_prize_win: 0,
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
    {
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss1.baidu.com/70cFfyinKgQFm2e88IuM_a/forum/pic/item/7a899e510fb30f24d4d19dd2c595d143ac4b0393.jpg",
      real_name: "",
      status: 2,
      today_active_user: 1256,
      today_add_user: "Soul",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 100.8,
      yesterday_active_user: 623,
      yesterday_add_user: "https://www.soulapp.cn/home",
      yesterday_best_gold: 0,
      yesterday_prize_win: 0,
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
    {
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3039807029,4092165540&fm=58&bpow=256&bpoh=256",
      real_name: "",
      status: 2,
      today_active_user: 8532,
      today_add_user: "QQ",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 741.1,
      yesterday_active_user: 778,
      yesterday_add_user: "https://im.qq.com/",
      yesterday_best_gold: 0,
      yesterday_prize_win: 0,
      yesterday_start_up: "停用",
      created: "2019/02/14"
    }
    ]
    return (
      <Card title="App管理">
        {this.state.isAddApp && (
          <Modal
            visible={this.state.isAddApp}
            width={700}
            onCancel={() => this.isAddApp(false)}
            footer={null}
          >
            <AddApp
            // data={this.state.currItem}
            // onClose={() => {
            //   this.isCreateCharRoom(false)
            //   // this.saveOpenManagementInfo({
            //   //   pageSize: this.state.pagination.pageSize,
            //   //   page: this.state.pagination.current,
            //   // })
            // }}
            />
          </Modal>
        )}
        <div className="tableList">       
          <Form >
            <Row
              gutter={{ md: 8, lg: 24, xl: 48 }}
              style={{ marginTop: '20px' }}
            >
              <Col span={24}>
                <Button
                  onClick={this.AddApp}
                  type="primary"
                  htmlType="button"
                >
                  创建App
                    </Button>
              </Col>
            </Row>
          </Form>
          <Table
            columns={this.state.columns}
            // rowKey={record=> record.id}
            dataSource={list}
            pagination={false}
          // onChange={this.handleTableChange}
          />
        </div>
      </Card>
    )
  }
}
