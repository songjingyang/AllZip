import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Row,
  Col,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Card,
  DatePicker,
  message,
} from 'antd'
import moment from 'moment'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
// import UploadImg from '../../components/UploadImg';
// import UploadImg from '../../components/UploadImgs';
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const { TextArea } = Input
interface Props  {
  // form: WrappedFormUtils,
  onChange?(url: string): void;
}

interface State {
  loading:boolean;
  imgUrl:string;
}
@Form.create()
export default class AddApp extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props)
    this.state = {
      // uploadUrl: '/api/channeles/Uploadfile/index',
      loading: false,
      imgUrl: '',
      // file: string,
    };
  }
  upload = async (formData: any) => {
    // const url = await this.props.global.upload(formData)
    // this.props.my.saveUpdateInfo({
    //   data: {
    //     nickname: this.props.my.myInfo.nickname,
    //     avatar: url
    //   },
    //   callback: res => {
    //     if (res.code === '1') {
    //       this.props.my.getMyInfo({
    //         data: {
    //         },
    //         //   callback:res=>{
    //         //     if (res.code === '1') {
    //         //      Toast.success(
    //         //     '上传成功',
    //         //     2,
    //         //     (onclose = () => {
    //         //       this.props.history.goBack()
    //         //     })
    //         // );}
    //         //   }
    //       })

    //     }
    //   }
    // },
    // )
    // return url;
  }
  getBase64=(img:any, callback:any)=> {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result));
  reader.readAsDataURL(img);
}
  handleChange = (info:any) => {
    debugger
    if (info.file.status === 'uploading') {
      this.setState({ loading: true });
      return;
    }
    if (info.file.status === 'done') {
      // Get this url from response in real world.
      if(info.file.response[0].code===200){
        const imgUrl = info.file.response[0].img_url_es;
        const baseUrl = window.location.protocol + '//' + document.domain + '/api';
        const url = imgUrl + baseUrl
          this.setState(
          {
            // imgUrl: "http://channel.669lottery.com/api/" + imgUrl,
            imgUrl: baseUrl + imgUrl,
            loading: false,
          },
          () => {
            this.props.onChange;
          }
        );
      }
    }
  }
  // beforeUpload = (info: any)=> {
  //    this.setState({
  //      file: this.state.file,
  //    });
  // }
  render() {
    // const { getFieldDecorator } = this.props.form
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    }
    const uploadButton = (
      <div>
        <Icon type={this.state.loading ? 'loading' : 'plus'} />
        <div className="ant-upload-text">Upload</div>
      </div>
    );
    return (
      <Card bordered={false} title={'创建App'}  >
      <Form>
        <Row gutter={{ xs: 8, sm: 16, md: 24 }} >
          <Col xl={24} md={24} sm={24}  >
              <FormItem label="App名称" {...formItemLayout} className="form-inline-item">
              {/* {getFieldDecorator('name')(
                <Input />
              )} */}
              <Input />
            </FormItem>
          </Col>
          <Col xl={24} md={24} sm={24}  >
              <FormItem label="首页URL" {...formItemLayout} className="form-inline-item">
                {/* {getFieldDecorator('name')(
                <Input />
              )} */}
                <Input />
              </FormItem>
          </Col>
          <Col xl={24} md={24} sm={24} >
              <FormItem label="登录地址" {...formItemLayout} className="form-inline-item">
              <Input />
            </FormItem>
          </Col>
          <Col xl={24} md={24} sm={24} >
              <FormItem label="登录回调" {...formItemLayout} className="form-inline-item">
              <Input />
            </FormItem>
          </Col>
            <Col xl={24} md={24} sm={24} >
              <FormItem label="图标" {...formItemLayout} className="form-inline-item">
              {/* <UploadImg
                onUpload={this.upload}
                value=""
                label=""
              /> */}
              {/* <UploadImg /> */}
                <Upload
                  name="avatar"
                  listType="picture-card"
                  className="avatar-uploader"
                  showUploadList={false}
                  action="/upload/images"
                  // beforeUpload={this.beforeUpload}
                  onChange={this.handleChange}
                >
                  {this.state.imgUrl ? <img src={this.state.imgUrl} alt="avatar" /> : uploadButton}
                </Upload>
            </FormItem>
          </Col>
          <Col xl={12} md={24} sm={24} offset={6}>
            <div className='submitButtons'>
              <Button type="primary" htmlType="submit" className='listsearch'>
               确定
              </Button>
            </div>
          </Col>
        </Row>
        </Form>
      </Card>
    )
  }
}
