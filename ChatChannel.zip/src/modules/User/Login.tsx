import React, { KeyboardEvent, ReactElement } from 'react'
import { Form, Icon, Input, Button, Checkbox } from 'antd';
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps} from 'antd/lib/form/Form'
import { inject } from 'mobx-react';
import { match } from 'react-router';
import { Link } from 'react-router-dom';
import { History } from 'history';
import create from 'antd/lib/icon/IconFont';
import './UserLogin.less'
const FormItem = Form.Item
interface Props extends FormComponentProps {
  form: WrappedFormUtils;
  history: History;
}

interface State{

}

// static create: <TOwnProps>(options?: FormCreateOption<TOwnProps>) => <ComponentDecorator extends Component<any>>(target: ComponentDecorator) => ComponentDecorator 

@Form.create()
@inject('user')
export default class Login extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {}
  }
  handleSubmit = (e: KeyboardEvent) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values);
        this.props.history.push(`/home/home`)
        localStorage.setItem("user", JSON.stringify(values));
      }
    });
  }
  render(){

    const { getFieldDecorator } = this.props.form;
    return (
      <Form onSubmit={this.handleSubmit} className="login-form">
        <FormItem label="用户名">
          {getFieldDecorator('username', {
            initialValue: '',
            rules: [{ required: true, message: '请输入用户名' }],
          })(
            <Input
              size="large"
              prefix={
                <Icon type="username" style={{ color: 'rgba(0,0,0,.25)' }} />
              }
              placeholder="请输入用户名"
            />
          )}
        </FormItem>
        <FormItem label="密码">
          {getFieldDecorator('userpwd', {
            rules: [{ required: true, message: '请输入密码' }],
          })(
            <Input
              size="large"
              prefix={
                <Icon type="userpwd" style={{ color: 'rgba(0,0,0,.25)' }} />
              }
              type="password"
              placeholder="请输入密码"
            />
          )}
        </FormItem>
        <FormItem label="验证码">
          {getFieldDecorator('signcode', {
            rules: [{ required: true, message: '请输入验证码' }],
          })(
            <Input
              size="large"
              prefix={
                <Icon type="signcode" style={{ color: 'rgba(0,0,0,.25)' }} />
              }
              type="verification"
              placeholder="请输入验证码"
            />
          )}
        </FormItem>
        <FormItem>
          <img
            alt="验证码"
            src='http://223.203.221.79:8089/api/index/login/verify?r=1550118052195'
            title="点击刷新"
            // onClick={this.handleChange}
          />
        </FormItem>
        <FormItem>
          <Button
            size="large"
            type="primary"
            htmlType="submit"
            className="login-form-button"
          >
            登录
          </Button>
        </FormItem>
      </Form>
    );
  }
}



// function reverse<T>(items: T[]): T[] {
//   const toreturn = [];
//   for (let i = items.length - 1; i >= 0; i--) {
//     toreturn.push(items[i]);
//   }
//   return toreturn;
// }

// const sample = [1, 2, 3];
// const reversed = reverse(sample);

// reversed[0] = '1'; // Error
// reversed = ['1', '2']; // Error

// reversed[0] = 1; // ok
// // reversed = [1, 2]; // ok