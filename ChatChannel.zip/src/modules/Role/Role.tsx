import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Popconfirm,
  Row,
  Col,
  Modal,
  message,
  Divider
} from 'antd'
import moment from 'moment'
import { WrappedFormUtils, FormComponentProps, RcBaseFormProps } from 'antd/lib/form/Form'
import PreviewImg from '../../components/PreviewImg'
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const { TextArea } = Input
interface Props extends FormComponentProps {
  form: WrappedFormUtils,

}

interface State {
  columns:any
}
@Form.create()
export default class Role extends React.Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.state = {
      // isEdit: false,
      // isAdd: false,
      // currItem:{},
      columns: [
        {
          title: '图标',
          dataIndex: 'nickname',
          render: (text: any) =>
            <PreviewImg src={text} alt="" />

        },
        {
          title: '昵称',
          dataIndex: 'today_add_user',
        },
        {
          title: '是否在线',
          dataIndex: 'yesterday_add_user',
        },
        {
          title: '状态',
          dataIndex: 'yesterday_start_up',
        },
        {
          title: '注册时间',
          dataIndex: 'created',
        },
        {
          title:'操作',
          dataIndex: 'play',
          render: (text: any, record: any) => (
            <span>
              <Popconfirm
                title="确定吗？"
                okText='确定'
                cancelText="取消"
              // onConfirm={() => this.refuse(record)}
              >
                <a
                  // onClick={() => this.CreateCharRoom(record)}
                  href="javascript:;">
                  停用
              </a>
              </Popconfirm>
              <Divider type="vertical" />

              <Popconfirm
                title="确定吗？"
                okText='确定'
                cancelText="取消"
              // onConfirm={() => this.refuse(record)}
              >
                <a
                  // onClick={() => this.CreateCharRoom(record)}
                  href="javascript:;">
                  启用
              </a>
              </Popconfirm>
             
            </span>
          ),
        }
      ],
    }
  }
  handleSubmit = (e: KeyboardEvent) => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('values :', values);
      }
    })
  }
  onChange = () => {
    console.log('开关 :');
  }
  render() {
    const { getFieldDecorator } = this.props.form
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
    }
    const list = [{
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=816022733,2864533631&fm=58&s=6B318A461B73081709D11A970300D094&bpow=121&bpoh=75",
      real_name: "",
      status: 2,
      today_active_user: 4123,
      today_add_user: "大狗",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 895,
      yesterday_active_user: 532,
      yesterday_add_user: "在线",
      yesterday_best_gold: 0,
      yesterday_prize_win: 0,
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
    {
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=830518863,2608787117&fm=58&s=45F6AC720C61BB112F2A5CEE0300E02B&bpow=121&bpoh=75",
      real_name: "",
      status: 2,
      today_active_user: 7841,
      today_add_user: "二狗",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 7844.5,
      yesterday_active_user: 451,
      yesterday_add_user: "离线",
      yesterday_best_gold: 0,
      yesterday_prize_win: 0,
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
    {
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss1.baidu.com/70cFfyinKgQFm2e88IuM_a/forum/pic/item/7a899e510fb30f24d4d19dd2c595d143ac4b0393.jpg",
      real_name: "",
      status: 2,
      today_active_user: 1256,
      today_add_user: "三狗",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 100.8,
      yesterday_active_user: 623,
      yesterday_add_user: "离线",
      yesterday_best_gold: 0,
      yesterday_prize_win: 0,
      yesterday_start_up: "启用",
      created: "2019/02/14"
    },
    {
      account: "qudaozu2",
      capital: "Q",
      id: "5c49aaf69dc6d6354f44ad9e",
      nickname: "https://ss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3039807029,4092165540&fm=58&bpow=256&bpoh=256",
      real_name: "",
      status: 2,
      today_active_user: 8532,
      today_add_user: "四狗",
      today_best_gold: 0,
      today_prize_win: 0,
      today_start_up: 741.1,
      yesterday_active_user: 778,
      yesterday_add_user: "在线",
      yesterday_best_gold: 0,
      yesterday_prize_win: 0,
      yesterday_start_up: "停用",
      created: "2019/02/14"
    }
    ]
    return (
      <Card bordered={false} title={'用户管理'}>
        <div className="tableList">
        <Form>
          <Row gutter={{ xs: 8, sm: 16, md: 24 }}>
            <Col xl={8} md={24} sm={24}>
                <FormItem label="搜索用户" {...formItemLayout} className="form-inline-item">
                {getFieldDecorator('name')(
                  <Input  />
                )}
              </FormItem>
            </Col>
            <Col xl={8} md={24} sm={24}>
                <FormItem label="搜索App" {...formItemLayout} className="form-inline-item">
                {getFieldDecorator('app')(
                  <Input />
                )}
              </FormItem>
            </Col>
           
            <Col xl={24} md={24} sm={24} offset={2}>
              <div className='submitButtons'>
                <Button type="primary" htmlType="submit" >
                  查询
                  </Button>
              </div>
            </Col>
          </Row>
          </Form>
          <Table
            columns={this.state.columns}
            // rowKey={record=> record.id}
            dataSource={list}
            pagination={false}
          // onChange={this.handleTableChange}
          />
        </div>
      </Card>
    )
  }
}
