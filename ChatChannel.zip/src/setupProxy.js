const proxy = require('http-proxy-middleware')

module.exports = function (app) {
  console.log('​app', app)
  // const proxyUrl = 'http://223.203.132.135:3100/mock/16/'
  const proxyUrl = 'http://223.203.221.89:9090'
  const uploadProxyUrl = 'http://223.203.221.89:9080'
  app.use(
    proxy('/api/upload', {
      target: uploadProxyUrl,
      pathRewrite: {
        '^/api': ''
      }
    })
  )
  app.use(
    proxy('/api', {
      target: proxyUrl,
      pathRewrite: {
        '^/api': ''
      }
    })
  )
}
