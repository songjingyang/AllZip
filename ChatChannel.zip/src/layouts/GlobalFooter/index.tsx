import React, {  ReactHTMLElement, ReactHTML, Fragment } from 'react'
import './index.less'


interface Props{

}

interface State{

}

const links = [
  {
    key: 'help',
    title: '帮助',
    href: ''
  },
  {
    key: 'privacy',
    title: '隐私',
    href: ''
  },
  {
    key: 'terms',
    title: '条款',
    href: ''
  }
]


export default class GlobalFooter extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    
  }
  

  render () {
    return (
      <div style={{ textAlign: 'center' }}>
        Copyright  © 2018-2020
      </div>
    )
  }
}

