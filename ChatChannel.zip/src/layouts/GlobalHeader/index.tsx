import React, { Fragment } from 'react'
import {
  Form,
  Menu,
  Icon,
  Spin,
  Tag,
  Dropdown,
  Avatar,
  Divider,
  Tooltip
} from 'antd'
import { Link } from 'react-router-dom'
import './index.less'
import { ClickParam } from 'antd/lib/menu';

interface Props{

}

interface State{

}

export default class GlobalHeader extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    
  }
  

 
  onMenuClick = (params: ClickParam) => {
    const key = params.key
    if (key === 'triggerError') {
      return
    }
    if (key === 'logout') {
      // this.props.dispatch({
      //   type: 'user/logout',
      //   payload: {},
      //   callback: res => {
      //     if (res.code === 200) {
      //       window.location.reload()
      //     }
      //   }
      // })
    }
  }

  // http://localhost:3002/#/user/userLogin
  // http://localhost:3002/#/user/userLogin
  render () {
    // const currentUser = this.props.user.userInfo
    const currentUser = {
      name: 'daycool',
      avatar: '',
    }
    const menu = (
      <Menu className='menu' selectedKeys={[]} onClick={this.onMenuClick}>
        <Menu.Item disabled>
          <Icon type='user' />
          个人中心
        </Menu.Item>
        <Menu.Item disabled>
          <Icon type='setting' />
          设置
        </Menu.Item>
        {/* <Menu.Item key='triggerError'>
          <Icon type='close-circle' />触发报错
        </Menu.Item> */}
        <Menu.Divider />
        <Menu.Item key='logout'>
          <Icon type='logout' />
          退出登录
        </Menu.Item>
      </Menu>
    )

    return (
      <div styleName="header">
        {this.props.children}
        <div className='right'>
          {currentUser.name ? (
            <Dropdown overlay={menu}>
              <span className={`account`}>
                <Avatar
                  size='small'
                  className='avatar'
                  src={
                    currentUser.avatar ||
                    'https://gw.alipayobjects.com/zos/rmsportal/BiazfanxmamNRoxxVxka.png'
                  }
                />
                <span className='name'>{currentUser.name}</span>
              </span>
            </Dropdown>
          ) : (
            <Spin size='small' style={{ marginLeft: 8 }} />
          )}
        </div>
      </div>
    )
  }
}
