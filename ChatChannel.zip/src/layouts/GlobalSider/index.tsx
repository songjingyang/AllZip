import React from 'react'
import { Menu, Icon, Layout } from 'antd'
import { Link } from 'react-router-dom'

import { getMenuData } from '../../common/menu'
import './index.less'

const SubMenu = Menu.SubMenu
const menuData = getMenuData()
const { Sider } = Layout


interface Props{
  collapsed: boolean;
  
}

interface State{
}

class GlobalSider extends React.Component<Props, State> {
  constructor (props: Props) {
    super(props)
    this.state = {
    }
   
  }

 

  render () {
    const collapsed = this.props.collapsed;
  
    return <Sider
      trigger={null}
      collapsible
      collapsed={collapsed}
      // onCollapse={this.onCollapse}
      breakpoint='lg'
      className='sider'
    >
      <div styleName='logo'>
        <Icon type='wallet' className='logo-img' />
        {!collapsed && <h1>渠道后台管理系统</h1>}
      </div>
      <Menu
        mode="inline"
        theme="dark"
        defaultSelectedKeys={['1']}
        defaultOpenKeys={['sub1']}
        inlineCollapsed={collapsed}
      >
        {menuData.map(item => {
          if(item.children){
            return <SubMenu key={item.path} title={<span><Icon type={item.icon} /><span>{item.name}</span></span>}>
              {item.children.map((subItem: any) => <Menu.Item key={subItem.path}><Link to={subItem.path}>{subItem.name}</Link></Menu.Item>)}
            </SubMenu>
          }else{
            return <Menu.Item><Icon type={item.icon} /><span><Link styleName="nav-link" to={item.path}>{item.name}</Link></span></Menu.Item>
          }
        } 
          
        )}
      </Menu>
    </Sider>
  }
}

export default GlobalSider
