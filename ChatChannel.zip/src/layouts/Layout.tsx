import React from 'react'
import { Route, Redirect } from 'react-router-dom'
import BasicLayout from './BasicLayout'
import UserLayout from './UserLayout'
// import UserLogin from '../modules/User/UserLogin'
// import UserRegister from '../modules/User/UserRegister'

import { getRouterData } from '../common/router'
import User from '../models/User';

interface Props {
  // user: User
}

interface State {}


const routerData = getRouterData()

export default class Layout extends React.Component<Props, State> {
  render () {
    const isLogin =  localStorage.getItem('user')
    // const isLogin =  false
    return isLogin ? (
      <BasicLayout {...this.props}>
        {routerData.map(item => (
          <Route key={item.path} path={item.path} component={item.component} />
        ))}
        {/* <Route exact component={NoMatch} /> */}
      </BasicLayout>
    ) : (
      <UserLayout {...this.props}>
        {routerData.map(item => (
          <Route key={item.path} path={item.path} component={item.component} />
        ))}
        <Redirect
          to={{
            pathname: '/user/login'
          }}
        />
      </UserLayout>
    )
  }
}
