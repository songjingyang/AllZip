import React, { Component } from 'react';
import { Provider } from 'mobx-react'
import DevTools from 'mobx-react-devtools';
import './App.css';

import store from './models/index'


import { BrowserRouter as Router, Route, Link, Switch, Redirect} from 'react-router-dom';
import Layout from './layouts/Layout';
// import getRouterData from './common/router';


// const routerData = getRouterData();

const userStr = localStorage.getItem('user');
if (userStr){
  try{
    const user = JSON.parse(localStorage.getItem('user') || '{}')
    store.user.userInfo = user;
  }catch(e){
    console.error(e)
  }
}

export default class App extends Component {


  render() {
    return <div>
        <Provider {...store}>
          <Router>
            <Switch>
              <Layout></Layout>
            </Switch>
          </Router>
        </Provider>
        <DevTools></DevTools>
      </div>;
  }
}



// import React from 'react';
// import { routerRedux, Route, Switch, Link, Redirect } from 'router-redux';
// import { LocaleProvider } from 'antd';
// import zhCN from 'antd/lib/locale-provider/zh_CN';

// import Layout from './layouts/Layout';

// // import UserLogin from '@/modules/User/UserLogin';

// // import Authorized from './utils/Authorized'
// // import { getQueryPath } from './utils/utils'

// const { ConnectedRouter } = routerRedux;
// // const { AuthorizedRoute } = Authorized

// function RouterConfig({ history, app }) {
//   return (
//     <LocaleProvider locale={zhCN}>
//       <ConnectedRouter history={history}>
//         <Switch>
//           <Layout app={app} />
//         </Switch>
//       </ConnectedRouter>
//     </LocaleProvider>
//   );
// }



// export default RouterConfig;

// class App extends Component {
//   render() {
//     return <div>
//         <Provider {...store}>
//           <Router>
//             <Switch>
//               {routerData.map(item => (
//                 <Route key={item.path} path={item.path} component={item.component} />
//               ))}
//               {/* <Route exact component={NoMatch} /> */}
//               {/* <Route path="/user/login" component={UserLogin} /> */}
//               <Redirect to={{ pathname: '/home/home' }} />
//             </Switch>
//           </Router>
//         </Provider>
//         <DevTools></DevTools>
//       </div>;
//   }
// }
