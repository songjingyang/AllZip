import React from 'react';
import Login from '../modules/User/Login';
import Dashedboard from '../modules/Dashed/Dashed';
import App from '../modules/App/App';
import Role from '../modules/Role/Role';
import Group from '../modules/Group/Group';
import Chatroom from '../modules/Chatroom/Chatroom';
import PushMsg from '../modules/PushMsg/PushMsg';
import RoleManagement from '../modules/System/RoleManagement';
import Account from '../modules/System/Account';
import SendRecord from '../modules/PushMsg/SendRecord';

const routerData: any[] = [
  // {
  //   path: '/home/:home',
  //   component: Home,
  //   meta: {
  //     title: '首页',
  //   },
  // },
  {
    path: '/user/login',
    component: Login,
    meta: {
      title: '登录',
    },
  },
  {
    path: '/home/home',
    component: Dashedboard,
    meta: {
      title: '首页',
    },
  },
  {
    path: '/app/app',
    component: App,
    meta: {
      title: 'App管理',
    },
  },
  {
    path: '/role/role',
    component: Role,
    meta: {
      title: '用户管理',
    },
  },
  {
    path: '/group/group',
    component: Group,
    meta: {
      title: '群管理',
    },
  },
  {
    path: '/chatroom/chatroom',
    component: Chatroom,
    meta: {
      title: '群管理',
    },
  },
  {
    path: '/pushMsg/pushMsg',
    component: PushMsg,
    meta: {
      title: '推送消息',
    },
  },
  {
    path: '/pushMsg/sendrecord',
    component: SendRecord,
    meta: {
      title: '发送记录',
    },
  },
  {
    path: '/system/roleManagement',
    component: RoleManagement,
    meta: {
      title: '角色管理',
    },
  },
  {
    path: '/system/account',
    component: Account,
    meta: {
      title: '账号操作记录',
    },
  },

];

export function getRouterData(): any[] {
  return routerData;
}

export default getRouterData;
