import { isUrl } from '../utils/utils';

const menuData = [
  {
    name: '首页',
    icon: 'dashboard',
    path: 'home',
    children: [
      {
        name: '主页',
        path: 'home'
      }
    ]
  },
  {
    name: 'APP管理',
    icon: 'dashboard',
    path: 'app',
    children: [
      {
        name: 'APP管理',
        path: 'app'
      }
    ]
  },
  {
    name: '用户管理',
    icon: 'dashboard',
    path: 'role',
    children: [
      {
        name: '用户管理',
        path: 'role'
      }
    ]
  },
  {
    name: '群管理',
    icon: 'dashboard',
    path: 'group',
    children: [
      {
        name: '群管理',
        path: 'group'
      }
    ]
  },
  {
    name: '聊天室管理',
    icon: 'dashboard',
    path: 'chatroom',
    children: [
      {
        name: '聊天室管理',
        path: 'chatroom'
      }
    ]
  },
  {
    name: '推送消息',
    icon: 'dashboard',
    path: 'pushMsg',
    children: [
      {
        name: '推送消息',
        path: 'pushMsg'
      }
    ]
  },
  // {
  //   name: '系统管理',
  //   icon: 'dashboard',
  //   path: 'system',
  //   children: [
  //     {
  //       name: '角色管理',
  //       icon: 'dashboard',
  //       path: 'roleManagement',
  //     }, {
  //       name: '账号操作记录',
  //       icon: 'dashboard',
  //       path: 'account',
  //     },
  //   ]
  // },
  
];

function formatter(data: any[], parentPath: string) {
  return data.map(item => {
    let path: string = item.path;
    if (!isUrl(path)) {
      path = parentPath + item.path;
    }
    const result = {
      ...item,
      path,
      authority: item.authority || false,
    };
    if (item.children) {
      result.children = formatter(
        item.children,
        `${parentPath}${item.path}/`,
        // item.authority
      );
    }
    return result;
  });
}

export const getMenuData = () => formatter(menuData, '/');
