import { notification, message } from 'antd';
import axios from 'axios';
import { generatePath } from 'react-router-dom'
import urlMaps, { baseUrl } from './urlMaps';
import { getQueryString } from '../utils/utils';

export {urlMaps}

export interface ReqData {
  data?: any;
  callback?(res: any): void;
}

export interface ResData<T> {
  code: string | number;
  msg: string;
  err_msg: string;
  ts: string;
  data: T;
}


/**
 * Requests a URL, returning a promise.
 *
 * @param  {string} url       The URL we want to request
 * @param  {object} [options] The options we want to pass to "fetch"
 * @return {object}           An object containing either "data" or "err"
 */
export default async function request<T>(url: string, data: any, options: any = { method: 'GET' }): Promise<ResData<T>> {

  options.originUrl = url;
  url = baseUrl + url;
  data = data || {};

  let newOptions = { ...options, data: data };
  let user = JSON.parse(window.localStorage.getItem('user') as string) || {};
  newOptions.headers = newOptions.headers || {};
  if (user) {
    newOptions.headers.uid = user.id;
    newOptions.headers.sign = '123456';
  }

  if (
    newOptions.method === 'POST' ||
    newOptions.method === 'PUT' ||
    newOptions.method === 'DELETE'
  ) {
    if (!(newOptions.data instanceof FormData)) {
      newOptions.headers = {
        Accept: 'application/json',
        'Content-Type': 'application/json; charset=utf-8',
        ...newOptions.headers,
      };
      newOptions.data = JSON.stringify(newOptions.data);
    } else {
      // newOptions.data is FormData
      newOptions.headers = {
        Accept: 'application/json',
        ...newOptions.headers,
      };
    }
  } else if (newOptions.method === 'GET') {
    newOptions.params = newOptions.data;
    newOptions.headers = {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      ...newOptions.headers,
    };
  }
  newOptions.url = newOptions.url || url;

  return axios(newOptions)
    .then(
      (response: any) => {
       
        if (!('code' in response.data)) {
          const resData = response
          return {
            code: 1,
            msg: '',
            err_msg: '',
            data: resData,
            ts: '',
          } as ResData<T>;
        }
        
        return response as ResData<T>;

      },
      (res: any) =>  {
        const response = res.response;

        if (response && response.data) {
						console.log('TCL: request -> generatePath', generatePath('/user/login'))
          if (response.data.code === '-800') {
            // window.location.href = generatePath('/user/login')
          }else if (response.data.code !== '1') {
            notification.error({
              message: `请求错误 ${response.status}: ${
                response.url
              }`,
              description: response.data.msg,
            });
          } 
        }
        return response.data as ResData<T>;
      }
    )
}
