import User from './User'

export default {

  user: new User(),
}