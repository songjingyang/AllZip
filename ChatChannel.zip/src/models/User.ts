import { observable, action} from 'mobx'
import request, { urlMaps, ResData, ReqData } from '../common/request';

export interface UserInfo{
  id: string;
  merchid: string;
  externalid: string;
  nickname: string;
  realname: string;
  sex: string;
  avatar: string;
  status: string;
}
export class User{
  @observable
   userInfo: UserInfo = {
      id: '',
      merchid: '',
      externalid: '',
      nickname: '',
      realname: '',
      sex: '',
      avatar: '',
      status: '',
   }
  @action
  async login({ data, callback }: ReqData){
    const res = await request<UserInfo>(urlMaps.login, data, {method: 'POST'})
    
    if(res.code === '1'){
      const data: any = res.data
      const user = data.player as UserInfo;
      this.userInfo = user;
      localStorage.setItem('user', JSON.stringify(user));
    }
    if(callback){
      callback(res);
    }
  }
  @action async register({ data, callback }: ReqData) {
    const res = await request<UserInfo>(urlMaps.register, data, { method: 'POST' })

    if (res.code === '1') {
      // this.register_name = res.data
    }
    if (callback) {
      callback(res);
    }
  }
  
}

export default User