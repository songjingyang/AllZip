<a name="0.1.0"></a>
# [0.1.0](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.15...v0.1.0) (2018-09-01)



<a name="0.1.15"></a>
## [0.1.15](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.14...v0.1.15) (2018-09-01)


### Bug Fixes

* laji ([6271b40](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/6271b40))



<a name="0.1.14"></a>
## [0.1.14](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.13...v0.1.14) (2018-09-01)


### Bug Fixes

* 默认错误提示 ([be1cd51](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/be1cd51))


### Features

* 统计开发 ([43d8449](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/43d8449))



<a name="0.1.13"></a>
## [0.1.13](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.12...v0.1.13) (2018-09-01)


### Bug Fixes

* 400同意提示 ([b28db80](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/b28db80))



<a name="0.1.12"></a>
## [0.1.12](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.11...v0.1.12) (2018-08-31)


### Bug Fixes

* status 4 ([de7e118](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/de7e118))



<a name="0.1.11"></a>
## [0.1.11](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.10...v0.1.11) (2018-08-31)


### Bug Fixes

* xxx ([8d31e59](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/8d31e59))
* 垃圾 ([a66cc85](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/a66cc85))
* 新分组开发 ([e27ed46](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/e27ed46))
* 新分组开发 ([cd61811](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/cd61811))
* 登录失效 调用resetUserInfo ([75fb996](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/75fb996))


### Features

* order ([8f080ae](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/8f080ae))
* orderInfo_20180830 ([497c629](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/497c629))
* 充值、降额审核_20180831 ([c760dba](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/c760dba))



<a name="0.1.10"></a>
## [0.1.10](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.9...v0.1.10) (2018-08-29)


### Bug Fixes

* 颜色 ([38574f8](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/38574f8))



<a name="0.1.9"></a>
## [0.1.9](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.8...v0.1.9) (2018-08-29)


### Bug Fixes

* 颜色 ([84ea777](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/84ea777))



<a name="0.1.8"></a>
## [0.1.8](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.7...v0.1.8) (2018-08-29)



<a name="0.1.7"></a>
## [0.1.7](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.6...v0.1.7) (2018-08-29)


### Bug Fixes

* yemian ([11f819a](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/11f819a))



<a name="0.1.6"></a>
## [0.1.6](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.5...v0.1.6) (2018-08-29)



<a name="0.1.5"></a>
## [0.1.5](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.2...v0.1.5) (2018-08-29)


### Bug Fixes

* 一封组loading ([f372b15](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/f372b15))
* 使用接口pageSize ([95796f5](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/95796f5))



<a name="0.1.2"></a>
## [0.1.2](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.1...v0.1.2) (2018-08-29)


### Bug Fixes

* 滚动条 ([f73c595](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/f73c595))



<a name="0.1.1"></a>
## [0.1.1](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/v0.1.0...v0.1.1) (2018-08-29)


### Bug Fixes

* 50   隐藏不必要 ([5d8bb86](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/5d8bb86))



<a name="0.1.0"></a>
# [0.1.0](http://172.1.2.29/git/ccpay/console-mgr-fe/compare/fbee174...v0.1.0) (2018-08-29)


### Bug Fixes

* add enquire-js依赖 ([fbee174](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/fbee174))
* 优化优化 ([e6c2d27](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/e6c2d27))
* 添加readme ([81a3975](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/81a3975))
* 添加readme  config.js ([e2633c2](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/e2633c2))
* 目录大写 ([3920f14](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/3920f14))
* 目录大写 ([862211d](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/862211d))
* 翻页bug ([146e048](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/146e048))
* 解决冲突 ([8ce5a22](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/8ce5a22))


### Features

* 二维码分组开发 ([412399d](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/412399d))
* 代理管理开发init ([fe2a3df](http://172.1.2.29/git/ccpay/console-mgr-fe/commits/fe2a3df))



