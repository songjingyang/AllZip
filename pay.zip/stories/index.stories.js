import React from 'react'

import { storiesOf } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import { linkTo } from '@storybook/addon-links'

import { Button, Welcome } from '@storybook/react/demo'

import SwitchConfirm from '../src/components/SwitchConfirm'
import PreviewImg from '../src/components/PreviewImg'
import UploadImg from '../src/components/UploadImg'
import UploadImgs from '../src/components/UploadImgs'

storiesOf('组件', module)
  .add('开关确认SwitchConfirm', () => (
    <SwitchConfirm
      title='确认操作吗？'
      checkedChildren='启动'
      unCheckedChildren='禁用'
      style={{ marginLeft: 16, marginTop: -5 }}
      onConfirm={action('您点击了确认')}
      onCancel={action('您点击了取消')}
    />
  ))
  .add('预览图片PreviewImg', () => (
    <PreviewImg
      src='https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png'
      alt='图片'
      style={{ height: 200 }}
    />
  ))
  .add('上传图片UploadImg', () => (
    <UploadImg src='https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png' />
  ))
  .add('上传多个图片UploadImgs', () => <UploadImgs />)
