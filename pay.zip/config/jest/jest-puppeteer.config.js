module.exports = {
  server: {
    command: 'node server.js',
    port: 4444
  }
}
