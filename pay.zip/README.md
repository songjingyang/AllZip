## 安装

- 安装nodejs
- 更换为淘宝源

`npm config set registry https://registry.npm.taobao.org `

- 在项目跟目录

`npm install --sass_binary_site=https://npm.taobao.org/mirrors/node-sass/`

## 开发

- 真接口模式
`npm start`

- mockData模式
`npm run start:mock`

## 打包

`npm build`

- 打包并上传服务器，请务必配置正确服务器目标地址
`build:product`

- 修改服务器目标地址config/deploy.js

`
    deployTo: '/home/share/pay-admin/',
`



项目名：支付运营后台管理系统，git仓库地址：http://172.1.2.29/git/ccpay/console-mgr-fe.git 。本项目第一负责人为 `钱明卫`。


## 安装node, git， 

 - node版本 `v8.11.3`
- 更换为淘宝源

`npm config set registry https://registry.npm.taobao.org `

- node-sass 安装失败时

`npm install --sass_binary_site=https://npm.taobao.org/mirrors/node-sass/`

### 开发环境配置

vscode

## 开发

- mockData模式
`npm run start:mock`
## 联调

- 真接口模式
`npm start`

## 打包

`npm build`

- 打包并上传服务器，请务必配置正确服务器目标地址
`build:product`

- 修改服务器目标地址config/deploy.js

` deployTo: '/home/share/pay-admin/',`
## 单独部署
`npm run deploy`

## 打tag 生成changelog
`npm run changelog`

## 打tag
`git tag`  查看tag
`git tag v0.1.1` 添加tag
`git push origin tag v0.1.1`  推送tag


####  代理配置

本地代理：
-   package.json  proxy: http://127.0.0.1/


`Fiddler` 线上代理：

- `regex:^https?:\/\/xx\.com/(.*\.map.*)$` `d:/my/build/$1`
  代理静态资源访问本地map。使用说明https://blog.csdn.net/hahavslinb/article/details/78791219


### 发布

| 发布产品 | 发布模块 |
| --- | --- |
| `[xxx]` | `[xxx]` |

> 发布时的备注

### 错误告警及监控
使用sentry错误日志上报http://223.203.221.89:9000/sentry/merchant-operation/


### 相关人员

| 角色 | 人员 |
| --- | --- |
| 产品经理 | 老宋 |
| 前端开发 | 钱明卫，吴宇 |
| 后台开发 | 刘晗 |
| 交互设计 | 钱明卫 |


### 其他

- [原型](http://223.203.221.51/axure_html)
- [接口文档](http://223.203.221.49:3100/project/11/interface/api)



> 项目备注
