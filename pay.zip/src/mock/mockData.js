import mockjs from 'mockjs';
import urlMaps from '../common/urlMaps';

let mockData = {
  [`GET ${urlMaps.getUserInfo}`]: () => {
    return success({
      name: 'daycool',
      email: 'qmw920@163.com'
    });
  },
  [`POST ${urlMaps.login}`]: () => {
    return success({
      name: 'daycool',
      email: 'qmw920@163.com'
    });
  },
  [`POST ${urlMaps.register}`]: () => {
    return success({
      name: 'daycool',
      email: 'qmw920@163.com'
    });
  },
  [`POST ${urlMaps.logout}`]: () => {
    return success({
      name: 'daycool',
      email: 'qmw920@163.com'
    });
  },
  // [`GET ${urlMaps.getFinanceStat}`]: () => {
  //   return success({
  //     lastSettleTime: '20180620',
  //     curr: [
  //       { name: 'today', label: '本期流水', 'value|100-500': 100 },
  //       { name: 'yesterday', label: '本期到账', 'value|100-500': 100 },
  //       {
  //         name: 'week',
  //         label: '本期在途',
  //         'value|100-500': 100
  //       },
  //       {
  //         name: 'month',
  //         label: '本期未收',
  //         'value|100-500': 100
  //       },
  //       {
  //         name: 'month',
  //         label: '往期复核',
  //         'value|100-500': 100
  //       }
  //     ],
  //     total: [
  //       {
  //         name: 'receivable',
  //         label: '总流水',
  //         'value|100-500': 100
  //       },
  //       { name: 'unreceptive', label: '总订单量', 'value|100-500': 100 },
  //       { name: 'wey', label: '总到账', 'value|100-500': 100 }
  //     ]
  //   });
  // },
  // [`GET ${urlMaps.getPastStatList}`]: () => {
  //   return success({
  //     ts: 1532492849,
  //     page: 1,
  //     pageSize: 20,
  //     'list|30-100': [
  //       {
  //         'id|+1': 100,
  //         time: '@date("yyyy-MM-dd")~@date("yyyy-MM-dd")',
  //         currFlow: '11111',
  //         currIncome: '11111',
  //         currWay: '11111',
  //         realIncome: '11111',
  //         passRecheck: '11111',
  //         platformTrans: '11111',
  //         status: '结算完成'
  //       }
  //     ]
  //   });
  // },
  // [`GET ${urlMaps.getIncomeDetail}`]: () => {
  //   return success({
  //     ts: 1532492849,
  //     page: 1,
  //     pageSize: 20,
  //     'list|30-100': [
  //       {
  //         'id|+1': 100,
  //         bankAccount: '1111',
  //         incomeBank: '11111',
  //         incomePrice: '11111',
  //         wayPice: '11111'
  //       }
  //     ]
  //   });
  // },
  [`GET ${urlMaps.getTransDetail}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          time: '@date("yyyy-MM-dd")~@date("yyyy-MM-dd")',
          account: '11111',
          price: '11111',
          status: '已到账',
          time: '@date(yyy-MM-dd)',
          img: '@image("200x200")'
        }
      ]
    });
  },
  // [`GET ${urlMaps.getYollonList}`]: () => {
  //   return success({
  //     ts: 1532492849,
  //     page: 1,
  //     pageSize: 20,
  //     'list|30-100': [
  //       {
  //         'id|+1': 100,
  //         incomeAccount: '333333333',
  //         endTime: '@date("yyyy-MM-dd")',
  //         incomeLimit: '333333333',
  //         incomePrice: '333333333',
  //         wayPice: '333333333',
  //         currPrice: '333333333',
  //         currWayPrice: '333333333',
  //         status: '收款中'
  //       }
  //     ]
  //   });
  // },
  // [`GET ${urlMaps.getYollonDetail}`]: () => {
  //   return success({
  //     ts: 1532492849,
  //     page: 1,
  //     pageSize: 20,
  //     'list|30-100': [
  //       {
  //         'id|+1': 100,
  //         account: '11111',
  //         period: '11111',
  //         price: '11111',
  //         status: '已到账',
  //         incomeTime: '@date("yyyy-MM-dd")',
  //         img: '@image("200x100")'
  //       }
  //     ]
  //   });
  // },
  // [`GET ${urlMaps.getYollon}`]: () => {
  //   return success({
  //     account: '11111',
  //     username: '11111',
  //     startTime: '@date("yyyy-MM-dd")',
  //     endTime: '@date("yyyy-MM-dd")',
  //     status: '已停用'
  //   });
  // },
  // [`POST ${urlMaps.saveYollon}`]: () => {
  //   return success({
  //     account: '11111',
  //     username: '11111',
  //     startTime: '@date("yyyy-MM-dd")',
  //     endTime: '@date("yyyy-MM-dd")'
  //   });
  // },
  // [`GET ${urlMaps.getAccount}`]: () => {
  //   return success({
  //     merchantName: 'daycool',
  //     merchantId: '130682199909999999',
  //     phone: '15888888888',
  //     status: 1,
  //     createAt: '@date("yyyy-MM-dd")'
  //   });
  // },
  // [`GET ${urlMaps.getStat}`]: () => {
  //   return success({
  //     deal: [
  //       { name: 'today', label: '今天交易', 'value|100-500': 100 },
  //       { name: 'yesterday', label: '昨天交易', 'value|100-500': 100 },
  //       { name: 'week', label: '本周交易', 'value|100-500': 100 },
  //       { name: 'month', label: '本月交易', 'value|100-500': 100 }
  //     ],
  //     order: [
  //       { name: 'today', label: '今天订单', 'value|100-500': 100 },
  //       { name: 'yesterday', label: '昨天订单', 'value|100-500': 100 },
  //       { name: 'week', label: '本周订单', 'value|100-500': 100 },
  //       { name: 'month', label: '本月订单', 'value|100-500': 100 }
  //     ],

  //     finishedDeal: [
  //       { name: 'today', label: '今天完成交易', 'value|100-500': 100 },
  //       { name: 'yesterday', label: '昨天完成交易', 'value|100-500': 100 },
  //       { name: 'week', label: '本周完成交易', 'value|100-500': 100 },
  //       { name: 'month', label: '本月完成交易', 'value|100-500': 100 }
  //     ],

  //     finishedOrder: [
  //       { name: 'today', label: '今天完成订单', 'value|100-500': 100 },
  //       { name: 'yesterday', label: '昨天完成订单', 'value|100-500': 100 },
  //       { name: 'week', label: '本周完成订单', 'value|100-500': 100 },
  //       { name: 'month', label: '本月完成订单', 'value|100-500': 100 }
  //     ],
  //     total: [
  //       { name: 'receivable', label: '累计应收', 'value|100-500': 100 },
  //       { name: 'receipted', label: '累计实收', 'value|100-500': 100 },
  //       { name: 'unreceptive', label: '累计未收', 'value|100-500': 100 },
  //       { name: 'wey', label: '在途金额', 'value|100-500': 100 }
  //     ]
  //   });
  // },

  // [`POST ${urlMaps.saveAccount}`]: () => {
  //   return success({
  //     merchantName: 'daycool',
  //     merchantId: '130682199909999999',
  //     status: 1,
  //     phone: '15888888888',
  //     createAt: '@date("yyyy-MM-dd")'
  //   });
  // },
  // [`POST ${urlMaps.saveAccountAuth}`]: () => {
  //   return success({
  //     username: 'daycool',
  //     phone: '15888888888',
  //     idCard: '130682199909999999',
  //     addr: '河北',
  //     idCardFront:
  //       'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1531730258383&di=c06768e19ee83454f1fcadbd1c540040&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20171111%2F8a2058c30d614674a4fa7e40cf171ebf.jpeg',
  //     idCardBack:
  //       'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1532324954&di=81c80e633026f3246ab4a0f9f17db3c1&imgtype=jpg&er=1&src=http%3A%2F%2Fimgsrc.baidu.com%2Fimage%2Fc0%253Dpixel_huitu%252C0%252C0%252C294%252C40%2Fsign%3Db05d0b3c38fa828bc52e95a394672458%2Fd788d43f8794a4c2717d681205f41bd5ad6e39a8.jpg'
  //   });
  // },
  // [`GET ${urlMaps.getRealAuthInfo}`]: () => {
  //   return success({
  //     username: 'daycool',
  //     phone: '15888888888',
  //     idCard: '130682199909999999',
  //     addr: '河北',
  //     idCardFront:
  //       'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1531730258383&di=c06768e19ee83454f1fcadbd1c540040&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20171111%2F8a2058c30d614674a4fa7e40cf171ebf.jpeg',
  //     idCardBack:
  //       'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1532324954&di=81c80e633026f3246ab4a0f9f17db3c1&imgtype=jpg&er=1&src=http%3A%2F%2Fimgsrc.baidu.com%2Fimage%2Fc0%253Dpixel_huitu%252C0%252C0%252C294%252C40%2Fsign%3Db05d0b3c38fa828bc52e95a394672458%2Fd788d43f8794a4c2717d681205f41bd5ad6e39a8.jpg'
  //   });
  // },
  // [`POST ${urlMaps.saveRealAuthInfo}`]: () => {
  //   return success({
  //     username: 'daycool',
  //     phone: '15888888888',
  //     idCard: '130682199909999999',
  //     addr: '河北',
  //     idCardFront:
  //       'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1531730258383&di=c06768e19ee83454f1fcadbd1c540040&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20171111%2F8a2058c30d614674a4fa7e40cf171ebf.jpeg',
  //     idCardBack:
  //       'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1532324954&di=81c80e633026f3246ab4a0f9f17db3c1&imgtype=jpg&er=1&src=http%3A%2F%2Fimgsrc.baidu.com%2Fimage%2Fc0%253Dpixel_huitu%252C0%252C0%252C294%252C40%2Fsign%3Db05d0b3c38fa828bc52e95a394672458%2Fd788d43f8794a4c2717d681205f41bd5ad6e39a8.jpg'
  //   });
  // },
  [`GET ${urlMaps.getOrderList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          name: '1111',
          payType: '1111',
          createdAt: '@date("yyyy-MM-dd")',
          merchant: '1111',
          goods: '1111',
          price: '1111',
          proxy: '1111',
          'status|0-5': 0
        }
      ]
    });
  },
  [`POST ${urlMaps.orderNotify}`]: () => {
    return success({
      status: 2
    });
  },
  [`GET ${urlMaps.getIncomeAccountList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          username: '1111',
          password: '1111',
          account: '1111',
          accountType: '1111',
          price: '1111',
          note: '1111',
          endTime: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`POST ${urlMaps.saveIncomeAccount}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getIncomeList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          time: '@date("yyyy-MM-dd HH:mm:ss")',
          price: '1111',
          img: '@image("200x200")',
          type: '1111',
          checkCode: '1111'
        }
      ]
    });
  },
  [`POST ${urlMaps.confirmIncome}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getApiInterface}`]: () => {
    return success({
      uid: '123456',
      token: '444444444444444',
      ip: '192.168.1.1'
    });
  },
  [`POST ${urlMaps.saveApiInterface}`]: () => {
    return success({
      uid: '123456',
      token: '444444444444444',
      ip: '192.168.1.1'
    });
  },
  [`POST ${urlMaps.resetApiInterface}`]: () => {
    return success({
      uid: '123456',
      token: '@guid()',
      ip: '192.168.1.1'
    });
  },
  [`GET ${urlMaps.getClearingRecordInfo}`]: () => {
    return success({
      nowList: [
        {
          'id|+1': 1,
          ach_id: 'ccpay:nowList',
          amount: 'http://test.522zf.com',
          price: 123,
          his_amount: 100
        }
      ],
      hisList: [
        {
          'id|+1': 1,
          ach_id: 'ccpay:hisList',
          amount: 'http://test.522zf.com',
          price: 258,
          his_amount: 350
        }
      ]
    });
  },
  //财务
  //代理转账
  [`GET ${urlMaps.getProxyTransferInfo}`]: () => {
    return success({
      flow_id: '13333401419',
      endTime: '@date("yyyy-MM-dd HH:mm:ss")',
      ach_id: '100,100',
      way_name: 0,
      card_no: '10,333',
      card_owner: '103,330',
      ticket: '@image("200x200")'
    });
  },
  [`GET ${urlMaps.getProxyClearing}`]: () => {
    return success({
      account: '13333401419',
      name: '张三',
      amount: '100,100',
      'groupCount|+1': 0,
      perIncome: '10,333',
      groupIncome: '103,330',
      notClearing: '78,900'
    });
  },
  //总代
  [`GET ${urlMaps.getFatherClearingDetail}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': '10',
          time: '@date("yyyy-MM-dd HH:mm:ss")',
          username: '总代',
          payType: 200,
          team_income_total: '100,100',
          'team_total|2-6': 2,
          'status|1-2': 1
        }
      ]
    });
  },
  //子代
  [`GET ${urlMaps.getSonClearingDetail}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-150': [
        {
          'id|+1': '10',
          time: '@date("yyyy-MM-dd HH:mm:ss")',
          username: '总代',
          account: '代理',
          payType: 200,
          individual_income_total: '100,100',
          'team_total|2-8': 5,
          'status|1-2': 1
        }
      ]
    });
  },
  // 代理
  [`GET ${urlMaps.getProxyList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      total: 1000,
      'list|30-100': [
        {
          'id|+1': 100,
          'account|+1': 18911031111,
          username: '天凉了',
          level: '1',
          invitate_code: '200',
          'status|0-2': 0,
          'audit_status|0-2': 0,
          created_at: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  //代理树
  [`GET ${urlMaps.getProxyTreeList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          account: '18201807270',
          id: 12,
          level: 1,
          name: '大爷',
          children: [
            {
              id: 14,
              name: '老宋',
              account: '15811459942',
              level: 2,
              children: [
                {
                  id: 27,
                  name: '刘晗',
                  account: '13050531001',
                  level: 3,
                  children: []
                }
              ]
            },
            {
              id: 13,
              name: '燕姐',
              account: '18911031111',
              level: 2,
              children: []
            }
          ]
        },
        {
          account: '18888888888',
          children: null,
          id: 24,
          level: 1,
          name: 'good',
          children: null
        },
        {
          account: '18222222222',
          children: null,
          id: 26,
          level: 1,
          name: '二营长',
          children: null
        },
        {
          account: '13333333333',
          children: null,
          id: 28,
          level: 1,
          name: '总代理？',
          children: []
        }
      ]
    });
  },
  [`GET ${urlMaps.getCreateProxy}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          'ProxyId|+1': 20180808160907456,
          'number|+1': 18334771413,
          password: '123456aa',
          name: 'zzzx'
        }
      ]
    });
  },
  [`POST ${urlMaps.saveCreateProxy}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getProxyAccout}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          'ProxyId|+1': 20180808160907456,
          'status|0-1': 0,
          Number: 18834771413,
          payLimit: 0,
          proxyAccout: 18834771413,
          nextAccout: 'zxc',
          codeNum: 0,
          'idCard|2': ['@image("200x100")']
        }
      ]
    });
  },
  [`POST ${urlMaps.saveProxyAccout}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getProxyInfo}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'ProxyId|+1': 20180808160907456,
          'number|+1': 18334771413,
          proxyName: 'zxc',
          realName: 'zxc',
          'status|0-5': 0
        }
      ]
    });
  },
  [`GET ${urlMaps.getNextCreateProxy}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'ProxyId|+1': 20180808160907456,
          number: 18834771413,
          password: '123456aa',
          shareCode: 'zxvc5456',
          name: 'zzz',
          idCard: 140603199306024999,
          idCardFront: '@image("200x150")',
          idCardBack: '@image("200x150")'
        }
      ]
    });
  },
  [`POST ${urlMaps.saveNextCreateProxy}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getIncomeDetailInfo}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          'ProxyId|+1': 20180808160907456,
          name: 'zzz',
          number: 18834771413,
          payLimit: 1111000,
          useLimit: 1000,
          restLimit: 1110000
        }
      ]
    });
  },
  [`POST ${urlMaps.saveIncomeDetailInfo}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getAddLimitInfo}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'ProxyId|+1': 20180808160907456,
          limit: 1110000
        }
      ]
    });
  },
  [`POST ${urlMaps.saveAddLimitInfo}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getStatusEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          'ProxyId|+1': 20180808160907456
        }
      ]
    });
  },
  [`POST ${urlMaps.saveStatusEdit}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getPayLimit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 100,
          'proxyAccount|+1': 18834771413,
          bankAccount: 'rentianfeiwu',
          bank: '中国银行',
          limit: '1000000.00元',
          'checkCode|+1': 1060,
          ticket: '@image("200x200")',
          account: '科技局',
          createAt: '@date("yyyy-MM-dd HH:mm:ss")',
          updateTime: '@date("yyyy-MM-dd HH:mm:ss")',
          'status|0-5': 0
        }
      ]
    });
  },
  [`GET ${urlMaps.getPayLimitEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          'ProxyId|+1': 20180808160907456
        }
      ]
    });
  },
  [`POST ${urlMaps.savePayLimitEdit}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getReduceLimit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 100,
          'proxyAccount|+1': 18834771413,
          reduceLimit: '1000.00元',
          'status|0-5': 0,
          createAt: '@date("yyyy-MM-dd HH:mm:ss")',
          updateTime: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getReduceLimitEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          'ProxyId|+1': 20180808160907456
        }
      ]
    });
  },
  [`POST ${urlMaps.saveReduceLimitEdit}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getRealCheck}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 100,
          'proxy|+1': 18834771413,
          realName: '1000.00元',
          number: 13333401419,
          idCardNum: 140603199306024999,
          'idCard|2': ['@image(200x200)'],
          'status|0-5': 0
        }
      ]
    });
  },
  [`GET ${urlMaps.getRealCheckEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          'ProxyId|+1': 20180808160907456
        }
      ]
    });
  },
  [`POST ${urlMaps.saveRealCheckEdit}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getCodeManage}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 100,
          proxyAccout: '18834771413',
          payType: 'weixin',
          payAccout: '793694132@qq.com',
          payName: '王五',
          payImg: '@image("200x200")',
          'price|+1': 123,
          'status|0-5': 0,
          createAt: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getCodeManageEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          'ProxyId|+1': 20180808160907456
        }
      ]
    });
  },
  [`POST ${urlMaps.saveCodeManageEdit}`]: () => {
    return success({});
  },
  // 对账单
  [`GET ${urlMaps.getOrderInfo}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'orderId|+1': 2018071317353883,
          payName: 'zxc',
          payType: 'zxc',
          created: '@date("yyyy-MM-dd HH:mm:ss")',
          account: 'zxc',
          goods: 'zxc',
          price: 'zxc',
          proxy: 'zxc',
          'status|0-5': 0
        }
      ]
    });
  },
  [`GET ${urlMaps.getProxyIncome}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 20180808160907456,
          'user|+1': 18334771413,
          price: 222,
          dayEnd: '@date("yyyy-MM-dd HH:mm:ss")',
          'status|0-5': 0
        }
      ]
    });
  },
  [`GET ${urlMaps.getProxyIncomeEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 20180808160907456,
          'status|0-5': 0
        }
      ]
    });
  },
  [`POST ${urlMaps.saveProxyIncomeEdit}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getProxyIncomeDetail}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|3-5': [
        {
          'flowId|+1': 20180808160907456,
          user: 18334771413,
          price: 222,
          time: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`POST ${urlMaps.saveProxyIncomeDetail}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getProfitFlow}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 20180808160907456,
          proxy: 'zxc',
          time: '@date("yyyy-MM-dd HH:mm:ss")',
          price: 222,
          status: '1'
        }
      ]
    });
  },
  [`GET ${urlMaps.getProfitFlowEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|3-5': [
        {
          'flowId|+1': 20180808160907456,
          user: 18334771413,
          price: 222,
          time: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`POST ${urlMaps.saveProfitFlowEdit}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getPlatformAccounts}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 244102987310436353,
          'merchantId|+1': 666,
          price: 222,
          editor: 'admin',
          editTime: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getOrderFeedback}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 20180808160907456,
          payType: 'zxc',
          createAt: '@date("yyyy-MM-dd HH:mm:ss")',
          account: 'zxc',
          goods: 'zxc',
          price: 222,
          proxy: 'zxc',
          img: '@image("200x200")',
          time: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getStatement}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 20180808160907456,
          endTime: '@date("yyyy-MM-dd HH:mm:ss")',
          merchantId: 11,
          proxyId: 22,
          price: 222,
          bankName: '中国银行',
          bankAccount: 6217858100003511010,
          img: '@image("50x50")',
          holder: '张三',
          checkCode: '45612',
          status: 1
        }
      ]
    });
  },
  [`GET ${urlMaps.getStatementEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 20180808160907456,
          'status|0-5': 0
        }
      ]
    });
  },
  [`POST ${urlMaps.saveStatementEdit}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getStatementRepay}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      list: [
        {
          'flowId|+1': 20180808160907456,
          title: ''
        }
      ]
    });
  },
  [`POST ${urlMaps.saveStatementRepay}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getOrderRelist}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'orderId|+1': 2441022018081301,
          payType: '支付宝',
          createAt: '@date("yyyy-MM-dd HH:mm:ss")',
          account: 'ww',
          goods: 'apple',
          price: 222,
          proxy: 'ls',
          payTime: '@date("yyyy-MM-dd HH:mm:ss")',
          disc: 'dfdkfjslkfj'
        }
      ]
    });
  },
  [`GET ${urlMaps.getFeedbackList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          title: '垃圾',
          status: '1',
          time: '@date("yyyy-MM-dd HH:mm:ss")',
          'imgs|1-4': ['@image("200x100")']
        }
      ]
    });
  },
  [`POST ${urlMaps.saveFeedbackEdit}`]: () => {
    return success();
  },
  [`POST ${urlMaps.changeStatus}`]: () => {
    return success({ status: 1 });
  },
  [`POST ${urlMaps.transAccount}`]: () => {
    return success({
      totalIncome: 222,
      totalRealIncome: 222
    });
  },
  [`POST ${urlMaps.settleAccount}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getUserAccuseAudit}`]: () => {
    return success({
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'orderId|+1': 300,
          createdAt: '@date("yyyy-MM-dd HH:mm:ss")',
          merchants: '222',
          goods: '222',
          price: '222',
          proxy: '222',
          payTime: '@date("yyyy-MM-dd HH:mm:ss")',
          'status|0-5': 0
        }
      ]
    });
  },
  [`GET ${urlMaps.getOrderReviewList}`]: () => {
    return success({
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'orderId|+1': 400,
          createdAt: '@date("yyyy-MM-dd HH:mm:ss")',
          merchants: '222',
          goods: '222',
          price: '222',
          actualPay: '222',
          proxy: '222',
          actualPayTime: '@date("yyyy-MM-dd HH:mm:ss")',
          disc: '222'
        }
      ]
    });
  },
  [`GET ${urlMaps.getFeedbackInfo}`]: () => {
    return success({
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 20180808160907456,
          provider: '222',
          title: '222',
          fdContent: '222',
          replyContent: '222',
          replyStatus: '222',
          fdTime: '222',
          img: '@image("200x200")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getFeedbackEditInfo}`]: () => {
    return success({
      list_: [
        {
          'id|+1': 1,
          status: '',
          fdContent: ''
        }
      ]
    });
  },
  [`POST ${urlMaps.saveFeedbackEdit}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getOperationFlow}`]: () => {
    return success({
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'flowId|+1': 20180808160907456,
          'managerId|+1': 1,
          url: '@url()',
          title: 'title',
          datas: '1',
          ip: '@ip()',
          operationTime: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getOperationPriceRecord}`]: () => {
    return success({
      page: 1,
      pageSize: 20,
      'list|30-150': [
        {
          'flowId|+1': 20180808160907456,
          userName: 'asd',
          price: 123,
          dayEndTime: '@date("yyyy-MM-dd")',
          status: 1
        }
      ]
    });
  },
  [`GET ${urlMaps.getSystemConfig}`]: () => {
    return success({
      list_domain: [
        {
          'id|+1': 1,
          key: 'ccpay:MasterDomain',
          value: 'http://test.522zf.com'
        }
      ],
      list_white: [
        {
          'id|+1': 1,
          key: 'ccpay:GlobalWhite',
          value: '45.248.86.188,127.0.0.1,222.128.84.18'
        }
      ]
    });
  },
  [`GET ${urlMaps.getProxyPrice}`]: () => {
    return success({
      page: 1,
      pageSize: 20,
      'list|30-150': [
        {
          'flowId|+1': 1,
          proxyName: 'w1',
          operateLimit: 0,
          operateName: 'admin',
          operateTime: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getSystemConfigEdit}`]: () => {
    return success({
      list_: [
        {
          'id|+1': 1,
          key: '',
          value: ''
        }
      ]
    });
  },
  [`POST ${urlMaps.saveSystemConfig}`]: () => {
    return success({});
  },
  //二维码
  [`GET ${urlMaps.getQrcodeSource}`]: () => {
    return success([
      { PayType: 100, Amount: '流水', Len: 100, Accounts: ['15811459942'] },
      { PayType: 200, Amount: '订单量', Len: 70, Accounts: ['13333401419'] },
      { PayType: 200, Amount: '到账', Len: 30 },
      { PayType: 100, Amount: '11', Len: 50 }
      // {
      //   PayType: 200, // 100:支付宝 200微信
      //   Amount: 12, // 金额，TODO:可能需要除100
      //   Len: 1, // 可用长度
      //   Accounts: ['15811459942']
      // },
      // {
      //   PayType: 200, // 100:支付宝 200微信
      //   Amount: 13, // 金额，TODO:可能需要除100
      //   Len: 1, // 可用长度
      //   Accounts: ['15811459942']
      // }
    ]);
    // lastSettleTime: '20180620',
    // total: [
    //   { name: 'receivable', label: '总流水', 'Len|100-500': 100 },
    //   { name: 'unreceptive', label: '总订单量', 'Len|100-500': 100 },
    //   { name: 'wey', label: '总到账', 'Len|100-500': 100 }
    // ],
    // lastSettleTime: '20180620',
    // curr: [
    //   { name: 'today', label: '本期流水', 'value|100-500': 100 },
    //   { name: 'yesterday', label: '本期到账', 'value|100-500': 100 },
    //   { name: 'week', label: '本期在途', 'value|100-500': 100 },
    //   { name: 'month', label: '本期未收', 'value|100-500': 100 },
    //   { name: 'month', label: '往期复核', 'value|100-500': 100 }
    // ],
    // total: [
    //   { name: 'receivable', label: '总流水', 'value|100-500': 100 },
    //   { name: 'unreceptive', label: '总订单量', 'value|100-500': 100 },
    //   { name: 'wey', label: '总到账', 'value|100-500': 100 }
    // ]
    // });
  },
  [`POST ${urlMaps.changeStatus}`]: () => {
    return success({ status: 1 });
  },
  [`POST ${urlMaps.transAccount}`]: () => {
    return success({
      totalIncome: 222,
      totalRealIncome: 222
    });
  },
  [`POST ${urlMaps.settleAccount}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getMerchantList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          merchantId: '1111',
          merchantName: '1111',
          totalIncome: '1111',
          totalRealIncome: '11111',
          totalUnIncome: '1111',
          'status|0-1': 0
        }
      ]
    });
  },
  //账户详情
  [`GET ${urlMaps.getAccountAuditList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          account: '李四',
          open: '张三',
          startTime: '@date("yyyy-MM-dd HH:mm:ss")',
          endTime: '@date("yyyy-MM-dd HH:mm:ss")',
          'status|1-2': 1
        }
      ]
    });
  },
  [`GET ${urlMaps.getAccountDetail}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          account: '李四',
          open: '张三',
          startTime: '@date("yyyy-MM-dd HH:mm:ss")',
          endTime: '@date("yyyy-MM-dd HH:mm:ss")',
          'status|1-2': 1
        }
      ]
    });
  },
  //收款详情
  [`GET ${urlMaps.getAmountDetail}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          account: 'asd',
          period: '本期',
          price: '1,111',
          proxy: '你好',
          'code|+1': 10000,
          'status|1-2': 1,
          endTime: '@date("yyyy-MM-dd HH:mm:ss")',
          price: '1,111',
          receiptedPrice: '1111',
          note: '1111',
          created: '@date("yyyy-MM-dd HH:mm:ss")',
          assessor: 'admin',
          img: '@image("100x100")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getAccountAuditList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          account: 'asdasd',
          merchantId: '1111',
          pageType: '1111',
          incomeAccount: '1111',
          accountPerson: '11111',
          'status|0-5': 0,
          endTime: '201809201236',
          price: '1111',
          receiptedPrice: '1111',
          note: '1111',
          updatedAt: '@date("yyyy-MM-dd")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getRealAuthAuditList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'id|+1': 100,
          merchantName: '1111',
          realName: '1111',
          phone: '121111',
          idCard: '1111',
          idCardImgs: '1111',
          status: '1111'
        }
      ]
    });
  },
  [`GET ${urlMaps.getAdministrator}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'userId|+1': 10,
          username: 'manager',
          group: 'admin',
          updateTime: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getAdministratorEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'userId|+1': 10,
          username: 'maneger',
          password: '123456',
          group: 'admin'
        }
      ]
    });
  },
  [`POST ${urlMaps.savaAdministratorEdit}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getCodeSource}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'userId|+1': 10,
          payType: 'weixin',
          'price|+1': 159,
          amount: 258
        }
      ]
    });
  },
  [`GET ${urlMaps.getBlackList}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'userId|+1': 10,
          ip: '192.168.1.1',
          endTime: '@date("yyyy-MM-dd HH:mm:ss")'
        }
      ]
    });
  },
  [`GET ${urlMaps.getBlackListInfo}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'userId|+1': 10,
          ip: '192.168.1.1'
        }
      ]
    });
  },
  [`POST ${urlMaps.saveBlackListInfo}`]: () => {
    return success({});
  },
  [`GET ${urlMaps.getBlackListEdit}`]: () => {
    return success({
      ts: 1532492849,
      page: 1,
      pageSize: 20,
      'list|30-100': [
        {
          'userId|+1': 10,
          ip: '192.168.1.1'
        }
      ]
    });
  },
  [`POST ${urlMaps.saveBlackListEdit}`]: () => {
    return success({});
  }
};

export default mockData;

function success(data, msg, code) {
  return {
    code: code || 200,
    msg: msg || '请求成功',
    data: mockjs.mock(data || {})
  };
}

function fail(code, msg, data) {
  return {
    code: code || 10001,
    msg: msg || '请求失败',
    data: mockjs.mock(data || {})
  };
}
