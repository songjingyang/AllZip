import { isUrl, dateFormater } from './utils'

describe('test utils', () => {
  it('test url', () => {
    expect(isUrl('http://www.baidu.com')).toEqual(true)
  })

  it(
    ('test https url', () => {
      expect(isUrl('https://www.baidu.com').toEqual(true))
    })
  )

  it('test urls', () => {
    expect(isUrl('www.baidu.com')).toEqual(true)
  })

  it('test date formater', () => {
    expect(dateFormater(new Date())).toEqual('YYYY-MM-DD HH:mm:ss')
  })
})
