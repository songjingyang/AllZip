import puppeteer from 'puppeteer'
import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'

describe('Login', () => {
  let browser
  let page

  beforeAll(async () => {
    browser = await puppeteer.launch({ args: ['--no-sandbox'] })
  })

  beforeEach(async () => {
    page = await browser.newPage()
    await page.goto('http://localhost:3000/#/user/login', {
      waitUntil: 'networkidle2'
    })
    await page.evaluate(() =>
      window.localStorage.setItem('antd-pro-authority', 'guest')
    )
  })

  afterEach(() => page.close())

  it('网络连接', async () => {
    await page.setViewport({ width: 1858, height: 1014 })
    await page.goto('http://localhost:3000/#/user/userLogin')
    let text = await page.evaluate(() => {
      return document.title
    })
    expect(text).toContain('运营管理平台')
  })

  // it('puppeteer login', async () => {
  //   // const browser = await puppeteer.launch()
  //   // const page = await browser.newPage()

  //   await page.setViewport({ width: 1858, height: 1014 })

  //   await page.goto('http://localhost:3000/#/user/userLogin')

  //   // const navigationPromise = page.waitForNavigation()
  //   // await navigationPromise

  //   await page.waitForSelector(
  //     '.ant-form-item-control-wrapper > .ant-form-item-control > .ant-form-item-children > .ant-input-affix-wrapper > #name',
  //     {
  //       timeout: 2000
  //     }
  //   )
  //   await page.click(
  //     '.ant-form-item-control-wrapper > .ant-form-item-control > .ant-form-item-children > .ant-input-affix-wrapper > #name'
  //   )

  //   await page.type(
  //     '.ant-form-item-control-wrapper > .ant-form-item-control > .ant-form-item-children > .ant-input-affix-wrapper > #name',
  //     'admin'
  //   )

  //   await page.waitForSelector(
  //     '.ant-row > .ant-form-item-control-wrapper > .ant-form-item-control > .ant-form-item-children > .ant-btn'
  //   )
  //   await page.click(
  //     '.ant-row > .ant-form-item-control-wrapper > .ant-form-item-control > .ant-form-item-children > .ant-btn'
  //   )
  //   await page.type(
  //     '.ant-row > .ant-form-item-control-wrapper > .ant-form-item-control > .ant-form-item-children > .ant-btn',
  //     'asd402402'
  //   )

  //   // await browser.close()
  // })

  afterAll(() => browser.close())
})
