import http from '@/common/request';
import { Object } from 'core-js';

export default {
  namespace: 'order',
  state: {
    stat: {
      total: []
    },
    orderInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    orderInfoEdit: {
      bu_name: '',
      product_id: '',
      extend: ''
    },
    proxyIncome: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyIncomeEdit: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyIncomeDetail: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    profitFlowEdit: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    orderFeedback: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    statement: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    statementEdit: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    statementRepay: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    platformAccounts: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    orderReviewAll: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    toOrderCheckDatasInfo:{
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyPushNotice: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    }
  },
  effects: {
    
    *toOrderCheckDatas({ payload, callback }, { call, put, select }) {
      const res = yield call(http.toOrderCheckDatas, payload);
      if (res.code === 200) {
        yield put({
          type: 'toOrderCheckDatasInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getOrderInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getOrderInfo, payload);
      if (res.code === 200) {
        if (res.data.list !== null) {
          yield put({
            type: 'orderInfo',
            payload: res.data
          });
        } else {
          console.log('Caught an effects getOrderInfo error');
          yield put({
            type: 'orderInfo',
            payload: {
              list: []
            }
          });
        }
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getOrdeNotify({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getOrdeNotify, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'updateOrdeNotify',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getForcedReview({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getForcedReview, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'updateForcedReview',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getOrderInfoEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getOrderInfoEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'updateOrderInfo',
          payload: payload
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveOrderInfoEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveOrderInfoEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'updateOrderInfo',
          payload: payload
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *orderInfoNotify({ payload, callback }, { call, put, select }) {
      const res = yield call(http.orderInfoNotify, payload);
      if (res.code === 200) {
        yield put({
          type: 'updateOrderInfo',
          payload: payload
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getProxyIncome({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyIncome, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyIncome',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getProxyIncomeEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyIncomeEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyIncomeEdit',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *saveProxyIncomeEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveProxyIncomeEdit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'proxyIncomeEdit',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getProxyIncomeDetail({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyIncomeDetail, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyIncomeDetail',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *saveProxyIncomeDetail({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveProxyIncomeDetail, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'proxyIncomeDetail',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getOrderFeedback({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getOrderFeedback, payload);
      if (res.code === 200) {
        yield put({
          type: 'orderFeedback',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getStatement({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getStatement, payload);
      if (res.code === 200) {
        yield put({
          type: 'statement',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getStatementEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getStatementEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'statementEdit',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *saveStatementEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveStatementEdit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'statementEdit',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getStatementRepay({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getStatementRepay, payload);
      if (res.code === 200) {
        yield put({
          type: 'statementRepay',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *saveStatementRepay({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveStatementRepay, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'statementRepay',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getPlatformAccounts({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getPlatformAccounts, payload);
      if (res.code === 200) {
        yield put({
          type: 'platformAccounts',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getOrderReviewAll({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getOrderReviewAll, payload);
      if (res.code === 200) {
        yield put({
          type: 'orderReviewAll',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getProxyPushNotice({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPushNotice, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyPushNotice',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    }
    // * getProxyPushNoticeEdit ({ payload, callback }, { call, put, select }) {
    //   const res = yield call(http.getProxyPushNoticeEdit, payload)
    //   if (res.code === 200) {
    //     yield put({
    //       type: 'updateProxyPushNotice',
    //       payload: payload
    //     })
    //   }
    //   if (callback) {
    //     callback(res)
    //   }
    // },
    // * saveProxyPushNoticeEdit ({ payload, callback }, { call, put, select }) {
    //   const res = yield call(http.saveProxyPushNoticeEdit, payload)
    //   if (res.code === 200) {
    //     yield put({
    //       type: 'updateProxyPushNotice',
    //       payload: payload
    //     })
    //   }
    //   if (callback) {
    //     callback(res)
    //   }
    // },
    // * updateDelete ({ payload, callback }, { call, put, select }) {
    //   const res = yield call(http.updateDelete, payload)
    //   if (res.code === 200) {
    //     yield put({
    //       type: 'orderReviewAll',
    //       payload: res.data
    //     })
    //     if (callback) {
    //       callback(res)
    //     }
    //   }
    // }
  },
  reducers: {
    
    toOrderCheckDatasInfo(state, { payload }) {
      return {
        ...state,
        toOrderCheckDatasInfo: { ...payload }
      };
    },
    orderInfo(state, { payload }) {
      // for (let i = 0; i < payload.list.length; i++) {
      //   payload.list[i].amount /= 100
      // }
      return {
        ...state,
        orderInfo: {
          ...payload
        }
      };
    },
    orderInfoEdit(state, { payload }) {
      return {
        ...state,
        orderInfoEdit: { ...payload }
      };
    },
    updateOrdeNotify(state, { payload }) {
      return {
        ...state,
        orderInfo: {
          ...state.orderInfo
        }
      };
    },
    updateForcedReview(state, { payload }) {
      return {
        ...state,
        orderInfo: {
          ...state.orderInfo
        }
      };
    },
    proxyIncome(state, { payload }) {
      return {
        ...state,
        proxyIncome: { ...payload }
      };
    },
    proxyIncomeEdit(state, { payload }) {
      return {
        ...state,
        proxyIncomeEdit: { ...payload }
      };
    },
    proxyIncomeDetail(state, { payload }) {
      return {
        ...state,
        proxyIncomeDetail: { ...payload }
      };
    },
    statementEdit(state, { payload }) {
      return {
        ...state,
        statementEdit: { ...payload }
      };
    },
    statementRepay(state, { payload }) {
      return {
        ...state,
        statementRepay: { ...payload }
      };
    },
    orderFeedback(state, { payload }) {
      return {
        ...state,
        orderFeedback: { ...payload }
      };
    },
    statement(state, { payload }) {
      return {
        ...state,
        statement: { ...payload }
      };
    },
    platformAccounts(state, { payload }) {
      return {
        ...state,
        platformAccounts: { ...payload }
      };
    },
    orderReviewAll(state, { payload }) {
      return {
        ...state,
        orderReviewAll: { ...payload }
      };
    },
    proxyPushNotice(state, { payload }) {
      return {
        ...state,
        proxyPushNotice: { ...payload }
      };
    },
    updateOrderReviewAll(state, { payload }) {
      let targetItem = state.orderReviewAll.list.filter(
        item => item.id !== payload.id
      );
      const states = Object.assign({}, state);
      states.orderReviewAll.list = targetItem;
      return {
        ...state,
        orderReviewAll: { ...state.orderReviewAll }
      };
    }
  },
  subscripts: {
    setup({ history }) {}
  }
};
