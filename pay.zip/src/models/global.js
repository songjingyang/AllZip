import http from '@/common/request';
import { formatter } from '@/common/menu';
import { enquireScreen, unenquireScreen } from 'enquire-js';

export default {
  namespace: 'global',

  state: {
    isMobile: false,
    form: {
      layout: 'inline'
    },
    collapsed: false,
    userInfo: {},
    noticeList: [],
    MenuData: [],
    addMenu: {},
    editMenu: {},
    showMenu: {},
    changeMenuStatus: {}
  },

  effects: {
    *getUserInfo({ payload }, { call, put, select }) {
      const response = yield call(http.getUserInfo, payload);
      yield put({
        type: 'userInfo',
        payload: {
          name: 'daycool',
          email: 'qmw920@163.com'
        }
      });
    },
    *fetchNotices(_, { call, put }) {},
    *clearNotices({ payload }, { put, select }) {},
    *getMenuData({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getMenuData, payload);
      (res.data ? res.data.list : []).forEach(item => {
        item.title = item.name;
        item.value = String(item.id);
        item.key = String(item.id);
        if (item.children) {
          item.children.forEach(item => {
            item.title = item.name;
            item.value = String(item.id);
            item.key = String(item.id);
          });
        }
      });

      res.data.list = formatter(res.data ? res.data.list : []);

      if (res.code === 200) {
        yield put({
          type: 'MenuData',
          payload: res.data.list
        });
      }
      // // console.log('res.data', res.data.list);
      if (callback) {
        callback(res);
      }
    },
    *saveAddMenu({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveAddMenu, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'addMenu',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveDelMenu({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveDelMenu, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'delMenu',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveEditMenu({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveEditMenu, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'editMenu',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveChangeMenuStatus({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveChangeMenuStatus, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'changeMenuStatus',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    }
  },

  reducers: {
    userInfo(state, { payload }) {
      return {
        ...state,
        userInfo: payload
      };
    },
    changeLayoutCollapsed(state, { payload }) {
      return {
        ...state,
        collapsed: payload
      };
    },
    saveNotices(state, { payload }) {
      return {
        ...state,
        noticeList: payload
      };
    },
    saveClearedNotices(state, { payload }) {
      return {
        ...state,
        noticeList: state.notices.filter(item => item.type !== payload)
      };
    },
    changeMobile(state, { payload }) {
      return {
        ...state,
        isMobile: payload.isMobile,
        form: {
          ...state.form,
          layout: payload.layout
        }
      };
    },
    MenuData(state, { payload }) {
      return {
        ...state,
        MenuData: [...payload]
      };
    },
    addMenu(state, { payload }) {
      return {
        ...state,
        addMenu: [...payload]
      };
    },
    delMenu(state, { payload }) {
      let targetItem = state.MenuData.filter(item => item.id !== payload.id);
      const states = Object.assign({}, state);
      states.MenuData = targetItem;
      return {
        ...state,
        MenuData: { ...state.MenuData }
      };
    },
    editMenu(state, { payload }) {
      return {
        ...state,
        editMenu: { ...payload }
      };
    },
    showMenu(state, { payload }) {
      return {
        ...state,
        showMenu: { ...payload }
      };
    },
    changeMenuStatus(state, { payload }) {
      return {
        ...state,
        changeMenuStatus: { ...payload }
      };
    }
  },
  subscriptions: {
    setup({ history, dispatch }) {
      // Subscribe history(url) change, trigger `load` action if pathname is `/`
      enquireScreen(isMobile => {
        dispatch({
          type: 'changeMobile',
          payload: {
            isMobile: isMobile,
            layout: isMobile ? 'vertical' : 'inline'
          }
        });
      });

      return history.listen(({ pathname, search }) => {
        if (typeof window.ga !== 'undefined') {
          window.ga('send', 'pageview', pathname + search);
        }
      });
    }
  }
};
