import http from '@/common/request';

export default {
  namespace: 'finance',
  state: {
    editMerchantProxyInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    }
  },
  effects: {
    *mchProxyTransfer({ payload, callback }, { call, put, select }) {
      const res = yield call(http.mchProxyTransfer, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'mchProxyTransferInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    }
  },
  reducers: {
    withdrawalListInfo(state, { payload }) {
      return {
        ...state,
        withdrawalListInfo: {
          ...payload
        }
      };
    }
  },
  subscriptions: {
    setup({ history }) {}
  }
};
