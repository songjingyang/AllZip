import http from '@/common/request';

export default {
  namespace: 'channel',
  state: {
    getChannelManageInfo:{},
    createPayChannelInfo:{},
    editPayChannelInfo:{}
  },

  effects: {
    // 创建
    *createPayChannel({ payload, callback }, { call, put, select }) {
      const res = yield call(http.createPayChannel, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'createPayChannelInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 修改
    *editPayChannel({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editPayChannel, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'editPayChannelInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 获取渠道
    *getChannelManage({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getChannelManage, payload);
      if (res.code === 200) {
        yield put({
          type: 'getChannelManageInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
  
  },
  reducers: {
    getChannelManageInfo(state, { payload }) {
      return {
        ...state,
        getChannelManageInfo: {
          ...payload
        }
      };
    },
    createPayChannelInfo(state, { payload }) {
      return {
        ...state,
        createPayChannelInfo: {
          ...payload
        }
      };
    },
    editPayChannelInfo(state, { payload }) {
      return {
        ...state,
        editPayChannelInfo: {
          ...payload
        }
      };
    },
    
  },
  subscriptions: {
    setup({ history }) {}
  }
};
