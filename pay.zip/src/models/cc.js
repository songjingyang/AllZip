import http from '@/common/request'

export default {
  namespace: 'cc',
  state: {
    stat: {
      deal: [],
      order: [],
      finishedDeal: [],
      finishedOrder: [],
      total: []
    },
    account: {
      // merchantName: '',
      // merchantId: '',
      // phone: '',
      createAt: '',
      account: '',
      username: '',
      phone: '',
      idCard: '',
      addr: '',
      idCardFront: '',
      idCardBack: ''
    },
    accountAuth: {
      account: '',
      username: '',
      phone: '',
      idCard: '',
      addr: '',
      idCardFront: '',
      idCardBack: ''
    },
    realAuth: {
      username: '',
      phone: '',
      idCard: '',
      addr: '',
      idCardFront: '',
      idCardBack: ''
    },
    orderListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    incomeAccount: {
      id: '',
      username: '',
      password: '',
      account: '',
      accountType: '',
      price: '',
      note: '',
      endTime: ''
    },
    incomeAccountListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: [],
      ts: 0
    },
    income: {
      id: '',
      time: '',
      price: '',
      img: '',
      type: '',
      checkCode: ''
    },
    incomeListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: [],
      ts: 0
    },
    apiInterface: {
      uid: '',
      token: '',
      ip: ''
    },
    feedback: {
      title: '',
      status: '',
      time: '',
      content: '',
      imgs: []
    },
    feedbackListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: [],
      ts: 0
    },
    // 商户结算记录
    withdrawRecordInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: [],
      ts: 0
    },
    withdrawRecordTransfer: {
      account_way_id: '',
      card_no: '',
      card_owner: '',
      amount: '',
      remark: ''
    }
  },

  effects: {
    * getStat ({ payload }, { call, put, select }) {
      // const stat = yield select(state => state.cc.stat)
      const res = yield call(http.getStat, payload)
      if (res.code === 200) {
        // today_orders: 12,
        // today_total: "25.54",
        // yesterday_orders: 0,
        // yesterday_total: "0",
        // week_orders: 12,
        // week_total: "25.54",
        // month_orders: 12,
        // month_total: "25.54",
        // today_paid_orders: 11,
        // today_paid_total: "25.44",
        // yesterday_paid_orders: 0,
        // yesterday_paid_total: "0",
        // week_paid_orders: 11,
        // week_paid_total: "25.44",
        // month_paid_orders: 11,
        // month_paid_total: "25.44",
        // receivalbe: "60.74",
        // received: "32.3",
        // unreceived: "28.440000000000005",
        // on_order: "0"
        const data = res.data
        // md改格式了在这里转换下吧
        const transData = {
          deal: [
            { name: 'today_total', label: '今日总金额', value: +data.today_total },
            {
              name: 'yesterday_total',
              label: '昨日总金额',
              value: +data.yesterday_total
            },
            { name: 'week_total', label: '本周总金额', value: +data.week_total },
            { name: 'month_total', label: '本月总金额', value: +data.month_total },

            { name: 'receivalbe', label: '可收', value: +data.receivalbe },
            { name: 'received', label: '实收', value: +data.received },
            { name: 'unreceived', label: '未到账', value: +data.unreceived }
          ],
          order: [
            { name: 'today_orders', label: '今日总订单', value: +data.today_orders },
            {
              name: 'yesterday_orders',
              label: '昨日总订单',
              value: +data.yesterday_orders
            },
            { name: 'week_orders', label: '本周总订单', value: +data.week_orders },
            { name: 'month_orders', label: '本月总订单', value: +data.month_orders }
          ],
          finishedDeal: [
            {
              name: 'today_paid_total',
              label: '今日已付款额',
              value: +data.today_paid_total
            },
            {
              name: 'yesterday_paid_total',
              label: '昨日已付款额',
              value: +data.yesterday_paid_total
            },
            {
              name: 'week_paid_total',
              label: '本周已付款额',
              value: +data.week_paid_total
            },
            {
              name: 'month_paid_total',
              label: '本月已付款额',
              value: +data.month_paid_total
            }
          ],
          finishedOrder: [
            {
              name: 'today_paid_orders',
              label: '今日已付款订单',
              value: +data.today_paid_orders
            },
            {
              name: 'yesterday_paid_orders',
              label: '昨日已付款订单',
              value: +data.yesterday_paid_orders
            },
            {
              name: 'week_paid_orders',
              label: '本周已付款订单',
              value: +data.week_paid_orders
            },
            {
              name: 'month_paid_orders',
              label: '本月已付款订单',
              value: +data.month_paid_orders
            }
          ],
          total: [{ name: 'on_order', label: '订单总额', value: +data.on_order }]
        }

        yield put({
          type: 'stat',
          payload: transData
        })
      }
    },
    * getAccount ({ payload }, { call, put, select }) {
      const res = yield call(http.getAccount, payload)
      if (res.code === 200) {
        yield put({
          type: 'account',
          payload: res.data
        })
      }
    },
    * saveAccount ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveAccount, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
        yield put({
          type: 'account',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * saveAccountAuth ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveAccountAuth, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
        yield put({
          type: 'accountAuth',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getRealAuthInfo ({ payload }, { call, put, select }) {
      const res = yield call(http.getRealAuthInfo, payload)
      if (res.code === 200) {
        yield put({
          type: 'realAuth',
          payload: res.data
        })
      }
    },
    * saveRealAuthInfo ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveRealAuthInfo, payload, { method: 'POST' })
      if (res.code === 200) {
        // yield put({
        //   type: 'realAuth',
        //   payload: res.data
        // })
      }
      if (callback) {
        callback(res)
      }
    },
    * getOrderList ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getOrderList, payload)
      if (res.code === 200) {
        yield put({
          type: 'orderListInfo',
          payload: res.data
        })
      }
      if (callback) {
        callback({ total: res.data.total })
      }
    },
    * orderNotify ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.orderNotify, payload, { method: 'POST' })
      if (res.code === 200) {
        yield put({
          type: 'updateOrderList',
          payload: payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getIncomeAccountInfo ({ payload }, { call, put, select }) {
      const res = yield call(http.getIncomeAccountInfo, payload)
      if (res.code === 200) {
        yield put({
          type: 'incomeAccount',
          payload: res.data
        })
      }
    },
    * saveIncomeAccount ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveIncomeAccount, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
        yield put({
          type: 'incomeAccount',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getIncomeAccountList ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getIncomeAccountList, payload)
      if (res.code === 200) {
        yield put({
          type: 'incomeAccountListInfo',
          payload: res.data
        })
      }
      if (callback) {
        callback({ total: res.data.total })
      }
    },
    * confirmIncome ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.confirmIncome, payload, {
        method: 'POST'
      })
      if (res.code === 200) {
        yield put({
          type: 'updateIncomeList',
          payload: payload
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getIncomeList ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getIncomeList, payload)
      if (res.code === 200) {
        yield put({
          type: 'incomeListInfo',
          payload: res.data
        })
      }
      if (callback) {
        callback({ total: res.data.total })
      }
    },
    * getApiInterface ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getApiInterface, payload)
      if (res.code === 200) {
        yield put({
          type: 'apiInterface',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * saveApiInterface ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveApiInterface, payload, { method: 'POST' })
      if (res.code === 200) {
        yield put({
          type: 'apiInterface',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * resetApiInterface ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.resetApiInterface, payload)

      if (res.code === 200) {
        yield put({
          type: 'apiInterface',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getFeedbackList ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getFeedbackList, payload)
      if (res.code === 200) {
        yield put({
          type: 'feedbackListInfo',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * saveFeedback ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveFeedback, payload, { method: 'POST' })
      if (res.code === 200) {
        yield put({
          type: 'feedback',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
    //商户结算记录
    * getWithdrawRecordInfo ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getWithdrawRecordInfo, payload)
      if (res.code === 200) {
        yield put({
          type: 'withdrawRecord',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
    * getWithdrawRecordTransfer ({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getWithdrawRecordTransfer, payload)
      if (res.code === 200) {
        yield put({
          type: 'withdrawRecordTransfer',
          payload: res.data
        })
      }
      if (callback) {
        callback(res)
      }
    },
  },
  reducers: {
    stat (state, { payload }) {
      return {
        ...state,
        stat: {
          ...payload
        }
      }
    },
    account (state, { payload }) {
      return {
        ...state,
        account: {
          ...payload
        }
      }
    },
    accountAuth (state, { payload }) {
      return {
        ...state,
        accountAuth: {
          ...payload
        }
      }
    },
    realAuth (state, { payload }) {
      return {
        ...state,
        realAuth: {
          ...payload
        }
      }
    },
    orderListInfo (state, { payload }) {
      for (let i = 0; i < payload.list.length; i++) {
        payload.list[i].price /= 100
      }
      return {
        ...state,
        orderListInfo: {
          ...payload
        }
      }
    },
    updateOrderList (state, { payload }) {
      let targetItem = state.orderListInfo.list.find(
        item => item.id === payload.id
      )
      if (targetItem) {
        targetItem.status = 3
      }
      return {
        ...state,
        orderListInfo: {
          ...state.orderListInfo
        }
      }
    },
    incomeAccount (state, { payload }) {
      return {
        ...state,
        incomeAccount: {
          ...payload
        }
      }
    },
    incomeAccountListInfo (state, { payload }) {
      return {
        ...state,
        incomeAccountListInfo: {
          ...payload
        }
      }
    },
    updateIncomeAccountList (state, { payload }) {
      let targetItem = state.incomeAccountListInfo.list.find(
        item => item.id === payload.id
      )
      if (targetItem) {
        targetItem.status = 3
      }
      return {
        ...state,
        incomeAccountListInfo: {
          ...state.incomeAccountListInfo
        }
      }
    },
    income (state, { payload }) {
      return {
        ...state,
        income: {
          ...payload
        }
      }
    },
    incomeListInfo (state, { payload }) {
      return {
        ...state,
        incomeListInfo: {
          ...payload
        }
      }
    },
    updateIncomeList (state, { payload }) {
      const list = state.incomeListInfo.list
      list.forEach((item, index) => {
        if (item.id === payload.id) {
          list[index] = { ...item, ...payload }
        }
      })
      return {
        ...state
      }
    },
    apiInterface (state, { payload }) {
      return {
        ...state,
        apiInterface: {
          ...payload
        }
      }
    },
    feedback (state, { payload }) {
      return {
        ...state,
        feedback: {
          ...payload
        }
      }
    },
    feedbackListInfo (state, { payload }) {
      return {
        ...state,
        feedbackListInfo: {
          ...payload
        }
      }
    },
    //商户结算记录
    withdrawRecord (state, { payload }) {
      return {
        ...state,
        withdrawRecordInfo: {
          ...payload
        }
      }
    },
    withdrawRecordTransfer (state, { payload }) {
      return {
        ...state,
        withdrawRecordTransfer: {
          ...payload
        }
      }
    },
  },
  subscriptions: {
    setup ({ history }) {}
  }
}
