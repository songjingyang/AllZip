import http from '@/common/request';
import { pageHandle } from '@/utils/utils';
export default {
  namespace: 'merchant',
  state: {
    mchOrderSettlementListInfo: {},
    merchantListViewInfo: {
      OnOrder: '',
      Receivable: '',
      Received: '',
      Unreceived: ''
    },
    businessUpdateStatusInfo: {},
    merchantListViewEdit: {},
    editBusinessUserInfo: {},
    editHistoryInfo:{},
    merchantListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    merchantInfo: {
      account: '',
      ach_id: '',
      created: '',
      serverChange: {
        alipy: '',
        weixin: ''
      }
    },
    merchantEditInfo: {
      status: 0,
      account: ''
    },
    cardManageInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    // 商户信息
    merchantTreeListInfo: {
      list: []
    },
    merchantUserInfo: {
      BusinessUser: {
        Id: 0
      },
      agent: {
        ali_rate: 0
      },
      rate: {},
      wealth: {},
      history:{},
      real_auth:{}
    },
    merchantTransferInfo: {
      odd_amount: ''
    },
    merchantTransfer: {
      ach_id: '1235'
    },
    bankListInfo: {
      page: 1,
      pageSize: 200,
      total: 0,
      list: []
    },
    accountAuditListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    //账户详情
    accountDetailInfo: {
      account: '',
      open: '',
      startTime: '',
      endTime: '',
      status: ''
    },
    //收款详情
    amountDetailInfo: {
      account: '',
      open: '',
      startTime: '',
      endTime: '',
      status: ''
    },
    realAuthAuditListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    }
  },
  effects: {
    *getMerchantListView({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getMerchantListView, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'merchantListViewInfo',
          payload: {
            ...payload,
            ...res.data
          }
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 商户账号封停
    *editBusinessPassWord({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editBusinessPassWord, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'editBusinessPassWordInfo',
          payload: {
            ...payload,
            ...res.data
          }
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 商户账号封停
    *businessUpdateStatus({ payload, callback }, { call, put, select }) {
      const res = yield call(http.businessUpdateStatus, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'businessUpdateStatusInfo',
          payload: {
            ...payload,
            ...res.data
          }
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *editHistory({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editHistory, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'editHistoryInfo',
          payload: {
            ...payload,
            ...res.data
          }
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 修改商户费率
    *editBusinessUser({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editBusinessUser, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateStatus',
          payload: {
            ...payload,
            ...res.data
          }
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *changeStatus({ payload, callback }, { call, put, select }) {
      const res = yield call(http.changeStatus, payload, { method: 'post' });
      if (res.code === 200) {
        yield put({
          type: 'updateStatus',
          payload: {
            ...payload,
            ...res.data
          }
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *transAccount({ payload, callback }, { call, put, select }) {
      const res = yield call(http.transAccount, payload, { method: 'post' });
      if (res.code === 200) {
        yield put({
          type: 'updateTransAccount',
          payload: {
            ...payload,
            ...res.data
          }
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *settleAccount({ payload, callback }, { call, put, select }) {
      const res = yield call(http.settleAccount, payload, { method: 'post' });
      if (res.code === 200) {
        yield put({
          type: 'updateSettleAccount',
          payload: {
            ...payload,
            ...res.data
          }
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *mchOrderSettlementList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.mchOrderSettlementList, payload);
      if (res.code === 200) {
        yield put({
          type: 'mchOrderSettlementListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getMerchantList({ payload, callback }, { call, put, select }) {
      const merchantListInfo = yield select(
        state => state.merchant.merchantListInfo
      );
      pageHandle(payload, merchantListInfo);
      const res = yield call(http.getMerchantList, payload);
      if (res.code === 200) {
        yield put({
          type: 'merchantListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getCardManagePass({ payload, callback }, { call, put, select }) {
      const res = yield call(http.changeCardManageStatus, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateCardManageStatus',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getCardManageRefuse({ payload, callback }, { call, put, select }) {
      const res = yield call(http.changeCardManageStatus, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateCardManageStatus',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *changeCardManageStatus({ payload, callback }, { call, put, select }) {
      const res = yield call(http.changeCardManageStatus, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'cardManageStatus',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //1.
    *getBankList({ payload }, { call, put, select }) {
      const res = yield call(http.getBankList, payload);
      if (res.code === 200) {
        yield put({
          type: 'bankListInfo',
          payload: res.data
        });
      }
    },
    *getMerchantTransfer({ payload }, { call, put, select }) {
      const res = yield call(http.getMerchantTransfer, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'merchantTransferInfo',
          payload: {
            ...res.data
          }
        });
      }
    },
    *saveMerchantTransfer({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveMerchantTransfer, payload, {
        method: 'post'
      });
      if (res.code === 200) {
      }
      if (callback) {
        callback(res);
      }
    },
    // 商户
    *getMerchantTreeList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getMerchantTreeList, payload);
      if (res.code === 200) {
        // if (res.data.list.length !== 0) {
        yield put({
          type: 'merchantTreeListInfo',
          payload: res.data
        });
        // }
      }
      if (callback) {
        callback({ res, total: res.data.total });
      }
    },
    *getMerchantUserInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getMerchantUserInfo, payload);
      if (res.code === 200) {
        // if (res.data.list.length !== 0) {
        yield put({
          type: 'merchantUserInfo',
          payload: res.data
        });
        // }
      }
      if (callback) {
        callback({ res, total: res.data.total });
      }
    },
    //2.
    // * saveMerchantTransfer ({ payload, callback }, { call, put, select }) {
    //   const res = yield call(http.saveMerchantTransfer, payload, {
    //     method: 'post'
    //   })
    //   if (res.code === 200) {
    //     yield put({
    //       type: 'merchantTransferInfo',
    //       payload: res.data
    //     })
    //   }
    //   if (callback) {
    //     callback(res)
    //   }
    // },
    *getAccountAuditList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAccountAuditList, payload);
      if (res.code === 200) {
        yield put({
          type: 'accountAuditListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //商户账号状态
    *getAccountAuditPass({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAccountAudit, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'updateAccountAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getAccountAuditRefuse({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAccountAudit, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'updateAccountAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getAccountAuditFreeze({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAccountAudit, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'updateAccountAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    //账户详情
    *getAccountDetail({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAccountDetail, payload);
      if (res.code === 200) {
        yield put({
          type: 'accountDetailInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //收款详情
    *getAmountDetail({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAmountDetail, payload);
      if (res.code === 200) {
        yield put({
          type: 'amountDetailInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //商户实名
    *getRealAuthAuditList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getRealAuthAuditList, payload);
      if (res.code === 200) {
        yield put({
          type: 'realAuthAuditListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getCardManageList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getCardManageList, payload);
      if (res.code === 200) {
        yield put({
          type: 'cardManageInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    }
  },
  reducers: {
    editHistoryInfo(state, { payload }) {
      return {
        ...state,
        editHistoryInfo: {
          ...payload
        }
      };
    },
    mchOrderSettlementListInfo(state, { payload }) {
      return {
        ...state,
        mchOrderSettlementListInfo: {
          ...payload
        }
      };
    },
    merchantListViewInfo(state, { payload }) {
      return {
        ...state,
        merchantListViewInfo: {
          ...payload
        }
      };
    },
    businessUpdateStatusInfo(state, { payload }) {
      return {
        ...state,
        businessUpdateStatusInfo: {
          ...payload
        }
      };
    },
    editBusinessUserInfo(state, { payload }) {
      return {
        ...state,
        editBusinessUserInfo: {
          ...payload
        }
      };
    },
    updateStatus(state, { payload }) {
      state.merchantListInfo.list.forEach(item => {
        if (item.id === payload.id) {
          item.status = payload.status;
        }
      });
      return {
        ...state
      };
    },
    updateTransAccount(state, { payload }) {
      const list = state.merchantListInfo.list;
      list.forEach((item, index) => {
        if (item.id === payload.id) {
          list[index] = { ...item, ...payload };
        }
      });
      return {
        ...state
      };
    },
    updateSettleAccount(state, { payload }) {
      const list = state.merchantListInfo.list;
      list.forEach((item, index) => {
        if (item.id === payload.id) {
          list[index] = { ...item, ...payload };
        }
      });
      return {
        ...state
      };
    },
    merchantListInfo(state, { payload }) {
      return {
        ...state,
        merchantListInfo: {
          ...payload
        }
      };
    },
    merchantEditInfo(state, { payload }) {
      return {
        ...state,
        merchantEditInfo: {
          ...payload
        }
      };
    },
    merchantTransferInfo(state, { payload }) {
      return {
        ...state,
        merchantTransferInfo: {
          ...payload
        }
      };
    },
    merchantTransfer(state, { payload }) {
      return {
        ...state,
        merchantTransfer: {
          ...payload
        }
      };
    },
    // 1.
    bankListInfo(state, { payload }) {
      return {
        ...state,
        bankListInfo: {
          ...payload
        }
      };
    },
    accountAuditListInfo(state, { payload }) {
      return {
        ...state,
        accountAuditListInfo: {
          ...payload
        }
      };
    },
    updateAccountAudit(state, { payload }) {
      return {
        ...state,
        accountAuditListInfo: {
          ...state.accountAuditListInfo
        }
      };
    },
    deleteAccountAudit(state, { payload }) {
      let targetItem = state.accountAuditListInfo.list.filter(
        item => item.id !== payload.id
      );
      const states = Object.assign({}, state);
      states.accountAuditListInfo.list = targetItem;
      return {
        ...state,
        accountAuditListInfo: { ...state.accountAuditListInfo }
      };
    },
    //账户详情
    accountDetailInfo(state, { payload }) {
      return {
        ...state,
        accountDetailInfo: {
          ...payload
        }
      };
    },
    //收款详情
    amountDetailInfo(state, { payload }) {
      return {
        ...state,
        amountDetailInfo: {
          ...payload
        }
      };
    },
    realAuthAuditListInfo(state, { payload }) {
      return {
        ...state,
        realAuthAuditListInfo: {
          ...payload
        }
      };
    },
    cardManageInfo(state, { payload }) {
      return {
        ...state,
        cardManageInfo: {
          ...payload
        }
      };
    },
    updateCardManageStatus(state, { payload }) {
      return {
        ...state,
        cardManageInfo: {
          ...state.cardManageInfo
        }
      };
    },
    merchantTreeListInfo(state, { payload }) {
      return {
        ...state,
        merchantTreeListInfo: {
          ...payload
        }
      };
    },
    merchantUserInfo(state, { payload }) {
      return {
        ...state,
        merchantUserInfo: {
          ...payload
        }
      };
    },
    merchantListViewEdit(state, { payload }) {
      return {
        ...state,
        merchantListViewEdit: {
          ...payload
        }
      };
    }
  },
  subscriptions: {
    setup({ history }) {}
  }
};
