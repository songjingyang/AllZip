import http from '@/common/request';
import { pageHandle } from '@/utils/utils';

export default {
  namespace: 'stat',
  state: {
    baseStatInfo: {
      today_paid_order: '', // 今天订单个数
      today_paid_total: '', // 今天总金额
      yesterday_paid_order: '', // 昨天订单个数
      yesterday_paid_total: '', // 昨天总金额
      week_paid_order: '', // 本周订单个数
      week_paid_total: '', // 本周总金额
      month_paid_order: '', // 本月订单个数
      month_paid_total: '' // 本月总金额
    },
    statTop10Info: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    statListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    merchantDayReportInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    clearingReportInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    }
  },
  // 处理异步逻辑
  effects: {
    //     getStat
    // getStatList
    // getStatTop10
    *getBaseStat({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getBaseStat, payload);
      if (res.code === 200) {
        yield put({
          type: 'baseStatInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total, res: res });
      }
    },
    *getStatTop10({ payload, callback }, { call, put, select }) {
      const statTop10Info = yield select(state => state.stat.statTop10Info);
      pageHandle(payload, statTop10Info);
      const res = yield call(http.getStatTop10, payload);
      if (res.code === 200) {
        yield put({
          type: 'statTop10Info',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total, res: res });
      }
    },
    *getStatList({ payload, callback }, { call, put, select }) {
      const statListInfo = yield select(state => state.stat.statListInfo);
      pageHandle(payload, statListInfo);
      const res = yield call(http.getStatList, payload);
      if (res.code === 200) {
        yield put({
          type: 'statListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total, res: res });
      }
    },
    //日报表
    *getMerchantDayReport({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getMerchantDayReport, payload);
      if (res.code === 200) {
        yield put({
          type: 'merchantDayReportInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getClearingReport({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getClearingReport, payload);
      if (res.code === 200) {
        yield put({
          type: 'clearingReportInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    }
  },
  // 接受action，同步更新state
  reducers: {
    baseStatInfo(state, { payload }) {
      return {
        ...state,
        baseStatInfo: { ...payload }
      };
    },
    statTop10Info(state, { payload }) {
      return {
        ...state,
        statTop10Info: {
          ...payload
        }
      };
    },
    statListInfo(state, { payload }) {
      return {
        ...state,
        statListInfo: {
          ...payload
        }
      };
    },
    //日报表
    merchantDayReportInfo(state, { payload }) {
      return {
        ...state,
        merchantDayReportInfo: {
          ...payload
        }
      };
    },
    //清算报表
    clearingReportInfo(state, { payload }) {
      return {
        ...state,
        clearingReportInfo: {
          ...payload
        }
      };
    }
  }
};
