import http from '@/common/request';

export default {
  namespace: 'exchange',
  state: {
    exchangeRecordView:{},
    editExchangeRecordStatusInfo:{},
    exchangeRecordEdit:{},
    getExchangeRecordInfo:{},
    getReceiveBankInfo:{},
    editReceiveBank:{},
    editReceiveBankInfos:{},
    getBankConfigAllInfo:{
      list:[]
    },
    createReceiveBankInfo:{},
    getExchangeWayInfo:{},
    createExchangeWayInfo:{},
    editReceiveWay:{},
    editExchangeWayInfo:{},
    getCurrencyConfigInfo:{},
    createCurrencyConfigInfo:{},
    editCurrencyConfig:{},
    editCurrencyConfigInfo:{},
    getCurrencyConfigListInfo:{
      list:[]
    },
  },

  effects: {
    
    // 创建货币类型
    *editExchangeRecordStatus({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editExchangeRecordStatus, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'editExchangeRecordStatusInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 货币列表
    *getCurrencyConfigList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getCurrencyConfigList, payload);
      if (res.code === 200) {
        yield put({
          type: 'getCurrencyConfigListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 创建货币类型
    *editCurrencyConfig({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editCurrencyConfig, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'editCurrencyConfigInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 创建货币类型
    *createCurrencyConfig({ payload, callback }, { call, put, select }) {
      const res = yield call(http.createCurrencyConfig, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'createCurrencyConfigInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 全部货币类型
    *getCurrencyConfig({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getCurrencyConfig, payload);
      if (res.code === 200) {
        yield put({
          type: 'getCurrencyConfigInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
     // 创建兑换放肆
     *editExchangeWay({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editExchangeWay, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'editExchangeWayInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 创建兑换放肆
    *createExchangeWay({ payload, callback }, { call, put, select }) {
      const res = yield call(http.createExchangeWay, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'createExchangeWayInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 获取全部兑换银行
    *getExchangeWay({ payload, callback }, { call, put, select }) {
      
      const res = yield call(http.getExchangeWay, payload);
      if (res.code === 200) {
        yield put({
          type: 'getExchangeWayInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 创建收款银行卡信息
    *createReceiveBank({ payload, callback }, { call, put, select }) {
      const res = yield call(http.createReceiveBank, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'createReceiveBankInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 修改收款银行卡信息
    *editReceiveBankInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editReceiveBankInfo, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'editReceiveBankInfos',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    
    // 获取兑换记录
    *getExchangeRecord({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getExchangeRecord, payload);
      if (res.code === 200) {
        yield put({
          type: 'getExchangeRecordInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
      // 获取收款银行记录
      *getReceiveBank({ payload, callback }, { call, put, select }) {
        
        const res = yield call(http.getReceiveBank, payload);
        if (res.code === 200) {
          yield put({
            type: 'getReceiveBankInfo',
            payload: res.data
          });
        }
        if (callback) {
          callback(res);
        }
      },
      // 获取全部兑换银行
      *getBankConfigAll({ payload, callback }, { call, put, select }) {
        const res = yield call(http.getBankConfigAll, payload);
        if (res.code === 200) {
          yield put({
            type: 'getBankConfigAllInfo',
            payload: res.data
          });
        }
        if (callback) {
          callback(res);
        }
      },
  },
  reducers: {
    
    exchangeRecordView(state, { payload }) {
      return {
        ...state,
        exchangeRecordView: {
          ...payload
        }
      };
    },
    editExchangeRecordStatusInfo(state, { payload }) {
      return {
        ...state,
        editExchangeRecordStatusInfo: {
          ...payload
        }
      };
    },
    exchangeRecordEdit(state, { payload }) {
      return {
        ...state,
        exchangeRecordEdit: {
          ...payload
        }
      };
    },
    getCurrencyConfigListInfo(state, { payload }) {
      return {
        ...state,
        getCurrencyConfigListInfo: {
          ...payload
        }
      };
    },
    editCurrencyConfigInfo(state, { payload }) {
      return {
        ...state,
        editCurrencyConfigInfo: {
          ...payload
        }
      };
    },
    editCurrencyConfig(state, { payload }) {
      return {
        ...state,
        editCurrencyConfig: {
          ...payload
        }
      };
    },
    createCurrencyConfigInfo(state, { payload }) {
      return {
        ...state,
        createCurrencyConfigInfo: {
          ...payload
        }
      };
    },
    getCurrencyConfigInfo(state, { payload }) {
      return {
        ...state,
        getCurrencyConfigInfo: {
          ...payload
        }
      };
    },
    editExchangeWayInfo(state, { payload }) {
      return {
        ...state,
        editExchangeWayInfo: {
          ...payload
        }
      };
    },
    editReceiveWay(state, { payload }) {
      return {
        ...state,
        editReceiveWay: {
          ...payload
        }
      };
    },
    createExchangeWayInfo(state, { payload }) {
      return {
        ...state,
        createExchangeWayInfo: {
          ...payload
        }
      };
    },
    getExchangeWayInfo(state, { payload }) {
      return {
        ...state,
        getExchangeWayInfo: {
          ...payload
        }
      };
    },
    createReceiveBankInfo(state, { payload }) {
      return {
        ...state,
        createReceiveBankInfo: {
          ...payload
        }
      };
    },
    getExchangeRecordInfo(state, { payload }) {
      return {
        ...state,
        getExchangeRecordInfo: {
          ...payload
        }
      };
    },
    getReceiveBankInfo(state, { payload }) {
      return {
        ...state,
        getReceiveBankInfo: {
          ...payload
        }
      };
    },
    editReceiveBank(state, { payload }) {
      return {
        ...state,
        editReceiveBank: {
          ...payload
        }
      };
    },
    editReceiveBankInfos(state, { payload }) {
      return {
        ...state,
        editReceiveBankInfos: {
          ...payload
        }
      };
    },
    getBankConfigAllInfo(state, { payload }) {
      return {
        ...state,
        getBankConfigAllInfo: {
          ...payload
        }
      };
    },
    
    
   
    
  },
  subscriptions: {
    setup({ history }) {}
  }
};
