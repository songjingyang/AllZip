import http from '@/common/request';
import { message } from 'antd';

export default {
  namespace: 'proxy',
  state: {
    getAliValidProxyListInfo:{},
    getRiskControlListInfo: {},
    proxyPassEdit: {},
    editProxyPassWordInfo: {},
    getProxyOrderNumListInfo: {},
    getProxyOperateListInfo: {},
    freezeProxyInfo: {},
    proxyListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyTreeListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyAccountInfo: {
      IsStopWxPay: '',
      IsStopAlipay: '',
      assetsInfo: '',
      collectionInfo: '',
      proxyInfo: '',
      proxyStatus: '',
      Ali: {
        qr_url: ''
      },
      Wx: {
        qr_url: ''
      }
      // Ali:{
      //   qr_url:''
      // },
      // Wx:{
      //   qr_url:''
      // },
    },
    profitFlow: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    profitFlowEdit: {
      account: '',
      amount: '',
      created: ''
    },
    createProxy: {
      number: 13333401419,
      password: 123456,
      shareCode: '',
      name: '探探',
      idCard: '',
      prosImg: '',
      consImg: ''
    },
    // proxyAccoutInfo: {
    //   page: 1,
    //   pageSize: 20,
    //   total: 0,
    //   ts: 0,
    //   list: []
    // },
    nextCreateProxy: {
      number: 18834771413,
      password: '123456aa',
      shareCode: 'zxvc5456',
      name: 'zzz',
      idCard: 140603199306024999
    },
    incomeDetailInfo: {
      name: 'zzz',
      number: 18834771413,
      limit: 1111000,
      useLimit: 1000,
      restLimit: 1110000
    },
    addLimitInfo: {
      limit: 1110000
    },
    statusEdit: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    passwordEdit: {
      password: ''
    },
    proxyPayAll: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyPayAllEdit: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyPreduceAll: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyPreduceAllEdit: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyRealAll: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyRealAllEdit: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    qrCodeList: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    qrCodeListEdit: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    }
  },
  // 处理异步逻辑
  effects: {
    
    *getAliValidProxyList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAliValidProxyList, payload);
      if (res.code === 200) {
        yield put({
          type: 'getAliValidProxyListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },

    *editProxyPassWord({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editProxyPassWord, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'editProxyPassWordInfo',
          payload: {
            ...payload,
            ...res.data
          }
        });
      }
      if (callback) {
        callback(res);
      }
    },

    *getRiskControlList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getRiskControlList, payload);
      if (res.code === 200) {
        yield put({
          type: 'getRiskControlListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxyOrderNumList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyOrderNumList, payload);
      if (res.code === 200) {
        yield put({
          type: 'getProxyOrderNumListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxyOperateList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyOperateList, payload);
      if (res.code === 200) {
        yield put({
          type: 'getProxyOperateListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *freezeProxy({ payload, callback }, { call, put, select }) {
      const res = yield call(http.freezeProxy, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'freezeProxyInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 创建商户代理
    *newProxy({ payload, callback }, { call, put, select }) {
      const res = yield call(http.newProxy, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'newProxyInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getProxyList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyList, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    // 上级
    *getJumpPrevLevel({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyFather, payload, { method: 'POST' });
      // if (res.data === null) {
      //   message.warning('没有下级')
      // }
      if (res.code === 200) {
        yield put({
          type: 'updateJumpPrevLevel',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    // 下级
    *getJumpNextLevel({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxySon, payload, { method: 'POST' });
      if (res.data === null) {
        message.warning('没有下级');
        return;
      }

      if (res.code === 200) {
        yield put({
          type: 'updateJumpNextLevel',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProfitFlow({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProfitFlow, payload);
      if (res.code === 200) {
        yield put({
          type: 'profitFlow',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *getProfitFlowEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProfitFlowEdit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'profitFlowEdit',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    *saveProfitFlowEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveProfitFlowEdit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'profitFlowEdit',
          payload: res.data
        });
        if (callback) {
          callback(res);
        }
      }
    },
    //代理树
    *getProxyTreeList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyTreeList, payload);
      if (res.code === 200) {
        if (res.data.list.length !== 0) {
          yield put({
            type: 'proxyTreeListInfo',
            payload: res.data
          });
        }
      }
      if (callback) {
        callback({ res, total: res.data.total });
      }
    },
    //冻结类型
    *freezeType({ payload, callback }, { call, put, select }) {
      const res = yield call(http.freezeType, payload, { method: 'POST' });
      if (res.code === 200) {
        // yield put({
        //   type: 'proxyAccountInfo',
        //   payload: res.data
        // })
      }
      if (callback) {
        callback(res);
      }
    },
    //删除账号
    *delAccount({ payload, callback }, { call, put, select }) {
      const res = yield call(http.delAccount, payload, { method: 'POST' });
      if (res.code === 200) {
        // yield put({
        //   type: 'proxyAccountInfo',
        //   payload: res.data
        // })
      }
      if (callback) {
        callback(res);
      }
    },
    //代理信息
    *getProxyAccountInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyAccountInfo, payload, {
        method: 'POST'
      });

      if (res.code === 200) {
        yield put({
          type: 'proxyAccountInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getCreateProxy({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getCreateProxy, payload);
      if (res.code === 200) {
        yield put({
          type: 'createProxy',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveCreateProxy({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveCreateProxy, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'createProxy',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // *getProxyAccout({ payload, callback }, { call, put, select }) {
    //   const res = yield call(http.getProxyAccout, payload);
    //   if (res.code === 200) {
    //     yield put({
    //       type: 'proxyAccoutInfo',
    //       payload: res.data
    //     });
    //   }
    //   if (callback) {
    //     callback(res);
    //   }
    // },
    // *saveProxyAccout({ payload, callback }, { call, put, select }) {
    //   const res = yield call(http.saveProxyAccout, payload, {
    //     method: 'post'
    //   });
    //   if (res.code === 200) {
    //     yield put({
    //       type: 'proxyAccoutInfo',
    //       payload: res.data
    //     });
    //   }
    //   if (callback) {
    //     callback(res);
    //   }
    // },
    *getIncomeDetailInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getIncomeDetailInfo, payload);
      if (res.code === 200) {
        yield put({
          type: 'incomeDetailInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveIncomeDetailInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveIncomeDetailInfo, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'incomeDetailInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getAddLimitInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAddLimitInfo, payload);
      if (res.code === 200) {
        yield put({
          type: 'addLimitInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveAddLimitInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveAddLimitInfo, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'addLimitInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getStatusEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getStatusEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'statusEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveStatusEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveStatusEdit, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'statusEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getPasswordEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getPasswordEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'passwordEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *savePasswordEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.savePasswordEdit, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'passwordEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getProxyPayAll({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPayAll, payload);
      if (res.code === 200) {
        if (res.data.list !== null) {
          yield put({
            type: 'proxyPayAll',
            payload: res.data
          });
        } else {
          yield put({
            type: 'proxyPayAll',
            payload: { list: [] }
          });
        }
      }
      if (callback) {
        callback(res);
      }
    },
    // 充值额度状态
    *getProxyPayPass({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPayAudit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateProxyPayAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxyPayRefuse({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPayAudit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateProxyPayAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxyPayAllEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPayAllEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyPayAllEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveProxyPayAllEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveProxyPayAllEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyPayAllEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getProxyPreduceAll({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPreduceAll, payload);
      if (res.code === 200) {
        if (res.data.list !== null) {
          yield put({
            type: 'proxyPreduceAll',
            payload: res.data
          });
        } else {
          yield put({
            type: 'proxyPreduceAll',
            payload: { list: [] }
          });
        }
      }
      if (callback) {
        callback(res);
      }
    },
    // 代理降额状态
    *getProxyPreducePass({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPreduceAudit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateProxyPreduceAudit',
          payload: res.data
        });
      } else {
        alert(res.msg);
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxyPreduceRefuse({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPreduceAudit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateProxyPreduceAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxyPreduceAllEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPreduceAllEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyPreduceAllEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveReduceLimitEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveReduceLimitEdit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'reduceLimitEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getProxyRealAll({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyRealAll, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyRealAll',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getProxyRealPass({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyRealAudit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateProxyRealAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxyRealRefuse({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyRealAudit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateProxyRealAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxyRealAllEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyRealAllEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyRealAll',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveProxyRealAllEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveProxyRealAllEdit, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'proxyRealAllEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getQRCodeList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getQRCodeList, payload);
      if (res.code === 200) {
        yield put({
          type: 'qrCodeList',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 二维码审核状态
    *getQRCodePass({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getQRAuditAudit, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'updateQRCodeAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getQRCodeRefuse({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getQRAuditAudit, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'deleteQRCodeAudit',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getQRCodeListEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getQRCodeListEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'qrCodeList',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveQRCodeListEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveQRCodeListEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'qrCodeList',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    }
  },
  // 接受action，同步更新state
  reducers: {
    getAliValidProxyListInfo(state, { payload }) {
      return {
        ...state,
        getAliValidProxyListInfo: {
          ...payload
        }
      };
    },
    getRiskControlListInfo(state, { payload }) {
      return {
        ...state,
        getRiskControlListInfo: {
          ...payload
        }
      };
    },
    proxyPassEdit(state, { payload }) {
      return {
        ...state,
        proxyPassEdit: {
          ...payload
        }
      };
    },
    editProxyPassWordInfo(state, { payload }) {
      return {
        ...state,
        editProxyPassWordInfo: {
          ...payload
        }
      };
    },
    getProxyOrderNumListInfo(state, { payload }) {
      return {
        ...state,
        getProxyOrderNumListInfo: {
          ...payload
        }
      };
    },
    getProxyOperateListInfo(state, { payload }) {
      return {
        ...state,
        getProxyOperateListInfo: {
          ...payload
        }
      };
    },
    freezeProxyInfo(state, { payload }) {
      return {
        ...state,
        freezeProxyInfo: {
          ...payload
        }
      };
    },
    // newProxyInfo: {},
    newProxyInfo(state, { payload }) {
      return {
        ...state,
        newProxyInfo: {
          ...payload
        }
      };
    },
    proxyListInfo(state, { payload }) {
      return {
        ...state,
        proxyListInfo: {
          ...payload
        }
      };
    },
    // 上级
    updateJumpPrevLevel(state, { payload }) {
      const states = Object.assign({}, state);
      states.proxyListInfo.list = payload;
      return {
        ...state,
        proxyListInfo: {
          ...state.proxyListInfo
        }
      };
    },
    // 下级
    updateJumpNextLevel(state, { payload }) {
      const states = Object.assign({}, state);
      states.proxyListInfo.list = payload;
      return {
        ...state,
        proxyListInfo: {
          ...state.proxyListInfo
        }
      };
    },
    profitFlow(state, { payload }) {
      return {
        ...state,
        profitFlow: { ...payload }
      };
    },
    profitFlowEdit(state, { payload }) {
      return {
        ...state,
        profitFlowEdit: { ...payload }
      };
    },
    //代理树
    proxyTreeListInfo(state, { payload }) {
      return {
        ...state,
        proxyTreeListInfo: {
          ...payload
        }
      };
    },
    //代理信息
    proxyAccountInfo(state, { payload }) {
      return {
        ...state,
        proxyAccountInfo: {
          ...payload
        }
      };
    },
    updateProxyList(state, { payload }) {
      let targetItem = state.proxyListInfo.list.find(
        item => item.id === payload.id
      );
      if (targetItem) {
        targetItem.status = 3;
      }
      return {
        ...state,
        proxyListInfo: {
          ...state.proxyListInfo
        }
      };
    },
    createProxy(state, { payload }) {
      return {
        ...state,
        createProxy: {
          ...payload
        }
      };
    },
    // proxyAccoutInfo(state, { payload }) {
    //   return {
    //     ...state,
    //     proxyAccoutInfo: {
    //       ...payload
    //     }
    //   };
    // },
    incomeDetailInfo(state, { payload }) {
      return {
        ...state,
        incomeDetailInfo: {
          ...payload
        }
      };
    },
    addLimitInfo(state, { payload }) {
      return {
        ...state,
        addLimitInfo: {
          ...payload
        }
      };
    },
    statusEdit(state, { payload }) {
      return {
        ...state,
        statusEdit: {
          ...payload
        }
      };
    },
    passwordEdit(state, { payload }) {
      return {
        ...state,
        passwordEdit: {
          ...payload
        }
      };
    },
    proxyPayAll(state, { payload }) {
      // for (let i = 0; i < payload.list.length; i++) {
      //   payload.list[i].amount /= 100
      // }
      return {
        ...state,
        proxyPayAll: {
          ...payload
        }
      };
    },
    // 充值状态
    updateProxyPayAudit(state, { payload }) {
      return {
        ...state,
        proxyPayAll: {
          ...state.proxyPayAll
        }
      };
    },
    deleteProxyPayAudit(state, { payload }) {
      let targetItem = state.proxyPayAll.list.filter(
        item => item.id !== payload.id
      );
      const states = Object.assign({}, state);
      states.proxyPayAll.list = targetItem;
      return {
        ...state,
        proxyPayAll: { ...state.proxyPayAll }
      };
    },
    proxyPayAllEdit(state, { payload }) {
      return {
        ...state,
        proxyPayAllEdit: {
          ...payload
        }
      };
    },
    proxyPreduceAll(state, { payload }) {
      // for (let i = 0; i < payload.list.length; i++) {
      //   payload.list[i].amount /= 100
      // }
      return {
        ...state,
        proxyPreduceAll: {
          ...payload
        }
      };
    },
    updateProxyPreduceAudit(state, { payload }) {
      return {
        ...state,
        proxyPreduceAll: {
          ...state.proxyPreduceAll
        }
      };
    },
    deleteProxyPreduceAudit(state, { payload }) {
      let targetItem = state.proxyPreduceAll.list.filter(
        item => item.id !== payload.id
      );
      const states = Object.assign({}, state);
      states.proxyPreduceAll.list = targetItem;
      return {
        ...state,
        proxyPreduceAll: { ...state.proxyPreduceAll }
      };
    },
    proxyPreduceAllEdit(state, { payload }) {
      return {
        ...state,
        proxyPreduceAllEdit: {
          ...payload
        }
      };
    },
    proxyRealAll(state, { payload }) {
      return {
        ...state,
        proxyRealAll: {
          ...payload
        }
      };
    },
    // 实名状态
    updateProxyRealAudit(state, { payload }) {
      return {
        ...state,
        proxyRealAll: {
          ...state.proxyRealAll
        }
      };
    },
    deleteProxyRealAudit(state, { payload }) {
      let targetItem = state.proxyRealAll.list.filter(
        item => item.id !== payload.id
      );
      const states = Object.assign({}, state);
      states.proxyRealAll.list = targetItem;
      return {
        ...state,
        proxyRealAll: { ...state.proxyRealAll }
      };
    },
    proxyRealAllEdit(state, { payload }) {
      return {
        ...state,
        proxyRealAllEdit: {
          ...payload
        }
      };
    },
    qrCodeList(state, { payload }) {
      return {
        ...state,
        qrCodeList: {
          ...payload
        }
      };
    },
    // 二维码状态
    updateQRCodeAudit(state, { payload }) {
      return {
        ...state,
        qrCodeList: {
          ...state.qrCodeList
        }
      };
    },
    deleteQRCodeAudit(state, { payload }) {
      let targetItem = state.qrCodeList.list.filter(
        item => item.id !== payload.id
      );
      const states = Object.assign({}, state);
      states.qrCodeList.list = targetItem;
      return {
        ...state,
        qrCodeList: { ...state.qrCodeList }
      };
    },
    qrCodeListEdit(state, { payload }) {
      return {
        ...state,
        qrCodeListEdit: {
          ...payload
        }
      };
    }
  },
  subscriptions: {
    setup({ history }) {}
  }
};
