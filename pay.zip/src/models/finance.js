import http from '@/common/request';

export default {
  namespace: 'finance',
  state: {
    getAcmClearMoveByGroupNumInfo:{
      list:[]
    },
    getPlatformTransferByGroupNumInfo: {
      list: {}
    },
    editHistoryIncomeInfo:{},
    HistorycomeEditDto:{},
    findMerchantHistoryIncomeInfo: {},
    getTheGoldAuditInfos: {},
    mchBatchTransferInfo: {},
    merchantProxyRemark: {},
    editMerchantProxyRateInfo: {},
    editMerchantProxyInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    merchantProxySettlementList: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    achProxyTime: {
      end_time: ''
    },
    delProxyAssociAchInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    findBusinessUserByAchId: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    merchantListViewEdit: {
      ach_id: ''
    },
    merchantProxyEdit: {
      name: '',
      ali_rate: '',
      wx_rate: ''
    },
    associMerchant: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    associMerchantInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    merchantProxyInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    platformTransferInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    platformTransferEditInfo: {
      ach_remark: '',
      plt_remark: ''
    },
    findPayChannelAll: {
      page: 1,
      pageSize: 20,
      total: 0,
      channel: []
    },
    platformTransferDetail: {
      id: 1,
      plt_remark: '',
      status: 1
    },
    proxyTransferInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    bankListInfo: {
      page: 1,
      pageSize: 200,
      total: 0,
      list: []
    },
    withdrawalTransferEdit: {},
    proxyTransferEdit: {},
    proxyTransferEditInfo: {
      ticket: '',
      price: '',
      pay_code: '',
      amount: '',
      use_amount: '',
      stop_unix: ''
    },
    proxyTransferStatus: {
      status: ''
    },
    proxySettlementInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    //总代明细
    settlementDetails: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    //未结算
    noSettlementTotal: {
      StatementTime: '',
      noSettlementTotal: '',
      start_time: ''
    },
    proxyNoSettlementTotal: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    proxyNoSettlementTotalShow: {
      pay_account: '',
      pay_name: '',
      pay_type: ''
    },
    proxyNoSettlementTotalStatus: {
      status: ''
    },
    sonClearingDetail: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    sonClearingDetailShow: {
      pay_account: '',
      pay_name: '',
      pay_type: ''
    },
    withdrawAuditListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    },
    searchWithdrawInfo: {
      data: {}
    },
    searchTransferInfo: {
      data: {}
    },
    merchantProxyTransfer: {
      id: 1,
      plt_remark: '',
      status: 1
    },
    merchantPayAllListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      list: []
    }
  },

  effects: {
    
    *getAcmClearMoveByGroupNum({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAcmClearMoveByGroupNum, payload);
      if (res.code === 200) {
        yield put({
          type: 'getAcmClearMoveByGroupNumInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *editHistoryIncome({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editHistoryIncome, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'editHistoryIncomeInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 平台转账  点击查询
    *saveSearch({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveSearch, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({});
      }
      if (callback) {
        callback(res);
      }
    },
    *getPlatformTransferByGroupNum(
      { payload, callback },
      { call, put, select }
    ) {
      const res = yield call(http.getPlatformTransferByGroupNum, payload);
      if (res.code === 200) {
        yield put({
          type: 'getPlatformTransferByGroupNumInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 出金审核
    *findMerchantHistoryIncome({ payload, callback }, { call, put, select }) {
      const res = yield call(http.findMerchantHistoryIncome, payload);
      if (res.code === 200) {
        yield put({
          type: 'findMerchantHistoryIncomeInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 出金审核
    *getTheGoldAuditInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getTheGoldAuditInfo, payload);
      if (res.code === 200) {
        yield put({
          type: 'getTheGoldAuditInfos',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 商户代理转账
    *mchProxyTransfer({ payload, callback }, { call, put, select }) {
      const res = yield call(http.mchProxyTransfer, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'mchProxyTransferInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 商户代理结算
    *getMerchantProxySettlement({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getMerchantProxySettlement, payload);
      if (res.code === 200) {
        yield put({
          type: 'merchantProxySettlementList',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //商户代理结算-初始时间
    *getAchProxyTime({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAchProxyTime, payload);
      if (res.code === 200) {
        yield put({
          type: 'achProxyTime',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //商户代理-结算
    *buildSettlement({ payload, callback }, { call, put, select }) {
      const res = yield call(http.buildSettlement, payload, { method: 'POST' });
      if (res.code === 200) {
      }
      if (callback) {
        callback(res);
      }
    },
    // 关联商户
    *delProxyAssociAch({ payload, callback }, { call, put, select }) {
      const res = yield call(http.delProxyAssociAch, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'delProxyAssociAchInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 关联商户
    *proxyAssociAch({ payload, callback }, { call, put, select }) {
      const res = yield call(http.proxyAssociAch, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'proxyAssociAchInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 根据商户id查询商户
    *getFindBusinessUserByAchId({ payload, callback }, { call, put, select }) {
      const res = yield call(http.findBusinessUserByAchId, payload);
      if (res.code === 200) {
        yield put({
          type: 'findBusinessUserByAchId',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 查询关联商户
    *findAssociMerchant({ payload, callback }, { call, put, select }) {
      const res = yield call(http.findAssociMerchant, payload);
      if (res.code === 200) {
        yield put({
          type: 'associMerchantInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 修改商户代理
    *editMerchantProxy({ payload, callback }, { call, put, select }) {
      const res = yield call(http.editMerchantProxy, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'editMerchantProxyInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 查询全部商户代理
    *getMerchantProxy({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getMerchantProxy, payload);
      if (res.code === 200) {
        yield put({
          type: 'merchantProxyInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 创建商户代理
    *createMerchantProxy({ payload, callback }, { call, put, select }) {
      const res = yield call(http.createMerchantProxy, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'createMerchantProxyInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //平台转账
    *getPlatformTransferInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getPlatformTransferInfo, payload);
      if (res.code === 200) {
        yield put({
          type: 'platformTransferInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *savePlatformTransferDetail({ payload, callback }, { call, put, select }) {
      const res = yield call(http.savePlatformTransferDetail, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'platformTransferDetail',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *mchBatchTransfer({ payload, callback }, { call, put, select }) {
      const res = yield call(http.mchBatchTransfer, payload, {
        method: 'post'
      });
      if (res.code === 200) {
        yield put({
          type: 'mchBatchTransferInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getFindPayChannelAll({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getFindPayChannelAll, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'findPayChannelAll',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getBankList({ payload }, { call, put, select }) {
      const res = yield call(http.getBankList, payload);
      if (res.code === 200) {
        if (res.data.list.length !== 0) {
          yield put({
            type: 'bankListInfo',
            payload: res.data
          });
        } else {
          return;
        }
      }
    },
    //代理转账
    *getProxyTransferInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyTransferInfo, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyTransferInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getProxyTransferEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyTransferEdit, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyTransferEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getProxyTransferPass({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyTransferStatus, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateProxyTransfer',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxyTransferRefuse({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyTransferStatus, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'updateProxyTransfer',
          payload: res.data
        });
      }
      if (callback) {
        callback({ total: res.data.total });
      }
    },
    *getProxySettlement({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxySettlement, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxySettlementInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //生成结算单
    *buildBill({ payload, callback }, { call, put, select }) {
      const res = yield call(http.buildBill, payload);
      if (res.code === 200) {
      }
      if (callback) {
        callback(res);
      }
    },
    //总代理明细
    *getSettlementDetails({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getSettlementDetails, payload);
      if (res.code === 200) {
        yield put({
          type: 'settlementDetails',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //未结算
    *getProxyNoSettlementTotal({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyNoSettlementTotal, payload);
      if (res.code === 200) {
        yield put({
          type: 'noSettlementTotal',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //导出excel
    *settlementDetailsDownload({ payload, callback }, { call, put, select }) {
      const res = yield call(http.settlementDetailsDownload, payload);
      if (res.code === 200) {
      }
      if (callback) {
        callback(res);
      }
    },
    //修改状态
    *updateProxySettlementStatus({ payload, callback }, { call, put, select }) {
      const res = yield call(http.updateProxySettlementStatus, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'proxyNoSettlementTotalStatus',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //子代理明细
    *getSonClearingDetail({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getSonClearingDetail, payload);
      if (res.code === 200) {
        yield put({
          type: 'sonClearingDetail',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *searchWithdraw({ payload, callback }, { call, put, select }) {
      const res = yield call(http.searchWithdrawInfo, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'searchWithdrawInfo',
          payload: res
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *searchTransfer({ payload, callback }, { call, put, select }) {
      const res = yield call(http.searchTransferInfo, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'searchTransferInfo',
          payload: res
        });
      }
      if (callback) {
        callback(res);
      }
    },
    // 商户充值
    *getMerchantPayAllList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getMerchantPayAllList, payload);
      if (res.code === 200) {
        yield put({
          type: 'merchantPayAllListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *merchantRecharge({ payload, callback }, { call, put, select }) {
      const res = yield call(http.merchantRecharge, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'merchantRechargeInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *searchAchId({ payload, callback }, { call, put, select }) {
      const res = yield call(http.searchAchId, payload);
      if (res.code === 200) {
        yield put({
          // type: 'searchAchIdInfo',
          // payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    }
  },
  reducers: {
    
    getAcmClearMoveByGroupNumInfo(state, { payload }) {
      return {
        ...state,
        getAcmClearMoveByGroupNumInfo: {
          ...payload
        }
      };
    },
    editHistoryIncomeInfo(state, { payload }) {
      return {
        ...state,
        editHistoryIncomeInfo: {
          ...payload
        }
      };
    },
    
    HistorycomeEditDto(state, { payload }) {
      return {
        ...state,
        HistorycomeEditDto: {
          ...payload
        }
      };
    },
    getPlatformTransferByGroupNumInfo(state, { payload }) {
      return {
        ...state,
        getPlatformTransferByGroupNumInfo: {
          ...payload
        }
      };
    },
    findMerchantHistoryIncomeInfo(state, { payload }) {
      return {
        ...state,
        findMerchantHistoryIncomeInfo: {
          ...payload
        }
      };
    },
    getTheGoldAuditInfos(state, { payload }) {
      return {
        ...state,
        getTheGoldAuditInfos: {
          ...payload
        }
      };
    },
    mchBatchTransferInfo(state, { payload }) {
      return {
        ...state,
        mchBatchTransferInfo: {
          ...payload
        }
      };
    },
    merchantProxyRemark(state, { payload }) {
      return {
        ...state,
        merchantProxyRemark: {
          ...payload
        }
      };
    },
    merchantProxySettlementList(state, { payload }) {
      return {
        ...state,
        merchantProxySettlementList: {
          ...payload
        }
      };
    },
    achProxyTime(state, { payload }) {
      return {
        ...state,
        achProxyTime: {
          ...payload
        }
      };
    },
    editMerchantProxyInfo(state, { payload }) {
      return {
        ...state,
        editMerchantProxyInfo: {
          ...payload
        }
      };
    },
    delProxyAssociAchInfo(state, { payload }) {
      return {
        ...state,
        delProxyAssociAchInfo: {
          ...payload
        }
      };
    },
    proxyAssociAchInfo(state, { payload }) {
      return {
        ...state,
        proxyAssociAchInfo: {
          ...payload
        }
      };
    },
    findBusinessUserByAchId(state, { payload }) {
      return {
        ...state,
        findBusinessUserByAchId: {
          ...payload
        }
      };
    },
    associMerchant(state, { payload }) {
      return {
        ...state,
        associMerchant: {
          ...payload
        }
      };
    },
    associMerchantInfo(state, { payload }) {
      return {
        ...state,
        associMerchantInfo: {
          ...payload
        }
      };
    },
    merchantProxyInfo(state, { payload }) {
      return {
        ...state,
        merchantProxyInfo: {
          ...payload
        }
      };
    },
    stat(state, { payload }) {
      return {
        ...state,
        stat: {
          ...payload
        }
      };
    },
    pastStatListInfo(state, { payload }) {
      return {
        ...state,
        pastStatListInfo: {
          ...payload
        }
      };
    },
    incomeDetailListInfo(state, { payload }) {
      return {
        ...state,
        incomeDetailListInfo: {
          ...payload
        }
      };
    },
    transDetailListInfo(state, { payload }) {
      return {
        ...state,
        transDetailListInfo: {
          ...payload
        }
      };
    },
    yollonListInfo(state, { payload }) {
      return {
        ...state,
        yollonListInfo: {
          ...payload
        }
      };
    },
    yollonDetailListInfo(state, { payload }) {
      return {
        ...state,
        yollonDetailListInfo: {
          ...payload
        }
      };
    },
    yollon(state, { payload }) {
      return {
        ...state,
        yollon: {
          ...payload
        }
      };
    },
    //平台转账
    platformTransferInfo(state, { payload }) {
      return {
        ...state,
        platformTransferInfo: {
          ...payload
        }
      };
    },
    findPayChannelAll(state, { payload }) {
      return {
        ...state,
        findPayChannelAll: {
          ...payload
        }
      };
    },
    bankListInfo(state, { payload }) {
      return {
        ...state,
        bankListInfo: {
          ...payload
        }
      };
    },
    platformTransferEditInfo(state, { payload }) {
      return {
        ...state,
        platformTransferEditInfo: {
          ...payload
        }
      };
    },
    //代理转账
    proxyTransferInfo(state, { payload }) {
      return {
        ...state,
        proxyTransferInfo: {
          ...payload
        }
      };
    },
    updateProxyTransfer(state, { payload }) {
      return {
        ...state,
        proxyTransferInfo: {
          ...state.proxyTransferInfo
        }
      };
    },
    deleteProxyTransfer(state, { payload }) {
      let targetItem = state.proxyTransferInfo.list.filter(
        item => item.id !== payload.id
      );
      const states = Object.assign({}, state);
      states.proxyTransferInfo.list = targetItem;
      return {
        ...state,
        proxyTransferInfo: { ...state.proxyTransferInfo }
      };
    },
    proxyTransferEditInfo(state, { payload }) {
      return {
        ...state,
        proxyTransferEditInfo: {
          ...payload
        }
      };
    },
    proxyTransferEdit(state, { payload }) {
      return {
        ...state,
        proxyTransferEdit: {
          ...payload
        }
      };
    },
    platformTransferDetail(state, { payload }) {
      return {
        ...state,
        platformTransferDetail: {
          ...payload
        }
      };
    },
    proxySettlementInfo(state, { payload }) {
      return {
        ...state,
        proxySettlementInfo: {
          ...payload
        }
      };
    },
    //总代理
    settlementDetails(state, { payload }) {
      return {
        ...state,
        settlementDetails: {
          ...payload
        }
      };
    },
    //未结算
    noSettlementTotal(state, { payload }) {
      return {
        ...state,
        noSettlementTotal: {
          ...payload
        }
      };
    },
    proxyNoSettlementTotalShow(state, { payload }) {
      return {
        ...state,
        proxyNoSettlementTotalShow: {
          ...payload
        }
      };
    },
    proxyNoSettlementTotalStatus(state, { payload }) {
      return {
        ...state,
        proxyNoSettlementTotalStatus: {
          ...payload
        }
      };
    },
    sonClearingDetail(state, { payload }) {
      return {
        ...state,
        sonClearingDetail: {
          ...payload
        }
      };
    },
    sonClearingDetailShow(state, { payload }) {
      return {
        ...state,
        sonClearingDetailShow: {
          ...payload
        }
      };
    },
    merchantProxyEdit(state, { payload }) {
      return {
        ...state,
        merchantProxyEdit: {
          ...payload
        }
      };
    },
    merchantListViewEdit(state, { payload }) {
      return {
        ...state,
        merchantListViewEdit: {
          ...payload
        }
      };
    },
    withdrawalTransferEdit(state, { payload }) {
      return {
        ...state,
        withdrawalTransferEdit: {
          ...payload
        }
      };
    },
    searchWithdrawInfo(state, { payload }) {
      return {
        ...state,
        searchWithdrawInfo: {
          ...payload
        }
      };
    },
    searchTransferInfo(state, { payload }) {
      return {
        ...state,
        searchTransferInfo: {
          ...payload
        }
      };
    },
    merchantProxyTransfer(state, { payload }) {
      return {
        ...state,
        merchantProxyTransfer: {
          ...payload
        }
      };
    },
    merchantPayAllListInfo(state, { payload }) {
      return {
        ...state,
        merchantPayAllListInfo: {
          ...payload
        }
      };
    }
  },
  subscriptions: {
    setup({ history }) {}
  }
};
