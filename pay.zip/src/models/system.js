import http from '@/common/request';
import { pageHandle } from '@/utils/utils';

export default {
  namespace: 'system',
  state: {
    editKoubeiConfig:{},
    addKoubeiConfigInfo:{},
    koubeiConfigView:{},
    getKoubeiConfigInfo:{},
    EditPermissionsInfo:{},
    permissionsEdit:{},
    getRoleAuthInfo: {},
    getPermissionsInfo: {},
    payPassEditInfo: {},
    delQrConsts: {},
    addQrConsts: {},
    getQrConstsInfo: {},
    stat: {
      alipay: [],
      wxipay: [],
      total: []
    },
    operationRecordsAllInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    proxyPriceInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    systemConfig: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    systemConfigEdit: {
      key: '',
      value: ''
    },
    qrcodeSourceInfo: {
      // page: 1,
      // pageSize: 20,
      // total: 0,
      // ts: 0,
      // list: []
      alipay: [],
      weixin: []
    },
    qrcodeSourceEditInfo: {
      price: '',
      floatPrice: ''
    },
    adminAllInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    adminAllInfoEdit: {
      account: '',
      password: '',
      group: ''
    },
    blackListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    addBlackListInfo: {
      ip: ''
    },
    qrcodeGroupListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    },
    qrcodeGroupedListInfo: {
      page: 1,
      pageSize: 20,
      total: 0,
      ts: 0,
      list: []
    }
  },
  // 处理异步逻辑
  effects: {
    
    * addKoubeiConfig({ payload, callback }, { call, put, select }) {
    const res = yield call(http.addKoubeiConfig, payload, { method: 'POST' });
    if (res.code === 200) {
      yield put({
        type: 'addKoubeiConfigInfo',
        payload: res.data
      });
    }
    if (callback) {
      callback(res);
    }
  },
    *getKoubeiConfig({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getKoubeiConfig, payload);
      if (res.code === 200) {
        yield put({
          type: 'getKoubeiConfigInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    * EditPermissions({ payload, callback }, { call, put, select }) {
      const res = yield call(http.EditPermissions, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'EditPermissionsInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getRoleAuth({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getRoleAuth, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'getRoleAuthInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getPermissions({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getPermissions, payload);
      if (res.code === 200) {
        yield put({
          type: 'getPermissionsInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *payPassEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.payPassEdit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'payPassEditInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *delQrConsts({ payload, callback }, { call, put, select }) {
      const res = yield call(http.delQrConsts, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'delQrConstsInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *addQrConsts({ payload, callback }, { call, put, select }) {
      const res = yield call(http.addQrConsts, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'addQrConstsInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getQrConsts({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getQrConsts, payload);
      if (res.code === 200) {
        yield put({
          type: 'getQrConstsInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getOperationRecordsAll({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getOperationRecordsAll, payload);
      if (res.code === 200) {
        yield put({
          type: 'operationRecordsAllInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getProxyPrice({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getProxyPrice, payload);
      if (res.code === 200) {
        yield put({
          type: 'proxyPriceInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //管理员
    *getAdminAllList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getAdminAllList, payload);
      if (res.code === 200) {
        yield put({
          type: 'adminAllInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getSystemConfig({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getSystemConfig, payload);
      if (res.code === 200) {
        yield put({
          type: 'systemConfig',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveSystemConfigEdit({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveSystemConfigEdit, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
        yield put({
          type: 'systemConfigEdit',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getQrcodeSource({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getQrcodeSource, payload);
      if (res.code === 200) {
        yield put({
          type: 'qrcodeSourceInfo',
          payload: res.data.list
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *saveQrcodeSourceEditInfo({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveQrcodeSourceEditInfo, payload);
      if (res.code === 200) {
        yield put({
          type: 'qrcodeSourceEditInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getBlackList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getBlackList, payload);
      if (res.code === 200) {
        yield put({
          type: 'blackListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //添加黑名单
    *saveAddBlackList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveAddBlackList, payload, {
        method: 'POST'
      });
      // console.log('res', res);
      if (res.code === 200) {
        yield put({
          type: 'blackListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    //删除黑名单
    *getDelBlackList({ payload, callback }, { call, put, select }) {
      const res = yield call(http.getDelBlackList, payload, { method: 'POST' });
      if (res.code === 200) {
        yield put({
          type: 'delBlackIp',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getQrcodeGroupList({ payload, callback }, { call, put, select }) {
      const qrcodeGroupListInfo = yield select(
        state => state.system.qrcodeGroupListInfo
      );
      pageHandle(payload, qrcodeGroupListInfo);
      const res = yield call(http.getQrcodeGroupList, payload);
      if (res.code === 200) {
        yield put({
          type: 'qrcodeGroupListInfo',
          payload: res.data
        });
      }
      if (callback) {
        callback(res);
      }
    },
    *getQrcodeGroupedList({ payload, callback }, { call, put, select }) {
      const qrcodeGroupedListInfo = yield select(
        state => state.system.qrcodeGroupedListInfo
      );
      pageHandle(payload, qrcodeGroupedListInfo);
      const res = yield call(http.getQrcodeGroupedList, payload);
      if (res.code === 200) {
        yield put({
          type: 'qrcodeGroupedListInfo',
          payload: res.data
        });
      }

      if (callback) {
        callback(res);
      }
    },
    *saveQrcodeGroup({ payload, callback }, { call, put, select }) {
      const res = yield call(http.saveQrcodeGroup, payload, { method: 'POST' });
      if (res.code === 200) {
      }
      if (callback) {
        callback(res);
      }
    },
    *deleteQrcodeGroup({ payload, callback }, { call, put, select }) {
      const res = yield call(http.deleteQrcodeGroup, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
      }
      if (callback) {
        callback(res);
      }
    },
    *changeGroupIsEnable({ payload, callback }, { call, put, select }) {
      const res = yield call(http.changeGroupIsEnable, payload, {
        method: 'POST'
      });
      if (res.code === 200) {
      }
      if (callback) {
        callback(res);
      }
    }
  },
  // 接受action，同步更新state
  reducers: {
    editKoubeiConfig(state, { payload }) {
      return {
        ...state,
        editKoubeiConfig: { ...payload }
      };
    },
    addKoubeiConfigInfo(state, { payload }) {
      return {
        ...state,
        addKoubeiConfigInfo: { ...payload }
      };
    },
    koubeiConfigView(state, { payload }) {
      return {
        ...state,
        koubeiConfigView: { ...payload }
      };
    },
    getKoubeiConfigInfo(state, { payload }) {
      return {
        ...state,
        getKoubeiConfigInfo: { ...payload }
      };
    },
    EditPermissionsInfo(state, { payload }) {
      return {
        ...state,
        EditPermissionsInfo: { ...payload }
      };
    },
    permissionsEdit(state, { payload }) {
      return {
        ...state,
        permissionsEdit: { ...payload }
      };
    },
    getRoleAuthInfo(state, { payload }) {
      return {
        ...state,
        getRoleAuthInfo: { ...payload }
      };
    },
    getPermissionsInfo(state, { payload }) {
      return {
        ...state,
        getPermissionsInfo: { ...payload }
      };
    },
    payPassEditInfo(state, { payload }) {
      return {
        ...state,
        payPassEditInfo: { ...payload }
      };
    },
    delQrConsts(state, { payload }) {
      return {
        ...state,
        delQrConsts: { ...payload }
      };
    },
    addQrConsts(state, { payload }) {
      return {
        ...state,
        addQrConsts: { ...payload }
      };
    },
    getQrConstsInfo(state, { payload }) {
      return {
        ...state,
        getQrConstsInfo: { ...payload }
      };
    },
    operationRecordsAllInfo(state, { payload }) {
      return {
        ...state,
        operationRecordsAllInfo: { ...payload }
      };
    },
    proxyPriceInfo(state, { payload }) {
      return {
        ...state,
        proxyPriceInfo: { ...payload }
      };
    },
    systemConfig(state, { payload }) {
      return {
        ...state,
        systemConfig: { ...payload }
      };
    },
    adminAllInfo(state, { payload }) {
      return {
        ...state,
        adminAllInfo: { ...payload }
      };
    },
    adminAllInfoEdit(state, { payload }) {
      return {
        ...state,
        adminAllInfoEdit: { ...payload }
      };
    },
    systemConfigEdit(state, { payload }) {
      return {
        ...state,
        systemConfigEdit: { ...payload }
      };
    },
    // qrcodeSourceInfo(state, { payload }) {
    //   return {
    //     ...state,
    //     qrcodeSourceInfo: { ...payload }
    //   };
    // },
    qrcodeSourceInfo(state, { payload }) {
      state.qrcodeSourceInfo.alipay = [];
      state.qrcodeSourceInfo.weixin = [];
      payload.map(item => {
        if (item.PayType === 100) {
          state.qrcodeSourceInfo.alipay.push(item);
        } else {
          state.qrcodeSourceInfo.weixin.push(item);
        }
      });
      return {
        ...state
        // qrcodeSourceInfo: {
        //   ...payload
        // }
      };
    },
    qrcodeSourceEditInfo(state, { payload }) {
      return {
        ...state,
        qrcodeSourceEditInfo: { ...payload }
      };
    },
    blackListInfo(state, { payload }) {
      return {
        ...state,
        blackListInfo: { ...payload }
      };
    },
    addBlackIp(state, { payload }) {
      let targetItem = state.blackListInfo.list.filter(
        item => item.id === payload.id
      );
      const states = Object.assign({}, state);
      states.blackListInfo.list = targetItem;
      return {
        ...state,
        blackListInfo: { ...state.blackListInfo }
      };
    },
    delBlackIp(state, { payload }) {
      let targetItem = state.blackListInfo.list.filter(
        item => item.id !== payload.id
      );
      const states = Object.assign({}, state);
      states.blackListInfo.list = targetItem;
      return {
        ...state,
        blackListInfo: { ...state.blackListInfo }
      };
    },
    qrcodeGroupListInfo(state, { payload }) {
      return {
        ...state,
        qrcodeGroupListInfo: {
          ...payload
        }
      };
    },
    qrcodeGroupedListInfo(state, { payload }) {
      return {
        ...state,
        qrcodeGroupedListInfo: {
          ...payload
        }
      };
    }
  },
  subscriptions: {
    setup({ history }) {}
  }
};
