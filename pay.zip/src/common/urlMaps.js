const urlMaps = {
  login: '/api/v1/operation/login',
  logout: '/api/v1/operation/logout',
  register: '/api/v1/user/register',
  getUserInfo: '/api/v1/info/detail',
  saveUserInfo: '/api/v1/info/modify',
  sendCaptcha: '/api/v1/user/code',
  forgetPassword: '/api/v1/user/forget/password',
  resetPassword: '/api/v1/user/reset/password',
  setPassword: '/api/v1/user/set/password',
  uploadAvatar: '/api/v1/upload/avatar',
  getMenuData: '/api/v1/menu/getMenu',
  saveAddMenu: '/api/v1/system/addMgrMenu',
  saveDelMenu: '/api/v1/system/delMgrMenu',
  saveEditMenu: '/api/v1/system/editMgrMenu',
  saveChangeMenuStatus: '/api/v1/system/editMgrMenuIsShow',
  getPermissions: '/api/v1/system/getPermissions',
  getRoleAuth: '/api/v1/system/getRoleAuth',
  EditPermissions: '/api/v1/system/editPermissions',

  //统计
  getBaseStat: '/api/v1/statistical/calendar',
  getStatList: '/api/v1/statistical/all',
  getStatTop10: '/api/v1/statistical/top10',
  getMerchantDayReport: '/api/v1/statistical/businessInfo',
  getClearingReport: '/api/v1/business/clearingReport',

  //财务
  saveSearch: '', // 平台转账  点击查询
  findMerchantHistoryIncome: '/api/v1/financial/findMerchantHistoryIncome',
  getTheGoldAuditInfo: '/api/v1/financial/getTheGoldAuditInfo',
  getPlatformTransferInfo: '/api/v1/financial/achClearMoveList',
  savePlatformTransferDetail: '/api/v1/financial/audit',
  getFindPayChannelAll: '/api/v1/financial/findPayChannelAll',
  getProxyTransferInfo: '/api/v1/financial/bill/list',
  getProxyTransferEdit: '/api/v1/financial/findAchReceiveAccountById',
  getProxyTransferStatus: '/api/v1/financial/bill/update',
  getProxySettlement: '/api/v1/financial/proxySettlement',
  buildBill: '/api/v1/xlsx/proxyNoSettlementBillDownload',
  getProxyNoSettlementTotal: '/api/v1/financial/proxyNoSettlementTotal',
  getSonClearingDetail: '/api/v1/financial/lowerProxySettlementDetails',
  getSettlementDetails: '/api/v1/financial/settlementDetails',
  download: '/api/v1/xlsxexcel/settlementDetailsDownload',
  settlementDetailsDownload: '/api/v1/xlsxexcel/settlementDetailsDownload',
  updateProxySettlementStatus: '/api/v1/financial/editSettlementDetails',
  searchWithdrawInfo: '/api/v1/financial/tradeQuery', // 查询提现
  searchTransferInfo: '/api/v1/financial/achProxyTradeQuery', // 查询转账
  getMerchantProxySettlement: '/api/v1/financial/getMchProxyWithdrawal', //商户代理结算
  getAchProxyTime: '/api/v1/financial/achProxyTime', //商户代理结算-初始时间
  buildSettlement: '/api/v1/financial/achProxySettlement',
  getMerchantPayAllList: '/api/v1/financial/findMerchantRecharge', // 商户充值
  merchantRecharge: '/api/v1/financial/merchantRecharge', // 商户充值
  searchAchId: '/api/v1/financial/findBusinessUser', // 商户ID查询
  mchBatchTransfer: '/api/v1/financial/mchBatchTransfer', // 商户批量转账
  getPlatformTransferByGroupNum: '/api/v1/financial/getAchClearMoveByGroupNum', // 根据批次号查询
  editHistoryIncome: '/api/v1/financial/editHistoryIncome', // 历史收益结算

  // 商户代理
  getMerchantProxy: '/api/v1/financial/getMerchantProxy', // 查询全部商户代理
  createMerchantProxy: '/api/v1/financial/createMerchantProxy', // 创建商户代理
  editMerchantProxy: '/api/v1/financial/editMerchantProxy', // 修改商户代理信息
  findAssociMerchant: '/api/v1/financial/findAssociMerchant', // 查询关联商户
  findBusinessUserByAchId: '/api/v1/financial/findBusinessUserByAchId', // 查询关联商户
  proxyAssociAch: '/api/v1/financial/proxyAssociAch', // 关联商户
  delProxyAssociAch: '/api/v1/financial/delProxyAssociAch', // 删除关联商户
  mchProxyTransfer: '/api/v1/financial/mchProxyTransfer', // 商户代理转账
  getAcmClearMoveByGroupNum: '/api/v1/financial/getAcmClearMoveByGroupNum', //

  //订单管理
  getOrderInfo: '/api/v1/orders/list',
  getForcedReview: '/api/v1/orders/forcedReview',
  getOrdeNotify: '/api/v1/orders/notifyOrder',
  getOrderReviewAll: '/api/v1/orders/orderReviewAll',
  getProxyPushNotice: '/api/v1/orders/proxyPushNotice',
  toOrderCheckDatas: '/api/v1/orders/toOrderCheckDatas',

  //商户管理
  getMerchantList: '/api/v1/business/businessAll',
  getCardManageList: '/api/v1/business/achReceiveAccountsAll',
  changeCardManageStatus: '/api/v1/business/achReceiveAccountsAudit',
  saveMerchantTransfer: '/api/v1/business/platformTransfer',
  getMerchantTransfer: '/api/v1/financial/opClickWithdrawal',
  getBankList: '/api/v1/financial/accountWayAll',
  getMerchantTreeList: '/api/v1/business/businessGroup',
  getMerchantUserInfo: '/api/v1/business/businessInfo',
  editBusinessUser: '/api/v1/business/editBusinessUser', // 修改商户费率
  businessUpdateStatus: '/api/v1/business/businessUpdateStatus', // 商户账号封停
  editBusinessPassWord: '/api/v1/operation/editBusinessPassWord', // 修改商户密码
  getMerchantListView: '/api/v1/business/stat',
  mchOrderSettlementList: '/api/v1/business/mchOrderSettlementList',
  editHistory: '/api/v1/business/editHistory', // 修改历史信息

  //代理管理
  editProxyPassWord: '/api/v1/operation/editProxyPassWord',
  getProxyList: '/api/v1/proxy/list',
  getProxyFather: '/api/v1/proxy/proxyFather',
  getProxySon: '/api/v1/proxy/proxySon',
  getProxyAccountInfo: '/api/v1/proxy/proxyInfo',
  getProxyTreeList: '/api/v1/proxy/proxyTree',
  freezeType: '/api/v1/proxy/setQrState',
  delAccount: '/api/v1/proxy/clean_qr',
  newProxy: '/api/v1/proxy/newProxy', // 创建总代理
  freezeProxy: '/api/v1/proxy/freezeProxy',
  getAliValidProxyList: '/api/v1/proxy/getAliValidProxyList',
  

  //分润流水
  getProfitFlow: '/api/v1/proxy/proxyIncomeDtails',
  getProfitFlowEdit: '/api/v1/proxy/proxyIncomeDtailsByOid',

  //充值额度
  getProxyPayAll: '/api/v1/proxy/proxyPayAll',
  getProxyPayAudit: '/api/v1/proxy/proxyPayAudit',
  getProxyPayAllEdit: '/api/v1/proxy/proxyPayAll',
  savePayLimitEdit: '/api/v1/proxy/proxyPayAll',

  //代理降额
  getProxyPreduceAll: '/api/v1/proxy/proxyPreduceAll',
  getProxyPreduceAudit: '/api/v1/proxy/proxyPreduceAudit',
  getProxyPreduceAllEdit: '/api/v1/proxy/proxyPreduceAll',
  saveProxyPreduceAlltEdit: '/api/v1/proxyPreduceAll/save',

  //代理实名
  getProxyRealAll: '/api/v1/proxy/proxyRealAll',
  getProxyRealAudit: '/api/v1/proxy/proxyRealAudit',
  getProxyRealAllEdit: '/api/v1/proxy/proxyRealAll',
  saveProxyRealAllEdit: '/api/v1/proxy/proxyRealAll',

  //二维码管理
  getQRCodeList: '/api/v1/proxy/qrcodeList',
  getQRAuditAudit: '/api/v1/proxy/qrAudit',
  getQRCodeListEdit: '/api/v1/proxy/qrcodeList',
  saveQRCodeListEdit: '/api/v1/proxy/qrcodeList',
  getProxyOperateList: '/api/v1/proxy/getProxyOperateList',
  getProxyOrderNumList: '/api/v1/proxy/getProxyOrderNumList',
  getRiskControlList: '/api/v1/proxy/getRiskControlList',

  //二维码资源
  getQrcodeSource: '/api/v1/system/onlineQr',
  // saveQrcodeSourceEditInfo: '/api/v1/system/onlineQr',

  //系统管理
  getSystemConfig: '/api/v1/system/systemConfig',
  saveSystemConfigEdit: '/api/v1/system/editSystemConfig',
  getOperationRecordsAll: '/api/v1/system/operationRecordsAll',
  payPassEdit: '/api/v1/operation/payPassEdit',
  getKoubeiConfig: '/api/v1/system/getKoubeiConfig',
  addKoubeiConfig: '/api/v1/system/addKoubeiConfig',
  
  

  //管理员
  getAdminAllList: '/api/v1/system/adminAll',
  getAdministratorEdit: '/api/v1/administrator/edit',
  savaAdministratorEdit: '/api/v1/administrator/save',

  // 黑名单
  getBlackList: '/api/v1/system/blackIpAll',
  saveAddBlackList: '/api/v1/system/addBlackIp',
  getDelBlackList: '/api/v1/system/delBlackIp',

  // 二维码配置
  getQrConsts: '/api/v1/system/getQrConsts',
  addQrConsts: '/api/v1/system/addQrConsts',
  delQrConsts: '/api/v1/system/delQrConsts',

  //二维码分组
  getQrcodeGroupList: '/api/v1/proxy/proxylist',
  getQrcodeGroupedList: '/api/v1/proxy/proxyGrouplist',
  saveQrcodeGroup: '/api/v1/proxy/addProxyGroup',
  deleteQrcodeGroup: '/api/v1/proxy/delProxyGroup',
  changeGroupIsEnable: '/api/v1/proxy/statrAndStopProxyGroup',

  // 渠道
  getChannelManage: '/api/v1/channel/getChannelManage',
  createPayChannel: '/api/v1/channel/createPayChannel',
  editPayChannel: '/api/v1/channel/editPayChannel',

  // 兑换
  getExchangeRecord: '/api/v1/exchange/getExchangeRecord',
  getReceiveBank: '/api/v1/exchange/getReceiveBankAll',
  editReceiveBankInfo: '/api/v1/exchange/editReceiveBankInfo',
  getBankConfigAll: '/api/v1/exchange/getBankConfigAll',
  createReceiveBank: '/api/v1/exchange/createReceiveBank',
  getExchangeWay: '/api/v1/exchange/getExchangeWayAll',
  createExchangeWay: '/api/v1/exchange/createExchangeWay',
  editExchangeWay: '/api/v1/exchange/editExchangeWay',
  getCurrencyConfig: '/api/v1/exchange/getCurrencyConfig',
  createCurrencyConfig: '/api/v1/exchange/createCurrencyConfig',
  editCurrencyConfig: '/api/v1/exchange/editCurrencyConfig',
  getCurrencyConfigList: '/api/v1/exchange/getCurrencyConfigList',
  editExchangeRecordStatus: '/api/v1/exchange/editExchangeRecordStatus'
};

// export const baseUrl = "http://share.axingxing.com/proxy"
export const baseUrl = '';

export const loginWhiteList = [urlMaps.getUserInfo, urlMaps.getBannerList];

export default urlMaps;
