import React from 'react';

// 登录
import UserLogin from '@/modules/User/UserLogin';
import UserRegister from '@/modules/User/UserRegister';

// 商户统计
import MerchantStat from '@/modules/Dashboard/MerchantStat';
import MerchantStatList from '@/modules/Dashboard/MerchantList';
import MerchantDayReport from '@/modules/Dashboard/MerchantDayReport';
import ClearingReport from '@/modules/Dashboard/ClearingReport';

// 财务

import TheGoldAudit from '@/modules/Finance/TheGoldAudit';
import PlatformTransfer from '@/modules/Finance/PlatformTransfer';
import ProxyTransfer from '@/modules/Finance/ProxyTransfer';
import ProxySettlement from '@/modules/Finance/ProxySettlement';
import ProxyNoSettlementTotal from '@/modules/Finance/ProxyNoSettlementTotal';
import SonClearingDetail from '@/modules/Finance/SonClearingDetail';
import WithdrawAudit from '@/modules/Finance/WithdrawAudit';
import MerchantProxySettlement from '@/modules/Finance/MerchantProxySettlement';
import MerchantPayAll from '@/modules/Finance/MerchantPayAll';
import MerchantHistoryIncome from '@/modules/Finance/MerchantHistoryIncome';

// 商户代理
import MerchantProxyManage from '@/modules/MerchantProxy/MerchantProxyManage';

// 渠道管理
import ChannelManage from '@/modules/Channel/ChannelManage';

// 订单
import OrderInfo from '@/modules/Order/OrderInfo';
import OrderReviewAll from '@/modules/Order/OrderReviewAll';
import ProxyPushNotice from '@/modules/Order/ProxyPushNotice';
import VerifyOrder from '@/modules/Order/VerifyOrder';

// 商户管理
import MerchantList from '@/modules/Merchant/MerchantList';
import CardManage from '@/modules/Merchant/CardManage';
import MerchantInfo from '@/modules/Merchant/MerchantInfo';
import MchOrderSettlement from '@/modules/Merchant/MchOrderSettlement';

// 代理管理
import ProxyList from '@/modules/Proxy/ProxyList';
import ProxyTree from '@/modules/Proxy/ProxyTree';
// import ProxyInfo from '@/modules/Proxy/ProxyInfo';
import ProfitFlow from '@/modules/Proxy/ProfitFlow';
import ProxyPayAll from '@/modules/Proxy/ProxyPayAll';
import ProxyPreduceAll from '@/modules/Proxy/ProxyPreduceAll';
import ProxyRealAll from '@/modules/Proxy/ProxyRealAll';
import QRCodeList from '@/modules/Proxy/QRCodeList';
import proxyOperateList from '@/modules/Proxy/ProxyOperateList';
import ProxyOrderNum from '@/modules/Proxy/ProxyOrderNum';
import RiskControl from '@/modules/Proxy/RiskControl';
import AliValidProxy from '@/modules/Proxy/AliValidProxy';


// 系统管理
import SystemConfig from '@/modules/System/SystemConfig';
import MenuConfig from '@/modules/System/MenuConfig';
import OperationRecordsAll from '@/modules/System/OperationRecordsAll';
import QrcodeGroup from '@/modules/System/QrcodeGroup';
import QrcodeSource from '@/modules/System/QrcodeSource';
import BlackList from '@/modules/System/BlackList';
import AdminAll from '@/modules/System/AdminAll';
import QrConsts from '@/modules/System/QrConsts';
import PayPassEdit from '@/modules/System/PayPassEdit';
import Permissions from '@/modules/System/Permissions';
import KoubeiConfig from '@/modules/System/KoubeiConfig';

// 商户
// import AccountAudit from '@/modules/Merchant/AccountAudit';
// import AmountDetail from '@/modules/Merchant/AmountDetail';
// import RealAuthAudit from '@/modules/Merchant/RealAuthAudit';

import Exception403 from '@/modules/Exception/403';
import Exception404 from '@/modules/Exception/404';
import Exception500 from '@/modules/Exception/500';

// 人民币兑换
import ExchangeRecord from '@/modules/Exchange/ExchangeRecord';
import ReceiveBank from '@/modules/Exchange/ReceiveBank';
import ExchangeWay from '@/modules/Exchange/ExchangeWay';
import CurrencyConfig from '@/modules/Exchange/CurrencyConfig';

const NoMatch = props => <h2>404</h2>;

const routerData = [
  {
    path: '/user/userLogin',
    component: UserLogin,
    meta: {
      title: '登录'
    },
    isshow: false
  },
  {
    path: '/user/userRegister',
    component: UserRegister,
    meta: {
      title: '注册'
    },
    isshow: false
  },
  {
    path: '/dashboard/merchantStat',
    component: MerchantStat,
    meta: {
      title: '商户统计'
    }
  },
  {
    path: '/dashboard/merchantList/',
    component: MerchantStatList,
    meta: {
      title: '商户收入统计'
    }
  },
  // {
  //   path: '/dashboard/merchantDayReport',
  //   component: MerchantDayReport,
  //   meta: {
  //     title: '商户日报表'
  //   }
  // },
  // {
  //   path: '/dashboard/clearingReport',
  //   component: ClearingReport,
  //   meta: {
  //     title: '清算报表'
  //   }
  // },
  {
    path: '/finance/TheGoldAudit',
    component: TheGoldAudit,
    meta: {
      title: '出金审核'
    },
    isShow: false
  },
  {
    path: '/finance/platformTransfer/:group_num/:status',
    component: PlatformTransfer,
    meta: {
      title: '平台转账'
    },
    isShow: false
  },
  {
    path: '/finance/platformTransfer/:group_num',
    component: PlatformTransfer,
    meta: {
      title: '平台转账'
    },
    isShow: false
  },
  {
    path: '/finance/platformTransfer',
    component: PlatformTransfer,
    meta: {
      title: '平台转账'
    },
    isShow: false
  },
  {
    path: '/finance/proxyTransfer/:account',
    component: ProxyTransfer,
    meta: {
      title: '代理结账'
    },
    isShow: false
  },
  {
    path: '/finance/proxyTransfer',
    component: ProxyTransfer,
    meta: {
      title: '代理结账'
    },
    isShow: false
  },
  {
    path: '/finance/proxySettlement',
    component: ProxySettlement,
    meta: {
      title: '代理收益结算'
    },
    isShow: false
  },
  {
    path: '/finance/proxyNoSettlementTotal',
    component: ProxyNoSettlementTotal,
    meta: {
      title: '总代理结算明细'
    },
    isShow: false
  },
  {
    path: '/finance/sonClearingDetail/:account/:time',
    component: SonClearingDetail,
    meta: {
      title: '子代理结算明细'
    },
    isShow: false
  },
  {
    path: '/finance/merchantProxySettlement',
    component: MerchantProxySettlement,
    meta: {
      title: '商户代理结算'
    },
    isShow: false
  },
  {
    path: '/finance/merchantPayAll',
    component: MerchantPayAll,
    meta: {
      title: '商户充值'
    },
    isShow: false
  },
  // {
  //   path: '/finance/withdrawAudit',
  //   component: WithdrawAudit,
  //   meta: {
  //     title: '出金审核'
  //   },
  //   isShow: false
  // },
  {
    path: '/order/OrderInfo/:account',
    component: OrderInfo,
    meta: {
      title: '订单信息'
    },
    isShow: false
  },
  {
    path: '/order/OrderInfo',
    component: OrderInfo,
    meta: {
      title: '订单信息'
    },
    isShow: false
  },
  {
    path: '/order/orderReviewAll',
    component: OrderReviewAll,
    meta: {
      title: '订单复核列表'
    },
    isShow: false
  },
  {
    path: '/order/proxyPushNotice',
    component: ProxyPushNotice,
    meta: {
      title: '代理推送通知'
    },
    isShow: false
  },
  //商户
  {
    path: '/merchant/merchantList/:arch_id',
    component: MerchantList,
    meta: {
      title: '商户列表'
    },
    isShow: false
  },
  {
    path: '/merchant/merchantList',
    component: MerchantList,
    meta: {
      title: '商户列表'
    },
    isShow: false
  },
  {
    path: '/merchant/cardManage/:account',
    component: CardManage,
    meta: {
      title: '银卡管理'
    },
    isShow: false
  },
  {
    path: '/merchant/cardManage',
    component: CardManage,
    meta: {
      title: '银卡管理'
    },
    isShow: false
  },
  {
    path: '/merchant/merchantInfo/:account',
    component: MerchantInfo,
    meta: {
      title: '商户信息'
    },
    isShow: false
  },
  {
    path: '/merchant/merchantInfo',
    component: MerchantInfo,
    meta: {
      title: '商户信息'
    },
    isShow: false
  },
  // {
  //   path: '/merchant/accountAudit',
  //   component: AccountAudit,
  //   meta: {
  //     title: '账户信息'
  //   },
  //   isShow: false
  // },
  // {
  //   path: '/merchant/amountDetail',
  //   component: AmountDetail,
  //   meta: {
  //     title: '收款详情'
  //   },
  //   isShow: false
  // },
  // {
  //   path: '/merchant/realAuthAudit',
  //   component: RealAuthAudit,
  //   meta: {
  //     title: '实名审核'
  //   },
  //   isShow: false
  // },
  {
    path: '/proxy/proxyList',
    component: ProxyList,
    meta: {
      title: '代理信息'
    },
    isShow: false
  },
  {
    path: '/proxy/proxyTree/:account',
    component: ProxyTree,
    meta: {
      title: '代理关系树'
    },
    isShow: false
  },
  {
    path: '/proxy/profitFlow/:account',
    component: ProfitFlow,
    meta: {
      title: '收益流水'
    },
    isShow: false
  },
  {
    path: '/proxy/profitFlow',
    component: ProfitFlow,
    meta: {
      title: '收益流水'
    },
    isShow: false
  },
  {
    path: '/proxy/proxyPayAll/:account',
    component: ProxyPayAll,
    meta: {
      title: '充值额度审核'
    },
    isShow: false
  },
  {
    path: '/proxy/proxyPayAll',
    component: ProxyPayAll,
    meta: {
      title: '充值额度审核'
    },
    isShow: false
  },
  {
    path: '/proxy/proxyPreduceAll/:account',
    component: ProxyPreduceAll,
    meta: {
      title: '代理降额申请'
    },
    isShow: false
  },
  {
    path: '/proxy/proxyPreduceAll',
    component: ProxyPreduceAll,
    meta: {
      title: '代理降额申请'
    },
    isShow: false
  },
  {
    path: '/proxy/proxyRealAll',
    component: ProxyRealAll,
    meta: {
      title: '实名审核'
    },
    isShow: false
  },
  {
    path: '/proxy/qrCodeList',
    component: QRCodeList,
    meta: {
      title: '二维码管理'
    },
    isShow: false
  },
  {
    path: '/system/systemConfig',
    component: SystemConfig,
    meta: {
      title: '系统配置'
    },
    isShow: false
  },
  {
    path: '/system/menuConfig',
    component: MenuConfig,
    meta: {
      title: '菜单管理'
    },
    isShow: false
  },
  {
    path: '/system/operationRecordsAll',
    component: OperationRecordsAll,
    meta: {
      title: '操作记录'
    },
    isShow: false
  },
  {
    path: '/system/qrcodeGroup',
    component: QrcodeGroup,
    meta: {
      title: '二维码分组'
    },
    isShow: false
  },
  {
    path: '/system/qrcodeSource',
    component: QrcodeSource,
    meta: {
      title: '二维码资源'
    },
    isShow: false
  },
  {
    path: '/system/blackList',
    component: BlackList,
    meta: {
      title: 'IP黑名单'
    },
    isShow: false
  },
  {
    path: '/system/adminAll',
    component: AdminAll,
    meta: {
      title: '管理员信息'
    },
    isShow: false
  },
  {
    path: '/exception/403',
    component: Exception403,
    meta: {
      title: '403'
    },
    isShow: false
  },
  {
    path: '/exception/404',
    component: Exception404,
    meta: {
      title: '404'
    },
    isShow: false
  },
  {
    path: '/exception/500',
    component: Exception500,
    meta: {
      title: '500'
    },
    isShow: false
  },
  {
    path: '/merchantproxy/merchantProxyManage',
    component: MerchantProxyManage,
    meta: {
      title: '商户代理管理'
    },
    isShow: false
  },
  {
    path: '/channel/channelManage',
    component: ChannelManage,
    meta: {
      title: '渠道管理'
    },
    isShow: false
  },
  {
    path: '/merchant/MchOrderSettlement',
    component: MchOrderSettlement,
    meta: {
      title: '订单日结'
    },
    isShow: false
  },
  {
    path: '/finance/MerchantHistoryIncome',
    component: MerchantHistoryIncome,
    meta: {
      title: '商户历史收入'
    },
    isShow: false
  },
  {
    path: '/system/QrConsts',
    component: QrConsts,
    meta: {
      title: '固码配置'
    },
    isShow: false
  },
  {
    path: '/system/PayPassEdit',
    component: PayPassEdit,
    meta: {
      title: '修改支付密码'
    },
    isShow: false
  },
  {
    path: '/system/Permissions',
    component: Permissions,
    meta: {
      title: '权限配置'
    },
    isShow: false
  },
  {
    path: '/proxy/proxyOperateList',
    component: proxyOperateList,
    meta: {
      title: '代理金额操作记录'
    },
    isShow: false
  },
  {
    path: '/order/VerifyOrder',
    component: VerifyOrder,
    meta: {
      title: '用户投诉复核'
    },
    isShow: false
  },
  {
    path: '/exchange/ExchangeRecord',
    component: ExchangeRecord,
    meta: {
      title: '兑换记录'
    },
    isShow: false
  },
  {
    path: '/exchange/ReceiveBank',
    component: ReceiveBank,
    meta: {
      title: '收款银行'
    },
    isShow: false
  },
  {
    path: '/exchange/ExchangeWay',
    component: ExchangeWay,
    meta: {
      title: '兑换方式配置'
    },
    isShow: false
  },
  {
    path: '/exchange/CurrencyConfig',
    component: CurrencyConfig,
    meta: {
      title: '货币类型'
    },
    isShow: false
  },
  {
    path: '/proxy/ProxyOrderNum',
    component: ProxyOrderNum,
    meta: {
      title: '今日代理订单数量'
    },
    isShow: false
  },
  {
    path: '/proxy/RiskControl',
    component: RiskControl,
    meta: {
      title: '支付宝风控'
    },
    isShow: false
  },
  {
    path: '/proxy/AliValidProxy',
    component: AliValidProxy,
    meta: {
      title: '支付宝可用代理'
    },
    isShow: false
  },
  {
    path: '/system/KoubeiConfig',
    component: KoubeiConfig,
    meta: {
      title: '口碑商户配置'
    },
    isShow: false
  },
  
];

export function getRouterData() {
  return routerData;
}

export default getRouterData;
