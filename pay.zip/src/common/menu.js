import { isUrl } from '../utils/utils';

const menuData = [
  {
    name: '统计',
    icon: 'dashboard',
    path: 'dashboard',
    children: [
      {
        name: '商户统计',
        path: 'merchantStat'
      },
      {
        name: '商户收入统计',
        path: 'merchantList'
      }
      // {
      //   name: '商户日报表',
      //   path: 'merchantDayReport'
      // }
      // {
      //   name: '清算报表',
      //   path: 'clearingReport'
      // }
    ]
  },
  {
    name: '财务',
    icon: 'credit-card',
    path: 'finance',
    children: [
      {
        name: '平台转账(批量)',
        path: 'theGoldAudit'
      },
      // {
      //   name: '平台转账',
      //   path: 'platformTransfer'
      // },
      {
        name: '代理转账',
        path: 'proxyTransfer'
      },
      {
        name: '终端代理结算',
        path: 'proxySettlement'
      },
      {
        name: '商户代理结算',
        path: 'merchantProxySettlement'
      },
      {
        name: '商户充值',
        path: 'merchantPayAll'
      },
      {
        name: '商户历史收益',
        path: 'MerchantHistoryIncome'
      }
      // {
      //   name: '出金审核',
      //   path: 'withdrawAudit'
      // }
    ]
  },
  {
    name: '订单管理',
    icon: 'appstore',
    path: 'order',
    children: [
      {
        name: '订单信息',
        path: 'orderInfo'
      },
      {
        name: '订单复核列表',
        path: 'orderReviewAll'
      },
      {
        name: '用户投诉复核列表',
        path: 'VerifyOrder'
      },
      {
        name: '代理推送通知',
        path: 'proxyPushNotice'
      }
    ]
  },
  {
    name: '商户管理',
    icon: 'form',
    path: 'merchant',
    children: [
      {
        name: '商户列表',
        path: 'merchantList'
      },
      {
        name: '银卡管理',
        path: 'cardManage'
      },
      {
        name: '订单日结',
        path: 'MchOrderSettlement'
      }
      // {
      //   name: '商户信息',
      //   path: 'merchantInfo'
      // }
      // {
      //   name: '商户信息变更记录',
      //   path: ''
      // },
      // {
      //   name: '账户信息',
      //   path: 'accountAudit'
      // },
      // {
      //   name: '收款详情',
      //   path: 'amountDetail'
      // },
      // {
      //   name: '实名审核',
      //   path: 'realAuthAudit'
      // }
    ]
  },
  {
    name: '商户代理管理',
    icon: 'copy',
    path: 'merchantproxy',
    children: [
      {
        name: '代理管理',
        path: 'MerchantProxyManage'
      }
    ]
  },
  {
    name: '终端代理管理',
    icon: 'user',
    path: 'proxy',
    children: [
      {
        name: '代理信息',
        path: 'proxyList'
      },
      {
        name: '收益流水',
        path: 'profitFlow'
      },
      {
        name: '充值额度审核',
        path: 'proxyPayAll'
      },
      {
        name: '代理降额审核',
        path: 'proxyPreduceAll'
      },
      {
        name: '实名审核',
        path: 'proxyRealAll'
      },
      {
        name: '二维码管理',
        path: 'qrCodeList'
      },
      {
        name: '代理金额操作记录',
        path: 'proxyOperateList'
      },
      {
        name: '今日代理订单数量',
        path: 'ProxyOrderNum'
      },
      
    ]
  },
  {
    name: '渠道管理',
    icon: 'book',
    path: 'channel',
    children: [
      // {
      //   name: '管理员',
      //   path: 'adminAll'
      // },
      {
        name: '渠道管理',
        path: 'channelManage'
      }
    ]
  },
  {
    name: '系统管理',
    icon: 'setting',
    path: 'system',
    children: [
      // {
      //   name: '管理员',
      //   path: 'adminAll'
      // },
      {
        name: '系统配置',
        path: 'systemConfig'
      },
      {
        name: '操作记录',
        path: 'operationRecordsAll'
      },
      {
        name: '固码配置',
        path: 'QrConsts'
      },
      {
        name: '二维码分组',
        path: 'qrcodeGroup'
      },
      {
        name: '二维码资源',
        path: 'qrcodeSource'
      },
      {
        name: 'IP黑名单',
        path: 'blackList'
      },
      // {
      //   name: '权限配置',
      //   path: 'Permissions'
      // },
      // {
      //   name: '修改支付密码',
      //   path: 'PayPassEdit'
      // }
    ]
  }
];
export function formatter(data, parentPath = '/', parentAuthority) {
  return data.map(item => {
    let { path } = item;
    if (!isUrl(path)) {
      path = parentPath + item.path;
    }
    const result = {
      ...item,
      path,
      authority: item.authority || parentAuthority
    };
    if (item.children) {
      result.children = formatter(
        item.children,
        `${parentPath}${item.path}/`,
        item.authority
      );
    }
    return result;
  });
}

export const getMenuData = () => formatter(menuData);
