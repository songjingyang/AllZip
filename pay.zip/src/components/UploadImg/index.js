import React from 'react'

import { Upload, Icon, message } from 'antd'

function getBase64 (img, callback) {
  const reader = new FileReader()
  reader.addEventListener('load', () => callback(reader.result))
  reader.readAsDataURL(img)
}

export default class UploadImg extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      uploadUrl: '/api/v1/feedback/upload',
      loading: false,
      imgUrl: ''
    }
  }
  componentWillReceiveProps (nextProps) {
    if ('value' in nextProps) {
      this.setState({
        imgUrl: nextProps.value
      })
    }
    if ('uploadUrl' in nextProps) {
      this.setState({
        uploadUrl: nextProps.uploadUrl
      })
    }
  }
  beforeUpload = file => {
    // const isJPG = file.type === 'image/jpeg'
    // if (!isJPG) {
    //   message.error('You can only upload JPG file!')
    // }
    // const isLt2M = file.size / 1024 / 1024 < 2
    // if (!isLt2M) {
    //   message.error('Image must smaller than 2MB!')
    // }
    // return isJPG && isLt2M
    return true
  }

  handleChange = ({ file }) => {
    if (file.status === 'uploading') {
      this.setState({ loading: true })
      return
    }
    if (file.status === 'done') {
      // Get this url from response in real world.
      if (file.response.code === 200) {
        const imgUrl = file.response.data.img
        this.setState(
          {
            imgUrl: imgUrl,
            loading: false
          },
          () => {
            this.props.onChange(imgUrl)
          }
        )
      }
      // getBase64(file.originFileObj, imgUrl =>
      //   this.setState(
      //     {
      //       imgUrl,
      //       loading: false
      //     },
      //     () => {
      //       this.props.onChange(imgUrl)
      //     }
      //   )
      // )
    }
  }

  render () {
    const uploadButton = (
      <div>
        <Icon type={this.state.loading ? 'loading' : 'plus'} />
        <div className='ant-upload-text'>上传</div>
      </div>
    )
    return (
      <Upload
        {...this.props}
        name='file'
        listType='picture-card'
        className='avatar-uploader'
        showUploadList={false}
        action={this.state.uploadUrl}
        beforeUpload={this.beforeUpload}
        onChange={this.handleChange}
      >
        {this.state.imgUrl
          ? <img
            src={this.state.imgUrl}
            alt='avatar'
            style={{ maxHeight: '150px' }}
            />
          : uploadButton}
      </Upload>
    )
  }
}
