import React from 'react'

class GlobalFooter extends React.Component {
  state = {}

  render () {
    return (
      <div style={{ textAlign: 'center' }}>
        Copyright cc pay © 2018-2020
      </div>
    )
  }
}

export default GlobalFooter
