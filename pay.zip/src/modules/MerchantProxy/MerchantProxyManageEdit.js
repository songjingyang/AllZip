import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class MerchantProxyManageEdit extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    // e.preventDefault();
    this.props.form.validateFields((err, values) => {
      values.status = Number(values.status);
      var data = {
        account: values.account,
        name: values.name,
        wx_rate: Number(values.wx_rate * 100),
        ali_rate: Number(values.ali_rate * 100)
      };
      if (!err) {
        this.props.dispatch({
          type: 'finance/editMerchantProxy',
          payload: {
            // ...this.props.finance.platformTransferDetail,
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('修改成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.merchantProxyEdit;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="账号">
          {getFieldDecorator('account', {
            initialValue: info.account
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="名称">
          {getFieldDecorator('name', {
            initialValue: info.name
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="支付宝点数(%)">
          {getFieldDecorator('ali_rate', {
            initialValue: info.ali_rate
          })(<Input style={{ width: '65%' }} type="type" />)}
          <span>（例：1=1%）</span>
        </FormItem>
        <FormItem {...formItemLayout} label="微信点数(%)">
          {getFieldDecorator('wx_rate', {
            initialValue: info.wx_rate
          })(<Input style={{ width: '65%' }} type="type" />)}
          <span>（例：1=1%）</span>
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            修改
          </Button>
        </FormItem>
      </Form>
    );
  }
}
