import React from 'react';
import {
  Popconfirm,
  Drawer,
  Table,
  message,
  Input,
  Select,
  Divider,
  Card,
  Modal,
  Form,
  Button,
  Col,
  Row,
  DatePicker
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import SimpleTable from '@/components/SimpleTable';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import classNames from 'classnames';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
var account = '';
@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/findAssociMerchant']
}))
export default class MerchantProxyManageAssoci extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      ach_agent: '',
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        0: '审核中',
        1: '正常',
        2: '封停'
      },
      auditStatusMap: {
        0: '未审核',
        1: '已通过',
        2: '未通过'
      },
      isProxyAccout: false,
      isEdit: false,
      isPassword: false,
      isClear: false,
      isCreateProxy: false,
      account_info: '',
      isCreate: false,
      itemList: [],
      isAssoci: false,
      isAssociCreate: false,

      columns: [
        {
          isExpand: true,
          title: 'ID',
          dataIndex: 'id'
        },
        {
          title: '商户ID',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '支付宝费率(%)',
          dataIndex: 'ali_rate'
        },
        {
          isExpand: true,
          title: '微信费率(%)',
          dataIndex: 'wx_rate'
        },
        {
          isExpand: true,
          title: '日期',
          dataIndex: 'create_time',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          title: '操作',
          // dataIndex: 'name',
          render: (text, record) => {
            return (
              <span>
                <div>
                  <Popconfirm
                    title="确定删除吗？"
                    onConfirm={() => this.del(record)}
                  >
                    <a href="javascript:;">删除</a>
                  </Popconfirm>
                </div>
              </span>
            );
          }
        }
      ]
    };
  }
  // 页面初始化调用
  componentDidMount() {
    this.findAssociMerchant();
  }
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.findAssociMerchant({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  findAssociMerchant = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.finance.associMerchantInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        params.account = this.props.finance.associMerchant.account;
        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'finance/findAssociMerchant',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('findAssociMerchant parameters error');
      }
    });
  };
  isAssociCreate = bool => {
    this.setState({ isAssociCreate: bool });
  };
  bind = item => {
    this.isAssociCreate(true);
  };
  onClose = () => {
    this.setState({
      isAssociCreate: false
    });
    // console.log('debugger', this.props.form.setFieldsValue)
    // this.props.form.setFieldsValue({
    //   Account: '',
    //   Status: '',
    //   ali_rate: '',
    //   wx_rate: '',
    //   CreateTime: ''
    // })
  };
  add = item => {
    this.props.form.validateFields((err, values) => {
      //

      let acc = this.state.data.Account;
      if (acc === undefined) {
        message.warning('数据不存在');
        return;
      }
      var data = {
        account: this.state.data.Account,
        ach_agent: this.props.finance.associMerchant.account
      };
      if (!err) {
        this.props.dispatch({
          type: 'finance/proxyAssociAch',
          payload: {
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('添加成功');
              this.state.isAssociCreate = false;
              if (this.props.onClose) {
                this.props.onClose();
                this.findAssociMerchant();
              }
            }
          }
        });
      }
    });
  };
  del = item => {
    item.account;
    var data = {
      account: item.account
    };
    this.props.dispatch({
      type: 'finance/delProxyAssociAch',
      payload: {
        ...data
      },
      callback: res => {
        if (res.code === 200) {
          message.success('删除成功');
          this.state.isAssociCreate = false;
          if (this.props.onClose) {
            this.props.onClose();
            this.findAssociMerchant();
          }
        }
      }
    });
  };

  search = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      var data = {
        account: values.account
      };
      if (!err) {
        this.props.dispatch({
          type: 'finance/getFindBusinessUserByAchId',
          payload: {
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              this.state.data = res.data;

              if (res.data === null) {
                message.warning('商户不存在');
              }
            }
          }
        });
      }
    });
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.associMerchantInfo;
    const info1 = this.props.finance.findBusinessUserByAchId;
    this.state.ach_agent = info.account;

    // const formItemLayout = {
    //   labelCol: { span: 6 },
    //   wrapperCol: { span: 14 }
    // };
    const treeLayout = {
      xs: 24,
      sm: 24,
      md: 24,
      lg: 12,
      xl: 12,
      xxl: 12
    };
    return (
      <Card bordered={false}>
        {this.state.isAssociCreate && (
          <div>
            <Drawer
              title="关联商户"
              width={'720'}
              placement="right"
              onClose={this.onClose}
              maskClosable={true}
              visible={this.state.isAssociCreate}
              destroyOnClose
              style={{
                height: 'calc(100% - 55px)',
                overflow: 'auto',
                paddingBottom: 53
              }}
            >
              <Form
                layout={global.form.layout}
                onSubmit={this.search}
                hideRequiredMark
              >
                <Row gutter={16}>
                  <Col span={12}>
                    {getFieldDecorator('account', {
                      rules: [{ required: true, message: '请输入商户号' }]
                    })(<Input placeholder="请输入商户号" />)}
                  </Col>
                  <Col span={12}>
                    <Button type="primary" htmlType="submit">
                      搜索
                    </Button>
                  </Col>
                </Row>
                <Row gutter={16}>
                  <Col span={6}>
                    <Form.Item label="" />
                  </Col>
                </Row>
                <Row gutter={16}>
                  <Col span={6}>
                    <Form.Item label="商户ID" />
                  </Col>
                  <Col span={12}>
                    <Form.Item label="">{info1.Account}</Form.Item>
                  </Col>
                </Row>
                <Row gutter={16}>
                  <Col span={6}>
                    <Form.Item label="状态" />
                  </Col>
                  <Col span={12}>
                    <Form.Item label="">
                      {this.state.statusMap[info1.Status]}
                    </Form.Item>
                  </Col>
                </Row>
                <Row gutter={16}>
                  <Col span={6}>
                    <Form.Item label="支付宝点数(%)" />
                  </Col>
                  <Col span={12}>
                    <Form.Item label="">
                      {info1.ali_rate === 0 ? '0' : info1.ali_rate}
                    </Form.Item>
                  </Col>
                </Row>
                <Row gutter={16}>
                  <Col span={6}>
                    <Form.Item label="微信点数(%)" />
                  </Col>
                  <Col span={12}>
                    <Form.Item label="">
                      {info1.wx_rate === 0 ? '0' : info1.wx_rate}
                    </Form.Item>
                  </Col>
                </Row>
                <Row gutter={16}>
                  <Col span={6}>
                    <Form.Item label="注册时间" />
                  </Col>
                  <Col span={12}>
                    <Form.Item label="">
                      {info1.CreateTime ? dateFormater(info1.CreateTime) : ''}
                    </Form.Item>
                  </Col>
                </Row>
              </Form>
              <div
                style={{
                  position: 'absolute',
                  bottom: 0,
                  width: '100%',
                  borderTop: '1px solid #e8e8e8',
                  padding: '10px 16px',
                  textAlign: 'right',
                  left: 0,
                  background: '#fff',
                  borderRadius: '0 0 4px 4px'
                }}
              >
                <Button
                  style={{
                    marginRight: 8
                  }}
                  onClick={this.onClose}
                >
                  取消
                </Button>
                <Button onClick={this.add} type="primary">
                  添加
                </Button>
              </div>
            </Drawer>
          </div>
        )}
        <div className={'tableList'}>
          <div
            style={{ marginBottom: '10px' }}
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Button type="primary" onClick={() => this.bind()}>
              关联商户
            </Button>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{
              ...this.state.pagination,
              total: info.total,
              account: info.account
            }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
