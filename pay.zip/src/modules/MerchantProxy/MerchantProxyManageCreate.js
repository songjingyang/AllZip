import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class MerchantProxyManageCreate extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      values.status = Number(values.status);
      var data = {
        account: values.account,
        name: values.name,
        password: values.password,
        phone: values.phone,
        wx_rate: Number(values.wx_rate),
        ali_rate: Number(values.ali_rate)
      };
      if (!err) {
        this.props.dispatch({
          type: 'finance/createMerchantProxy',
          payload: {
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('创建成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  compareToFirstPassword = (rule, value, callback) => {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('两次密码输出不一致!');
    } else {
      callback();
    }
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.ClearingRecordTransfer;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem
          style={{ marginBottom: '15px' }}
          {...formItemLayout}
          label="账号"
        >
          {getFieldDecorator('account', {
            rules: [
              {
                required: true,
                message: '请填写账号!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="名称">
          {getFieldDecorator('name', {
            rules: [
              {
                required: true,
                message: '请填写名称!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="密码">
          {getFieldDecorator('password', {
            rules: [
              {
                required: true,
                message: '请填写密码!'
              },
              {
                validator: this.validateToNextPassword
              }
            ]
          })(<Input type="password" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="确认密码">
          {getFieldDecorator('confirm', {
            rules: [
              {
                required: true,
                message: '请填写确认密码!'
              },
              {
                validator: this.compareToFirstPassword
              }
            ]
          })(<Input type="password" onBlur={this.handleConfirmBlur} />)}
        </FormItem>
        <FormItem {...formItemLayout} label="手机号">
          {getFieldDecorator('phone', {
            // initialValue: '',
            rules: [
              {
                required: true,
                message: '请填写手机号!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="支付宝点数(%)">
          {getFieldDecorator('ali_rate', {
            // initialValue: '',
            rules: [
              {
                required: true,
                message: '请填写支付宝点数!',
                writespace: true
              }
            ]
          })(<Input style={{ width: '65%' }} type="type" />)}
          <span>（例：1=1%）</span>
        </FormItem>
        <FormItem {...formItemLayout} label="微信点数(%)">
          {getFieldDecorator('wx_rate', {
            // initialValue: '',
            rules: [
              {
                required: true,
                message: '请填写微信点数!',
                writespace: true
              }
            ]
          })(<Input style={{ width: '65%' }} type="type" />)}
          <span>（例：1=1%）</span>
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            创建
          </Button>
        </FormItem>
      </Form>
    );
  }
}
