import React from 'react';
import { Modal, message, Form, Input, Select, TreeSelect, Button } from 'antd';
import { connect } from 'dva';
import { commafy, toFixed } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ system, global }) => ({
  system,
  global
}))
export default class AddMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: undefined
    };
  }
  componentDidMount() {}

  // handleSubmit = e => {
  //   e.preventDefault();
  //   this.props.form.validateFields((err, values) => {
  //     if (!err) {
  //       const formItemLayout = {
  //         labelCol: { span: 8 },
  //         wrapperCol: { span: 14 }
  //       };
  //       Modal.confirm({
  //         title: '提交确认',
  //         okText: '确认',
  //         cancelText: '取消',
  //         onOk: () => {
  //           return this.save();
  //         },
  //         content: (
  //           <Form>
  //             <FormItem {...formItemLayout} label="上级">
  //               {values.level}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="名字">
  //               {values.name}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="父级ID">
  //               {values.parent_id}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="Url">
  //               {values.url}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="Icon">
  //               {values.icon}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="Path">
  //               {values.path}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="排列序号">
  //               {values.sort}
  //             </FormItem>
  //           </Form>
  //         )
  //       });
  //     }
  //   });
  // };
  handleSubmit = () => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        values.level = +values.level;
        values.parent_id = +values.parent_id;
        values.sort = +values.sort;
        this.props.dispatch({
          type: 'global/saveAddMenu',
          payload: {
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  onChange = value => {
    this.setState({ value });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    const menu = [
      {
        title: '顶级菜单',
        value: 0,
        key: 0,
        children: this.props.global.MenuData
      }
    ];
    console.log('addmenu', menu);
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="上级">
          {getFieldDecorator('level', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入上级'
              }
            ]
          })(
            <TreeSelect
              // value={this.state.value}
              dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
              treeData={menu}
              placeholder="请输入上级"
              treeDefaultExpandAll
              // onChange={this.onChange}
            />
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="名字">
          {getFieldDecorator('name', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入名字'
              }
            ]
          })(<Input placeholder="请输入名字" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="父级ID">
          {getFieldDecorator('parent_id', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入父级ID'
              }
            ]
          })(<Input placeholder="请输入父级ID" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="Url">
          {getFieldDecorator('url', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入Url'
              }
            ]
          })(<Input placeholder="请输入Url" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="Icon">
          {getFieldDecorator('icon', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入Icon'
              }
            ]
          })(<Input placeholder="请输入Icon" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="Path">
          {getFieldDecorator('path', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入Path'
              }
            ]
          })(<Input placeholder="请输入Path" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="排列序号">
          {getFieldDecorator('sort', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入排列序号'
              }
            ]
          })(<Input placeholder="请输入排列序号" />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
