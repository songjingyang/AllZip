import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Modal,
  Row,
  Col,
  Popconfirm,
  message,
  Tag
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import SwitchConfirm from '@/components/SwitchConfirm';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ system, global, loading }) => ({
  system,
  global,
  loading: loading.effects['system/getQrcodeGroupList'],
  qrcodeGroupedLoading: loading.effects['system/getQrcodeGroupedList']
}))
export default class QrcodeGroup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      height: 600,

      statusMap: {
        1: '正常',
        2: '冻结',
        3: '封号'
      },
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      qrcodeGroupedPagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      qrcodeGroupedLoading: false,
      selectedRowKeys: [],
      selectedRows: [],
      group: ['1', '2', '3', '4', '5', '6', '7', '8'],
      team_id: '',
      groupSelectedRowKeys: [],
      groupSelectedRows: [],
      groupTeam_id: '1',
      isShowGroupModal: false,
      columns: [
        {
          title: '代理账户',
          dataIndex: 'account',
          width: 150,
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        // {
        //   title: '代理名称',
        //   dataIndex: 'username',
        //   width: 150
        // },
        {
          isExpand: true,
          title: '真实名称',
          dataIndex: 'real_name',
          width: 150
        },
        {
          title: '所属组',
          dataIndex: 'team_id',
          width: 150,
          render: text => <span>{text === 0 ? '未分组' : `第${text}组`}</span>
        },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'status',
          width: 150,
          render: text => (
            <span>
              <Tag color={text === 1 ? 'blue' : 'red'}>
                {this.state.statusMap[text]}
              </Tag>
            </span>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getQrcodeGroup({ pageSize: 20 });
    this.getQrcodeGrouped({
      // pageSize: 20,
      team_id: this.state.groupTeam_id
    });
    this.resizeTableBodyHeight();
    window.addEventListener('resize', this.resizeTableBodyHeight);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.resizeTableBodyHeight);
  }

  resizeTableBodyHeight = () => {
    let height = window.innerHeight || document.documentElement.clientHeight;
    height = height - 64 - 24 * 2 - 70 - 96 - 54 - 32 - 80;
    const { height: stateHeight } = this.state;
    console.log(height);
    if (stateHeight !== height) {
      this.setState({ height });
    }
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getQrcodeGroup({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  qrcodeGroupedHandleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.qrcodeGroupedPagination };
    pager.current = pagination.current;
    this.setState({
      qrcodeGroupedPagination: pager
    });
    this.getQrcodeGrouped({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getQrcodeGroup = (params = { page: 1, pageSize: 20 }) => {
    this.props.form.validateFields((err, values) => {
      // alert(err)
      if (!err) {
        let status = '';
        let team_id = '-1';
        if (values.status === "3" || values.status === "4") {
          status = values.status;
          // team_id = -1;
        } else {
          team_id = values.status;
        }
        this.props.dispatch({
          type: 'system/getQrcodeGroupList',
          payload: {
            ...params,
            status: status,
            team_id: team_id
          }
        });
      }
    });
  };
  onSubmit = () => {
    this.getQrcodeGroup({});
  };
  getQrcodeGrouped = (params = {}) => {
    this.props.dispatch({
      type: 'system/getQrcodeGroupedList',
      payload: {
        ...params,
        team_id: this.state.groupTeam_id
      }
    });
  };

  changeGroupList = teamId => {
    this.setState({ groupTeam_id: teamId }, () => {
      this.getQrcodeGrouped({ team_id: teamId });
    });
  };

  add = info => () => {
    if (!this.state.team_id) {
      message.error('请选择分组');
      return;
    }

    this.setState({
      isShowGroupModal: false
    });

    this.props.dispatch({
      type: 'system/saveQrcodeGroup',
      payload: {
        list: this.state.selectedRows.map(item => ({
          account: item.account,
          id: item.id
        })),
        team_id: this.state.team_id
      },
      callback: res => {
        if (res.code === 200) {
          message.success('添加成功');
          this.setState({
            selectedRowKeys: [],
            selectedRows: [],
            team_id: ''
          });
          let currPage = this.state.pagination.current;
          this.getQrcodeGroup({
            page: info.page
          });
          this.getQrcodeGrouped({
            page: 1
          });
        } else {
          message.danger(res.msg);
        }
      }
    });
  };

  del = info => () => {
    if (this.state.groupSelectedRowKeys.length === 0) {
      message.error('请选择要移除组的账户');
      return;
    }
    this.props.dispatch({
      type: 'system/deleteQrcodeGroup',
      payload: {
        list: info.list.map(item => item.account),
        team_id: this.state.groupTeam_id
      },
      callback: res => {
        if (res.code === 200) {
          message.success('删除成功');
          this.getQrcodeGroup({
            page: 1
          });
          this.getQrcodeGrouped({
            // pageSize: 2,
            team_id: this.state.groupTeam_id,
            page: 1
          });
        } else {
          message.danger(res.msg);
        }
      }
    });
  };

  changeGroupIsEnable = bool => {
    this.props.dispatch({
      type: 'system/changeGroupIsEnable',
      payload: {
        is_open: bool ? '1' : '0',
        group_num: this.state.groupTeam_id
      },
      callback: res => {
        this.getQrcodeGroup();
        this.getQrcodeGrouped();
        if (res.code === 200) {
          // this.setState({
          //   qrcodeGroupedListInfo: {
          //     ...this.qrcodeGroupedListInfo,
          //     status: bool
          //   }
          // })
        }
      }
    });
  };

  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.system.qrcodeGroupListInfo;
    const infoed = this.props.system.qrcodeGroupedListInfo;
    const treeLayout = {
      xs: 24,
      sm: 24,
      md: 24,
      lg: 12,
      xl: 12,
      xxl: 12
    };

    return (
      <Row gutter={16}>
        <Col style={{ marginBottom: '10px' }} {...treeLayout} span={12}>
          <Card title="账户资源" bordered={false}>
            <div className={'tableList'}>
              <div
                className={classNames({
                  tableListForm: !global.isMobile,
                  tableListFormMobile: global.isMobile
                })}
              >
                <Form layout={global.form.layout} onSubmit={this.onSubmit}>
                  <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                    <Col xl={12} md={24} sm={24}>
                      <FormItem label="" className="form-inline-item">
                        {getFieldDecorator('status', {
                          initialValue: '-1'
                        })(
                          <RadioGroup>
                            <Radio value="-1">全部</Radio>
                            <Radio value="0">未分组</Radio>
                            <Radio value="3">已封号</Radio>
                            <Radio value="4">未封号</Radio>
                          </RadioGroup>
                        )}
                      </FormItem>
                    </Col>
                    <Col xl={12} md={24} sm={24}>
                      <div className={'submitButtons'}>
                        <Button type="primary" htmlType="submit">
                          查询
                        </Button>
                      </div>
                    </Col>
                  </Row>
                </Form>
              </div>
              <Button
                onClick={() => {
                  if (this.state.selectedRowKeys.length === 0) {
                    message.error('请选择要分组的账户');
                    return;
                  }
                  this.setState({ isShowGroupModal: true });
                }}
                type="primary"
                style={{ marginTop: 16 }}
              >
                添加到分组
              </Button>
              <SimpleTable
                columns={this.state.columns}
                rowKey={record => record.id}
                dataSource={info.list}
                pagination={{
                  ...this.state.pagination,
                  current: info.page,
                  pageSize: info.pageSize,
                  total: info.total
                }}
                loading={this.props.loading}
                onChange={this.handleTableChange}
                // style={{ height: this.state.height }}
                // scroll={{ y: this.state.height }}
                rowSelection={{
                  onChange: (selectedRowKeys, selectedRows) => {
                    this.setState({
                      selectedRowKeys,
                      selectedRows
                    });
                    // console.log(
                    //   `selectedRowKeys: ${selectedRowKeys}`,
                    //   'selectedRows: ',
                    //   selectedRows
                    // )
                  },
                  selectedRowKeys: this.state.selectedRowKeys,
                  getCheckboxProps: record => ({
                    disabled: record.team_id > 0, // Column configuration not to be checked
                    name: record.name
                  })
                }}
              />
            </div>
          </Card>
        </Col>
        <Col {...treeLayout} span={12}>
          <Card title="已分组账户资源" bordered={false}>
            <RadioGroup
              onChange={e => this.changeGroupList(e.target.value)}
              defaultValue={this.state.groupTeam_id}
            >
              {this.state.group.map(item => (
                <RadioButton value={item}>第{item}组</RadioButton>
              ))}
            </RadioGroup>
            <div>
              <Button
                onClick={this.del(infoed)}
                type="primary"
                style={{ marginTop: 16 }}
              >
                删除
              </Button>
              <SwitchConfirm
                title="确认操作吗？"
                onConfirm={this.changeGroupIsEnable}
                checkedChildren="启动"
                unCheckedChildren="禁用"
                checked={infoed.is_open === 1}
                // onChange={}
                style={{ marginLeft: 16, marginTop: -5 }}
              />
            </div>
            <SimpleTable
              columns={this.state.columns}
              rowKey={record => record.id}
              dataSource={infoed.list}
              pagination={{
                ...this.state.qrcodeGroupedPagination,
                current: infoed.page,
                pageSize: infoed.pageSize,
                total: infoed.total
              }}
              loading={this.props.qrcodeGroupedLoading}
              onChange={this.qrcodeGroupedHandleTableChange}
              // style={{ height: this.state.height }}
              // scroll={{ y: this.state.height }}
              rowSelection={{
                onChange: (groupSelectedRowKeys, groupSelectedRows) => {
                  this.setState({
                    groupSelectedRowKeys,
                    groupSelectedRows
                  });
                },
                selectedRowKeys: this.state.groupSelectedRowKeys,
                getCheckboxProps: record => ({
                  disabled: infoed.is_open === 1, // Column configuration not to be checked
                  name: record.name
                })
              }}
            />
          </Card>
          <Modal
            title="请选择分组"
            visible={this.state.isShowGroupModal}
            onOk={this.add(info)}
            onCancel={() =>
              this.setState({
                isShowGroupModal: false
              })
            }
          >
            <RadioGroup
              onChange={e => {
                this.setState({ team_id: e.target.value });
              }}
            >
              {this.state.group.map(item => (
                <Radio value={item}>第{item}组</Radio>
              ))}
            </RadioGroup>
          </Modal>
        </Col>
      </Row>
    );
  }
}
