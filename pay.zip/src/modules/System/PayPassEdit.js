import React from 'react';
import { Form, Icon, Input, Button, Card, message } from 'antd';
import { routerRedux, Link } from 'dva/router';
import { connect } from 'dva';
// import './UserLogin.css'

const FormItem = Form.Item;

@Form.create()
// @connect(({ system }) => ({ system }))
@connect(({ system, global, loading }) => ({
  system,
  global
  // loading: loading.effects['system/getQrConsts']
}))
export default class PayPassEdit extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        // this.props.dispatch({
        //   type: 'system/delQrConsts',
        //   payload: {
        //     id: Number(item.id)
        //   }
        // });

        this.props.dispatch({
          type: 'system/payPassEdit',
          payload: {
            // ...values
            password: values.password,
            pay_password: values.newPassword
          },
          callback: res => {
            if (res.code === 200) {
              message.success('更新成功');
            }
          }
        });
      } else {
        console.log('有错误');
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <Form onSubmit={this.handleSubmit} className="login-form">
        {/* <FormItem>
          {getFieldDecorator('name', {
            // initialValue: this.props.user.userInfo.name
          })(
            <Input
              disabled
              size='large'
              prefix={<Icon type='user' style={{ color: 'rgba(0,0,0,.25)' }} />}
              type='text'
            />
          )}
        </FormItem> */}
        <FormItem>
          {getFieldDecorator('password', {
            // rules: [{ required: true, message: '请输入原支付密码' }]
          })(
            <Input
              size="large"
              prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
              type="password"
              placeholder="请输入原支付密码"
            />
          )}
        </FormItem>
        <span
          style={{
            color: 'red',
            position: 'absolute',
            top: '125px',
            paddingLeft: '15px'
          }}
        >
          第一次修改不用填写原密码
        </span>
        <FormItem>
          {getFieldDecorator('newPassword', {
            rules: [
              { required: true, message: '请输入新支付密码' },
              {
                validator: (rule, value, callback) => {
                  if (value && value.length !== 6) {
                    callback('请输入6位密码');
                    return;
                  }
                  if (value && Number.isNaN(+value)) {
                    callback('只能输入数字');
                    return;
                  }
                  if (value.includes('.')) {
                    callback('只能输入数字');
                    return;
                  }
                  callback();
                }
              }
            ]
          })(
            <Input
              size="large"
              prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
              type="password"
              placeholder="请输入新支付密码"
            />
          )}
        </FormItem>
        <FormItem>
          {getFieldDecorator('confirmPassword', {
            rules: [
              { required: true, message: '请输入确认密码' },
              {
                validator: (rule, value, callback) => {
                  const form = this.props.form;
                  if (value && value !== form.getFieldValue('newPassword')) {
                    callback('两次输入密码不一致');
                  } else {
                    callback();
                  }
                }
              }
            ]
          })(
            <Input
              size="large"
              prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
              type="password"
              placeholder="请输入确认密码"
            />
          )}
        </FormItem>
        <FormItem>
          {/* {getFieldDecorator('remember', {
            valuePropName: 'checked',
            initialValue: true
          })(<Checkbox>记住我</Checkbox>)}
          <a className='login-form-forgot' href=''>忘记密码</a> */}
          <Button
            size="large"
            type="primary"
            htmlType="submit"
            className="login-form-button"
          >
            更新支付密码
          </Button>
        </FormItem>
      </Form>
    );
  }
}
