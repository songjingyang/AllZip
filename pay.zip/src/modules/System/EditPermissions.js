import React from 'react';
import { Form, Input, message, Button,Tree } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const TreeNode = Tree.TreeNode;
var treeData = [{
  title: '0-0',
  key: '0-0',
  children: [{
    title: '0-0-0',
    key: '0-0-0',
    children: [
      { title: '0-0-0-0', key: '0-0-0-0' },
      { title: '0-0-0-1', key: '0-0-0-1' },
      { title: '0-0-0-2', key: '0-0-0-2' },
    ],
  }, {
    title: '0-0-1',
    key: '0-0-1',
    children: [
      { title: '0-0-1-0', key: '0-0-1-0' },
      { title: '0-0-1-1', key: '0-0-1-1' },
      { title: '0-0-1-2', key: '0-0-1-2' },
    ],
  }, {
    title: '0-0-2',
    key: '0-0-2',
  }],
}, {
  title: '0-1',
  key: '0-1',
  children: [
    { title: '0-1-0-0', key: '0-1-0-0' },
    { title: '0-1-0-1', key: '0-1-0-1' },
    { title: '0-1-0-2', key: '0-1-0-2' },
  ],
}, {
  title: '0-2',
  key: '0-2',
}];

@Form.create()
@connect(({ system }) => ({
  system
}))
export default class EditPermissions extends React.Component {
  state = {
    expandedKeys: ['0-0-0', '0-0-1'],
    autoExpandParent: true,
    checkedKeys: [],
    selectedKeys: [],
  }

  onExpand = (expandedKeys) => {
    console.log('onExpand', expandedKeys);
    // if not set autoExpandParent to false, if children expanded, parent can not collapse.
    // or, you can remove all expanded children keys.
    this.setState({
      expandedKeys,
      autoExpandParent: false,
    });
  }

  onCheck = (checkedKeys) => {
    console.log('onCheck', checkedKeys);
    this.setState({ checkedKeys });
    this.props.system.getRoleAuthInfo.RoleAuth = []
    // this.state.checkedKeys = checkedKeys
  }

  onSelect = (selectedKeys, info) => {
    console.log('onSelect', info);
    this.setState({ selectedKeys });
  }

  renderTreeNodes = (data) => {
    if (data === undefined) {
      return
    }
    return data.map((item) => {
      if (item.children) {
        return (
          <TreeNode title={item.title} key={item.key} dataRef={item}>
            {this.renderTreeNodes(item.children)}
          </TreeNode>
        );
      }
      return <TreeNode {...item} />;
    });
  }

  componentDidMount() {
    this.getRolePermissions();
  }
  componentWillUnmount(){
    this.props.system.getRoleAuthInfo.RoleAuth = []
  }
  getRolePermissions = (params = {}) => {
    this.props.dispatch({
      type: 'system/getRoleAuth',
      payload: {
        role_id: this.props.system.permissionsEdit.id
      },
      callback: params.callback
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        var keys = this.state.checkedKeys
        this.props.dispatch({
          type: 'system/EditPermissions',
          payload: {
            // ...this.props.system.blackListInfo,
            role_id:this.props.system.permissionsEdit.id,
            keys:keys,
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.system.getRoleAuthInfo.list;
    treeData = info
    var keys = this.props.system.getRoleAuthInfo.RoleAuth
    if (this.state.checkedKeys.length === 0) {
      var checkedKeys = []
      if (keys !== undefined) {
        if (keys !== null) {
          for (var value of keys) {
            checkedKeys.push(value.id)
          }
        }
      }
      this.state.checkedKeys = checkedKeys
    }
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      
      <Form onSubmit={this.handleSubmit}>
        <Tree
          checkable
          onExpand={this.onExpand}
          expandedKeys={this.state.expandedKeys}
          autoExpandParent={this.state.autoExpandParent}
          onCheck={this.onCheck}
          checkedKeys={this.state.checkedKeys}
          onSelect={this.onSelect}
          selectedKeys={this.state.selectedKeys}
        >
      {this.renderTreeNodes(treeData)}
      </Tree>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
