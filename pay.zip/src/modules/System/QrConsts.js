import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Alert,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import { now } from 'moment';
import AddQrConsts from './AddQrConsts';

const FormItem = Form.Item;

@Form.create()
@connect(({ system, global, loading }) => ({
  system,
  global,
  loading: loading.effects['system/getQrConsts']
}))
export default class QrConsts extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      isDelete: false,
      isAddQrConsts: false,
      columns: [
        // {
        //   isExpand: true,
        //   title: 'id',
        //   dataIndex: 'id'
        // },
        {
          title: '金额',
          dataIndex: 'amount'
        },
        // {
        //   isExpand: true,
        //   title: '到期时间',
        //   dataIndex: 'expire',
        //   render: text => <span>{dateFormater(text)}</span>
        // },
        {
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <span>
              {/* <a
                onClick={() => this.deleteBlackList(record)}
                href="javascript:;"
              >
                删除
              </a> */}
              <Popconfirm
                title="确定吗?"
                onConfirm={() => this.deleteQcCensts(record)}
              >
                <a href="javascript:;">删除</a>
              </Popconfirm>
            </span>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getQrConsts();
  }
  getQrConsts = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          // params.ts = this.props.system.blackList.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'system/getQrConsts',
          payload: { ...payload },
          callback: params.callback
        });
      } else {
        console.log('getQrConsts err');
      }
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getQrConsts(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({ pagination: pager });
    this.getQrConsts({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  deleteQcCensts = item => {
    // this.props.dispatch({
    //   type: 'system/delQrConsts',
    //   payload: {
    //     ...item
    //   }
    // });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'system/delQrConsts',
          payload: {
            id: Number(item.id)
          },
          callback: res => {
            if (res.code === 200) {
              this.state.pagination.current = 1
              this.getQrConsts();
            }
          }
        });
      } else {
        console.log('delQrConsts parameters error');
      }


    });
  };
  isAddQrConsts = bool => {
    this.setState({ isAddQrConsts: bool });
  };
  addQrConsts = item => {
    this.isAddQrConsts(true);
  };
  add = () => {
    this.isAddQrConsts(false);
    this.state.pagination.current = 1
    this.getQrConsts();
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.system.getQrConstsInfo;
    return (
      <Card bordered={false} title="二维码金额配置">
        {this.state.isAddQrConsts && (
          <Modal
            title="添加"
            visible={this.state.isAddQrConsts}
            onCancel={() => this.isAddQrConsts(false)}
            footer={null}
          >
            <AddQrConsts onClose={this.add} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={6} md={24} sm={24}>
                  <div >
                    <Button
                      icon="plus"
                      onClick={this.addQrConsts}
                      type="primary"
                      htmlType="button"
                    >
                      添加
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
