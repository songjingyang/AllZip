import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Input,
  message,
  Row,
  Col,
  Modal,
  Card
} from 'antd';

import { Chart, Tooltip, Axis, Bar, Coord, Legend } from 'viser-react';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
// import QrcodeSourceEdit from './QrcodeSourceEdit';
// import Stat from '../Finance/Stat';

const DataSet = require('@antv/data-set');

@connect(({ system, global, loading }) => ({
  system,
  global,
  loading: loading.effects['system/getQrcodeSource']
}))
export default class QrcodeSource extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      columns: [
        {
          title: '二维码金额',
          dataIndex: 'Amount'
        },
        {
          title: '数量',
          dataIndex: 'Len'
        }
      ]
    };
  }
  componentWillMount() {
    this.props.dispatch({
      type: 'system/getQrcodeSource',
      payload: {}
    });
  }
  render() {
    const global = this.props.global;
    const info = this.props.system.qrcodeSourceInfo;
    const treeLayout = {
      xs: 24,
      sm: 24,
      md: 24,
      lg: 12,
      xl: 12,
      xxl: 12
    };

    return (
      <Row gutter={16}>
        <Col style={{ marginBottom: '10px' }} {...treeLayout}>
          <Card>
            <SimpleTable
              title={() => '支付宝'}
              columns={this.state.columns}
              rowKey={record => record.id}
              dataSource={info.alipay}
              pagination={false}
              loading={this.props.loading}
              onChange={this.handleTableChange}
            />
          </Card>
        </Col>
        <Col {...treeLayout}>
          <Card>
            <SimpleTable
              title={() => '微信'}
              columns={this.state.columns}
              rowKey={record => record.id}
              dataSource={info.weixin}
              pagination={false}
              loading={this.props.loading}
              onChange={this.handleTableChange}
            />
          </Card>
        </Col>
      </Row>
    );
  }
}
