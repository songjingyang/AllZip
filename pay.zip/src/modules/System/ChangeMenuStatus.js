import React from 'react';
import { Modal, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';
import { commafy, toFixed } from '@/utils/utils';
import { debug } from 'util';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ system, global }) => ({
  system,
  global
}))
export default class ChangeMenuStatus extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'global/saveChangeMenuStatus',
          payload: {
            id: this.props.global.changeMenuStatus.id,
            is_show: +values.is_show
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    const info = this.props.finance;
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="操作状态">
          {getFieldDecorator('is_show', {
            initialValue: '0',
            rules: [
              {
                required: true,
                message: '请选择状态'
              }
            ]
          })(
            <Select>
              <Option value="0">启用</Option>
              <Option value="1">禁用</Option>
            </Select>
          )}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
