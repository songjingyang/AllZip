import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Alert,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import { now } from 'moment';
import AddBlackList from './AddBlackList';
import KoubeiConfigView from './KoubeiConfigView';
import KoubeiConfigCreate from './KoubeiConfigCreate';
import KoubeiConfigEdit from './KoubeiConfigEdit';



const FormItem = Form.Item;

@Form.create()
@connect(({ system, global, loading }) => ({
  system,
  global,
  loading: loading.effects['system/getKoubeiConfig']
}))
export default class KoubeiConfig extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      statusMap: {
        0: '封禁',
        1: '开启',
      },
      isEditKoubeiConfig:false,
      isAddKoubeiConfig:false,
      isDelete: false,
      isAddBlackList: false,
      columns: [
        {
          isExpand: true,
          title: 'id',
          dataIndex: 'id'
        },
        {
          title: 'app_id',
          dataIndex: 'app_id'
        },
        // {
        //   title: '应用私钥',
        //   dataIndex: 'private_key'
        // },
        // {
        //   title: '应用公钥',
        //   dataIndex: 'public_key'
        // },
        // {
        //   title: '支付宝公钥',
        //   dataIndex: 'alipay_key'
        // },
        {
          title: '最大收款总额',
          dataIndex: 'largest_total'
        },
        {
          title: '单日限制最大金额',
          dataIndex: 'daily_limit'
        },
        {
          title: '单笔最小收款金额',
          dataIndex: 'min_amount'
        },
        {
          title: '单笔最大收款金额',
          dataIndex: 'largest_amount'
        },
        {
          title: '收款时段',
          dataIndex: 'collect_time'
        },
        {
          title: '回调地址',
          dataIndex: 'notify_url'
        },
        {
          title: '创建时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          title: '修改时间',
          dataIndex: 'updated',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          title: '状态',
          dataIndex: 'status',
          render: text => <span>{this.state.statusMap[text]}</span>
        },
        {
          isExpand: true,
          title: '查看秘钥',
          render: (text, record) => (
            <a onClick={() => this.view(record)} href="javascript:;">
              查看
            </a>
          )
        },
        {
          title: '操作',
          dataIndex: '',
          render: (text, record) => {
            return (
              <span>
                <div>
                  <a onClick={() => this.editKoubeiConfig(record)} href="javascript:;">
                    编辑
                  </a>
                </div>
              </span>
            );
          }
        }
      ]
    };
  }
  componentDidMount() {
    this.getKoubeiConfig();
  }
  getKoubeiConfig = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.system.blackList.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'system/getKoubeiConfig',
          payload: { ...payload },
          callback: params.callback
        });
      } else {
        console.log('getKoubeiConfig err');
      }
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getKoubeiConfig(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({ pagination: pager });
    this.getKoubeiConfig({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  isEditKoubeiConfig = bool => {
    this.setState({ isEditKoubeiConfig: bool });
  };
  editKoubeiConfig = item => {
    this.isEditKoubeiConfig(true);
    this.props.dispatch({
      type: 'system/editKoubeiConfig',
      payload: {
        ...item
      }
    });
  };
  isAddKoubeiConfig = bool => {
    this.setState({ isAddKoubeiConfig: bool });
  };
  addKoubeiConfig = item => {
    this.isAddKoubeiConfig(true);
  };
  reload = () => {
    this.isAddKoubeiConfig(false);
    this.isEditKoubeiConfig(false);
    this.getKoubeiConfig();
  };
  isView = bool => {
    this.setState({ isView: bool });
  };
  view = item => {
    this.isView(true);
    this.props.dispatch({
      type: 'system/koubeiConfigView',
      payload: {
        ...item
      }
    });
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.system.getKoubeiConfigInfo;
    return (
      <Card bordered={false} title="口碑商户配置">
        {this.state.isView && (
          <Modal
            width={800}
            title="其他信息"
            visible={this.state.isView}
            onCancel={() => this.isView(false)}
            footer={null}
          >
            <KoubeiConfigView onClose={this.closeEdit} />
          </Modal>
        )}
        {this.state.isEditKoubeiConfig && (
          <Modal
            title="修改口碑商户"
            visible={this.state.isEditKoubeiConfig}
            onCancel={() => this.isEditKoubeiConfig(false)}
            footer={null}
          >
            <KoubeiConfigEdit onClose={this.reload} />
          </Modal>
        )}
        {this.state.isAddKoubeiConfig && (
          <Modal
            title="添加口碑商户"
            visible={this.state.isAddKoubeiConfig}
            onCancel={() => this.isAddKoubeiConfig(false)}
            footer={null}
          >
            <KoubeiConfigCreate onClose={this.reload} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="IP" className="form-inline-item">
                    {getFieldDecorator('ip')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={4} md={24} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
                <Col xl={6} md={24} sm={24}>
                  <div className={'submitButtons'}>
                    <Button
                      icon="plus"
                      onClick={this.addKoubeiConfig}
                      type="primary"
                      htmlType="button"
                    >
                      添加口碑商户配置
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
