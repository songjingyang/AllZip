import React from 'react';
import { message, Form, Input, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const { TextArea } = Input;

@Form.create()
@connect(({ system }) => ({
  system
}))
export default class SystemConfigEdit extends React.Component {
  componentDidMount() {}
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'system/saveSystemConfigEdit',
          payload: {
            ...this.props.system.systemConfigEdit,
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('修改成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.system.systemConfigEdit;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="key">
          {getFieldDecorator('key', {
            initialValue: info.key,
            rules: [
              {
                required: true,
                message: '配置key',
                whitespace: true
              }
            ]
          })(<Input disabled placeholder="配置key" />)}
        </FormItem>
        {info.key === 'ccpay:MasterDomain' ? (
          <FormItem {...formItemLayout} label="value">
            {getFieldDecorator('value', {
              initialValue: info.value,
              rules: [
                {
                  required: true,
                  message: '配置value',
                  whitespace: true
                }
              ]
            })(<Input placeholder="配置value" />)}
          </FormItem>
        ) : (
          <FormItem {...formItemLayout} label="value">
            {getFieldDecorator('value', {
              initialValue: info.value,
              rules: [
                {
                  required: true,
                  message: '配置value',
                  whitespace: true
                }
              ]
            })(<TextArea rows={4} placeholder="配置value" />)}
          </FormItem>
        )}
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            修改
          </Button>
        </FormItem>
      </Form>
    );
  }
}
