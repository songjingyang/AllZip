import React from 'react';
import { Button, Card, Modal, Divider, Popconfirm } from 'antd';
import { connect } from 'dva';

import { Link } from 'dva/router';
import classNames from 'classnames';
import SimpleTable from '@/components/SimpleTable';

import AddMenu from './AddMenu';
import EditMenu from './EditMenu';
import ShowMenu from './ShowMenu';
import ChangeMenuStatus from './ChangeMenuStatus';

@connect(({ system, global, loading }) => ({
  system,
  global
  // loading: loading.effects['system/getSystemConfig']
}))
export default class MenuConfig extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      statusMap: {
        1: '启用',
        2: '禁用'
      },
      columns: [
        {
          isExpand: true,
          title: '菜单名',
          dataIndex: 'name'
        },
        {
          isExpand: true,
          title: '路径',
          dataIndex: 'url'
        },
        // {
        //   isExpand: true,
        //   title: '菜单别名',
        //   dataIndex: 'show'
        // },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'is_show',
          render: text => <span>{this.state.statusMap[text]}</span>
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <span>
              <Popconfirm
                title="确定吗？"
                onConfirm={() => this.delete(record)}
              >
                <a href="javascript:;">删除</a>
              </Popconfirm>
              <Divider type="vertical" />
              <a onClick={() => this.edit(record)} href="javascript:;">
                编辑
              </a>
              <Divider type="vertical" />
              <a onClick={() => this.show(record)} href="javascript:;">
                查询
              </a>
              <Divider type="vertical" />
              <a onClick={() => this.changeStatus(record)} href="javascript:;">
                状态
              </a>
            </span>
          )
        }
      ]
    };
  }

  componentDidMount() {}
  getMenuConfigList = () => {};

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({ pagination: pager });
    this.getBlackList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  isAdd = bool => this.setState({ isAdd: bool });
  addMenu = () => {
    this.isAdd(true);
  };
  delete = item => {
    this.props.dispatch({
      type: 'global/delMenu',
      payload: { ...item }
    });
    this.props.dispatch({
      type: 'global/saveDelMenu',
      payload: { ...item }
    });
  };
  isEdit = bool => this.setState({ isEdit: bool });
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'global/editMenu',
      payload: { ...item }
    });
  };
  isShow = bool => this.setState({ isShow: bool });
  show = item => {
    this.isShow(true);
    this.props.dispatch({
      type: 'global/showMenu',
      payload: { ...item }
    });
  };
  isChangeStatus = bool => this.setState({ isChangeStatus: bool });
  changeStatus = item => {
    this.isChangeStatus(true);
    this.props.dispatch({
      type: 'global/changeMenuStatus',
      payload: { ...item }
    });
  };
  close = () => {
    this.isShow(false);
  };
  reload = () => {
    this.isAdd(false);
    this.isEdit(false);
    this.isChangeStatus(false);
    this.props.dispatch({
      type: 'global/getMenuData',
      payload: {}
    });
  };

  render() {
    const global = this.props.global;
    const info = this.props.global.MenuData;
    return (
      <Card title="菜单管理">
        {this.state.isAdd && (
          <Modal
            title="添加菜单"
            visible={this.state.isAdd}
            onCancel={() => this.isAdd(false)}
            footer={null}
          >
            <AddMenu onClose={this.reload} />
          </Modal>
        )}
        {this.state.isEdit && (
          <Modal
            title="编辑"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <EditMenu onClose={this.reload} />
          </Modal>
        )}
        {this.state.isShow && (
          <Modal
            title="查询"
            visible={this.state.isShow}
            onCancel={() => this.isShow(false)}
            footer={null}
          >
            <ShowMenu onClose={this.close} />
          </Modal>
        )}
        {this.state.isChangeStatus && (
          <Modal
            title="状态"
            visible={this.state.isChangeStatus}
            onCancel={() => this.isChangeStatus(false)}
            footer={null}
          >
            <ChangeMenuStatus onClose={this.reload} />
          </Modal>
        )}
        <div className="tableList">
          <div className={'tableListOperator'}>
            <Button icon="plus" onClick={this.addMenu} type="primary">
              添加菜单
            </Button>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info}
            // pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
