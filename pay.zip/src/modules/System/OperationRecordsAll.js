import React from 'react';
import {
  Form,
  Select,
  Input,
  Radio,
  Button,
  Card,
  DatePicker,
  Row,
  Col
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ system, global, loading }) => ({
  system,
  global,
  loading: loading.effects['system/getOperationRecordsAll']
}))
export default class OperationRecordsAll extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      columns: [
        {
          isExpand: true,
          title: '流水ID',
          dataIndex: 'id'
        },
        {
          title: '管理员',
          dataIndex: 'account'
        },
        {
          title: '标题',
          dataIndex: 'title'
        },
        {
          isExpand: true,
          title: '内容',
          dataIndex: 'content'
        },
        {
          isExpand: true,
          title: 'IP',
          dataIndex: 'ip'
        },
        {
          isExpand: true,
          title: '操作时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        }
      ]
    };
  }
  updatePagination = param => {
    this.setState({
      pagination: { total: param.total }
    });
  };
  componentDidMount() {
    this.getOperationRecordsAll();
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getOperationRecordsAll(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getOperationRecordsAll({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getOperationRecordsAll = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.system.operationRecordsAllInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }

        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'system/getOperationRecordsAll',
          payload: { ...payload },
          callback: params.callback
        });
      } else {
        console.log('getOperationRecordsAll err');
      }
    });
  };

  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.system.operationRecordsAllInfo;

    return (
      <Card bordered={false}>
        <div className={'tableList'}>
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                      initialValue: getTimeDistance('today'),
                      rules: [
                        {
                          validator: (rule, value, callback) => {
                            let startTm;
                            let endTm;
                            if (value.length !== 0) {
                              startTm = parseInt(value[0].valueOf() / 1000);
                              endTm = parseInt(value[1].valueOf() / 1000);
                              if (endTm - startTm > 90 * 24 * 3600) {
                                callback('最大范围 3个月');
                              }
                            } else {
                              startTm = 0;
                              endTm = 0;
                            }
                            callback();
                          }
                        }
                      ]
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        showTime
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="标题" className="form-inline-item">
                    {getFieldDecorator('title', {
                      initialValue: ''
                    })(
                      <Select
                        placeholder="请选择标题"
                        onChange={this.onChangeBank}
                      >
                        <Option value="">全部</Option>
                        <Option value="财务管理-平台转账">
                          财务管理-平台转账
                        </Option>
                        <Option value="财务管理-代理转账">
                          财务管理-代理转账
                        </Option>
                        <Option value="财务管理-代理结算-总代结算明细">
                          财务管理-代理结算-总代结算明细
                        </Option>
                        <Option value="财务管理-代理结算-生成结算单">
                          财务管理-代理结算-生成结算单
                        </Option>
                        <Option value="财务管理-代理结算-下载结算单">
                          财务管理-代理结算-下载结算单
                        </Option>
                        <Option value="订单管理-流水单">订单管理-流水单</Option>
                        <Option value="代理管理-二维码审核">
                          代理管理-二维码审核
                        </Option>
                        <Option value="代理管理-充值额度审核">
                          代理管理-充值额度审核
                        </Option>
                        <Option value="代理管理-降低额度审核">
                          代理管理-降低额度审核
                        </Option>
                        <Option value="代理管理-实名审核">
                          代理管理-实名审核
                        </Option>
                        <Option value="系统管理-二维码分组">
                          系统管理-二维码分组
                        </Option>
                        <Option value="系统管理-代理树">系统管理-代理树</Option>
                        <Option value="系统管理-系统配置">
                          系统管理-系统配置
                        </Option>
                        <Option value="系统管理-ip黑名单">
                          系统管理-ip黑名单
                        </Option>
                        <Option value="商户代理管理-提现申请-转账">
                          商户代理-提现申请-转账
                        </Option>
                        <Option value="商户代理管理-商户代理-创建商户代理">
                          商户代理管理-商户代理-创建商户代理
                        </Option>
                        <Option value="商户代理管理-商户代理-修改商户代理">
                          商户代理管理-商户代理-修改商户代理
                        </Option>
                      </Select>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
