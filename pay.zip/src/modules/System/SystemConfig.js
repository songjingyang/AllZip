import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import SystemConfigEdit from './SystemConfigEdit';

@connect(({ system, global, loading }) => ({
  system,
  global,
  loading: loading.effects['system/getSystemConfig']
}))
export default class SystemConfig extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      isEdit: false,
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      columns_domain: [
        {
          title: '域名key',
          dataIndex: 'key',
          width: 350
        },
        {
          isExpand: true,
          title: '域名value',
          dataIndex: 'value'
        },
        {
          title: '编辑',
          dataIndex: 'domain',
          width: 350,
          render: (text, record) => {
            return (
              <span>
                <Button type="primary" onClick={() => this.edit(record)}>
                  编辑
                </Button>
              </span>
            );
          }
        }
      ],
      columns_white: [
        {
          title: '白名单key',
          dataIndex: 'key',
          width: 350
        },
        {
          isExpand: true,
          title: '白名单value',
          dataIndex: 'value'
        },
        {
          title: '编辑',
          dataIndex: 'white',
          width: 350,
          render: (text, record) => (
            <span>
              <Button
                type="primary"
                onClick={() => this.edit(record)}
                href="javascript:;"
              >
                编辑
              </Button>
            </span>
          )
        }
      ]
    };
  }

  componentDidMount() {
    this.getSystemConfig();
  }
  getSystemConfig = (params = {}) => {
    this.props.dispatch({
      type: 'system/getSystemConfig',
      payload: { ...params },
      callback: params.callback
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getSystemConfig({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'system/systemConfigEdit',
      payload: {
        ...item
      }
    });
  };
  addSystemConfig = () => {
    this.isEdit(false);
    this.getSystemConfig();
  };
  render() {
    const info = this.props.system.systemConfig;
    return (
      <Card title="配置信息">
        {this.state.isEdit && (
          <Modal
            // width={800}
            title="编辑"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <SystemConfigEdit onClose={this.addSystemConfig} />
          </Modal>
        )}
        <div className="tableList">
          <SimpleTable
            bordered={true}
            columns={this.state.columns_domain}
            rowKey={record => record.id}
            dataSource={info.doMain}
            pagination={false}
            loading={this.props.loading}
            onChange={this.handleTableChange}
            style={{ marginBottom: '30px' }}
          />
          <SimpleTable
            bordered={true}
            columns={this.state.columns_white}
            rowKey={record => record.id}
            dataSource={info.globalWhite}
            pagination={false}
            loading={this.props.loading}
            onChange={this.handleTableChange}
            style={{ marginBottom: '30px' }}
          />
        </div>
      </Card>
    );
  }
}
