import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';

const { TextArea } = Input;
const FormItem = Form.Item;
const Option = Select.Option;

@Form.create()
@connect(({ system }) => ({ system }))
export default class KoubeiConfigView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: []
    };
  }
  componentDidMount() {}
  handleSubmit = e => {
    e.preventDefault();
    this.props.onClose();
  };
  render() {
    const info = this.props.system.koubeiConfigView;
    debugger
    const extend_data = info.extend
      ? JSON.stringify(JSON.parse(info.extend), null, 2)
      : '';
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label='应用公钥'>
          {getFieldDecorator('public_key', {
            initialValue: info.public_key,
          })(<TextArea disabled rows={9} />)}
        </FormItem>
        <FormItem {...formItemLayout} label='应用公钥'>
          {getFieldDecorator('private_key', {
            initialValue: info.private_key,
          })(<TextArea  disabled rows={9}/>)}
        </FormItem>
        <FormItem {...formItemLayout} label='支付宝公钥'>
          {getFieldDecorator('alipay_key', {
            initialValue: info.alipay_key,
          })(<TextArea  disabled rows={9}/>)}
        </FormItem>
        {/* <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            关闭
          </Button>
        </FormItem> */}
      </Form>
    );
  }
}
