import React from 'react';
import { message, Form, Input, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;

@Form.create()
@connect(({ system }) => ({
  system
}))
export default class QrcodeSourceEdit extends React.Component {
  componentDidMount() {
    this.props.dispatch({
      type: 'system/getQrcodeSourceEdit'
    });
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'system/saveQrcodeSourceEditInfo',
          payload: {
            ...this.props.system.qrcodeSourceEditInfo,
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.system.qrcodeSourceEditInfo;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="定价（分）">
          {getFieldDecorator('price', {
            // initialValue: info.key,
            rules: [
              {
                required: true,
                message: '请输入定价',
                whitespace: true
              }
            ]
          })(<Input placeholder="1000" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="浮动价（分）">
          {getFieldDecorator('floatPrice', {
            // initialValue: info.value,
            rules: [
              {
                required: true,
                message: '请输入浮动价',
                whitespace: true
              }
            ]
          })(<Input placeholder="1001" />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            添加
          </Button>
        </FormItem>
      </Form>
    );
  }
}
