import React from 'react';
import { Card, Form, Input, Select, Button, message } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;

@Form.create()
@connect(({ system }) => ({ system }))
export default class AdminAllEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      groupMap: {
        1: '禁用用户',
        2: '运营人员',
        3: '财务人员',
        4: '管理人员',
        5: '超级管理员'
      }
    };
  }
  componentDidMount() {
    // this.props.dispatch({
    //     type: 'system/getAdminAllInfoEdit'
    // })
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'system/saveAdminAllInfoEdit',
          payload: {
            ...this.props.system.adminAllInfoEdit,
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.system.adminAllInfoEdit;
    console.log('info', info.account);
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Card bordered={false}>
        <Form onSubmit={this.handleSubmit}>
          <FormItem {...formItemLayout} label="账号：">
            {getFieldDecorator('account', {
              initialValue: info.account,
              rules: [
                {
                  require: true,
                  message: 'account',
                  whitespace: true
                }
              ]
            })(<Input disabled />)}
          </FormItem>
          <FormItem {...formItemLayout} label="密码：">
            {getFieldDecorator('password', {
              rules: [
                {
                  require: true,
                  message: 'password',
                  whitespace: true
                }
              ]
            })(<Input placeholder="密码" />)}
          </FormItem>
          <FormItem {...formItemLayout} label="分组：">
            {getFieldDecorator('group', {
              initialValue: this.state.groupMap[info.group],
              rules: [
                {
                  require: true,
                  message: 'group',
                  whitespace: true
                }
              ]
            })(
              <Select>
                <Option value="1">禁用用户</Option>
                <Option value="2">运营人员</Option>
                <Option value="3">财务人员</Option>
                <Option value="4">管理人员</Option>
                <Option value="5">超级管理员</Option>
              </Select>
            )}
          </FormItem>
          <FormItem wrapperCol={{ span: 12, offset: 6 }}>
            <Button type="primary" htmlType="submit">
              保存
            </Button>
          </FormItem>
        </Form>
      </Card>
    );
  }
}
