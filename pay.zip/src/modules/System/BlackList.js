import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Alert,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import { now } from 'moment';
import AddBlackList from './AddBlackList';

const FormItem = Form.Item;

@Form.create()
@connect(({ system, global, loading }) => ({
  system,
  global,
  loading: loading.effects['system/getBlackList']
}))
export default class BlackList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      isDelete: false,
      isAddBlackList: false,
      columns: [
        {
          isExpand: true,
          title: 'id',
          dataIndex: 'id'
        },
        {
          title: 'IP',
          dataIndex: 'ip'
        },
        {
          isExpand: true,
          title: '到期时间',
          dataIndex: 'expire',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <span>
              {/* <a
                onClick={() => this.deleteBlackList(record)}
                href="javascript:;"
              >
                删除
              </a> */}
              <Popconfirm
                title="确定吗?"
                onConfirm={() => this.deleteBlackList(record)}
              >
                <a href="javascript:;">删除</a>
              </Popconfirm>
            </span>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getBlackList();
  }
  getBlackList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.system.blackList.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'system/getBlackList',
          payload: { ...payload },
          callback: params.callback
        });
      } else {
        console.log('getBlackList err');
      }
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getBlackList(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({ pagination: pager });
    this.getBlackList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  deleteBlackList = item => {
    this.props.dispatch({
      type: 'system/delBlackIp',
      payload: {
        ...item
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'system/getDelBlackList',
          payload: {
            id: Number(item.id)
          }
        });
      } else {
        console.log('deleteBlackList parameters error');
      }
    });
  };
  isAddBlackList = bool => {
    this.setState({ isAddBlackList: bool });
  };
  addBlackList = item => {
    this.isAddBlackList(true);
  };
  add = () => {
    this.isAddBlackList(false);
    this.getBlackList();
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.system.blackListInfo;
    return (
      <Card bordered={false} title="黑名单IP管理">
        {this.state.isAddBlackList && (
          <Modal
            title="添加黑名单IP"
            visible={this.state.isAddBlackList}
            onCancel={() => this.isAddBlackList(false)}
            footer={null}
          >
            <AddBlackList onClose={this.add} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="IP" className="form-inline-item">
                    {getFieldDecorator('ip')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={4} md={24} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
                <Col xl={6} md={24} sm={24}>
                  <div className={'submitButtons'}>
                    <Button
                      icon="plus"
                      onClick={this.addBlackList}
                      type="primary"
                      htmlType="button"
                    >
                      添加IP黑名单
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
