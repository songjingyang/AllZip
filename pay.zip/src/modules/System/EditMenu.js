import React from 'react';
import { Modal, message, Form, Input, Select, TreeSelect, Button } from 'antd';
import { connect } from 'dva';
import { commafy, toFixed } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ system, global }) => ({
  system,
  global
}))
export default class EditMenu extends React.Component {
  componentDidMount() {}

  // handleSubmit = e => {
  //   e.preventDefault();
  //   this.props.form.validateFields((err, values) => {
  //     if (!err) {
  //       const formItemLayout = {
  //         labelCol: { span: 8 },
  //         wrapperCol: { span: 14 }
  //       };
  //       Modal.confirm({
  //         title: '提交确认',
  //         okText: '确认',
  //         cancelText: '取消',
  //         onOk: () => {
  //           return this.save();
  //         },
  //         content: (
  //           <Form>
  //             <FormItem {...formItemLayout} label="上级">
  //               {/* {values.level} */}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="名字">
  //               {/* {values.name} */}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="Url">
  //               {/* {values.url} */}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="Icon">
  //               {/* {values.icon} */}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="Path">
  //               {/* {values.path} */}
  //             </FormItem>
  //             <FormItem {...formItemLayout} label="排列序号">
  //               {/* {values.sort} */}
  //             </FormItem>
  //           </Form>
  //         )
  //       });
  //     }
  //   });
  // };
  handleSubmit = e => {
    this.props.form.validateFields((err, values) => {
      values.ach_rate = values.ach_rate * 100;
      values.amount = +values.amount;
      values.request_amount = +values.request_amount;
      if (!err) {
        this.props.dispatch({
          type: 'global/saveEditMenu',
          payload: {
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    const menu = [
      {
        title: '顶级菜单',
        value: '',
        key: '',
        children: this.props.global.MenuData
      }
    ];
    const menuValue = this.props.global.editMenu;
    console.log('menuValue', this.props.global.editMenu);
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="上级">
          {getFieldDecorator('level', {
            initialValue: menuValue.level,
            rules: [
              {
                required: true,
                message: '请输入上级'
              }
            ]
          })(
            <TreeSelect
              dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
              treeData={menu}
              placeholder="请选择上级"
              treeDefaultExpandAll
            />
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="名字">
          {getFieldDecorator('name', {
            initialValue: menuValue.name,
            rules: [
              {
                required: true,
                message: '请输入名字'
              }
            ]
          })(<Input />)}
        </FormItem>
        <FormItem {...formItemLayout} label="Url">
          {getFieldDecorator('url', {
            initialValue: menuValue.url,
            rules: [
              {
                required: true,
                message: '请输入Url'
              }
            ]
          })(<Input />)}
        </FormItem>
        <FormItem {...formItemLayout} label="Icon">
          {getFieldDecorator('icon', {
            initialValue: menuValue.icon,
            rules: [
              {
                required: true,
                message: '请输入Icon'
              }
            ]
          })(<Input />)}
        </FormItem>
        <FormItem {...formItemLayout} label="Path">
          {getFieldDecorator('path', {
            initialValue: menuValue.path,
            rules: [
              {
                required: true,
                message: '请输入Path'
              }
            ]
          })(<Input />)}
        </FormItem>
        <FormItem {...formItemLayout} label="排列序号">
          {getFieldDecorator('sort', {
            initialValue: menuValue.sort,
            rules: [
              {
                required: true,
                message: '请输入排列序号'
              }
            ]
          })(<Input />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
