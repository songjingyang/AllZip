import React from 'react';
import { Modal, message, Form, Input, Select, TreeSelect, Button } from 'antd';
import { connect } from 'dva';
import { commafy, toFixed } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ system, global }) => ({
  system,
  global
}))
export default class ShowMenu extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    e.preventDefault();
    this.props.onClose();
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    const menuValue = this.props.global.showMenu;
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem style={{ marginBottom: 10 }} {...formItemLayout} label="上级">
          {getFieldDecorator('level')(<span>{menuValue.name}</span>)}
        </FormItem>
        <FormItem style={{ marginBottom: 10 }} {...formItemLayout} label="名字">
          {getFieldDecorator('name')(<span>{menuValue.name}</span>)}
        </FormItem>
        {/* <FormItem style={{ marginBottom: 10 }} {...formItemLayout} label="别名">
          {getFieldDecorator('show')(<span>{menuValue.show}</span>)}
        </FormItem> */}
        <FormItem style={{ marginBottom: 10 }} {...formItemLayout} label="Url">
          {getFieldDecorator('url')(<span>{menuValue.url}</span>)}
        </FormItem>
        <FormItem style={{ marginBottom: 10 }} {...formItemLayout} label="Icon">
          {getFieldDecorator('icon')(<span>{menuValue.icon}</span>)}
        </FormItem>
        <FormItem style={{ marginBottom: 10 }} {...formItemLayout} label="Path">
          {getFieldDecorator('path')(<span>{menuValue.path}</span>)}
        </FormItem>
        <FormItem
          style={{ marginBottom: 10 }}
          {...formItemLayout}
          label="排列序号"
        >
          {getFieldDecorator('sort')(<span>{menuValue.sort}</span>)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            关闭
          </Button>
        </FormItem>
      </Form>
    );
  }
}
