import React from 'react';
import { Table, message, Form, Input, Select, Button, Radio } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

@Form.create()
@connect(({ system }) => ({
  system
}))
export default class KoubeiConfigEdit extends React.Component {
  componentDidMount() {
    
  }

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      var data = {
        alipay_key: values.alipay_key,
        app_id: values.app_id,
        collect_time: values.collect_time,
        daily_limit: Number(values.daily_limit),
        largest_amount: Number(values.largest_amount),
        largest_total: Number(values.largest_total),
        min_amount: Number(values.min_amount),
        notify_url: values.notify_url,
        private_key: values.private_key,
        public_key: values.public_key,
        status: Number(values.status),
        // ...values 
        
      };
      if (!err) {
        this.props.dispatch({
          type: 'system/editKoubeiConfig',
          payload: {
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('创建成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    debugger
    const { getFieldDecorator } = this.props.form;
    
    const info = this.props.system.editKoubeiConfig;
    
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="id">
          {getFieldDecorator('id', {
            initialValue: info.id,
            rules: [
              {
                required: true,
                message: '请填写id!',
                writespace: true
              },
            ]
          })(<Input type="type" disabled/>)}
        </FormItem>
        <FormItem {...formItemLayout} label="app_id">
          {getFieldDecorator('app_id', {
            initialValue: info.app_id,
            rules: [
              {
                required: true,
                message: '请填写app_id!',
                writespace: true
              },
              // {
              //   validator: (rule, value, callback) => {
              //     if (value && Number.isNaN(+value)) {
              //       callback('只能输入整数')
              //       return
              //     }
              //     if (value.includes('.')) {
              //       callback('只能输入整数')
              //       return
              //     }
              //     callback()
              //   }
              // }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="应用私钥">
          {getFieldDecorator('private_key', {
            initialValue: info.private_key,
            rules: [
              {
                required: true,
                message: '请输入应用私钥'
                // whitespace: true
              }
            ]
          })(<TextArea rows={5} />)}
        </FormItem>
        <FormItem {...formItemLayout} label="应用公钥">
          {getFieldDecorator('public_key', {
            initialValue: info.public_key,
            rules: [
              {
                required: true,
                message: '请输入应用公钥'
                // whitespace: true
              }
            ]
          })(<TextArea rows={5} />)}
        </FormItem>
        <FormItem {...formItemLayout} label="支付宝公钥">
          {getFieldDecorator('alipay_key', {
            initialValue: info.alipay_key,
            rules: [
              {
                required: true,
                message: '请输入支付宝公钥'
                // whitespace: true
              }
            ]
          })(<TextArea rows={5} />)}
        </FormItem>
        <FormItem {...formItemLayout} label="最大收款总额">
          {getFieldDecorator('largest_total', {
            initialValue: info.largest_total,
            rules: [
              {
                required: true,
                message: '请输入最大收款总额!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>          
        {/* <FormItem style={{marginBottom: 10}} {...formItemLayout} label='银行'>
            {getFieldDecorator('type', {
              initialValue: '',
              rules: [
                {
                  required: true,
                  message: '请选择银行'
                  // whitespace: true
                }
              ]
            })(
              <Select placeholder='请选择银行' onChange={this.onChangeBank}>
                {this.props.exchange.getBankConfigAllInfo.list.map(item => (
                  <Option value={item.type}>{item.name}</Option>
                ))}
              </Select>
            )}
        </FormItem> */}
        <FormItem {...formItemLayout} label="单日最大金额">
          {getFieldDecorator('daily_limit', {
            initialValue: info.daily_limit,
            rules: [
              {
                required: true,
                message: '请输入单日限制最大金额!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="单笔最小金额">
          {getFieldDecorator('min_amount', {
            initialValue: info.min_amount,
            rules: [
              {
                required: true,
                message: '请输入单笔最小收款金额!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="单笔最大金额">
          {getFieldDecorator('largest_amount', {
            initialValue: info.largest_amount,
            rules: [
              {
                required: true,
                message: '请输入单笔最大收款金额!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="收款时段">
          {getFieldDecorator('collect_time', {
            initialValue: info.collect_time,
            rules: [
              {
                required: true,
                message: '请输入收款时段!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="回调地址">
          {getFieldDecorator('notify_url', {
            initialValue: info.notify_url,
            rules: [
              {
                required: true,
                message: '请输入回调地址!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>

        <FormItem {...formItemLayout} label="状态">
          {getFieldDecorator('status', {
            initialValue: String(info.status),
            rules: [
              {
                required: true,
                message: '请选择状态'
                // whitespace: true
              }
            ]
          })(
            <RadioGroup>
              <Radio value="1">开启</Radio>
              <Radio value="0">封禁</Radio>
            </RadioGroup>
          )}
        </FormItem>

        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            创建
          </Button>
        </FormItem>
      </Form>
    );
  }
}
