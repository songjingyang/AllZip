import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import AdminAllEdit from './AdminAllEdit';

@Form.create()
@connect(({ system, global, loading }) => ({
  system,
  global,
  loading: loading.effects['syatem/getAdminAll']
}))
export default class AdminAll extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      // admin_extend: {},
      loading: false,
      isEdit: false,
      groupMap: {
        1: '禁用用户',
        2: '运营人员',
        3: '财务人员',
        4: '管理人员',
        5: '超级管理员'
      },
      columns: [
        {
          title: 'id',
          dataIndex: 'id'
        },
        {
          title: '账号',
          dataIndex: 'account'
        },
        {
          title: '分组',
          dataIndex: '',
          render: (text, record) => (
            <span>{this.state.groupMap[record.group]}</span>
          )
        },
        {
          title: '更新时间',
          dataIndex: 'create_time',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          title: '操作',
          dataIndex: 'edit',
          render: (text, record) => (
            <span>
              <a onClick={() => this.edit(record)} href="javascript:;">
                编辑
              </a>
            </span>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getAdminAll();
  }
  getAdminAll = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = {
          ...values
        };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.system.adminAllInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'system/getAdminAllList',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getAdminAllList parameters error');
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({ pagination: pager });
    this.getAdminAll({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    console.log('item', item);
    this.props.dispatch({
      type: 'system/adminAllInfoEdit',
      payload: {
        ...item
      }
    });
  };
  addAdminAllEdit = () => {
    this.isEdit(false);
    this.getAdminAll();
  };
  render() {
    const info = this.props.system.adminAllInfo;
    return (
      <Card>
        {
          <Modal
            title="编辑"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <AdminAllEdit
              // item={this.state.admin_extend}
              onClose={this.addAdminAllEdit}
            />
          </Modal>
        }
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
