import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Input,
  message,
  Row,
  Col,
  Modal,
  Card
} from 'antd';

import { Chart, Tooltip, Axis, Bar, Coord, Legend } from 'viser-react';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';

const DataSet = require('@antv/data-set');

@connect(({ system, global, loading }) => ({
  system,
  global,
  loading: loading.effects['system/getQrcodeSource']
}))
export default class QrcodeSource extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isEdit: false
    };
  }
  componentWillMount() {
    this.props.dispatch({
      type: 'system/getQrcodeSource',
      payload: {}
    });
  }
  getChart(data) {
    return (
      <Chart forceFit={true} height={350} data={data}>
        {/* <SmoothLine position="month*temperature" color="city" size="1" /> */}
        <Coord type="rect" direction="HB" />
        <Tooltip />
        <Axis dataKey="Amount" Amount={{ offset: 2 }} />
        <Legend itemGap={20} size={50} />
        <Slider
          padding={[20, 100, 60]}
          start={0}
          end={0.14}
          data={data}
          xAxis="release"
          yAxis="count"
          // scales: {
          //   release: {
          //     formatter: (val) => {
          //       return parseInt(val, 10);
          //     }
          //   }
          // },
          // backgroundChart: {
          //   type: 'interval',
          //   color: 'rgba(0, 0, 0, 0.3)'
          // },
          // onChange: ({ startText, endText }) => {
          //   // !!! 更新状态量
          //   ds.setState('from', startText);
          //   ds.setState('to', endText);
          // }
        />
        <Bar
          position="Amount*Len"
          adjust={[{ type: 'dodge', marginRatio: 1 / 32 }]}
        />
      </Chart>
    );
  }
  isEdit = bool => {
    this.setState({
      isEdit: bool
    });
  };

  add = () => {
    this.isEdit(true);
  };

  closeEdit = () => {
    this.isEdit(false);
    this.getQrcodeSource();
  };

  render() {
    const stat = this.props.system.qrcodeSourceInfo;

    let dv = new DataSet.View().source(stat.alipay);
    const alipay = dv.transform({
      type: 'sort',
      callback(a, b) {
        return a.value - b.value < 0;
      }
    }).rows;

    dv = new DataSet.View().source(stat.weixin);
    const weixin = dv.transform({
      type: 'sort',
      callback(a, b) {
        return a.value - b.value < 0;
      }
    }).rows;

    const topColResponsiveProps = {
      xs: 24,
      sm: 12,
      md: 12,
      lg: 12,
      xl: 12,
      style: { marginBottom: 24 }
    };

    return (
      <div>
        {/* 最近结算时间: {stat.lastSettleTime} */}
        <Card title="支付宝" style={{ marginBottom: '10px' }}>
          <Row gutter={{ xs: 8, sm: 16, md: 24, xl: 24 }}>
            <Col {...topColResponsiveProps}>{this.getChart(alipay)}</Col>
          </Row>
        </Card>
        <Card title="微信">
          <Row gutter={{ xs: 8, sm: 16, md: 24, xl: 24 }}>
            <Col {...topColResponsiveProps}>{this.getChart(weixin)}</Col>
          </Row>
        </Card>
      </div>
    );
  }
}
