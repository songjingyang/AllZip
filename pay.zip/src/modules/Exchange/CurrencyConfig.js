import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm,
  Divider,
  Checkbox
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import SwitchConfirm from '@/components/SwitchConfirm';
import ReceiveBankEdit from './ReceiveBankEdit';
import ExchangeWayCreate from './ExchangeWayCreate';
import ExchangeWayEdit from './ExchangeWayEdit';
import CurrencyConfigCreate from './CurrencyConfigCreate';
import CurrencyConfigEdit from './CurrencyConfigEdit';
import PreviewImg from '@/components/PreviewImg';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ exchange, global, loading }) => ({
  exchange,
  global,
  loading: loading.effects['exchange/getCurrencyConfig']
}))
export default class CurrencyConfig extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        0: '审核中',
        1: '已通过',
        2: '未通过'
      },
      merchantMap: {
        0: '签约商户',
        1: '平台商户'
      },
      isEdit: false,
      isTransfer: false,
      columns: [
        {
          isExpand: true,
          title: 'id',
          dataIndex: 'id'
        },
        {
          title: '货币名称',
          dataIndex: 'name'
          // render: (text, record) => (
          //   <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
          //     {text}
          //   </Link>
          // )
        },
        {
          isExpand: true,
          title: '货币类型',
          dataIndex: 'type'
        },
        {
          isExpand: true,
          title: '货币图标',
          dataIndex: 'icon',
          render: (text, record) => (
            <PreviewImg src={text} style={{ width: '80px', height: '50px' }} />
          )
        },
        {
          isExpand: true,
          title: '创建时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '更新时间',
          dataIndex: 'updated',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          title: '操作',
          render: (text, record) => {
            return (
              <span>
                <div>
                  <a onClick={() => this.edit(record)} href="javascript:;">
                    编辑
                  </a>
                </div>
              </span>
            );
          }
        }
      ]
    };
  }
  componentDidMount() {
    // let arch_id = this.props.match.params.arch_id;
    // if (arch_id != 0) {
    //   this.props.form.setFieldsValue({ name: arch_id });
    // }
    this.getCurrencyConfig();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getCurrencyConfig(values);
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getCurrencyConfig({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getCurrencyConfig = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.merchant.cardManageInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }

        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'exchange/getCurrencyConfig',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getCurrencyConfig parameters error');
      }
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'exchange/editCurrencyConfig',
      payload: {
        ...item
      }
    });
  };

  isCreate = bool => {
    this.setState({ isCreate: bool });
  };
  create = item => {
    this.isCreate(true);
  };

  reload = () => {
    this.isEdit(false);
    this.isCreate(false);
    this.getCurrencyConfig();
  };

  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.exchange.getCurrencyConfigInfo;

    return (
      <Card bordered={false} title="货币类型">
        {this.state.isEdit && (
          <Modal
            title="编辑"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <CurrencyConfigEdit onClose={this.reload} />
          </Modal>
        )}
        {this.state.isCreate && (
          <Modal
            title="新增"
            visible={this.state.isCreate}
            onCancel={() => this.isCreate(false)}
            footer={null}
          >
            <CurrencyConfigCreate onClose={this.reload} />
          </Modal>
        )}
        <div className="tableList">
          <div className={'tableListOperator'}>
            <Button icon="plus" type="primary" onClick={() => this.create()}>
              新增
            </Button>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
