import React from 'react';
import {
  Table,
  message,
  Form,
  Input,
  Select,
  Button,
  Radio,
  DatePicker,
  Upload,
  Icon,
  Modal
} from 'antd';
import { connect } from 'dva';
import { dateFormater, getTimeDistance } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

function beforeUpload(file) {
  const isJPG = file.type === 'image/jpeg';
  if (!isJPG) {
    message.error('You can only upload JPG file!');
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error('Image must smaller than 2MB!');
  }
  return isJPG && isLt2M;
}

@Form.create()
@connect(({ exchange }) => ({
  exchange
}))
export default class CurrencyConfigEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      uploadUrl: '/api/v1/upload/upload',
      loading: false,
      imgUrl: ''
    };
  }

  componentDidMount() {
    // this.getBankConfig()
  }
  // getBankConfig() {
  //   this.props.dispatch({
  //     type: 'exchange/getBankConfigAll',
  //     payload: {
  //     },
  //   });
  // }

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      var data = {
        id: values.id,
        name: values.name,
        type: Number(values.type),
        benchmark_icon: values.benchmark_icon,
        icon: this.state.imgUrl
      };
      if (!err) {
        this.props.dispatch({
          type: 'exchange/editCurrencyConfig',
          payload: {
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('修改成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  // handleChange = ({ fileList }) => this.setState({ fileList })
  beforeUpload = file => {
    // const isJPG = file.type === 'image/jpeg'
    // if (!isJPG) {
    //   message.error('You can only upload JPG file!')
    // }
    // const isLt2M = file.size / 1024 / 1024 < 2
    // if (!isLt2M) {
    //   message.error('Image must smaller than 2MB!')
    // }
    // return isJPG && isLt2M
    return true;
  };

  handleChange = ({ file }) => {
    if (file.status === 'uploading') {
      this.setState({ loading: true });
      return;
    }
    if (file.status === 'done') {
      // Get this url from response in real world.
      if (file.response.code === 200) {
        const imgUrl = file.response.data;
        this.setState(
          {
            imgUrl: imgUrl,
            loading: false
          }
          // () => {
          //   this.props.onChange(imgUrl)
          // }
        );
      }
      // getBase64(file.originFileObj, imgUrl =>
      //   this.setState(
      //     {
      //       imgUrl,
      //       loading: false
      //     },
      //     () => {
      //       this.props.onChange(imgUrl)
      //     }
      //   )
      // )
    }
  };

  handlePreview = file => {
    this.setState({
      previewImage: file.url || file.thumbUrl,
      previewVisible: true
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;

    const info = this.props.exchange.editCurrencyConfig;
    // this.state.imgUrl = info.icon
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    // const imageUrl = this.state.imageUrl;
    const uploadButton = (
      <div>
        <Icon type={this.state.loading ? 'loading' : 'plus'} />
        <div className="ant-upload-text">Upload</div>
      </div>
    );
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="Id">
          {getFieldDecorator('id', {
            initialValue: info.id
            // rules: [
            //   {
            //     required: true,
            //     message: '请填写货币名称!',
            //     writespace: true
            //   },
            // ]
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="货币名称">
          {getFieldDecorator('name', {
            initialValue: info.name,
            rules: [
              {
                required: true,
                message: '请填写货币名称!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="货币类型">
          {getFieldDecorator('type', {
            initialValue: info.type
            // rules: [
            //   {
            //     required: true,
            //     message: '请输入货币类型!',
            //     writespace: true
            //   }
            // ]
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="货币图标">
          <Upload
            {...this.props}
            name="file"
            listType="picture-card"
            className="avatar-uploader"
            showUploadList={false}
            action={this.state.uploadUrl}
            beforeUpload={this.beforeUpload}
            onChange={this.handleChange}
            onPreview={this.handlePreview}
          >
            {this.state.imgUrl ? (
              <img
                src={this.state.imgUrl}
                alt="avatar"
                style={{ width: '100px', height: '100px' }}
              />
            ) : (
              <img
                src={info.icon}
                alt="avatar"
                style={{ width: '100px', height: '100px' }}
              />
            )}
          </Upload>
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            修改
          </Button>
        </FormItem>
      </Form>
    );
  }
}
