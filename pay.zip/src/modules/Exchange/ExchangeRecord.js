import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm,
  Divider,
  Checkbox
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import SwitchConfirm from '@/components/SwitchConfirm';
import PreviewImg from '@/components/PreviewImg';
import ExchangeRecordEdit from './ExchangeRecordEdit';
import ExchangeRecordView from './ExchangeRecordView';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ exchange, global, loading }) => ({
  exchange,
  global,
  loading: loading.effects['exchange/getExchangeRecord']
}))
export default class ExchangeRecord extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        0: '审核中',
        1: '已通过',
        2: '未通过'
      },
      merchantMap: {
        0: '签约商户',
        1: '平台商户'
      },
      isEdit: false,
      isView: false,
      isTransfer: false,
      columns: [
        {
          isExpand: true,
          title: 'Id',
          dataIndex: 'id',
          width: 80,
          fixed: 'left'
        },
        {
          isExpand: true,
          title: '商户id',
          dataIndex: 'ach_id',
          width: 80,
          fixed: 'left'
        },
        {
          isExpand: true,
          title: '基准货币',
          dataIndex: 'benchmark_currency',
          width: 80,
          fixed: 'left'
        },
        {
          isExpand: true,
          title: '外币名称',
          dataIndex: 'foreign_currency',
          width: 80,
          fixed: 'left'
        },
        {
          isExpand: true,
          title: '基准货币需兑换的金额',
          dataIndex: 'exchange_amount',
          width: 80,
          fixed: 'left'
        },
        {
          isExpand: true,
          title: '手续费',
          dataIndex: 'poundage',
          width: 80,
          fixed: 'left'
        },
        {
          isExpand: true,
          title: '真实可兑换金额',
          dataIndex: 'real_amount',
          width: 80,
          fixed: 'left'
        },
        {
          title: '按汇率转换后的金额',
          dataIndex: 'conversion_amount',
          width: 80,
          fixed: 'left'
        },
        {
          isExpand: true,
          title: '费率',
          dataIndex: 'poundage_rate'
        },
        {
          isExpand: true,
          title: '汇率',
          dataIndex: 'exchange_rate'
        },
        {
          isExpand: true,
          title: '收款银行名称',
          dataIndex: 'rb_name'
        },
        {
          isExpand: true,
          title: '收款银行卡号',
          dataIndex: 'rb_account'
        },
        {
          isExpand: true,
          title: '收款银行卡开户人',
          dataIndex: 'rb_open'
        },
        {
          isExpand: true,
          title: '回款银行名称',
          dataIndex: 'bank_name'
        },
        {
          isExpand: true,
          title: '回款银行卡号',
          dataIndex: 'card_no'
        },
        {
          isExpand: true,
          title: '回款银行卡开户人',
          dataIndex: 'card_owner'
        },
        {
          isExpand: true,
          title: '转账凭证',
          dataIndex: 'transfer_voucher',
          render: (text, record) => (
            <PreviewImg src={text} style={{ width: '80px', height: '50px' }} />
          )
        },
        {
          isExpand: true,
          title: '平台备注',
          dataIndex: 'plt_remark'
        },
        {
          isExpand: true,
          title: '商户备注',
          dataIndex: 'ach_remark'
        },
        // {
        //   isExpand: true,
        //   title: '停止收款时间',
        //   dataIndex: 'stop_unix',
        //   render: text => <span>{dateFormater(text)}</span>
        // },
        {
          isExpand: true,
          title: '创建时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '更新时间',
          dataIndex: 'updated',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'status',
          width: 80,
          fixed: 'right',
          render: text => (
            <span>
              {text === 1 && <span>审核中</span>}
              {text === 2 && <span style={{ color: 'green' }}>成功</span>}
              {text === 3 && <span style={{ color: 'red' }}>拒绝</span>}
            </span>
          )
        },
        {
          title: '查看',
          width: 80,
          fixed: 'right',
          render: (text, record) => {
            return (
              <span>
                <div>
                  <a onClick={() => this.view(record)} href="javascript:;">
                    查看
                  </a>
                </div>
              </span>
            );
          }
        },
        {
          title: '操作',
          width: 80,
          fixed: 'right',
          render: (text, record) => {
            return (
              <span>
                <div>
                  {record.status !== 1 ? (
                    <a style={{ color: '#ccc' }} href="javascript:;">
                      审核
                    </a>
                  ) : (
                    <a onClick={() => this.edit(record)} href="javascript:;">
                      审核
                    </a>
                  )}
                </div>
              </span>
            );
          }
        }
      ]
    };
  }
  componentDidMount() {
    // let arch_id = this.props.match.params.arch_id;
    // if (arch_id != 0) {
    //   this.props.form.setFieldsValue({ name: arch_id });
    // }
    this.getExchangeRecord();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getExchangeRecord(values);
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getExchangeRecord({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getExchangeRecord = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.merchant.cardManageInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }

        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'exchange/getExchangeRecord',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getExchangeRecord parameters error');
      }
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'exchange/exchangeRecordEdit',
      payload: {
        ...item
      }
    });
  };
  isView = bool => {
    this.setState({ isView: bool });
  };
  view = item => {
    this.isView(true);
    this.props.dispatch({
      type: 'exchange/exchangeRecordView',
      payload: {
        ...item
      }
    });
  };
  changeStatus = () => {
    this.isEdit(false);
    this.getExchangeRecord();
  };
  pass = item => {
    item.status = 1;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'merchant/getCardManagePass',
          payload: {
            id: Number(item.id),
            status: 1
          }
        });
      } else {
        console.log('getPass parameters error');
      }
    });
  };
  refuse = item => {
    item.status = 2;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'merchant/getCardManageRefuse',
          payload: {
            id: Number(item.id),
            status: 2
          }
        });
      } else {
        console.log('getRefuse parameters error');
      }
    });
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.exchange.getExchangeRecordInfo;

    return (
      <Card bordered={false} title="兑换记录">
        {this.state.isEdit && (
          <Modal
            title="编辑"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <ExchangeRecordEdit onClose={this.changeStatus} />
          </Modal>
        )}
        {this.state.isView && (
          <Modal
            title="编辑"
            visible={this.state.isView}
            onCancel={() => this.isView(false)}
            footer={null}
          >
            <ExchangeRecordView onClose={this.changeStatus} />
          </Modal>
        )}

        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={12} sm={24}>
                  <FormItem label="商户ID" className="form-inline-item">
                    {getFieldDecorator('ach_id', {
                      initialValue: this.props.match.params.account
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col md={12} sm={24}>
                  <FormItem label="审核状态" className="form-inline-item">
                    {getFieldDecorator('status', {
                      initialValue: '0'
                    })(
                      <RadioGroup>
                        <Radio value="0">全部</Radio>
                        <Radio value="1">审核中</Radio>
                        <Radio value="2">已通过</Radio>
                        <Radio value="3">已拒绝</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                {/* <Col md={12} sm={24}>
                  <FormItem label="条件" className="form-inline-item">
                    {getFieldDecorator('type', {
                      initialValue: ''
                    })(
                      <RadioGroup>
                        <Radio value="">全部</Radio>
                        <Radio value="1">将要到期</Radio>
                        <Radio value="2">将要到上限</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col> */}
                {/* <Col md={8} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="button">
                      将要到期
                    </Button>
                  </div>
                </Col>
                <Col md={8} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="button">
                      将要到上限
                    </Button>
                  </div>
                </Col> */}
                <Col md={8} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            scroll={{ x: 2300 }}
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
