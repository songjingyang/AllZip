import React from 'react';
import { Table, message, Form, Input, Select, Button, Radio } from 'antd';
import { connect } from 'dva';
import { dateFormater } from '@/utils/utils';
import PreviewImg from '@/components/PreviewImg';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

@Form.create()
@connect(({ exchange }) => ({
  exchange
}))
export default class ExchangeRecordEdit extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      var data = {
        id: values.id,
        status: Number(values.status),
        plt_remark: values.plt_remark
      };
      if (!err) {
        this.props.dispatch({
          type: 'exchange/editExchangeRecordStatus',
          payload: {
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('修改成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.exchange.exchangeRecordEdit;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="id">
          {getFieldDecorator('id', {
            initialValue: info.id
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="商户id">
          {getFieldDecorator('ach_id', {
            initialValue: info.ach_id
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="基准货币">
          {getFieldDecorator('benchmark_currency', {
            initialValue: info.benchmark_currency
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="外币名称">
          {getFieldDecorator('foreign_currency', {
            initialValue: info.foreign_currency
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="兑换金额">
          {getFieldDecorator('exchange_amount', {
            initialValue: info.exchange_amount
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="手续费">
          {getFieldDecorator('poundage', {
            initialValue: info.poundage
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="真实可兑换金额">
          {getFieldDecorator('real_amount', {
            initialValue: info.real_amount
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="转换后的金额">
          {getFieldDecorator('conversion_amount', {
            initialValue: info.conversion_amount
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="费率">
          {getFieldDecorator('poundage_rate', {
            initialValue: info.poundage_rate
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="汇率">
          {getFieldDecorator('exchange_rate', {
            initialValue: info.exchange_rate
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="收款银行名称">
          {getFieldDecorator('bank_name', {
            initialValue: info.bank_name
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="收款银行卡号">
          {getFieldDecorator('card_no', {
            initialValue: info.card_no
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="收款银行开户人">
          {getFieldDecorator('card_owner', {
            initialValue: info.card_owner
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="回款银行名称">
          {getFieldDecorator('rb_name', {
            initialValue: info.rb_name
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="回款银行卡号">
          {getFieldDecorator('rb_account', {
            initialValue: info.rb_account
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="回款银行开户人">
          {getFieldDecorator('rb_open', {
            initialValue: info.rb_open
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="转账凭证">
          <PreviewImg
            src={info.transfer_voucher}
            alt="avatar"
            style={{ width: '100px', height: '100px' }}
          />
        </FormItem>
        <FormItem {...formItemLayout} label="申请时间">
          {getFieldDecorator('created', {
            initialValue: dateFormater(info.created)
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="商户备注">
          {getFieldDecorator('ach_remark', {
            initialValue: info.ach_remark
          })(<TextArea disabled />)}
        </FormItem>
        <FormItem {...formItemLayout} label="平台备注">
          {getFieldDecorator('plt_remark', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入备注，最多100个字符',
                whitespace: true
              },
              {
                validator: (rule, value, callback) => {
                  if (value && value.length > 100) {
                    callback('最多100个字符');
                    return;
                  }

                  callback();
                }
              }
            ]
          })(<TextArea />)}
        </FormItem>

        <FormItem {...formItemLayout} label="状态">
          {getFieldDecorator('status', {
            initialValue: String(info.status),
            rules: [
              {
                required: true,
                message: '请选择状态'
                // whitespace: true
              }
            ]
          })(
            <RadioGroup>
              <Radio value="2">通过</Radio>
              <Radio value="3">拒绝</Radio>
            </RadioGroup>
          )}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
