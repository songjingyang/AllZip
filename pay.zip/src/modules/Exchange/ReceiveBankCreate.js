import React from 'react';
import { Table, message, Form, Input, Select, Button, Radio } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

@Form.create()
@connect(({ exchange }) => ({
  exchange
}))
export default class ReceiveBankCreate extends React.Component {
  componentDidMount() {
    this.getBankConfig()
    
  }
  getBankConfig() {
    this.props.dispatch({
      type: 'exchange/getBankConfigAll',
      payload: {
      },
    });
  }

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      var data = {
        id: values.id,
        amount: Number(values.amount),
        status: Number(values.status),
        score: Number(values.score),
        remark: values.remark,
        account: values.account,
        open: values.open,
        type: Number(values.type),
        
      };
      if (!err) {
        this.props.dispatch({
          type: 'exchange/createReceiveBank',
          payload: {
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('创建成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    
    // const bankList = this.props.exchange.getBankConfigAllInfo.list;
    
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="汇款的额度">
          {getFieldDecorator('amount', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请填写汇款的额度!',
                writespace: true
              },
              {
                validator: (rule, value, callback) => {
                  if (value && Number.isNaN(+value)) {
                    callback('只能输入整数')
                    return
                  }
                  if (value.includes('.')) {
                    callback('只能输入整数')
                    return
                  }
                  callback()
                }
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        {/* <FormItem {...formItemLayout} label="已收额度">
          {getFieldDecorator('use_amount', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请填写已收额度!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem> */}
        <FormItem {...formItemLayout} label="开户人">
          {getFieldDecorator('open', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入开户人!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>          
        <FormItem style={{marginBottom: 10}} {...formItemLayout} label='银行'>
            {getFieldDecorator('type', {
              initialValue: '',
              rules: [
                {
                  required: true,
                  message: '请选择银行'
                  // whitespace: true
                }
              ]
            })(
              <Select placeholder='请选择银行' onChange={this.onChangeBank}>
                {this.props.exchange.getBankConfigAllInfo.list.map(item => (
                  <Option value={item.type}>{item.name}</Option>
                ))}
              </Select>
            )}
        </FormItem>
        <FormItem {...formItemLayout} label="收款账号">
          {getFieldDecorator('account', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入收款账号!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        {/* <FormItem {...formItemLayout} label="账号类型">
          {getFieldDecorator('type', {
            initialValue: '',
            // rules: [
            //   {
            //     required: true,
            //     message: '请输入账号类型!',
            //     writespace: true
            //   }
            // ]
          })(<Input type="type" />)}
        </FormItem> */}
        <FormItem {...formItemLayout} label="排序">
          {getFieldDecorator('score', {
            initialValue: '',
            // rules: [
            //   {
            //     required: true,
            //     message: '查询url!',
            //     writespace: true
            //   }
            // ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="是否展示">
          {getFieldDecorator('status', {
            initialValue: '1',
            rules: [
              {
                required: true,
                message: '请选择状态'
                // whitespace: true
              }
            ]
          })(
            <RadioGroup>
              <Radio value="1">展示</Radio>
              <Radio value="2">不展示</Radio>
            </RadioGroup>
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="备注">
          {getFieldDecorator('remark', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入备注'
                // whitespace: true
              }
            ]
          })(<TextArea rows={5} />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            创建
          </Button>
        </FormItem>
      </Form>
    );
  }
}
