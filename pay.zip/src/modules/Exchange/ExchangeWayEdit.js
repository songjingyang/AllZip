import React from 'react';
import {
  Table,
  message,
  Form,
  Input,
  Select,
  Button,
  Radio,
  DatePicker
} from 'antd';
import { connect } from 'dva';
import { dateFormater, getTimeDistance } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;
function onChange(value, dateString) {
  console.log('Selected Time: ', value);
  console.log('Formatted Selected Time: ', dateString);
}

function onOk(value) {
  console.log('onOk: ', value);
}

@Form.create()
@connect(({ exchange }) => ({
  exchange
}))
export default class ExchangeWayEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      benchmark_icon: '',
      foreign_icon: ''
    };
  }
  componentDidMount() {
    this.getCurrencyConfigList();
  }
  getCurrencyConfigList() {
    this.props.dispatch({
      type: 'exchange/getCurrencyConfigList',
      payload: {}
    });
  }

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      var benchmark_icon = '';
      if (this.state.benchmark_icon) {
        benchmark_icon = this.state.benchmark_icon;
      } else {
        benchmark_icon = this.props.exchange.editReceiveWay.benchmark_ico;
      }
      var foreign_icon = '';
      if (this.state.foreign_icon) {
        foreign_icon = this.state.foreign_icon;
      } else {
        foreign_icon = this.props.exchange.editReceiveWay.foreign_icon;
      }
      var data = {
        //       BenchmarkCurrency string `json:"benchmark_currency"` // 基准货币
        // ForeignCurrency   string `json:"foreign_currency"`   // 外币名称
        // BenchmarkIcon     string `json:"benchmark_icon"`     // 基准货币图标
        // ForeignIcon       string `json:"foreign_icon"`       // 外币图标
        // ExchangeRate      int    `json:"exchange_rate"`      // 汇率
        // PoundageRate      int    `json:"poundage_rate"`      // 费率
        // BeginTm           int    `json:"begin_tm"`           // 开始时间
        // EndTm             int    `json:"end_tm"`             // 结束时间
        // Status            int    `json:"status"`             // 状态  1 有效 2 无效
        id: values.id,
        benchmark_currency: values.benchmark_currency,
        foreign_currency: values.foreign_currency,
        benchmark_icon: benchmark_icon,
        foreign_icon: foreign_icon,
        exchange_rate: parseInt(values.exchange_rate * 100),
        poundage_rate: parseInt(values.poundage_rate * 100),
        // payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
        // payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
        begin_tm: parseInt(values.timeRange[0].valueOf() / 1000),
        end_tm: parseInt(values.timeRange[1].valueOf() / 1000),
        status: Number(values.status)
      };
      if (!err) {
        this.props.dispatch({
          type: 'exchange/editExchangeWay',
          payload: {
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('修改成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  onChangeForeignCurrency(icon) {
    this.state.foreign_icon = icon;
  }
  onChangeBenchmarkCurrency(icon) {
    this.state.benchmark_icon = icon;
  }

  render() {
    const { getFieldDecorator } = this.props.form;

    // const bankList = this.props.exchange.getBankConfigAllInfo.list;
    const info = this.props.exchange.editReceiveWay;

    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="ID">
          {getFieldDecorator('id', {
            initialValue: info.id,
            rules: [
              // {
              //   required: true,
              //   message: '!',
              //   writespace: true
              // },
              // {
              //   validator: (rule, value, callback) => {
              //     if (value && Number.isNaN(+value)) {
              //       callback('只能输入整数')
              //       return
              //     }
              //     if (value.includes('.')) {
              //       callback('只能输入整数')
              //       return
              //     }
              //     callback()
              //   }
              // }
            ]
          })(<Input disabled type="type" />)}
        </FormItem>
        <FormItem
          style={{ marginBottom: 10 }}
          {...formItemLayout}
          label="基准货币"
        >
          {getFieldDecorator('benchmark_currency', {
            initialValue: info.benchmark_currency,
            rules: [
              {
                required: true,
                message: '请选择基准货币!'
                // whitespace: true
              }
            ]
          })(
            <Select placeholder="请选择基准货币" onChange={this.onChangeBank}>
              {this.props.exchange.getCurrencyConfigListInfo.list.map(item => (
                <Option
                  value={item.name}
                  onClick={() => this.onChangeBenchmarkCurrency(item.icon)}
                >
                  {item.name}
                </Option>
              ))}
            </Select>
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="基准货币图标">
          <img
            src={
              this.state.benchmark_icon
                ? this.state.benchmark_icon
                : info.benchmark_icon
            }
            alt=""
            style={{ width: '100px', height: '100px' }}
          />
        </FormItem>
        <FormItem
          style={{ marginBottom: 10 }}
          {...formItemLayout}
          label="外币名称"
        >
          {getFieldDecorator('foreign_currency', {
            initialValue: info.foreign_currency,
            rules: [
              {
                required: true,
                message: '请选择外币名称!'
                // whitespace: true
              }
            ]
          })(
            <Select placeholder="请选择外币名称" onChange={this.onChange}>
              {this.props.exchange.getCurrencyConfigListInfo.list.map(item => (
                <Option
                  value={item.name}
                  onClick={() => this.onChangeForeignCurrency(item.icon)}
                >
                  {item.name}
                </Option>
              ))}
            </Select>
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="外币图标">
          <img
            src={
              this.state.foreign_icon
                ? this.state.foreign_icon
                : info.foreign_icon
            }
            alt=""
            style={{ width: '100px', height: '100px' }}
          />
        </FormItem>
        <FormItem {...formItemLayout} label="汇率">
          {getFieldDecorator('exchange_rate', {
            initialValue: info.exchange_rate,
            rules: [
              {
                required: true,
                message: '请输入汇率!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="费率">
          {getFieldDecorator('poundage_rate', {
            initialValue: info.poundage_rate,
            rules: [
              {
                required: true,
                message: '请输入外币图标!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="时间范围">
          {getFieldDecorator('timeRange', {
            initialValue: getTimeDistance('today'),
            rules: [
              // {
              //   required: true,
              //   message: '请输入时间范围!',
              //   writespace: true
              // },
              {
                validator: (rule, value, callback) => {
                  let startTm;
                  let endTm;

                  if (value.length !== 0) {
                    startTm = parseInt(value[0].valueOf() / 1000);
                    endTm = parseInt(value[1].valueOf() / 1000);
                    if (endTm - startTm > 90 * 24 * 3600) {
                      callback('最大范围 3个月');
                    }
                  } else {
                    startTm = 0;
                    endTm = 0;
                  }
                  if (startTm === 0 || endTm === 0) {
                    callback('请输入时间范围');
                  }
                  callback();
                }
              }
            ]
          })(
            <RangePicker
              disabledDate={this.disabledDate}
              showTime
              format="YYYY-MM-DD HH:mm:ss"
            />
          )}
        </FormItem>

        {/* <FormItem {...formItemLayout} label="开始时间">
          {getFieldDecorator('begin_tm', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入开始时间!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="结束时间">
          {getFieldDecorator('end_tm', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入结束时间!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem> */}
        <FormItem {...formItemLayout} label="状态">
          {getFieldDecorator('status', {
            initialValue: String(info.status),
            rules: [
              {
                required: true,
                message: '请选择状态'
                // whitespace: true
              }
            ]
          })(
            <RadioGroup>
              <Radio value="1">有效</Radio>
              <Radio value="2">无效</Radio>
            </RadioGroup>
          )}
        </FormItem>
        {/* <FormItem {...formItemLayout} label="备注">
          {getFieldDecorator('remark', {
            initialValue: info.remark,
            rules: [
              {
                required: true,
                message: '请输入备注'
                // whitespace: true
              }
            ]
          })(<TextArea rows={5} />)}
        </FormItem> */}
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            创建
          </Button>
        </FormItem>
      </Form>
    );
  }
}
