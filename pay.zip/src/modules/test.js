import React from 'react'

const Products = props => <h2>List of Products</h2>

export default Products
