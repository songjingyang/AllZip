import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import { Link } from 'dva/router';
import ProxyPreduceAllEdit from './ProxyPreduceAllEdit';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ proxy, global, loading }) => ({
  proxy,
  global,
  loading: loading.effects['proxy/getProxyPreduceAll']
}))
export default class ProxyPreduceAll extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        1: '未处理',
        2: '已处理',
        '-1': '未通过'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          isExpand: true,
          title: 'ID',
          dataIndex: 'id'
        },
        {
          title: '代理账户',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '代理名称',
          dataIndex: 'proxy_name'
        },
        {
          title: '金额',
          dataIndex: 'amount'
        },
        {
          isExpand: true,
          title: '打款状态',
          dataIndex: 'status',
          render: (text, record) => <span>{this.state.statusMap[text]}</span>
        },
        {
          isExpand: true,
          title: '申请时间',
          dataIndex: 'created',
          render: text => {
            return <span>{dateFormater(text)}</span>;
          }
        },
        {
          isExpand: true,
          title: '操作时间',
          dataIndex: 'updated',
          render: text => {
            return <span>{dateFormater(text)}</span>;
          }
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: 'edit',
          render: (text, record) => {
            return (
              <span>
                {record.status === 2 && (
                  <span style={{ color: 'green' }}>已通过</span>
                )}
                {record.status === -1 && (
                  <span style={{ color: 'red' }}>未通过</span>
                )}
                {record.status === 1 && (
                  <div>
                    <Popconfirm
                      title="确定吗？"
                      onConfirm={() => this.pass(record)}
                    >
                      <a href="javascript:;">通过</a>
                    </Popconfirm>
                    <Divider type="vertical" />
                    <Popconfirm
                      title="确定吗？"
                      onConfirm={() => this.refuse(record)}
                    >
                      <a href="javascript:;">拒绝</a>
                    </Popconfirm>
                  </div>
                )}
              </span>
            );
          }
        }
      ]
    };
  }
  componentDidMount() {
    this.getProxyPreduceAll();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getProxyPreduceAll(values);
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getProxyPreduceAll({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  getProxyPreduceAll = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.proxy.proxyPreduceAll.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }

        payload = { ...payload, ...params };

        this.props.dispatch({
          type: 'proxy/getProxyPreduceAll',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getProxyPreduceAll parameters error');
      }
    });
  };
  pass = item => {
    item.status = 2;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'proxy/getProxyPreducePass',
          payload: {
            id: Number(item.id),
            status: 2
          }
        });
      } else {
        console.log('getPass parameters error');
      }
    });
  };
  refuse = item => {
    // this.props.dispatch({
    //   type: 'proxy/deleteProxyPreduceAudit',
    //   payload: {
    //       ...item
    //   }
    // })
    item.status = -1;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'proxy/getProxyPreduceRefuse',
          payload: {
            id: Number(item.id),
            account: item.account,
            amount: item.amounts,
            status: -1
          }
        });
      } else {
        console.log('getRefuse parameters error');
      }
    });
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.proxy.proxyPreduceAll;

    return (
      <Card bordered={false} title="代理降额申请">
        <div className={'tableList'}>
          {this.state.isEdit && (
            <Modal
              title="编辑"
              visible={this.state.isEdit}
              onCancel={() => this.isEdit(false)}
              footer={null}
            >
              <ProxyPreduceAllEdit onClose={this.addproxyPreduceAll} />
            </Modal>
          )}
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="代理账户" className="form-inline-item">
                    {getFieldDecorator('account', {
                      initialValue: this.props.match.params.account
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="审核状态" className="form-inline-item">
                    {getFieldDecorator('status', {
                      initialValue: ''
                    })(
                      <RadioGroup>
                        <Radio value="">全部</Radio>
                        <Radio value="1">未处理</Radio>
                        <Radio value="2">已通过</Radio>
                        <Radio value="-1">未通过</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="代理名称" className="form-inline-item">
                    {getFieldDecorator('name')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
