import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import ProfitFlowEdit from './ProfitFlowEdit';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ proxy, global, loading }) => ({
  proxy,
  global,
  loading: loading.effects['proxy/getProxyOperateList']
}))
export default class ProxyOperateList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isDetail: false,
      divideMap: {
        1: '总代',
        2: '一级代理',
        3: '三级代理'
      },
      columns: [
        {
          isExpand: true,
          title: 'ID',
          dataIndex: 'id'
        },
        {
          title: '代理账户',
          dataIndex: 'proxy_id',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.proxy_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '代理名称',
          dataIndex: 'proxy_name'
        },
        {
          isExpand: true,
          title: '操作额度',
          dataIndex: 'amount'
        },
        {
          isExpand: true,
          title: '备注',
          dataIndex: 'content'
        },
        {
          isExpand: true,
          title: '操作人',
          dataIndex: 'operate_name'
        },
        {
          isExpand: true,
          title: '操作时间',
          dataIndex: 'operate_time',
          render: text => <span>{dateFormater(text)}</span>
        },
      ]
    };
  }
  componentDidMount() {
    this.getProxyOperateList();
  }
  getProxyOperateList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          // params.ts = this.props.proxy.profitFlow.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'proxy/getProxyOperateList',
          payload: {
            ...payload
          },
          callback: params.callback
        });
      } else {
        console.log('getProxyIncome err');
      }
    });
  };
  handleLast1Hours = () => {
    this.props.form.setFieldsValue({
      timeRange: [
        moment(new Date().getTime() - 3600000),
        moment(new Date().getTime())
      ]
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getProxyOperateList(values);
      }
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getProxyOperateList(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getProxyOperateList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  isDetail = bool => {
    this.setState({ isDetail: bool });
  };
  detail = item => {
    this.isDetail(true);
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'proxy/getProxyOperateListEdit',
          payload: {
            order_id: item.order_id
          }
        });
      } else {
        console.log('getProxyOperateListEdit parameters error');
      }
    });
  };
  addProfitFlow = () => {
    this.isDetail(false);
    // this.getProxyOperateList()
  };
  //时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.proxy.getProxyOperateListInfo;
    return (
      <Card bordered={false} title="收益流水">
        {this.state.isDetail && (
          <Modal
            title="详情"
            width={600}
            visible={this.state.isDetail}
            onCancel={() => this.isDetail(false)}
            footer={null}
          >
            <ProfitFlowEdit onClose={this.addProfitFlow} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
             
            </Form>
          </div>
        </div>
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
