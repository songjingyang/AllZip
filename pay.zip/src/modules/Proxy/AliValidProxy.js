import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm,
  Divider
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import { routerRedux } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import ProfitFlowEdit from './ProfitFlowEdit';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ proxy, global, loading }) => ({
  proxy,
  global,
  loading: loading.effects['proxy/getAliValidProxyList']
}))
export default class AliValidProxy extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isDetail: false,
      divideMap: {
        1: '总代',
        2: '一级代理',
        3: '三级代理'
      },
      columns: [
        // {
        //   isExpand: true,
        //   title: 'ID',
        //   dataIndex: 'id'
        // },
        {
          title: '代理账户',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '代理名称',
          dataIndex: 'username'
        },
        // {
        //   isExpand: true,
        //   title: '连续未成交次数',
        //   dataIndex: 'count'
        // }
      ]
    };
  }
  componentDidMount() {
    this.getAliValidProxyList();
  }
  getAliValidProxyList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          // params.ts = this.props.proxy.profitFlow.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'proxy/getAliValidProxyList',
          payload: {
            ...payload
          },
          callback: params.callback
        });
      } else {
        console.log('getProxyIncome err');
      }
    });
  };
  handleLast1Hours = () => {
    this.props.form.setFieldsValue({
      timeRange: [
        moment(new Date().getTime() - 3600000),
        moment(new Date().getTime())
      ]
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getAliValidProxyList(values);
      }
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getAliValidProxyList(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getAliValidProxyList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  isDetail = bool => {
    this.setState({ isDetail: bool });
  };
  detail = item => {
    this.isDetail(true);
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'proxy/getAliValidProxyListEdit',
          payload: {
            order_id: item.order_id
          }
        });
      } else {
        console.log('getAliValidProxyListEdit parameters error');
      }
    });
  };
  addProfitFlow = () => {
    this.isDetail(false);
    // this.getAliValidProxyList()
  };
  //时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  freezeType = type => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        values.account = type.account;
        values.qr_type = 100;
        values.state = 1;
        this.props.dispatch({
          type: 'proxy/freezeType',
          payload: {
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('操作成功');
              this.state.pagination.current = 1;
              this.getAliValidProxyList();
            }
          }
        });
      }
    });
  };
  unfreezeType = type => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        values.account = type.account;
        values.qr_type = 100;
        values.state = 0;
        this.props.dispatch({
          type: 'proxy/freezeType',
          payload: {
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('操作成功');
              this.state.pagination.current = 1;
              this.getAliValidProxyList();
            }
          }
        });
      }
    });
  };
  proxy_order_num = item => {
    this.props.dispatch(routerRedux.push('/proxy/ProxyOrderNum'));
  };
  risk_control = item => {
    this.props.dispatch(routerRedux.push('/proxy/RiskControl'));
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.proxy.getAliValidProxyListInfo;
    return (
      <Card bordered={false} title="支付宝可用代理">
        {/* <Button type="primary" onClick={() => this.proxy_order_num()}>
          今日支付宝订单数量
        </Button> */}
        {/* <Button type="primary" onClick={() => this.proxy_order_num()}>
          今日支付宝订单数量
        </Button> */}
        <div style={{textAlign: 'right'}}>
          <a onClick={() => this.proxy_order_num()}>今日支付宝订单数量</a>
          &nbsp;&nbsp;&nbsp;
          <a onClick={() => this.risk_control()}>代理连续未成交</a>
        </div>
        {/* <Button type="primary" onClick={() => this.risk_control()}>
          代理连续未成交
        </Button> */}
        {this.state.isDetail && (
          <Modal
            title="详情"
            width={600}
            visible={this.state.isDetail}
            onCancel={() => this.isDetail(false)}
            footer={null}
          >
            <ProfitFlowEdit onClose={this.addProfitFlow} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit} />
          </div>
        </div>
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
