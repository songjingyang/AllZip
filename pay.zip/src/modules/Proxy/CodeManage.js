import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message
} from 'antd'
import { connect } from 'dva'
import classNames from 'classnames'
import { dateFormater } from '@/utils/utils'
import UploadImg from '@/components/UploadImg'
import PreviewImg from '@/components/PreviewImg'
import SimpleTable from '@/components/SimpleTable'
import CodeManageEdit from './CodeManageEdit'

const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const RangePicker = DatePicker.RangePicker

@Form.create()
@connect(({ proxy, global, loading }) => ({
  proxy,
  global,
  loading: loading.effects['proxy/getCodeManage']
}))
export default class CodeManage extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isEdit: false,
      statusMap: {
        0: '未审核',
        1: '已通过'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          isExpand: true,
          title: '流水id',
          dataIndex: 'flowId'
        },
        {
          title: '代理账户',
          dataIndex: 'proxyAccout'
        },
        {
          isExpand: true,
          title: '支付类型',
          dataIndex: 'payType',
          render: (text, record) => (
            <span>{this.state.payMap[record.payType]}</span>
          )
        },
        {
          isExpand: true,
          title: '支付账号',
          dataIndex: 'payAccout'
        },
        {
          title: '支付昵称',
          dataIndex: 'payName'
        },
        {
          isExpand: true,
          title: '支付连接',
          dataIndex: 'payImg',
          render: (text, record) => (
            <PreviewImg src={text} style={{ height: '100px' }} />
          )
        },
        {
          title: '支付金额',
          dataIndex: 'price'
        },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'status',
          render: (text, record) => (
            <span>{this.state.statusMap[record.status]}</span>
          )
        },
        {
          isExpand: true,
          title: '创建时间',
          dataIndex: 'createAt'
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: 'name',
          render: (text, record) => (
            <a onClick={() => this.edit(record)} href='javascript:;'>操作</a>
          )
        }
      ]
    }
  }
  componentDidMount () {
    this.getCodeManage()
  }
  handleChangeDate = date => {}
  handleSubmit = e => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getCodeManage(values)
      }
    })
  }

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination }
    pager.current = pagination.current
    this.setState({
      pagination: pager
    })
    this.getCodeManage({
      pageSize: pagination.pageSize,
      page: pagination.current
    })
  }

  getCodeManage = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values }

        if (!params.page) {
          params.page = 1
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000
        } else {
          params.ts = this.props.proxy.codeManage.ts
        }
        if (!params.pageSize) {
          params.pageSize = 20
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000)
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000)
        }

        payload = { ...payload, ...params }

        this.props.dispatch({
          type: 'proxy/getCodeManage',
          payload: {
            ...payload
          }
        })
      } else {
        console.log('get order list parameters error')
      }
    })
  }

  isEdit = bool => {
    this.setState({ isEdit: bool })
  }
  edit = item => {
    this.isEdit(true)
    this.props.dispatch({
      type: 'proxy/codeManageEdit',
      payload: { ...item }
    })
  }
  addCodeManage = () => {
    this.isEdit(false)
    this.getCodeManage()
  }

  render () {
    const global = this.props.global
    const { getFieldDecorator } = this.props.form
    const info = this.props.proxy.codeManage

    return (
      <Card bordered={false}>
        <div className={'tableList'}>
          { 
            this.state.isEdit && 
            <Modal
                title='编辑'
                visible = { this.state.isEdit }
                onCancel = { () => this.isEdit(false) }
                footer = { null }
            >
                <CodeManageEdit onClose={this.addCodeManage} />
            </Modal>
          }
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={8} md={12} sm={12}>
                  <FormItem label='代理账户' className='form-inline-item'>
                    {getFieldDecorator('proxyAccout')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={8} md={12} sm={12}>
                  <FormItem label='支付类型' className='form-inline-item'>
                    {getFieldDecorator('payType')(
                      <RadioGroup>
                        <Radio value=''>全部</Radio>
                        <Radio value='100'>支付宝</Radio>
                        <Radio value='200'>微信</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={8} md={12} sm={12}>
                  <FormItem label='审核状态' className='form-inline-item'>
                    {getFieldDecorator('status')(
                      <RadioGroup>
                        <Radio value=''>全部</Radio>
                        <Radio value='0'>未审核</Radio>
                        <Radio value='1'>已通过</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type='primary' htmlType='submit'>查询</Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          {/* <div className={'tableListOperator'}>
          <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
            新建
          </Button>
        </div> */}

          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    )
  }
}
