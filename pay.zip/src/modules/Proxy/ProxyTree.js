import React from 'react'
import { routerRedux } from 'dva/router'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  message,
  Divider,
  Tree,
  Popconfirm,
  Modal,
} from 'antd'
import { connect } from 'dva'
import classNames from 'classnames'
import { dateFormater } from '@/utils/utils'
import PreviewImg from '@/components/PreviewImg'
import DescriptionList from '@/components/DescriptionList'
import './ProxyTree.css'
import { Link } from 'dva/router'
import ProxyTreeEditPass from './ProxyTreeEditPass'

const { Description } = DescriptionList
const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const RangePicker = DatePicker.RangePicker
const TreeNode = Tree.TreeNode

@Form.create()
@connect(({ proxy, global, loading }) => ({
  proxy,
  global,
  // loading: loading.effects['proxy/getProxyTreeList']
}))
export default class ProxyTree extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isReset: false,
      IsStopAlipay: '',
      IsStopWxPay: '',
      levelMap: {
        1: '总代',
        2: '一级代理',
        3: '二级代理',
      },
      expandedKeys: [],
      autoExpandParent: true,
      selectedKeys: [],
      treeData: [
        {
          title: '0-0',
          key: '0-0',
          children: [
            {
              title: '0-0-0',
              key: '0-0-0',
              children: [
                { title: '0-0-0-0', key: '0-0-0-0' },
                { title: '0-0-0-1', key: '0-0-0-1' },
                { title: '0-0-0-2', key: '0-0-0-2' },
              ],
            },
            {
              title: '0-0-1',
              key: '0-0-1',
              children: [
                { title: '0-0-1-0', key: '0-0-1-0' },
                { title: '0-0-1-1', key: '0-0-1-1' },
                { title: '0-0-1-2', key: '0-0-1-2' },
              ],
            },
            {
              title: '0-0-2',
              key: '0-0-2',
            },
          ],
        },
        {
          title: '0-1',
          key: '0-1',
          children: [
            { title: '0-1-0-0', key: '0-1-0-0' },
            { title: '0-1-0-1', key: '0-1-0-1' },
            { title: '0-1-0-2', key: '0-1-0-2' },
          ],
        },
        {
          title: '0-2',
          key: '0-2',
        },
      ],
    }
  }
  componentDidMount() {
    this.getProxyTreeList()
    this.getProxyAccountInfo()
    this.setState({
      expandedKeys: [this.props.match.params.account],
      autoExpandParent: true,
    })
  }
  getProxyTreeList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values }

        if (!params.page) {
          params.page = 1
        }
        if (!params.pageSize) {
          params.pageSize = 20
        }
        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000)
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000)
        }
        payload = { ...payload, ...params }
        payload.account = this.props.match.params.account
        this.props.dispatch({
          type: 'proxy/getProxyTreeList',
          payload: {
            ...payload,
          },
        })
      } else {
        console.log('getProxyTreeList parameters error')
      }
    })
  }
  getProxyAccountInfo = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values }

        if (!params.page) {
          params.page = 1
        }
        if (!params.pageSize) {
          params.pageSize = 20
        }
        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000)
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000)
        }
        payload = { ...payload, ...params }
        payload.account = this.props.match.params.account
        this.props.dispatch({
          type: 'proxy/getProxyAccountInfo',
          payload: {
            ...payload,
          },
        })
      } else {
        console.log('getProxyAccountInfo parameters error')
      }
    })
  }
  onExpand = (expandedKeys, info) => {
    // console.log('onExpand', expandedKeys)
    this.setState({
      expandedKeys,
      autoExpandParent: false,
    })
  }
  onSelect = (selectedKeys, info) => {
    this.setState({ selectedKeys })
    this.props.form.validateFields((err, values) => {
      if (!err) {
        if (info.selectedNodes.length !== 0) {
          values.account = String(info.selectedNodes[0].props.dataRef.account)
          this.props.dispatch(
            routerRedux.push(`/proxy/proxyTree/${values.account}`)
          )
          this.props.dispatch({
            type: 'proxy/getProxyAccountInfo',
            payload: {
              ...values,
            },
          })
        }
        return
      }
    })
  }
  renderTreeNodes = data => {
    return data.map(item => {
      console.log('item', item)
      if (item.children === null) item.children = []
      if (item.children) {
        return (
          <TreeNode
            title={`${item.name} ${item.account}（${
              this.state.levelMap[item.level]
            }）`}
            checkStrictly={false}
            key={item.account}
            dataRef={item}
            // disabled = {(item.status === 2 && item.level === 1) ? 'disabled' : ''}
            style={
              item.status === 2 && item.level === 1
                ? { background: '#fff' }
                : { background: '' }
            }
          >
            {this.renderTreeNodes(item.children)}
          </TreeNode>
        )
      }
      return <TreeNode {...item} />
    })
  }
  freezeType = type => {
    if (type === 'weixin') {
      this.props.form.validateFields((err, values) => {
        if (!err) {
          values.account = this.props.proxy.proxyAccountInfo.account
          values.qr_type = 200
          if (this.props.proxy.proxyAccountInfo.IsStopWxPay) {
            values.state = 0
            this.props.dispatch({
              type: 'proxy/freezeType',
              payload: { ...values },
              callback: res => {
                if (res.code === 200) {
                  message.success('操作成功')
                  this.getProxyAccountInfo()
                }
              },
            })
          } else {
            values.state = 1
            this.props.dispatch({
              type: 'proxy/freezeType',
              payload: { ...values },
              callback: res => {
                if (res.code === 200) {
                  message.success('操作成功')
                  this.getProxyAccountInfo()
                }
              },
            })
          }
        }
      })
    } else if (type === 'alipy') {
      this.props.form.validateFields((err, values) => {
        if (!err) {
          values.account = this.props.proxy.proxyAccountInfo.account
          values.qr_type = 100
          if (this.props.proxy.proxyAccountInfo.IsStopAlipay) {
            values.state = 0
            this.props.dispatch({
              type: 'proxy/freezeType',
              payload: {
                ...values,
              },
              callback: res => {
                if (res.code === 200) {
                  message.success('操作成功')
                  this.getProxyAccountInfo()
                }
              },
            })
          } else {
            values.state = 1
            this.props.dispatch({
              type: 'proxy/freezeType',
              payload: {
                ...values,
              },
              callback: res => {
                if (res.code === 200) {
                  message.success('操作成功')
                  this.getProxyAccountInfo()
                }
              },
            })
          }
        }
      })
    }
  }
  freezeProxy = type => {
    this.props.form.validateFields((err, values) => {
      this.props.dispatch({
        type: 'proxy/freezeProxy',
        payload: {
          account: this.props.proxy.proxyAccountInfo.account,
          status: 2,
        },
        callback: res => {
          if (res.code === 200) {
            message.success('操作成功')
            this.getProxyAccountInfo()
          }
        },
      })
    })
  }
  unfreezeProxy = type => {
    this.props.form.validateFields((err, values) => {
      this.props.dispatch({
        type: 'proxy/freezeProxy',
        payload: {
          account: this.props.proxy.proxyAccountInfo.account,
          status: 1,
        },
        callback: res => {
          if (res.code === 200) {
            message.success('操作成功')
            this.getProxyAccountInfo()
          }
        },
      })
    })
  }
  delAccount = type => {
    if (type === 'weixin') {
      this.props.form.validateFields((err, values) => {
        if (!err) {
          values.account = this.props.proxy.proxyAccountInfo.account
          values.pay_type = 200
          this.props.dispatch({
            type: 'proxy/delAccount',
            payload: {
              ...values,
            },
            callback: res => {
              if (res.code === 200) {
                message.success('操作成功')
              }
            },
          })
        }
      })
    } else if (type === 'alipay') {
      this.props.form.validateFields((err, values) => {
        if (!err) {
          values.account = this.props.proxy.proxyAccountInfo.account
          values.pay_type = 100
          this.props.dispatch({
            type: 'proxy/delAccount',
            payload: {
              ...values,
            },
            callback: res => {
              if (res.code === 200) {
                message.success('操作成功')
              }
            },
          })
        }
      })
    }
  }
  isReset = bool => {
    this.setState({ isReset: bool })
  }
  Reset = item => {
    this.isReset(true)
    this.props.dispatch({
      type: 'proxy/proxyPassEdit',
      payload: { ...item },
    })
  }
  reload = () => {
    this.isReset(false)
  }
  render() {
    const global = this.props.global
    const treeData = this.props.proxy.proxyTreeListInfo.list
    const account_info = this.props.proxy.proxyAccountInfo
    const treeLeftLayout = {
      xs: 24,
      sm: 12,
      md: 12,
      lg: 9,
      xl: 6,
      xxl: 6,
    }
    const treeRightLayout = {
      xs: 24,
      sm: 12,
      md: 12,
      lg: 15,
      xl: 18,
      xxl: 18,
    }
    const layout = {
      xs: 24,
      sm: 24,
      md: 24,
      lg: 12,
      xl: 8,
      xxl: 6,
    }
    return (
      <Row type="flex" gutter={24} className="vertical-gutter">
        <Col style={{ maxHeight: 1180, overflow: 'auto' }} {...treeLeftLayout}>
          <Card style={{ height: '100%', overflow: 'auto' }} title="代理树">
            {this.state.isReset && (
              <Modal
                title="重置密码"
                visible={this.state.isReset}
                onCancel={() => this.isReset(false)}
                footer={null}
              >
                <ProxyTreeEditPass onClose={this.reload} />
              </Modal>
            )}
            <Tree
              onExpand={this.onExpand}
              expandedKeys={this.state.expandedKeys}
              defaultExpandedKeys={this.state.expandedKeys}
              autoExpandParent={this.state.autoExpandParent}
              onSelect={this.onSelect}
              selectedKeys={this.state.selectedKeys}
            >
              {this.renderTreeNodes(treeData)}
            </Tree>
          </Card>
        </Col>
        <Col {...treeRightLayout}>
          <Row gutter={24} className="vertical-gutter">
            <Col {...layout}>
              <Card style={{ height: 400 }} title="基本信息">
                <DescriptionList col={1} size="large" title="">
                  <Description term="姓名">
                    {account_info.proxyInfo.name}
                  </Description>
                  <Description term="账号">
                    {account_info.proxyInfo.account}
                  </Description>
                  <Description term="支付宝ID">
                    {account_info.proxyInfo.ali_id}
                  </Description>
                  <Description term="支付宝昵称">
                    {account_info.proxyInfo.ali_account_nick}
                  </Description>
                  <Description term="微信ID">
                    {account_info.proxyInfo.wx_id}
                  </Description>
                  <Description term="微信昵称">
                    {account_info.proxyInfo.wx_account_nick}
                  </Description>
                  <Description term="身份证">
                    <PreviewImg
                      src={account_info.proxyInfo.front_pic}
                      alt="正面"
                      height="30"
                      style={{ marginRight: '8px' }}
                    />
                    <PreviewImg
                      src={account_info.proxyInfo.back_pic}
                      alt="反面"
                      height="30"
                    />
                  </Description>
                </DescriptionList>
              </Card>
            </Col>
            <Col {...layout}>
              <Card style={{ height: 400 }} title="状态检查">
                <DescriptionList col={1} size="large" title="">
                  <Description term="在线状态">
                    {account_info.proxyStatus.user_online_status === true
                      ? '在线'
                      : '不在线'}
                  </Description>
                  <Description term="账号状态">
                    {account_info.proxyStatus.pay_app_status === 0
                      ? '正常'
                      : '不正常'}
                  </Description>
                  <Description term="APP环境">
                    {account_info.proxyStatus.app_env_status === 1
                      ? '正常'
                      : '不正常'}
                  </Description>
                  <Description term="代理状态">
                    {account_info.proxyStatus.status === 1
                      ? '正常'
                      : account_info.proxyStatus.status === 2
                      ? '冻结'
                      : '封禁'}
                  </Description>
                </DescriptionList>
              </Card>
            </Col>
            <Col {...layout}>
              <Card style={{ height: 400 }} title="资产信息">
                <DescriptionList col={1} size="large" title="">
                  <Description term="充值额度">
                    {account_info.assetsInfo.owner_amount}
                  </Description>
                  <Description term="上级分配额度">
                    {account_info.assetsInfo.father_amount}
                  </Description>
                  <Description term="上上级分配额度">
                    {account_info.assetsInfo.GF_amount}
                  </Description>
                  <Description term="已分配给下级的额度">
                    {account_info.assetsInfo.lower_amount}
                  </Description>
                  <Description term="已用额度">
                    {account_info.assetsInfo.use_amount}
                  </Description>
                  <Description term="当日收益">
                    {account_info.assetsInfo.today_total_income}
                  </Description>
                  <Description term="总收益">
                    {account_info.assetsInfo.total_income}
                  </Description>
                </DescriptionList>
              </Card>
            </Col>
            <Col {...layout}>
              <Card style={{ height: 400 }} title="收款">
                <DescriptionList col={1} size="large" title="">
                  <Description term="微信二维码">
                    {account_info.collectionInfo.wx_qr_total} 个
                  </Description>
                  <Description term="支付宝二维码">
                    {account_info.collectionInfo.ali_qr_total} 个
                  </Description>
                  <Description term="今日微信收款">
                    {account_info.collectionInfo.wx_amount} 元
                  </Description>
                  <Description term="今日支付宝收款">
                    {account_info.collectionInfo.ali_amount} 元
                  </Description>
                </DescriptionList>
              </Card>
            </Col>
            <Col {...layout}>
              <Card style={{ height: 400 }} title="二维码">
                <Description term="">
                  <PreviewImg
                    src={account_info.Ali}
                    alt="支付宝"
                    height="30"
                    style={{ marginRight: '8px' }}
                  />
                  <PreviewImg src={account_info.Wx} alt="微信" height="30" />
                </Description>
              </Card>
            </Col>
            <Col span={24}>
              <Card title="快捷链接">
                <Link
                  className="btn_router"
                  to={{
                    pathname: `/proxy/proxyPayAll/${
                      account_info.proxyInfo.account
                    }`,
                  }}
                >
                  历史充值流水
                </Link>
                <Link
                  className="btn_router"
                  to={{
                    pathname: `/proxy/proxyPreduceAll/${
                      account_info.proxyInfo.account
                    }`,
                  }}
                >
                  历史降额记录
                </Link>
                <Link
                  className="btn_router"
                  to={{
                    pathname: `/order/OrderInfo/${
                      account_info.proxyInfo.account
                    }`,
                  }}
                >
                  订单流水
                </Link>
                <Link
                  className="btn_router"
                  to={{
                    pathname: `/proxy/profitFlow/${
                      account_info.proxyInfo.account
                    }`,
                  }}
                >
                  收益流水
                </Link>
              </Card>
            </Col>
            <Col span={24} style={{ marginBottom: 0 }}>
              <Card title="操作">
                {account_info.proxyStatus.status === 1 && (
                  <Popconfirm
                    title="确定吗？"
                    onConfirm={() => this.freezeProxy()}
                  >
                    <Button
                      type="primary"
                      ghost
                      style={{ marginRight: 16, marginBottom: 16 }}
                    >
                      冻结代理
                    </Button>
                  </Popconfirm>
                )}
                {account_info.proxyStatus.status === 2 && (
                  <Popconfirm
                    title="确定吗？"
                    onConfirm={() => this.unfreezeProxy()}
                  >
                    <Button
                      type="primary"
                      ghost
                      style={{ marginRight: 16, marginBottom: 16 }}
                    >
                      解冻代理
                    </Button>
                  </Popconfirm>
                )}
                <Popconfirm
                  title="确定吗？"
                  onConfirm={() => this.freezeType('weixin')}
                >
                  <Button
                    type="primary"
                    ghost
                    style={{ marginRight: 16, marginBottom: 16 }}
                  >
                    {this.props.proxy.proxyAccountInfo.IsStopWxPay
                      ? '解冻微信'
                      : '冻结微信'}
                  </Button>
                </Popconfirm>
                <Popconfirm
                  title="确定吗？"
                  onConfirm={() => this.freezeType('alipy')}
                >
                  <Button
                    type="primary"
                    ghost
                    style={{ marginRight: 16, marginBottom: 16 }}
                  >
                    {this.props.proxy.proxyAccountInfo.IsStopAlipay
                      ? '解冻支付宝'
                      : '冻结支付宝'}
                  </Button>
                </Popconfirm>
                <Popconfirm
                  title="确定吗？"
                  onConfirm={() => this.delAccount('alipay')}
                >
                  <Button
                    type="danger"
                    style={{ marginRight: 16, marginBottom: 16 }}
                  >
                    删除支付宝账号及二维码
                  </Button>
                </Popconfirm>
                <Popconfirm
                  title="确定吗？"
                  onConfirm={() => this.delAccount('weixin')}
                >
                  <Button
                    type="danger"
                    style={{ marginRight: 16, marginBottom: 16 }}
                  >
                    删除微信账号及二维码
                  </Button>
                </Popconfirm>
                <Button
                  type="primary"
                  ghost
                  style={{ marginRight: 16, marginBottom: 16 }}
                >
                  <a
                    onClick={() =>
                      this.Reset(this.props.proxy.proxyAccountInfo)
                    }
                  >
                    密码重置
                  </a>
                </Button>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    )
  }
}
