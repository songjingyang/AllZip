import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm
} from 'antd'
import { connect } from 'dva'
import { Link } from 'dva/router'
import classNames from 'classnames'
import moment from 'moment'
import { dateFormater } from '@/utils/utils'
import UploadImg from '@/components/UploadImg'
import SimpleTable from '@/components/SimpleTable'

const FormItem = Form.Item
const Option = Select.Option

@Form.create()
@connect(({ proxy }) => ({ proxy }))
export default class ProfitFlowEdit extends React.Component {
    constructor (props) {
        super(props)
        this.state = {
            columns: [
                {
                    title: '分润的用户',
                    dataIndex: 'account'
                },
                {
                    title: '分润的金额',
                    dataIndex: 'amount'
                },
                {
                    title: '创建的时间',
                    dataIndex: 'created',
                    render: text => (
                       <span>{dateFormater(text)}</span>
                    )
                }
            ]
        }
    }
    handleSubmit = e => {
        e.preventDefault()
        this.props.onClose()
        // this.props.form.validateFields((err, values) => {
        //     if(!err) {
        //         this.props.dispatch({
        //             type: 'proxy/saveProfitFlowEdit',
        //             payload: {
        //                 ...this.props.proxy.profitFlowEdit,
        //                 ...values
        //             },
        //             callback: res => {
        //                 if (res.code === 200) {
        //                     if (this.props.onClose) {
        //                         this.props.onClose()
        //                     }
        //                 }
        //             }
        //         })
        //     }
        // })
    }
    render () {
        const { getFieldDecorator } = this.props.form
        const info = this.props.proxy.profitFlowEdit
        const formItemLayout = {
            labelCol: { span: 12 },
            wrapperCol: { span: 24 }
        }
        return (
            <Form onSubmit = {this.handleSubmit}>
                <FormItem { ...formItemLayout } label=''>
                {
                    getFieldDecorator('detail')(
                        <SimpleTable
                            columns={this.state.columns}
                            rowKey={record => record.id}
                            dataSource={info.list}           
                            pagination={false}
                            loading={this.props.loading}
                            onChange={this.handleTableChange}
                        />
                    )
                }
                </FormItem>
                <FormItem wrapperCol={{ span: 12, offset: 6 }}>
                    <Button type='primary' htmlType='submit'>关闭</Button>
                </FormItem>
            </Form>
        )
    }
}