import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Alert
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import { now } from 'moment';
import ProxyListCreate from './ProxyListCreate';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ proxy, global, loading }) => ({
  proxy,
  global,
  loading: loading.effects['proxy/getProxyList']
}))
export default class ProxyList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isCreate: false,
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        1: '正常',
        2: '冻结',
        3: '封禁'
      },
      auditStatusMap: {
        0: '未审核',
        1: '已通过',
        2: '未通过'
      },
      levelMap: {
        1: '总代',
        2: '一级代理',
        3: '二级代理'
      },
      columns: [
        {
          isExpand: true,
          title: 'ID',
          dataIndex: 'id'
        },
        {
          title: '代理账户',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '代理名称',
          dataIndex: 'username'
        },
        {
          isExpand: true,
          title: '级别',
          dataIndex: 'level',
          render: text => <span>{this.state.levelMap[text]}</span>
        },
        {
          isExpand: true,
          title: '邀请码',
          dataIndex: 'invitate_code'
        },
        {
          isExpand: true,
          title: '冻结状态',
          dataIndex: 'status',
          render: (text, record) => (
            <span>{this.state.statusMap[record.status]}</span>
          )
        },
        {
          isExpand: true,
          title: '审核',
          dataIndex: 'audit_status',
          render: (text, record) =>
            record.audit_status === 2 ? (
              <span style={{ color: 'red' }}>
                {this.state.auditStatusMap[record.audit_status]}
              </span>
            ) : (
              <span style={{ color: 'green' }}>
                {this.state.auditStatusMap[record.audit_status]}
              </span>
            )
        },
        {
          isExpand: true,
          title: '注册时间',
          dataIndex: 'created_at',
          render: text => {
            return <span>{dateFormater(text)}</span>;
          }
        },
        {
          title: '关系',
          dataIndex: 'name',
          render: (text, record) => {
            return (
              <span>
                {record.level === 1 ? (
                  <span style={{ color: '#c1c1c1' }}>上级</span>
                ) : (
                  <a
                    onClick={() => this.jumpPrevLevel(record)}
                    href="javascript:;"
                  >
                    上级
                  </a>
                )}
                <Divider type="vertical" />
                {record.level === 3 ? (
                  <span style={{ color: '#c1c1c1' }}>下级</span>
                ) : (
                  <a
                    onClick={() => this.jumpNextLevel(record)}
                    href="javascript:;"
                  >
                    下级
                  </a>
                )}
              </span>
            );
          }
        }
      ]
    };
  }
  componentDidMount() {
    this.getProxyList();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getProxyList(values);
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getProxyList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getProxyList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.proxy.proxyListInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }

        payload = { ...payload, ...params };

        this.props.dispatch({
          type: 'proxy/getProxyList',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getProxyList parameters error');
      }
    });
  };
  getJumpPrevLevel = (params = {}) => {
    if (params.parent_account === '') {
      message.warning('没有上级');
      return;
    } else {
      this.props.form.validateFields((err, values) => {
        if (!err) {
          this.props.dispatch({
            type: 'proxy/getJumpPrevLevel',
            payload: {
              parent_account: params.parent_account
            }
          });
        } else {
          console.log('getJumpPrevLevel parameters error');
        }
      });
    }
  };
  getJumpNextLevel = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'proxy/getJumpNextLevel',
          payload: {
            account: params.account
          }
        });
      } else {
        console.log('getJumpNextLevel parameters error');
      }
    });
  };
  jumpPrevLevel = item => {
    this.getJumpPrevLevel(item);
  };
  jumpNextLevel = item => {
    this.getJumpNextLevel(item);
  };

  isCreateProxy = bool => {
    this.setState({ isCreateProxy: bool });
  };

  isCreate = bool => {
    this.setState({ isCreate: bool });
  };
  create = item => {
    this.isCreate(true);
  };
  reload = () => {
    this.isCreate(false);
    this.getProxyList();
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.proxy.proxyListInfo;

    return (
      <Card bordered={false}>
        {this.state.isCreate && (
          <Modal
            title="创建"
            visible={this.state.isCreate}
            onCancel={() => this.isCreate(false)}
            footer={null}
          >
            <ProxyListCreate onClose={this.reload} />
          </Modal>
        )}
        <div className={'tableList'}>
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="代理账户" className="form-inline-item">
                    {getFieldDecorator('account')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="代理名称" className="form-inline-item">
                    {getFieldDecorator('username')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="状态" className="form-inline-item">
                    {getFieldDecorator('status', {
                      initialValue: '-2'
                    })(
                      <RadioGroup>
                        <Radio value="-2">全部</Radio>
                        <Radio value="1">正常</Radio>
                        <Radio value="2">冻结</Radio>
                        <Radio value="3">封禁</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <div className={'submitButtons'}>
                    <Button
                      type="primary"
                      htmlType="submit"
                      style={{ marginRight: '20px' }}
                    >
                      查询
                    </Button>
                    <Button
                      icon="plus"
                      type="primary"
                      onClick={() => this.create()}
                    >
                      创建总代
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
