import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Alert
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import { now } from 'moment';
import ChannelManageCreate from './ChannelManageCreate';
import ChannelManageEdit from './ChannelManageEdit';
// import MerchantProxyManageAssoci from './MerchantProxyManageAssoci';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ channel, global, loading }) => ({
  channel,
  global,
  loading: loading.effects['finance/getChanenl']
}))
export default class ChannelManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        0: '显示',
        1: '不显示'
      },
      auditStatusMap: {
        0: '未审核',
        1: '已通过',
        2: '未通过'
      },
      isProxyAccout: false,
      isEdit: false,
      isPassword: false,
      isClear: false,
      isCreateProxy: false,
      account_info: '',
      isCreate: false,
      itemList: [],
      isAssoci: false,
      columns: [
        {
          isExpand: true,
          title: 'id',
          dataIndex: 'id'
        },
        {
          isExpand: true,
          title: '名称',
          dataIndex: 'name'
        },
        {
          title: '下分通道uid',
          dataIndex: 'uid'
          // render: (text, record) => (
          //   <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
          //     {text}
          //   </Link>
          // )
        },
        {
          isExpand: true,
          title: '下分通道secret',
          dataIndex: 'secret'
        },
        {
          isExpand: true,
          title: '下单url',
          dataIndex: 'create_url'
        },
        {
          isExpand: true,
          title: '查询请求url',
          dataIndex: 'query_url'
        },
        {
          isExpand: true,
          title: '费率(%)',
          dataIndex: 'rate'
        },
        {
          isExpand: true,
          title: '单次费用',
          dataIndex: 'cost'
        },
        {
          isExpand: true,
          title: '排序',
          dataIndex: 'sort'
        },
        {
          isExpand: true,
          title: '是否显示',
          dataIndex: 'display',
          render: (text, record) => (
            <span>{this.state.statusMap[record.display]}</span>
          )
        },
        {
          title: '操作',
          // dataIndex: 'name',
          render: (text, record) => {
            return (
              <span>
                <div>
                  <a onClick={() => this.edit(record)} href="javascript:;">
                    编辑
                  </a>
                  {/* <Divider type="vertical" />
                  <a onClick={() => this.associ(record)} href="javascript:;">
                    关联商户
                  </a> */}
                </div>
              </span>
            );
          }
        }
      ]
    };
  }
  // 页面初始化调用
  componentDidMount() {
    this.getChannelManage();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getChannelManage(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getChannelManage({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getChannelManage = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        // if (params.page === 1) {
        //   params.ts = Date.parse(new Date()) / 1000;
        // } else {
        //   params.ts = this.props.channel.channelManageInfo.ts;
        // }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }

        payload = { ...payload, ...params };
        console.log('payload', payload);

        this.props.dispatch({
          type: 'channel/getChannelManage',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getChannelManage parameters error');
      }
    });
  };
  isCreate = bool => {
    this.setState({ isCreate: bool });
  };
  create = item => {
    this.isCreate(true);
    // this.props.dispatch({
    //   type: 'finance/merchantProxyManageCreate',
    //   payload: {
    //     ...item
    //   }
    // });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.itemList = item;
    this.props.dispatch({
      type: 'channel/editPayChannelInfo',
      payload: {
        ...item
      }
    });
  };

  isAssoci = bool => {
    this.setState({ isAssoci: bool });
  };
  associ = item => {
    this.isAssoci(true);
    this.itemList = item;
    this.props.dispatch({
      type: 'finance/associMerchant',
      payload: {
        ...item
      }
    });
  };
  reload = () => {
    this.isCreate(false);
    this.isEdit(false);
    // this.isAssoci(false)
    this.getChannelManage();
  };

  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.channel.getChannelManageInfo;

    return (
      <Card bordered={false}>
        {this.state.isCreate && (
          <Modal
            title="创建"
            visible={this.state.isCreate}
            onCancel={() => this.isCreate(false)}
            footer={null}
          >
            <ChannelManageCreate onClose={this.reload} />
          </Modal>
        )}

        {this.state.isEdit && (
          <Modal
            title="编辑"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <ChannelManageEdit onClose={this.reload} />
          </Modal>
        )}
        {/* 
        {this.state.isAssoci && (
          <Modal
            width={800}
            title="关联商户"
            visible={this.state.isAssoci}
            onCancel={() => this.isAssoci(false)}
            footer={null}
          >
            <MerchantProxyManageAssoci
              onClose={this.associ}
              onClose={this.reload}
            />
          </Modal>
        )} */}
        <div className={'tableList'}>
          <div className={'tableListOperator'}>
            <Button icon="plus" type="primary" onClick={() => this.create()}>
              新增
            </Button>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
