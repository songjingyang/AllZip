import React from 'react';
import { Table, message, Form, Input, Select, Button, Radio } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const RadioGroup = Radio.Group;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class ChannelManageCreate extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      values.status = Number(values.status);
      var data = {
        cost: Number(values.cost),
        create_url: values.create_url,
        display: Number(values.display),
        name: values.name,
        query_url: values.query_url,
        rate: Number(values.rate),
        secret: values.secret,
        sort: Number(values.sort),
        uid: values.uid
      };
      if (!err) {
        this.props.dispatch({
          type: 'channel/createPayChannel',
          payload: {
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('创建成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.ClearingRecordTransfer;
    const formItemLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        {/* <FormItem
          style={{ marginBottom: '15px' }}
          {...formItemLayout}
          label="账号"
        >
          {getFieldDecorator('account', {
            rules: [
              {
                required: true,
                message: '请填写账号!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem> */}
        <FormItem {...formItemLayout} label="名称">
          {getFieldDecorator('name', {
            rules: [
              {
                required: true,
                message: '请填写名称!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="下分通道uid">
          {getFieldDecorator('uid', {
            rules: [
              {
                required: true,
                message: '下分通道uid!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="下分通道secret">
          {getFieldDecorator('secret', {
            rules: [
              {
                required: true,
                message: '下分通道secret!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="下单url">
          {getFieldDecorator('create_url', {
            rules: [
              {
                required: true,
                message: '下单url!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="查询url">
          {getFieldDecorator('query_url', {
            // initialValue: '',
            rules: [
              {
                required: true,
                message: '查询url!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="费率(%)">
          {getFieldDecorator('rate', {
            // initialValue: '',
            rules: [
              {
                required: true,
                message: '费率!',
                writespace: true
              }
            ]
          })(<Input type="type" style={{ width: '65%' }} />)}
          <span>（例：1=1%）</span>
        </FormItem>
        <FormItem {...formItemLayout} label="单次费用(元)">
          {getFieldDecorator('cost', {
            // initialValue: '',
            rules: [
              {
                required: true,
                message: '单次费用!',
                writespace: true
              }
            ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="是否显示">
          {getFieldDecorator('display', {
            initialValue: '0',
            rules: [
              {
                required: true,
                message: '请选择状态'
                // whitespace: true
              }
            ]
          })(
            <RadioGroup>
              <Radio value="0">显示</Radio>
              <Radio value="1">不显示</Radio>
            </RadioGroup>
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="排序">
          {getFieldDecorator('sort', {})(<Input type="type" />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            创建
          </Button>
        </FormItem>
      </Form>
    );
  }
}
