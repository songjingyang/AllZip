import React from 'react';
import {
  Form,
  Select,
  Radio,
  Button,
  Input,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  Popconfirm,
  Divider
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import PlatformTransferEdit from './PlatformTransferEdit';
import PlatformTransferDetail from './PlatformTransferDetail';
import PlatformTransferInfo from './PlatformTransferInfo';
import PlatformBatchTransferDetail from './PlatformBatchTransferDetail';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;
const Option = Select.Option;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/getPlatformTransferInfo']
}))
export default class PlatformTransfer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isBatchtransfer: false,
      statusMap: {
        '-1': '拒绝',
        0: '审核中',
        1: '成功',
        2: '失败',
        3: '处理中',
        4: '待处理',
        5: '审核驳回',
        6: '待审核',
        7: '交易不存在',
        8: '未知状态'
      },
      backoutMap: {
        0: '未撤销',
        1: '已撤销'
      },
      theGoldAudit_columns: [
        {
          isExpand: true,
          title: '商户',
          dataIndex: 'bu_name'
        },
        {
          isExpand: true,
          title: '总金额',
          dataIndex: 'sum_amount}'
        },
        {
          isExpand: true,
          title: '总数量',
          dataIndex: 'counts'
        },
        {
          isExpand: true,
          title: '拒绝',
          dataIndex: 'refuse'
        },
        {
          isExpand: true,
          title: '审核中',
          dataIndex: 'in_the_review'
        },
        {
          isExpand: true,
          title: '成功',
          dataIndex: 'success'
        },
        {
          isExpand: true,
          title: '失败',
          dataIndex: 'fail'
        },
        {
          isExpand: true,
          title: '处理中',
          dataIndex: 'processing'
        },
        {
          isExpand: true,
          title: '待处理',
          dataIndex: 'to_be_processed'
        },
        {
          isExpand: true,
          title: '审核驳回',
          dataIndex: 'rejected'
        },
        {
          isExpand: true,
          title: '待审核',
          dataIndex: 'to_audit'
        },
        {
          isExpand: true,
          title: '交易不存在',
          dataIndex: 'trade_not_exists'
        },
        {
          isExpand: true,
          title: '位置状态',
          dataIndex: 'unknown_state'
        }
      ],
      platformTransfer_columns: [
        {
          isExpand: true,
          title: '日期',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '期号',
          dataIndex: 'group_num'
        },
        {
          isExpand: true,
          title: '渠道',
          dataIndex: 'channel_name'
        },
        {
          title: '商户',
          dataIndex: 'ach_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '银行',
          dataIndex: 'bank_name',
          render: (text, record) => <span>{text ? text : record.way_name}</span>
        },
        {
          isExpand: true,
          title: '收款账户',
          dataIndex: 'card_no'
        },
        {
          isExpand: true,
          title: '开户人',
          dataIndex: 'card_owner'
        },
        {
          isExpand: true,
          title: '省份',
          dataIndex: 'province'
        },
        {
          isExpand: true,
          title: '城市',
          dataIndex: 'city'
        },
        {
          title: '金额',
          dataIndex: 'amount'
        },
        {
          title: '手续费',
          dataIndex: 'pundage'
        },
        {
          isExpand: true,
          title: '备注',
          dataIndex: '',
          render: (text, record) => (
            <a onClick={() => this.edit(record)} href="javascript:;">
              查看
            </a>
          )
        },
        {
          isExpand: true,
          title: '是否撤销',
          dataIndex: '',
          render: (text, record) =>
            record.backout === 0 ? (
              <span style={{ color: 'green' }}>
                {this.state.backoutMap[record.backout]}
              </span>
            ) : (
              <span style={{ color: 'red' }}>
                {this.state.backoutMap[record.backout]}
              </span>
            )
        },
        {
          isExpand: true,
          title: '转账状态',
          dataIndex: '',
          render: (text, record) => (
            <span>{this.state.statusMap[record.status]}</span>
          )
        }
        // {
        //   isExpand: true,
        //   title: '操作',
        //   dataIndex: '',
        //   render: (text, record) => (
        //     <div>
        //       {record.status === 0 ? (
        //         record.backout === 0 ? (
        //           <a onClick={() => this.transfer(record)} href="javascript:;">
        //             转账
        //           </a>
        //         ) : (
        //           <span style={{ color: '#ccc' }}>转账</span>
        //         )
        //       ) : record.status !== 1 && record.status !== 2 ? (
        //         record.channel_name === '平台' ? (
        //           <span style={{ color: '#ccc' }}>转账</span>
        //         ) : (
        //           <div>
        //             <span style={{ color: '#ccc' }}>转账</span>
        //             <Divider type="vertical" />
        //             <a onClick={() => this.info(record)} href="javascript:;">
        //               查看
        //             </a>
        //           </div>
        //         )
        //       ) : (
        //         <span style={{ color: '#ccc' }}>转账</span>
        //       )}
        //     </div>
        //   )
        // }
      ]
    };
  }
  componentDidMount() {
    this.getPlatformTransferInfo();
  }
  getPlatformTransferInfo = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.finance.platformTransferInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'finance/getPlatformTransferInfo',
          payload: {
            ...payload,
            group_num: this.props.match.params.group_num,
            status: this.props.match.params.status
          },
          callback: params.callback
        });

        // 根据批次号查询相应信息

        this.props.dispatch({
          type: 'finance/getPlatformTransferByGroupNum',
          payload: {
            group_num: this.props.match.params.group_num
          },
          callback: params.callback
        });
      } else {
        console.log('getPlatformTransferInfo err');
      }
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'finance/platformTransferEditInfo',
      payload: {
        ...item
      }
    });
  };
  isTransfer = bool => {
    this.setState({ isTransfer: bool });
  };
  transfer = item => {
    this.isTransfer(true);
    this.props.dispatch({
      type: 'finance/platformTransferDetail',
      payload: {
        ...item
      }
    });
    // 渠道接口
    this.props.dispatch({
      type: 'finance/getFindPayChannelAll',
      payload: {
        ach_id: item.ach_id
      }
    });
    this.props.dispatch({
      type: 'finance/getAcmClearMoveByGroupNum',
      payload: {
        group_num: item.group_num
      }
    });
  };
  isBatchtransfer = bool => {
    this.setState({ isBatchtransfer: bool });
  };
  Batchtransfer = item => {
    this.isBatchtransfer(true);
    this.props.dispatch({
      type: 'finance/platformTransferDetail',
      payload: {
        ...item.ach_id
      }
    });
    // 渠道接口
    this.props.dispatch({
      type: 'finance/getFindPayChannelAll',
      payload: {
        ach_id: item.ach_id
      }
    });
    this.props.dispatch({
      type: 'finance/getAcmClearMoveByGroupNum',
      payload: {
        group_num: item.group_num
      }
    });
  };
  isInfo = bool => {
    this.setState({ isInfo: bool });
  };
  info = item => {
    this.isInfo(true);
    this.props.dispatch({
      type: 'finance/searchWithdraw',
      payload: {
        id: +item.id
      }
    });
  };
  closeTrabsferEdit = () => {
    this.isEdit(false);
  };
  addPlatformTransferInfo = () => {
    this.isTransfer(false);
    this.isInfo(false);
    this.isBatchtransfer(false);
    this.getPlatformTransferInfo();
  };
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getPlatformTransferInfo(values);
      } else {
        console.log('getPlatformTransferInfo submit');
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getPlatformTransferInfo({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  // 时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  // 平台转账  点击查询
  search = data => {
    let search_data = this.props.finance.getPlatformTransferByGroupNumInfo.list;
    this.props.dispatch({
      type: 'finance/getPlatformTransferInfo',
      payload: {
        // ...payload,
        group_num: this.props.match.params.group_num,
        status: data
      }
      // callback: params.callback
    });
    // if (data === 'bu_name') {
    //   this.props.dispatch({
    //     type: 'finance/saveSeach',
    //     payload: {
    //       bu_name: search_data.bu_name
    //     }
    //   });
    // } else if (data === 'sum_amount') {
    //   this.props.dispatch({
    //     type: 'finance/saveSeach',
    //     payload: {
    //       sum_amount: search_data.sum_amount
    //     }
    // });
    // }
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.platformTransferInfo;
    const infos = this.props.finance.getPlatformTransferByGroupNumInfo.list;
    return (
      <Card bordered={false}>
        {this.state.isEdit && (
          <Modal
            title="查看"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <PlatformTransferEdit onClose={this.closeTrabsferEdit} />
          </Modal>
        )}
        {this.state.isTransfer && (
          <Modal
            title="转账"
            visible={this.state.isTransfer}
            onCancel={() => this.isTransfer(false)}
            footer={null}
          >
            <PlatformTransferDetail onClose={this.addPlatformTransferInfo} />
          </Modal>
        )}
        {this.state.isBatchtransfer && (
          <Modal
            title="批次号转账"
            visible={this.state.isBatchtransfer}
            onCancel={() => this.isBatchtransfer(false)}
            footer={null}
          >
            <PlatformBatchTransferDetail
              onClose={this.addPlatformTransferInfo}
            />
          </Modal>
        )}
        {this.state.isInfo && (
          <Modal
            title="查看"
            visible={this.state.isInfo}
            onCancel={() => this.isInfo(false)}
            footer={null}
          >
            <PlatformTransferInfo onClose={this.addPlatformTransferInfo} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row
                gutter={{ md: 8, lg: 24, xl: 48 }}
                style={{ marginBottom: '15px' }}
              >
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>商户</h4>
                  <div
                    // onClick={() => this.search('bu_name')}
                    style={{ marginTop: '15px' }}
                  >
                    {infos.bu_name}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>总金额</h4>
                  <div
                    // onClick={() => this.search('sum_amount')}
                    style={{ marginTop: '15px' }}
                  >
                    {infos.sum_amount}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>总数量</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('-3')}
                  >
                    {infos.counts}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>拒绝</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('-1')}
                  >
                    {infos.refuse}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>审核中</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('0')}
                  >
                    {infos.in_the_review}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>成功</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('1')}
                  >
                    {infos.success}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>失败</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('2')}
                  >
                    {infos.fail}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>处理中</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('3')}
                  >
                    {infos.processing}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>待处理</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('4')}
                  >
                    {infos.to_be_processed}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>审核驳回</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('5')}
                  >
                    {infos.rejected}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>待审核</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('6')}
                  >
                    {infos.to_audit}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>交易不存在</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('7')}
                  >
                    {infos.trade_not_exists}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>未知状态</h4>
                  <div
                    style={{
                      marginTop: '15px',
                      color: '#008dff',
                      cursor: 'pointer'
                    }}
                    onClick={() => this.search('8')}
                  >
                    {infos.unknown_state}
                  </div>
                </Col>
                <Col style={{ display: 'inline-block', paddingRight: '15px' }}>
                  <h4>操作</h4>
                  {infos.in_the_review === infos.counts ? (
                    <div
                      style={{
                        marginTop: '15px',
                        color: '#008dff',
                        cursor: 'pointer'
                      }}
                      onClick={() => this.Batchtransfer(infos)}
                    >
                      转账
                    </div>
                  ) : (
                    <div
                      style={{
                        marginTop: '15px',
                        color: '#cccccc',
                        cursor: 'pointer'
                      }}
                    >
                      转账
                    </div>
                    // <span style={{ color: '#ccc' }}>转账</span>
                  )}
                </Col>
              </Row>
              {/* <Co style={{display: 'inline-block'}} md={24} sm={24}> */}
              {/* <label>商户:{infos.bu_name}</label>
                <label>:{infos.sum_amount}</label>
                <label>总数量:{infos.counts}</label>
                <label>拒绝:{infos.refuse}</label>
                <label>审核中:{infos.in_the_review}</label>
                <label>成功:{infos.success}</label>
                <label>失败:{infos.fail}</label>
                <label>处理中:{infos.processing}</label>
                <label>待处理:{infos.to_be_processed}</label>
                <label>审核驳回:{infos.rejected}</label>
                <label>待审核:{infos.to_audit}</label>
                <label>交易不存在:{infos.trade_not_exists}</label>
                <label>未知状态:{infos.unknown_state}</label> */}
              {/* <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        showTime
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="商户" className="form-inline-item">
                    {getFieldDecorator('ach_id', {
                      initialValue: this.props.match.params.account
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="批次号" className="form-inline-item">
                    {getFieldDecorator('group_num', {
                      initialValue: this.props.match.params.group_num
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                    <FormItem label="状态" className="form-inline-item">
                      {getFieldDecorator('status', {
                        initialValue: this.props.match.params.status
                      })(
                        <Select>
                          <Option value="-3">全部</Option>
                          <Option value="-1">拒绝</Option>
                          <Option value="0">审核中</Option>
                          <Option value="1">成功</Option>
                          <Option value="2">失败</Option>
                          <Option value="3">处理中</Option>
                          <Option value="4">待处理</Option>
                          <Option value="5">审核驳回</Option>
                          <Option value="6">待审核</Option>
                          <Option value="7">交易不存在</Option>
                          <Option value="8">未知状态</Option>
                        </Select>
                      )}
                    </FormItem>
                  </Col>
                
                <Col xl={12} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div> */}
              {/* </Col>
              </Row> */}
            </Form>
          </div>
          {/* <SimpleTable
            columns={this.state.theGoldAudit_columns}
            rowKey={record => record.id}
            // dataSource={infos.list}
            pagination={false}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          /> */}
          <SimpleTable
            columns={this.state.platformTransfer_columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
