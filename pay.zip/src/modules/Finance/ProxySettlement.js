import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Alert
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import { now } from 'moment';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/getProxySettlement']
}))
export default class ProxySettlement extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        1: '正常',
        2: '冻结'
      },
      auditStatusMap: {
        0: '未审核',
        1: '已通过',
        2: '未通过'
      },
      isProxyAccout: false,
      isEdit: false,
      isPassword: false,
      isClear: false,
      isCreateProxy: false,
      account_info: '',
      columns: [
        {
          title: '代理账户',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '代理名称',
          dataIndex: 'name'
        },
        {
          title: '充值总额度',
          dataIndex: 'anount_total'
        },
        {
          isExpand: true,
          title: '团队人数',
          dataIndex: 'team_total'
        },
        {
          isExpand: true,
          title: '个人收益',
          dataIndex: 'individual_income_total'
        },
        {
          isExpand: true,
          title: '团队收益',
          dataIndex: 'team_income_total'
        },
        {
          isExpand: true,
          title: '未结算收益',
          dataIndex: 'no_settlement_total'
        }
      ]
    };
  }
  componentDidMount() {
    this.getProxySettlement();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getProxySettlement(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getProxySettlement({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getProxySettlement = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        // if (params.page === 1) {
        //   params.ts = Date.parse(new Date()) / 1000;
        // } else {
        //   params.ts = this.props.finance.proxySettlementInfo.ts;
        // }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }

        payload = { ...payload, ...params };

        this.props.dispatch({
          type: 'finance/getProxySettlement',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getProxySettlement parameters error');
      }
    });
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.proxySettlementInfo;

    return (
      <Card bordered={false}>
        <div className={'tableList'}>
          <div
            style={{ marginBottom: '10px' }}
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Link
              style={{
                display: 'block',
                color: '#fff',
                width: '64px',
                height: '32px',
                background: '#1890ff',
                borderRadius: '4px',
                textAlign: 'center',
                lineHeight: '32px'
              }}
              to={{ pathname: '/finance/proxyNoSettlementTotal' }}
            >
              结账
            </Link>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
