import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Divider,
  Row,
  Col,
  Modal,
  message,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import PreviewImg from '@/components/PreviewImg';
import MerchantPayAllEdit from './MerchantPayAllEdit';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/getMerchantPayAllList']
}))
export default class MerchantPayAll extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      // isPay: false,
      statusMap: {
        2: '通过'
      },
      backoutMap: {
        0: '未撤销',
        1: '已撤销'
      },
      columns: [
        {
          isExpand: true,
          title: '流水ID',
          dataIndex: 'order_id'
        },
        {
          title: '商户',
          dataIndex: 'ach_id'
        },
        {
          title: '商户名称',
          dataIndex: 'bu_name'
        },
        {
          isExpand: true,
          title: '姓名',
          dataIndex: '平台',
          render: text => '平台'
        },
        {
          isExpand: true,
          title: '通道',
          dataIndex: '代付',
          render: text => '代付'
        },
        {
          title: '充值金额',
          dataIndex: 'amount'
        },
        // {
        //   title: '金额',
        //   dataIndex: 'amount'
        // },
        // {
        //   title: '点数',
        //   dataIndex: 'ach_rate',
        //   render: text => <span>{text}%</span>
        // },
        // {
        //   title: '可提现(自动/手动)',
        //   dataIndex: '',
        //   render: (text, record) => (
        //     <div>
        //       {record.boo ? (
        //         <span>
        //           {record.withdraw}/{record.amount}
        //         </span>
        //       ) : (
        //         <span style={{ color: 'red' }}>
        //           {record.amount}/{record.withdraw}
        //         </span>
        //       )}
        //     </div>
        //   )
        // },
        {
          title: '充值时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'status',
          render: (text, record) => (
            <span>{this.state.statusMap[record.status]}</span>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getMerchantPayAllList();
  }
  getMerchantPayAllList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.finance.merchantPayAllListInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'finance/getMerchantPayAllList',
          payload: {
            ...payload
          },
          callback: params.callback
        });
      } else {
        console.log('getMerchantPayAllList err');
      }
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });

    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getMerchantPayAllList(values);
      } else {
        console.log('getMerchantPayAllList');
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getMerchantPayAllList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  // 时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  isPay = bool => {
    this.setState({ isPay: bool });
  };
  closePay = () => {
    this.isPay(false);
    this.getMerchantPayAllList();
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.merchantPayAllListInfo;
    return (
      <Card bordered={false}>
        {this.state.isPay && (
          <Modal
            title="充值"
            visible={this.state.isPay}
            onCancel={() => this.isPay(false)}
            footer={null}
          >
            <MerchantPayAllEdit onClose={this.closePay} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                      initialValue: getTimeDistance('today'),
                      rules: [
                        {
                          validator: (rule, value, callback) => {
                            let startTm;
                            let endTm;
                            if (value.length !== 0) {
                              startTm = parseInt(value[0].valueOf() / 1000);
                              endTm = parseInt(value[1].valueOf() / 1000);
                              if (endTm - startTm > 90 * 24 * 3600) {
                                callback('最大范围 3个月');
                              }
                            } else {
                              startTm = 0;
                              endTm = 0;
                            }
                            callback();
                          }
                        }
                      ]
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        showTime
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="商户" className="form-inline-item">
                    {getFieldDecorator('achId')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button
                      type="primary"
                      htmlType="submit"
                      style={{ marginRight: '20px' }}
                    >
                      查询
                    </Button>
                    <Button
                      icon="plus"
                      type="primary"
                      onClick={() => this.isPay(true)}
                    >
                      充值
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
