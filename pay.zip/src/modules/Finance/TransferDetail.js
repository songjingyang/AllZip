import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Modal,
  Row,
  Col,
  message
} from 'antd'
import { connect } from 'dva'
import PreviewImg from '@/components/PreviewImg'

const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const RangePicker = DatePicker.RangePicker

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class TransferDetail extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20
      },
      loading: false,
      columns: [
        {
          title: '账户',
          dataIndex: 'account'
        },
        {
          title: '转账金额',
          dataIndex: 'price'
        },
        {
          title: '转账状态',
          dataIndex: 'status'
        },
        {
          title: '到账时间',
          dataIndex: 'time'
        },
        {
          title: '转账凭证',
          dataIndex: 'img',
          render: (text, record) => <PreviewImg src={text} height={100} />
        }
      ]
    }
  }

  componentDidMount () {
    this.getTransferDetail()
  }
  handleChangeDate = date => {}
  handleSubmit = e => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getTransferDetail(values)
      }
    })
  }

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination }
    pager.current = pagination.current
    this.setState({
      pagination: pager
    })
    this.getTransferDetail({
      pageSize: pagination.pageSize,
      page: pagination.current
    })
  }

  getTransferDetail = (params = {}) => {
    let payload = {
      ...params
    }
    if (payload.timeRange) {
      payload.timeRange = [
        payload.timeRange[0].format('YYYY-MM-DD HH:mm:ss'),
        payload.timeRange[1].format('YYYY-MM-DD HH:mm:ss')
      ]
    }

    this.props.dispatch({
      type: 'finance/getTransDetail',
      payload: {
        ...params
      }
    })
  }

  render () {
    const { getFieldDecorator } = this.props.form
    const info = this.props.finance.transDetailListInfo

    return (
      <Card bordered={false}>

        <div className={'tableList'}>
          {/* <div className={'tableListForm'}>
            <Form layout='inline' onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={8} sm={24}>
                  <FormItem label='时间范围' className='form-inline-item'>
                    {getFieldDecorator('timeRange', {})(
                      <RangePicker showTime format='YYYY-MM-DD HH:mm:ss' />
                    )}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <FormItem label='支付状态' className='form-inline-item'>
                    {getFieldDecorator('payStatus')(
                      <RadioGroup>
                        <Radio value=''>全部</Radio>
                        <Radio value='1'>已支付</Radio>
                        <Radio value='0'>未支付</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <FormItem label='支付方式' className='form-inline-item'>
                    {getFieldDecorator('payType')(
                      <RadioGroup>
                        <Radio value=''>全部</Radio>
                        <Radio value='100'>支付宝</Radio>
                        <Radio value='200'>微信</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <FormItem label='商户' className='form-inline-item'>
                    {getFieldDecorator('merchantId')(<Input />)}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <FormItem label='用户id' className='form-inline-item'>
                    {getFieldDecorator('userId')(<Input />)}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <FormItem label='订单id' className='form-inline-item'>
                    {getFieldDecorator('orderId')(<Input />)}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <FormItem label='平台id' className='form-inline-item'>
                    {getFieldDecorator('platformId')(<Input />)}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <span className={'submitButtons'}>
                    <Button type='primary' htmlType='submit'>查询</Button>
                  </span>
                </Col>
              </Row>
            </Form>
          </div> */}
          {/* <div className={'tableListOperator'}>
          <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
            新建
          </Button>
        </div> */}

          <Table
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={this.state.pagination}
            loading={this.state.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    )
  }
}
