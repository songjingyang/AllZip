import React from 'react';
import { Modal, message, Form, Input, Select, Button} from 'antd';
import { connect } from 'dva';
import { commafy, toFixed } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class MerchantPayAllEdit extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        const formItemLayout = {
          labelCol: { span: 8 },
          wrapperCol: { span: 14 }
        };
        Modal.confirm({
          title: '提交确认',
          okText: '确认',
          cancelText: '取消',
          onOk: () => {
            return this.save();
          },
          content: (
            <Form>
              <FormItem {...formItemLayout} label="商户ID">
                {values.ach_id}
              </FormItem>
              {/* <FormItem {...formItemLayout} label="点数(%)">
                {values.ach_rate}%
              </FormItem> */}
              <FormItem {...formItemLayout} label="充值金额(元)">
                {values.request_amount}
              </FormItem>
              {/* <FormItem {...formItemLayout} label="可提现(元)">
                {commafy(values.amount)}
              </FormItem> */}
            </Form>
          )
        });
      }
    });
  };
  save = e => {
    this.props.form.validateFields((err, values) => {
      values.ach_rate = values.ach_rate * 100;
      values.amount = +values.amount;
      values.request_amount = +values.request_amount;
      if (!err) {
        this.props.dispatch({
          type: 'finance/merchantRecharge',
          payload: {
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    const info = this.props.finance;
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="商户ID">
          {getFieldDecorator('ach_id', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入商户ID'
              }
            ]
          })(<Input />)}
        </FormItem>
        {/* <FormItem {...formItemLayout} label="点数(%)">
          {getFieldDecorator('ach_rate', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入点数'
              },
              {
                validator: (rule, value, callback) => {
                  if (value && !Number(+value)) {
                    callback('只能输入数字');
                    return;
                  }
                  callback();
                }
              }
            ]
          })(<Input style={{ width: '65%' }} />)}
          <span>（例：0.02）</span>
        </FormItem> */}
        <FormItem {...formItemLayout} label="充值金额(元)">
          {getFieldDecorator('request_amount', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入充值金额'
              },
              {
                validator: (rule, value, callback) => {
                  if (value && !Number.isInteger(+value)) {
                    callback('只能输入整数金额');
                    return;
                  }
                  callback();
                }
              }
            ]
          })(<Input />)}
        </FormItem>
        <FormItem style={{marginBottom: 10}} {...formItemLayout} label='支付密码'>
            {getFieldDecorator('pay_password', {
              initialValue:'',
              rules: [
                {
                  required: true,
                  message: '请输入支付密码'
                },
                {
                  validator: (rule, value, callback) => {
                    if (value && value.length !== 6) {
                      callback('请输入6位密码')
                      return
                    }
                    if (value && Number.isNaN(+value)) {
                      callback('只能输入数字')
                      return
                    }
                    if (value.includes('.')) {
                      callback('只能输入数字')
                      return
                    }
                    callback()
                  }
                }
              ]
            })(<Input type='password' />)}
          </FormItem>
        {/* <FormItem {...formItemLayout} label="支付密码">
          {getFieldDecorator('pay_password', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入支付密码'
              },
              {
                validator: (rule, value, callback) => {
                  if (value && !Number.isInteger(+value)) {
                    callback('只能输入数字');
                    return;
                  }
                  callback();
                }
              }
            ]
          })(<Input />)}
        </FormItem> */}
        {/* <FormItem {...formItemLayout} label="可提现(元)">
          {getFieldDecorator('amount', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入提现金额'
              },
              {
                validator: (rule, value, callback) => {
                  if (
                    Number(value) &&
                    Number(value) >
                      Number(this.props.form.getFieldValue('request_amount'))
                  ) {
                    callback('不能大于充值金额');
                    return;
                  }
                  console.log(value, 'sss');
                  console.log(Number.isInteger(value));

                  if (value && !Number.isInteger(+value)) {
                    callback('只能输入整数金额');
                    return;
                  }
                  callback();
                }
              }
            ]
          })(<Input />)}
        </FormItem> */}
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
