import React from 'react';
import { message, Form, Input, Select, Button, Radio, Modal } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class ClearingRecordTransfer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      statusMap: {
        '-1': '拒绝',
        3: '通过'
      }
    };
  }
  componentDidMount() {}
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (values.status === '3') {
        values.status = values.channel_id === 1 ? 1 : 3;
      }
      if (!err) {
        values.status = +values.status;
        this.props.dispatch({
          type: 'finance/savePlatformTransferDetail',
          payload: {
            ...this.props.finance.platformTransferDetail,
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  // handleSubmit = e => {
  //   e.preventDefault();
  //   this.props.form.validateFields((err, values) => {
  //     if (!err) {
  //       const formItemLayout = {
  //         labelCol: { span: 6 },
  //         wrapperCol: { span: 14 }
  //       }
  //       console.log('values', values)
  //       Modal.confirm({
  //         title: '提交确认',
  //         okText: '确认',
  //         cancelText: '取消',
  //         onOk: () => {
  //           return this.save()
  //         },
  //         content: (
  //           <Form>
  //             <FormItem style={{marginBottom: 0}} {...formItemLayout} label='备注'>
  //               {values.plt_remark}
  //             </FormItem>
  //             <FormItem style={{marginBottom: 0}} {...formItemLayout} label='可提现金额'>
  //               {this.props.finance.findPayChannelAll.odd_amount}
  //             </FormItem>
  //             <FormItem style={{marginBottom: 0}} {...formItemLayout} label='渠道'>
  //               {this.state[values.channel_id]}
  //             </FormItem>
  //             <FormItem style={{marginBottom: 0}} {...formItemLayout} label='状态'>
  //               {this.state.statusMap[values.status]}
  //             </FormItem>
  //           </Form>
  //         )
  //       })
  //     }
  //   })
  // }
  // save = () => {
  //   this.props.form.validateFields((err, values) => {
  //     if (values.status === '3') {
  //       values.status = values.channel_id === 1 ? 1 : 3;
  //     }
  //     if (!err) {
  //       values.status = +values.status;
  //       this.props.dispatch({
  //         type: 'finance/savePlatformTransferDetail',
  //         payload: {
  //           ...this.props.finance.platformTransferDetail,
  //           ...values
  //         },
  //         callback: res => {
  //           if (res.code === 200) {
  //             message.success('保存成功');
  //             if (this.props.onClose) {
  //               this.props.onClose();
  //             }
  //           }
  //         }
  //       })
  //     }
  //   })
  // }
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.findPayChannelAll;
    const infos = this.props.finance.platformTransferDetail;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="商户号">
          {getFieldDecorator('ach_id', {
            initialValue: infos.ach_id,
            rules: [
              {
                required: true,
                message: '请输入商户号'
                // whitespace: true
              }
            ]
          })(<Input disabled placeholder="请输入商户号" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="收款账号">
          {getFieldDecorator('card_no', {
            initialValue: infos.card_no,
            rules: [
              {
                required: true,
                message: '请输入收款账号'
                // whitespace: true
              }
            ]
          })(<Input disabled placeholder="请输入收款账号" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="开户人">
          {getFieldDecorator('card_owner', {
            initialValue: infos.card_owner,
            rules: [
              {
                required: true,
                message: '请输入开户人'
                // whitespace: true
              }
            ]
          })(<Input disabled placeholder="请输入开户人" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="提现金额">
          {getFieldDecorator('amount', {
            initialValue: infos.amount,
            rules: [
              {
                required: true,
                message: '请输入提现金额'
                // whitespace: true
              }
            ]
          })(<Input disabled placeholder="请输入提现金额" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="备注">
          {getFieldDecorator('plt_remark', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入备注'
                // whitespace: true
              }
            ]
          })(<TextArea rows={5} />)}
        </FormItem>
        <FormItem
          {...formItemLayout}
          style={{ color: '#20baf9', paddingLeft: '73px' }}
        >
          <div>
          可提现金额(元)：
          <span>{info.odd_amount ? info.odd_amount : 0}元</span>
          </div> 
          <div>
          已冻结金额(元)：
          <span>{info.total_freeze ? info.total_freeze : 0}元</span>
          </div> 
        </FormItem>
        <FormItem {...formItemLayout} label="渠道">
          {getFieldDecorator('channel_id', {
            initialValue: 1,
            rules: [
              {
                required: true,
                message: '请选择渠道'
                // whitespace: true
              },
              {
                validator: (rule, value, callback) => {
                  if (value === '1') {
                    callback('请选择渠道');
                    return;
                  }
                  callback();
                }
              }
            ]
          })(
            <RadioGroup onChange={this.onChangeBank}>
              {(info.channel ? info.channel : []).map(item => (
                <Radio value={item.id}>{item.name}</Radio>
              ))}
            </RadioGroup>
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="状态">
          {getFieldDecorator('status', {
            initialValue: '3',
            rules: [
              {
                required: true,
                message: '请选择状态'
                // whitespace: true
              }
            ]
          })(
            <RadioGroup>
              <Radio value="3">通过</Radio>
              {this.props.form.getFieldValue('channel_id') !== 1 ? (
                ''
              ) : (
                <Radio value="-1">拒绝</Radio>
              )}
            </RadioGroup>
          )}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
