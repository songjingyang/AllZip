import React from 'react';
import { message, Form, Input, Select, Button, Radio, Modal } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class HistorycomeEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      statusMap: {
        '-1': '拒绝',
        3: '通过'
      }
    };
  }
  componentDidMount() {}
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        values.status = +values.status;
        this.props.dispatch({
          type: 'finance/editHistoryIncome',
          payload: {
            // ...this.infos,
            // ...values
            mac_id:values.mch_id,
            remark:values.plt_remark,
            amount:Number(values.amount),
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.findPayChannelAll;
    const infos =  this.props.finance.HistorycomeEditDto;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="商户名称">
          {getFieldDecorator('mch_id', {
            initialValue: infos.mch_id,
            rules: [
              {
                required: true,
                message: '请输入商户名称'
                // whitespace: true
              }
            ]
          })(<Input disabled placeholder="请输入商户名称" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="历史应收">
          {getFieldDecorator('receivable', {
            initialValue: infos.receivable,
            rules: [
              {
                required: true,
                message: '历史应收'
              }
            ]
          })(<Input disabled placeholder="历史应收" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="历史实收">
          {getFieldDecorator('received', {
            initialValue: infos.received,
            rules: [
              {
                required: true,
                message: '历史实收'
              }
            ]
          })(<Input disabled placeholder="历史实收" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="历史未到账">
          {getFieldDecorator('not_received', {
            initialValue: infos.not_received,
            rules: [
              {
                required: true,
                message: '历史未到账'
              }
            ]
          })(<Input disabled placeholder="历史未到账" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="历史在途">
          {getFieldDecorator('auto_transfer', {
            initialValue: infos.auto_transfer,
            rules: [
              {
                required: true,
                message: '历史在途'
              }
            ]
          })(<Input disabled placeholder="历史在途" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="结算金额">
          {getFieldDecorator('amount', {
            initialValue: infos.amount,
            rules: [
              {
                required: true,
                message: '请输入结算金额'
              }
            ]
          })(<Input placeholder="请输入结算金额" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="备注">
          {getFieldDecorator('plt_remark', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入备注'
                // whitespace: true
              }
            ]
          })(<TextArea rows={5} />)}
        </FormItem>
    
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
