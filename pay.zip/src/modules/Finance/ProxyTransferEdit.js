import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';
import PreviewImg from '@/components/PreviewImg';
import { dateFormater, getTimeDistance } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class ProxyTransferEdit extends React.Component {
  componentDidMount() {
    console.log('transfer', this.props.finance.proxyTransferEditInfo);
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.onClose();
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.proxyTransferEditInfo;
    const info_data = this.props.finance.proxyTransferEdit;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem
          style={{ marginBottom: '15px' }}
          {...formItemLayout}
          label="凭据"
        >
          {getFieldDecorator('ticket')(
            info.ticket ? (
              <PreviewImg src={info.ticket} style={{ height: '50px' }} />
            ) : (
              <span>无</span>
            )
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="金额">
          {getFieldDecorator('price')(
            <span>{info.price ? info.price + '元' : ''}</span>
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="对账码">
          {getFieldDecorator('pay_code')(<span>{info.pay_code}</span>)}
        </FormItem>
        <FormItem {...formItemLayout} label="汇款额度">
          {getFieldDecorator('amount')(
            <span>{info_data.amount ? info_data.amount + '元' : ''}</span>
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="已经收到额度">
          {getFieldDecorator('use_amount')(
            <span>
              {info_data.use_amount ? info_data.use_amount + '元' : ''}
            </span>
          )}
        </FormItem>
        <FormItem {...formItemLayout} label="停止收款时间">
          {getFieldDecorator('stop_unix')(
            <span>{dateFormater(info_data.updated)}</span>
          )}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            关闭
          </Button>
        </FormItem>
      </Form>
    );
  }
}
