import React from 'react';
import {
  Form,
  Radio,
  Button,
  Input,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  Popconfirm,
  Divider
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import PlatformTransferEdit from './PlatformTransferEdit';
import PlatformTransferDetail from './PlatformTransferDetail';
import PlatformTransferInfo from './PlatformTransferInfo';
import HistorycomeEdit from './HistorycomeEdit';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/findMerchantHistoryIncome']
}))
export default class MerchantHistoryIncome extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isBatchtransfer: false,
      isHistorycomeEdit: false,
      statusMap: {
        '-1': '拒绝',
        0: '审核中',
        1: '成功',
        2: '失败',
        3: '处理中',
        4: '待处理',
        5: '审核驳回',
        6: '待审核',
        7: '交易不存在',
        8: '未知状态'
      },
      backoutMap: {
        0: '未撤销',
        1: '已撤销'
      },
      columns: [
        {
          title: '商户id',
          dataIndex: 'mch_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.mch_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '历史周期',
          dataIndex: 'history_period'
        },
        {
          isExpand: true,
          title: '历史应收',
          dataIndex: 'receivable'
        },
        {
          isExpand: true,
          title: '历史实收',
          dataIndex: 'received'
        },
        {
          isExpand: true,
          title: '历史未到账',
          dataIndex: 'not_received'
        },
        {
          isExpand: true,
          title: '历史在途',
          dataIndex: 'auto_transfer'
        },
        {
          isExpand: true,
          title: '最后一个订单',
          dataIndex: 'last_order'
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <div>
              <a
                onClick={() => this.HistorycomeEdit(record)}
                href="javascript:;"
              >
                历史结算
              </a>
            </div>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.findMerchantHistoryIncome();
  }
  findMerchantHistoryIncome = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.finance.platformTransferInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'finance/findMerchantHistoryIncome',
          payload: {
            ...payload
          },
          callback: params.callback
        });
      } else {
        console.log('findMerchantHistoryIncome err');
      }
    });
  };
 
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.findMerchantHistoryIncome(values);
      } else {
        console.log('findMerchantHistoryIncome submit');
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.findMerchantHistoryIncome({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  // 时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  
  isHistorycomeEdit = bool => {
    this.setState({ isHistorycomeEdit: bool });
  };
  HistorycomeEdit = item => {
    this.isHistorycomeEdit(true);
    this.props.dispatch({
      type: 'finance/HistorycomeEditDto',
      payload: {
        ...item
      }
    });

  };

  reload = () => {
    this.isHistorycomeEdit(false);
    this.findMerchantHistoryIncome();
    this.state.pagination.current = 1
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.findMerchantHistoryIncomeInfo;

    return (
      <Card bordered={false}>
        {this.state.isHistorycomeEdit && (
          <Modal
            title="历史收益结算"
            visible={this.state.isHistorycomeEdit}
            onCancel={() => this.isHistorycomeEdit(false)}
            footer={null}
          >
            <HistorycomeEdit
              onClose={this.reload}
            />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="商户" className="form-inline-item">
                    {getFieldDecorator('ach_id', {
                      initialValue: this.props.match.params.account
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
