import React from 'react';
import { message, Form, Input, Select, Button, Radio, Modal } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class PlatformBatchTransferDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      statusMap: {
        '-1': '拒绝',
        3: '通过'
      }
    };
  }
  componentDidMount() {}
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (values.status === '3') {
        values.status = values.channel_id === 1 || values.channel_id === 3 ? 1 : 3;
      }
      if (!err) {
        values.status = +values.status;
        this.props.dispatch({
          type: 'finance/mchBatchTransfer',
          payload: {
            // ...this.infos,
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.findPayChannelAll;
    // debugger
    const plt_trade_id = this.props.finance.getAcmClearMoveByGroupNumInfo.list.plt_trade_id;
    // alert(plt_trade_id)
    
    // const infos = this.props.finance.platformTransferDetail;
    // var infos =  this.props.finance.getPlatformTransferByGroupNumInfo.list
    // if(infos.ach_id==undefined){
    const infos =this.props.finance.platformTransferDetail;
    // }
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="商户名称">
          {getFieldDecorator('bu_name', {
            initialValue: infos.bu_name,
            rules: [
              {
                required: true,
                message: '请输入商户名称'
                // whitespace: true
              }
            ]
          })(<Input disabled placeholder="请输入商户名称" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="总金额">
          {getFieldDecorator('sum_amount', {
            initialValue: infos.sum_amount,
            rules: [
              {
                required: true,
                message: '请输入总金额'
                // whitespace: true
              }
            ]
          })(<Input disabled placeholder="请输入批次号" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="批次号">
          {getFieldDecorator('group_num', {
            initialValue: infos.group_num,
            rules: [
              {
                required: true,
                message: '请输入批次号'
                // whitespace: true
              }
            ]
          })(<Input disabled placeholder="请输入批次号" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="备注">
          {getFieldDecorator('plt_remark', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入备注'
                // whitespace: true
              }
            ]
          })(<TextArea rows={5} />)}
        </FormItem>
        <FormItem
          {...formItemLayout}
          style={{ color: '#20baf9', paddingLeft: '73px' }}
        >
        <div>
          可提现金额：
          <span>{info.odd_amount ? info.odd_amount : 0}元</span>
          </div> 
          <div>
          已冻结金额：
          <span>{info.total_freeze ? info.total_freeze : 0}元</span>
          </div> 
        </FormItem>
   
        <FormItem {...formItemLayout} label="渠道">
        <div>
          {plt_trade_id ? '(代付)':'(提现)'}
          </div> 
          {getFieldDecorator('channel_id', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请选择渠道'
                // whitespace: true
              },
              {
                validator: (rule, value, callback) => {
                  if (value === '1') {
                    callback('请选择渠道');
                    return;
                  }
                  callback();
                }
              }
            ]
          })(
            <RadioGroup onChange={this.onChangeBank} >
              {(info.channel ? info.channel : []).map(item => (
                 item.id ===1 && plt_trade_id ? <Radio disabled value={item.id} >{item.name}</Radio>
                 :  item.id ===3 && !plt_trade_id?
                 <Radio disabled value={item.id} >{item.name}</Radio>
                 : <Radio value={item.id} >{item.name}</Radio>
                // <Radio value={item.id} >{item.name}</Radio>
              ))}
            </RadioGroup>
          )}
        </FormItem>

        <FormItem {...formItemLayout} label="状态">
          {getFieldDecorator('status', {
            initialValue: '3',
            rules: [
              {
                required: true,
                message: '请选择状态'
                // whitespace: true
              }
            ]
          })(
            <RadioGroup>
              <Radio value="3">通过</Radio>
              {this.props.form.getFieldValue('channel_id') === 1 || this.props.form.getFieldValue('channel_id') === 3 ? (
                <Radio value="-1">拒绝</Radio>
              ) : (
                ''
              )}
            </RadioGroup>
          )}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
