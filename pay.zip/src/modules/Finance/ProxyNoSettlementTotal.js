import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm,
  Divider,
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import {
  dateFormater,
  getTimeDistance,
  toSecond,
  getStartTime
} from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import ProxyNoSettlementTotalShow from './ProxyNoSettlementTotalShow';
import ProxyNoSettlementTotalStatus from './ProxyNoSettlementTotalStatus';
import urlMaps, { baseUrl } from '@/common/urlMaps';
import axios from 'axios'

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/getSettlementDetails']
}))
export default class ProxyNoSettlementTotal extends React.Component {
  constructor(props) {
    super(props);

    let now = new Date();
    now.setHours(0);
    now.setMinutes(0);
    now.setSeconds(0);

    this.state = {
      startValue: 0,
      endValue: moment(now.getTime() - 1000),

      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        1: '未结',
        2: '已结'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          isExpand: true,
          title: '结账周期',
          dataIndex: 'time'
        },
        {
          title: '总代',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '代理姓名',
          dataIndex: 'proxy_name'
        },
        {
          title: '团队收益',
          dataIndex: 'team_income'
        },
        {
          isExpand: true,
          title: '团队人数',
          dataIndex: 'team_num',
          render: (text, record) => (
            <Link
              to={{
                pathname: `/finance/sonClearingDetail/${record.account}/${
                  record.time
                }`
              }}
            >
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '创建时间',
          dataIndex: 'created',
          render: text => {
            return <span>{dateFormater(text)}</span>;
          }
        },
        {
          isExpand: true,
          title: '支付方式',
          dataIndex: 'pay_type',
          render: (text, record) => (
            <a onClick={() => this.show(record)} href="javascript:;">
              查看
            </a>
          )
        },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'status',
          render: text => (
            <span>
              {text === 1 && <span style={{ color: 'red' }}>未结</span>}
              {text === 2 && <span style={{ color: 'green' }}>已结</span>}
            </span>
          )
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <span>
              {record.status === 1 ? (
                <div>
                  <Popconfirm
                    title="确定吗？"
                    onConfirm={() => this.changeStatus(record)}
                  >
                    <a href="javascript:;">结算</a>
                  </Popconfirm>
                  <Divider type="vertical" />
                  <a href={baseUrl + urlMaps.download + '?id=' + record.id}>
                    导出Excel
                  </a>      
                  {/* <a onClick={() => this.download(record.id)} >
                    导出Excel
                  </a> */}
                </div>
              ) : (
                <div>
                  <span style={{ color: '#ccc' }}>结算</span>
                  <Divider type="vertical" />
                  {/* <a onClick={() => this.download(record.id)} >
                    导出Excel
                  </a> */}
                  <a href={baseUrl + urlMaps.download + '?id=' + record.id}>
                    导出Excel
                  </a>
                </div>
              )}
            </span>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getSettlementDetails();

    this.props.dispatch({
      type: 'finance/getProxyNoSettlementTotal',
      payload: {},
      callback: res => {
        this.setState({
          startValue: moment((res.data.start_time + 1) * 1000)
        });
      }
    });
  }
  handleChangeDate = date => {};

  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getSettlementDetails();
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getSettlementDetails({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getSettlementDetails = (params = {}) => {
    // window.location.reload()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.finance.proxyNoSettlementTotal.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.billTimeRange) {
          if (payload.billTimeRange.length !== 0) {
            payload.startTm = parseInt(
              payload.billTimeRange[0].valueOf() / 1000
            );
            payload.endTm = parseInt(payload.billTimeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }

        if (payload.searchTimeRange) {
          if (payload.searchTimeRange.length !== 0) {
            payload.startTm = parseInt(
              payload.searchTimeRange[0].valueOf() / 1000
            );
            payload.endTm = parseInt(
              payload.searchTimeRange[1].valueOf() / 1000
            );
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }

        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'finance/getSettlementDetails',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getSettlementDetails parameters error');
      }
    });
    // this.props.dispatch({
    //   type: 'finance/getProxyNoSettlementTotal',
    //   payload: {},
    //   callback: res => {
    //     this.setState(
    //       {
    //         startValue: moment((res.data.start_time + 1) * 1000)
    //       },
    //       () => {
    //         console.log(this.state.startValue);
    //       }
    //     );
    //   }
    // });
    this.setState({
      startValue: moment(
        (this.props.finance.noSettlementTotal.start_time + 1) * 1000
      )
    });
  };
  isShow = bool => {
    this.setState({ isShow: bool });
  };
  show = item => {
    this.isShow(true);
    this.props.dispatch({
      type: 'finance/proxyNoSettlementTotalShow',
      payload: {
        ...item
      }
    });
  };

download = id =>{
  // data为参数
  const data = {
    id: id
  }
  axios.get(
    '/api/v1/xlsxexcel/settlementDetailsDownload',
    {
      params: {
          id: id
      },
      headers: {
        Type: 'mgr'
      }
    }
  ).then(res => {

  }).catch(res => {
    // message.error(res.data.msg)
  })
  // this.props.dispatch({
  //   type: 'finance/settlementDetailsDownload',
  //   payload: {
  //     // ...this.infos,
  //     id :  id
  //   },
    // callback: res => {
    //   debugger
    //   // if (res.code === 200) {
    //   //   message.success('保存成功');
    //   //   if (this.props.onClose) {
    //   //     this.props.onClose();
    //   //   }
    //   // }
    // }
  // });
}
  isChangeStatus = bool => {
    this.setState({ isChangeStatus: bool });
  };
  changeStatus = item => {
    item.status = 2;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'finance/updateProxySettlementStatus',
          payload: {
            id: Number(item.id),
            status: 2
          }
        });
      } else {
        console.log('getPass parameters error');
      }
    });
  };
  // changeStatus = item => {
  //   this.isChangeStatus(true);
  //   this.props.form.validateFields((err, values) => {
  //     if (!err) {
  //       this.props.dispatch({
  //         type: 'finance/proxyNoSettlementTotalStatus',
  //         payload: {
  //           ...item
  //         }
  //       });
  //     } else {
  //       console.log('getPass parameters error');
  //     }
  //   });
  // };
  closeModal = () => {
    this.isShow(false);
  };
  savaChangeStatus = () => {
    this.isChangeStatus(false);
    this.getSettlementDetails();
  };
  //日期限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  //
  range = (start, end) => {
    const result = [];
    for (let i = start; i < end; i++) {
      result.push(i);
    }
    return result;
  };
  disabledRangeTime = (_, type) => {
    if (type === 'start') {
      return {
        disabledHours: () => this.range(0, 60).splice(1, 23),
        disabledMinutes: () => this.range(1, 60),
        disabledSeconds: () => this.range(1, 60)
      };
    }
    return {
      disabledHours: () => this.range(0, 60).splice(0, 23),
      disabledMinutes: () => this.range(0, 59),
      disabledSeconds: () => this.range(0, 59)
    };
  };
  //结算单
  billDownload = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        Modal.confirm({
          title: '确认',
          content: (
            <div>
              {this.state.startValue.format('YYYY-MM-DD HH:mm:ss')}~
              {this.state.endValue.format('YYYY-MM-DD HH:mm:ss')}
            </div>
          ),
          okText: '确认',
          cancelText: '取消',
          onOk: () => {
            this.props.dispatch({
              type: 'finance/buildBill',
              payload: {
                startTm: toSecond(this.state.startValue),
                endTm: toSecond(this.state.endValue) - 1
              },
              callback: res => {
                if (res.code === 200) {
                  Modal.success({
                    content: '订单正在生成中，请稍后刷新列表',
                    onOk: () => {
                      window.location.reload();
                    }
                  });
                }
              }
            });
          }
        });
      }
    });
  };

  onChange = (field, value) => {
    this.setState({
      [field]: value
    });
  };

  onStartChange = value => {
    this.onChange('startValue', value);
  };

  onEndChange = value => {
    this.onChange('endValue', value);
  };

  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.settlementDetails;
    // console.log('info', this.props.finance.noSettlementTotal.StatementTime)

    return (
      <div>
        <Card bordered={false} style={{ marginBottom: 20 }}>
          <div className={'tableList'}>
            <div
              className={classNames({
                tableListForm: !global.isMobile,
                tableListFormMobile: global.isMobile
              })}
            >
              <Form layout={global.form.layout} onSubmit={this.billDownload}>
                <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label="时间范围" className="form-inline-item">
                      {getFieldDecorator('billTimeRange', {
                        initialValue: getStartTime('created')
                      })(
                        <div>
                          <DatePicker
                            disabled
                            disabledDate={this.disabledStartDate}
                            showTime
                            format="YYYY-MM-DD HH:mm:ss"
                            value={this.state.startValue}
                            onChange={this.onStartChange}
                            style={{ marginRight: '10px' }}
                          />
                          <DatePicker
                            disabledDate={this.disabledEndDate}
                            showTime
                            format="YYYY-MM-DD HH:mm:ss"
                            value={this.state.endValue}
                            onChange={this.onEndChange}
                          />
                        </div>
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={6} md={24} sm={24}>
                    <FormItem
                      style={{ fontWeight: 900 }}
                      label="所有代理未结算"
                      className="form-inline-item"
                    >
                      {getFieldDecorator('account')(
                        <pre>
                          {
                            this.props.finance.noSettlementTotal
                              .noSettlementTotal
                          }
                        </pre>
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={6} md={24} sm={24}>
                    <div className={'submitButtons'}>
                      {this.props.finance.noSettlementTotal.StatementTime ===
                      0 ? (
                        <Button type="primary" htmlType="submit">
                          生成结算单
                        </Button>
                      ) : (
                        <Button disabled>账单生成中...</Button>
                      )}
                    </div>
                  </Col>
                </Row>
              </Form>
            </div>
          </div>
        </Card>

        <Card
          title={
            <div>
              已生成结算单
              <a onClick={() => this.getSettlementDetails()}>刷新</a>
            </div>
          }
          bordered={false}
        >
          {this.state.isShow && (
            <Modal
              title={this.props.finance.proxyNoSettlementTotalShow.pay_type}
              visible={this.state.isShow}
              onCancel={() => this.isShow(false)}
              footer={null}
            >
              <ProxyNoSettlementTotalShow onClose={this.closeModal} />
            </Modal>
          )}
          {this.state.isChangeStatus && (
            <Modal
              title="状态"
              visible={this.state.isChangeStatus}
              onCancel={() => this.isChangeStatus(false)}
              footer={null}
            >
              <ProxyNoSettlementTotalStatus onClose={this.savaChangeStatus} />
            </Modal>
          )}
          <div className={'tableList'}>
            <div
              className={classNames({
                tableListForm: !global.isMobile,
                tableListFormMobile: global.isMobile
              })}
            >
              <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
                <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label="时间范围" className="form-inline-item">
                      {getFieldDecorator('searchTimeRange', {
                        initialValue: getTimeDistance('oneMonth'),
                        rules: [
                          {
                            validator: (rule, value, callback) => {
                              let startTm;
                              let endTm;
                              if (value.length !== 0) {
                                startTm = parseInt(value[0].valueOf() / 1000);
                                endTm = parseInt(value[1].valueOf() / 1000);
                                if (endTm - startTm > 90 * 24 * 3600) {
                                  callback('最大范围 3个月');
                                }
                              } else {
                                startTm = 0;
                                endTm = 0;
                              }
                              callback();
                            }
                          }
                        ]
                      })(
                        <RangePicker
                          disabledDate={this.disabledDate}
                          showTime
                          format="YYYY-MM-DD HH:mm:ss"
                        />
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label="状态" className="form-inline-item">
                      {getFieldDecorator('status', {
                        initialValue: ''
                      })(
                        <RadioGroup>
                          <Radio value="">全部</Radio>
                          <Radio value="1">未结</Radio>
                          <Radio value="2">已结</Radio>
                        </RadioGroup>
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label="代理账户" className="form-inline-item">
                      {getFieldDecorator('account')(<Input />)}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <div className={'submitButtons'}>
                      <Button type="primary" htmlType="submit">
                        查询
                      </Button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </div>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </Card>
      </div>
    );
  }
}
