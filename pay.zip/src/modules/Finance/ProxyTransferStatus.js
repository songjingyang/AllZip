import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';
import PreviewImg from '@/components/PreviewImg';
import { dateFormater, getTimeDistance } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class ProxyTransferStatus extends React.Component {
  componentDidMount() {
    console.log(this.props.finance.proxyTransferStatus.status, 'aaaaa');
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        values.id = String(this.props.finance.proxyTransferStatus.id);
        values.status = Number(values.status);
        this.props.dispatch({
          type: 'finance/saveProxyTransferStatus',
          payload: {
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      } else {
        console.log('saveProxyTransferStatus');
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.proxyTransferStatus;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="状态">
          {getFieldDecorator('status', {
            initialValue: '2'
          })(
            <Select>
              <Option value="-1">拒绝</Option>
              <Option value="2">通过</Option>
            </Select>
          )}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
