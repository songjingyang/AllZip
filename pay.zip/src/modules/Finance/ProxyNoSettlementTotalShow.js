import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';
import PreviewImg from '@/components/PreviewImg';
import { dateFormater, getTimeDistance } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class FatherClearingDetailShow extends React.Component {
  componentDidMount() {}
  handleSubmit = e => {
    e.preventDefault();
    this.props.onClose();
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.proxyNoSettlementTotalShow;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="账号">
          {getFieldDecorator('pay_account', {
            initialValue: info.pay_account
          })(<Input disabled />)}
        </FormItem>
        <FormItem {...formItemLayout} label="昵称">
          {getFieldDecorator('pay_name', {
            initialValue: info.pay_name
          })(<Input disabled />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            关闭
          </Button>
        </FormItem>
      </Form>
    );
  }
}
