import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import SonClearingDetailShow from './SonClearingDetailShow';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/getSonClearingDetail']
}))
export default class SonClearingDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        1: '未结',
        2: '已结'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          title: '结账周期',
          dataIndex: 'time'
        },
        {
          isExpand: true,
          title: '总代',
          dataIndex: 'general_agent',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          title: '总代姓名',
          dataIndex: 'general_name'
        },
        {
          isExpand: true,
          title: '代理',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          title: '代理姓名',
          dataIndex: 'proxy_name'
        },
        {
          isExpand: true,
          title: '个人收益',
          dataIndex: 'income'
        },
        {
          isExpand: true,
          title: '创建时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'status',
          render: text => (
            <span>
              {text === 1 && <span style={{ color: 'red' }}>未结</span>}
              {text === 2 && <span style={{ color: 'green' }}>已结</span>}
            </span>
          )
        },
        {
          isExpand: true,
          title: '支付方式',
          dataIndex: 'payType',
          render: (text, record) => (
            <a onClick={() => this.show(record)} href="javascript:;">
              查看
            </a>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getSonClearingDetail();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        // if (!values.page) {
        //   params.page = 1;
        // }
        // if (params.page === 1) {
        //   params.ts = Date.parse(new Date()) / 1000;
        // } else {
        //   params.ts = this.props.finance.sonClearingDetail.ts;
        // }
        // if (!params.pageSize) {
        //   params.pageSize = 20;
        // }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload.time = this.props.match.params.time;
        payload.general_agent = this.props.match.params.account;
        this.props.dispatch({
          type: 'finance/getSonClearingDetail',
          payload: {
            ...payload
          }
        });
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getSonClearingDetail({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getSonClearingDetail = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.finance.sonClearingDetail.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }

        payload = { ...payload, ...params };
        payload.general_agent = this.props.match.params.account;
        payload.time = this.props.match.params.time;

        this.props.dispatch({
          type: 'finance/getSonClearingDetail',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getSonClearingDetail parameters error');
      }
    });
  };
  isShow = bool => {
    this.setState({ isShow: bool });
  };
  show = item => {
    this.isShow(true);
    this.props.dispatch({
      type: 'finance/sonClearingDetailShow',
      payload: {
        ...item
      }
    });
  };
  closeModal = () => {
    this.isShow(false);
  };
  exportExcel = () => {};

  // 时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.sonClearingDetail;

    return (
      <Card bordered={false}>
        {this.state.isShow && (
          <Modal
            // title={
            //   this.state.payMap[
            //     this.props.finance.sonClearingDetailShow.payType
            //   ]
            // }
            title={this.props.finance.proxyNoSettlementTotalShow.pay_type}
            visible={this.state.isShow}
            onCancel={() => this.isShow(false)}
            footer={null}
          >
            <SonClearingDetailShow onClose={this.closeModal} />
          </Modal>
        )}
        <div className={'tableList'}>
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                      initialValue: getTimeDistance('today'),
                      rules: [
                        {
                          validator: (rule, value, callback) => {
                            let startTm;
                            let endTm;
                            if (value.length !== 0) {
                              startTm = parseInt(value[0].valueOf() / 1000);
                              endTm = parseInt(value[1].valueOf() / 1000);
                              if (endTm - startTm > 90 * 24 * 3600) {
                                callback('最大范围 3个月');
                              }
                            } else {
                              startTm = 0;
                              endTm = 0;
                            }
                            callback();
                          }
                        }
                      ]
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        showTime
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="状态" className="form-inline-item">
                    {getFieldDecorator('status', {
                      initialValue: ''
                    })(
                      <RadioGroup>
                        <Radio value="">全部</Radio>
                        <Radio value="1">未结</Radio>
                        <Radio value="2">已结</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="代理账户" className="form-inline-item">
                    {getFieldDecorator('account')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={8} md={24} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
