import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm,
  Divider
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import {
  dateFormater,
  getTimeDistance,
  toSecond,
  getStartTime
} from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import MerchantProxyRemark from './MerchantProxyRemark';
import MerchantProxyInfo from './MerchantProxyInfo';
import MerchantProxyTransfer from './MerchantProxyTransfer';
import urlMaps, { baseUrl } from '@/common/urlMaps';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global
  // loading: loading.effects['finance/getMerchantProxySettlement']
}))
export default class MerchantProxySettlement extends React.Component {
  constructor(props) {
    super(props);
    let now = new Date();
    now.setHours(0);
    now.setMinutes(0);
    now.setSeconds(0);

    this.state = {
      startValue: 0,
      endValue: moment(now.getTime() - 1000),

      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        '-1': '拒绝',
        '-2': '待转账',
        0: '待提现',
        1: '成功',
        2: '失败',
        3: '处理中',
        4: '待处理',
        5: '审核驳回',
        6: '待审核',
        7: '交易不存在',
        8: '未知状态'
      },
      columns: [
        {
          isExpand: true,
          title: '周期',
          dataIndex: 'time'
        },
        {
          isExpand: true,
          title: '商户代理',
          dataIndex: 'ach_proxy_name'
        },
        {
          isExpand: true,
          title: '商户名称',
          dataIndex: 'bu_name'
        },
        {
          isExpand: true,
          title: '渠道',
          dataIndex: 'channel_name'
        },
        {
          isExpand: true,
          title: '银行',
          dataIndex: 'way_name'
        },
        {
          isExpand: true,
          title: '收款账户',
          dataIndex: 'bank_card'
        },
        {
          isExpand: true,
          title: '开户人',
          dataIndex: 'open'
        },
        {
          isExpand: true,
          title: '金额',
          dataIndex: 'amount_total'
        },
        {
          isExpand: true,
          title: '商户点数',
          dataIndex: 'ach_rate_vag',
          filterDropdown: () => (
            <div className="custom-filter-dropdown">
              此点数为平均商户点数，不作为代理收入的依据
            </div>
          ),
          filterIcon: filtered => (
            <Icon
              type="info-circle"
              style={{ color: filtered ? '#108ee9' : '#fdc73e' }}
            />
          ),
          render: text => <span>{text}%</span>
        },
        {
          isExpand: true,
          title: '商户代理点数',
          dataIndex: 'agent_rate_vag',
          filterDropdown: () => (
            <div className="custom-filter-dropdown">
              此点数为平均商户代理点数，不作为代理收入的依据
            </div>
          ),
          filterIcon: filtered => (
            <Icon
              type="info-circle"
              style={{ color: filtered ? '#108ee9' : '#fdc73e' }}
            />
          ),
          render: text => <span>{text}%</span>
        },
        {
          isExpand: true,
          title: '代理收入',
          dataIndex: 'agent_earnings_total'
        },
        {
          isExpand: true,
          title: '创建时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '备注',
          dataIndex: '',
          render: (text, record) => (
            <a onClick={() => this.remark(record)} href="javascript:;">
              查看
            </a>
          )
        },
        {
          isExpand: true,
          title: '转账状态',
          dataIndex: 'status',
          render: text => <span>{this.state.statusMap[text]}</span>
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <div>
              {record.status === -2 ? (
                <a onClick={() => this.transfer(record)} href="javascript:;">
                  转账
                </a>
              ) : record.status !== 0 &&
              record.status !== 1 &&
              record.status !== 2 ? (
                record.channel_name === '平台' ? (
                  <span style={{ color: '#ccc' }}>转账</span>
                ) : (
                  <div>
                    <span style={{ color: '#ccc' }}>转账</span>
                    <Divider type="vertical" />
                    <a onClick={() => this.info(record)} href="javascript:;">
                      查看
                    </a>
                  </div>
                )
              ) : (
                <span style={{ color: '#ccc' }}>转账</span>
              )}
            </div>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getMerchantProxySettlement();
    this.getStartTime();
    this.props.dispatch({
      type: 'finance/getFindPayChannelAll',
      payload: {}
    });
  }
  getStartTime = () => {
    this.props.dispatch({
      type: 'finance/getAchProxyTime',
      payload: {},
      callback: res => {
        this.setState({
          startValue: moment(res.data.end_time * 1000)
        });
      }
    });
  };
  handleChangeDate = date => {};

  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getMerchantProxySettlement();
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getMerchantProxySettlement({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getMerchantProxySettlement = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.finance.merchantProxySettlementList.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.billTimeRange) {
          if (payload.billTimeRange.length !== 0) {
            payload.startTm = parseInt(
              payload.billTimeRange[0].valueOf() / 1000
            );
            payload.endTm = parseInt(payload.billTimeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }

        if (payload.searchTimeRange) {
          if (payload.searchTimeRange.length !== 0) {
            payload.startTm = parseInt(
              payload.searchTimeRange[0].valueOf() / 1000
            );
            payload.endTm = parseInt(
              payload.searchTimeRange[1].valueOf() / 1000
            );
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'finance/getMerchantProxySettlement',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getMerchantProxySettlement parameters error');
      }
    });
    console.log('dadada', this.props.finance.achProxyTime);
    this.setState({
      startValue: moment(this.props.finance.achProxyTime.end_time * 1000)
    });
  };

  isRemark = bool => {
    this.setState({ isRemark: bool });
  };

  remark = item => {
    this.isRemark(true);
    this.props.dispatch({
      type: 'finance/merchantProxyRemark',
      payload: {
        ...item
      }
    });
  };
  isInfo = bool => {
    this.setState({ isInfo: bool });
  };
  info = item => {
    this.isInfo(true);
    this.props.dispatch({
      type: 'finance/searchTransfer',
      payload: {
        id: +item.id
      }
    });
  };
  isTransfer = bool => {
    this.setState({ isTransfer: bool });
  };
  transfer = item => {
    this.isTransfer(true);
    this.props.dispatch({
      type: 'finance/merchantProxyTransfer',
      payload: {
        ...item
      }
    });
    // 渠道接口
    this.props.dispatch({
      type: 'finance/getFindPayChannelAll',
      payload: {
        ach_id: item.ach_id
      }
    });
  };
  closeRemark = () => {
    this.isRemark(false);
  };
  savaTransfer = () => {
    this.isTransfer(false);
    this.isInfo(false);
    this.getMerchantProxySettlement();
  };
  //日期限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  //
  range = (start, end) => {
    const result = [];
    for (let i = start; i < end; i++) {
      result.push(i);
    }
    return result;
  };
  disabledRangeTime = (_, type) => {
    if (type === 'start') {
      return {
        disabledHours: () => this.range(0, 60).splice(1, 23),
        disabledMinutes: () => this.range(1, 60),
        disabledSeconds: () => this.range(1, 60)
      };
    }
    return {
      disabledHours: () => this.range(0, 60).splice(0, 23),
      disabledMinutes: () => this.range(0, 59),
      disabledSeconds: () => this.range(0, 59)
    };
  };
  //结算单
  billDownload = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        Modal.confirm({
          title: '确认',
          content: (
            <div>
              {this.state.startValue.format('YYYY-MM-DD HH:mm:ss')}~
              {this.state.endValue.format('YYYY-MM-DD HH:mm:ss')}
            </div>
          ),
          okText: '确认',
          cancelText: '取消',
          onOk: () => {
            this.props.dispatch({
              type: 'finance/buildSettlement',
              payload: {
                start_time: +toSecond(this.state.startValue),
                end_time: toSecond(this.state.endValue) - 1
              },
              callback: res => {
                if (res.code === 200) {
                  Modal.success({
                    content: '订单正在生成中，请稍后刷新列表',
                    onOk: () => {
                      window.location.reload();
                    }
                  });
                }
              }
            });
          }
        });
      }
    });
  };

  onChange = (field, value) => {
    this.setState(
      {
        [field]: value
      },
      () => {
        console.log(this.state.endValue);
      }
    );
  };

  onStartChange = value => {
    this.onChange('startValue', value);
  };

  onEndChange = value => {
    this.onChange('endValue', value);
  };

  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.merchantProxySettlementList;
    const achProxyTime = this.props.finance.achProxyTime.end_time;

    return (
      <div>
        <Card bordered={false} style={{ marginBottom: 20 }}>
          <div className={'tableList'}>
            <div
              className={classNames({
                tableListForm: !global.isMobile,
                tableListFormMobile: global.isMobile
              })}
            >
              <Form layout={global.form.layout} onSubmit={this.billDownload}>
                <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label="时间范围" className="form-inline-item">
                      {getFieldDecorator('billTimeRange', {
                        initialValue: getStartTime('created')
                      })(
                        <div>
                          <DatePicker
                            disabled={achProxyTime === 0 ? '' : 'disabled'}
                            disabledDate={this.disabledStartDate}
                            showTime
                            format="YYYY-MM-DD HH:mm:ss"
                            value={this.state.startValue}
                            onChange={this.onStartChange}
                            style={{ marginRight: '10px' }}
                          />
                          <DatePicker
                            disabledDate={this.disabledEndDate}
                            showTime
                            format="YYYY-MM-DD HH:mm:ss"
                            value={this.state.endValue}
                            onChange={this.onEndChange}
                          />
                        </div>
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <div className={'submitButtons'}>
                      <Button type="primary" htmlType="submit">
                        结算
                      </Button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </div>
          </div>
        </Card>

        <Card
          title={
            <div>
              已生成结算单
              <a onClick={() => this.getMerchantProxySettlement()}>刷新</a>
            </div>
          }
          bordered={false}
        >
          {this.state.isRemark && (
            <Modal
              title="查看"
              visible={this.state.isRemark}
              onCancel={() => this.isRemark(false)}
              footer={null}
            >
              <MerchantProxyRemark onClose={this.closeRemark} />
            </Modal>
          )}
          {this.state.isTransfer && (
            <Modal
              title="转账"
              visible={this.state.isTransfer}
              onCancel={() => this.isTransfer(false)}
              footer={null}
            >
              <MerchantProxyTransfer onClose={this.savaTransfer} />
            </Modal>
          )}
          {this.state.isInfo && (
            <Modal
              title="查看"
              visible={this.state.isInfo}
              onCancel={() => this.isInfo(false)}
              footer={null}
            >
              <MerchantProxyInfo onClose={this.savaTransfer} />
            </Modal>
          )}
          <div className={'tableList'}>
            <div
              className={classNames({
                tableListForm: !global.isMobile,
                tableListFormMobile: global.isMobile
              })}
            >
              <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
                <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label="时间范围" className="form-inline-item">
                      {getFieldDecorator('searchTimeRange', {
                        initialValue: getTimeDistance('oneMonth'),
                        rules: [
                          {
                            validator: (rule, value, callback) => {
                              let startTm;
                              let endTm;
                              if (value.length !== 0) {
                                startTm = parseInt(value[0].valueOf() / 1000);
                                endTm = parseInt(value[1].valueOf() / 1000);
                                if (endTm - startTm > 90 * 24 * 3600) {
                                  callback('最大范围 3个月');
                                }
                              } else {
                                startTm = 0;
                                endTm = 0;
                              }
                              callback();
                            }
                          }
                        ]
                      })(
                        <RangePicker
                          disabledDate={this.disabledDate}
                          showTime
                          format="YYYY-MM-DD HH:mm:ss"
                        />
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label="状态" className="form-inline-item">
                      {getFieldDecorator('status', {
                        initialValue: '-3'
                      })(
                        <Select>
                          <Option value="-3">全部</Option>
                          <Option value="-1">拒绝</Option>
                          <Option value="-2">待转账</Option>
                          <Option value="0">待提现</Option>
                          <Option value="1">成功</Option>
                          <Option value="2">失败</Option>
                          <Option value="3">处理中</Option>
                          <Option value="4">待处理</Option>
                          <Option value="5">审核驳回</Option>
                          <Option value="6">待审核</Option>
                          <Option value="7">交易不存在</Option>
                          <Option value="8">未知状态</Option>
                        </Select>
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label="渠道" className="form-inline-item">
                      {getFieldDecorator('pay_channel_id', {
                        initialValue: ''
                      })(
                        <Select>
                          <Option value="">全部</Option>
                          {this.props.finance.findPayChannelAll.channel.map(
                            item => (
                              <Option value={item.id}>{item.name}</Option>
                            )
                          )}
                        </Select>
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <div className={'submitButtons'}>
                      <Button type="primary" htmlType="submit">
                        查询
                      </Button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </div>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </Card>
      </div>
    );
  }
}
