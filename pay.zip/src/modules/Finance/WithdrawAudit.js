import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
// import OrderInfoEdit from './OrderInfoEdit';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/getWithdrawAuditList']
}))
export default class WithdrawAudit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      batch_columns: [
        {
          isExpand: true,
          title: '批次',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '商户名称',
          dataIndex: 'ach_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '总数量',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '成功',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '失败',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '处理中',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '待处理',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '审核驳回',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '待审核',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '交易不存在',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '未知状态',
          dataIndex: 'status'
        },
        {
          isExpand: true,
          title: '创建时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <div>
              <Popconfirm title="确定吗?" onConfirm={() => this.notify(record)}>
                <a href="javascript:;">通过</a>
              </Popconfirm>
              <Popconfirm title="确定吗?" onConfirm={() => this.notify(record)}>
                <a href="javascript:;">刷新</a>
              </Popconfirm>
              <Popconfirm title="确定吗?" onConfirm={() => this.notify(record)}>
                <a href="javascript:;">Excel</a>
              </Popconfirm>
            </div>
          )
        }
      ],
      withdraw_columns: [
        {
          isExpand: true,
          title: '商户名称',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '订单号',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '开户行名称',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '支行名称',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '开户名',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '银行卡号',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '身份',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '城市',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '金额（元）',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '申请时间',
          dataIndex: 'edit',
          render: text => <span>{text}</span>
        },
        {
          isExpand: true,
          title: '处理时间',
          dataIndex: 'edit',
          render: text => <span>{text}</span>
        },
        {
          isExpand: true,
          title: '扩展信息',
          dataIndex: 'extend',
          render: (text, record) => (
            <a onClick={() => this.extend(record)} href="javascript:;">
              查看
            </a>
          )
        }
      ],
      excel_columns: [
        {
          isExpand: true,
          title: '开户行名称',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '支行名称',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '开户名',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '银行卡号',
          dataIndex: 'edit'
        },
        {
          isExpand: true,
          title: '省份',
          dataIndex: 'province'
        },
        {
          isExpand: true,
          title: '城市',
          dataIndex: 'city'
        },
        {
          isExpand: true,
          title: '金额',
          dataIndex: 'amount'
        }
      ]
    };
  }
  componentDidMount() {
    this.getWithdrawAuditList();
  }
  getWithdrawAuditList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.order.orderInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'finance/getWithdrawAuditList',
          payload: {
            ...payload
          },
          callback: params.callback
        });
      } else {
        console.log('getWithdrawAuditList err');
      }
    });
  };
  isExtend = bool => {
    this.setState({ isExtend: bool });
  };
  extend = item => {
    this.isExtend(true);
    this.props.dispatch({
      type: 'finance/orderInfoEdit',
      payload: {
        ...item
      }
    });
  };
  closeExtend = () => {
    this.isExtend(false);
  };
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getWithdrawAuditList(values);
      } else {
        console.log('123');
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getWithdrawAuditList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  // 时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.withdrawAuditListInfo;
    return (
      <Card bordered={false} title="">
        {this.state.isEdit && (
          <Modal
            width={800}
            title="其他信息"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            {/* <OrderInfoEdit onClose={this.closeEdit} /> */}
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                      initialValue: getTimeDistance('today'),
                      rules: [
                        {
                          validator: (rule, value, callback) => {
                            let startTm;
                            let endTm;
                            if (value.length !== 0) {
                              startTm = parseInt(value[0].valueOf() / 1000);
                              endTm = parseInt(value[1].valueOf() / 1000);
                              if (endTm - startTm > 90 * 24 * 3600) {
                                callback('最大范围 3个月');
                              }
                            } else {
                              startTm = 0;
                              endTm = 0;
                            }
                            callback();
                          }
                        }
                      ]
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        showTime
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col xl={8} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            title={() => '批次列表'}
            columns={this.state.batch_columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
          <SimpleTable
            title={() => '出金列表'}
            columns={this.state.withdraw_columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
          <SimpleTable
            title={() => 'Excel'}
            columns={this.state.excel_columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
