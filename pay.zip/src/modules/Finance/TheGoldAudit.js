import React from 'react';
import {
  Form,
  Radio,
  Button,
  Input,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  Popconfirm,
  Divider
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import PlatformTransferEdit from './PlatformTransferEdit';
import PlatformTransferDetail from './PlatformTransferDetail';
import PlatformTransferInfo from './PlatformTransferInfo';
import TheGoldAuditTransferDetail from './TheGoldAuditTransferDetail';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/getTheGoldAuditInfo']
}))
export default class TheGoldAudit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isBatchtransfer: false,
      statusMap: {
        '-1': '拒绝',
        0: '审核中',
        1: '成功',
        2: '失败',
        3: '处理中',
        4: '待处理',
        5: '审核驳回',
        6: '待审核',
        7: '交易不存在',
        8: '未知状态'
      },
      backoutMap: {
        0: '未撤销',
        1: '已撤销'
      },
      columns: [
        {
          isExpand: true,
          title: '批次',
          dataIndex: 'group_num',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/-3` }}
            >
              {text}
            </Link>
          )
        },
        {
          title: '商户id',
          dataIndex: 'ach_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '商户名称',
          dataIndex: 'bu_name'
        },
        {
          isExpand: true,
          title: '总金额',
          dataIndex: 'sum_amount'
        },
        {
          isExpand: true,
          title: '总数量',
          dataIndex: 'counts',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/-3` }}
            >
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '拒绝',
          dataIndex: 'refuse',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/-1` }}
            >
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '审核中',
          dataIndex: 'in_the_review',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/0` }}
            >
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '成功',
          dataIndex: 'success',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/1` }}
            >
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '失败',
          dataIndex: 'fail',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/2` }}
            >
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '处理中',
          dataIndex: 'processing',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/3` }}
            >
              {text}
            </Link>
          )
        },
        {
          title: '待处理',
          dataIndex: 'to_be_processed',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/4` }}
            >
              {text}
            </Link>
          )
        },
        {
          title: '审核驳回',
          dataIndex: 'rejected',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/5` }}
            >
              {text}
            </Link>
          )
        },
        {
          title: '待审核',
          dataIndex: 'to_audit',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/6` }}
            >
              {text}
            </Link>
          )
        },
        {
          title: '交易不存在',
          dataIndex: 'trade_not_exists',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/7` }}
            >
              {text}
            </Link>
          )
        },
        {
          title: '未知状态',
          dataIndex: 'unknown_state',
          render: (text, record) => (
            <Link
              to={{ pathname: `/finance/platformTransfer/${record.group_num}/8` }}
            >
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '创建时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <div>
              {record.in_the_review === record.counts ? (
                <a
                  onClick={() => this.Batchtransfer(record)}
                  href="javascript:;"
                >
                  通过
                </a>
              ) : (
                <span style={{ color: '#ccc' }}>通过</span>
              )}
            </div>
            // <div>
            //   {record.status === 0 ? (
            //     record.backout === 0 ? (
            //       <a onClick={() => this.transfer(record)} href="javascript:;">
            //         转账
            //       </a>
            //     ) : (
            //       <span style={{ color: '#ccc' }}>转账</span>
            //     )
            //   ) : record.status !== 1 && record.status !== 2 ? (
            //     record.channel_name === '平台' ? (
            //       <span style={{ color: '#ccc' }}>转账</span>
            //     ) : (
            //       <div>
            //         <span style={{ color: '#ccc' }}>转账</span>
            //         <Divider type="vertical" />
            //         <a onClick={() => this.info(record)} href="javascript:;">
            //           查看
            //         </a>
            //       </div>
            //     )
            //   ) : (
            //     <span style={{ color: '#ccc' }}>转账</span>
            //   )}
            // </div>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getTheGoldAuditInfo();
  }
  getTheGoldAuditInfo = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.finance.platformTransferInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'finance/getTheGoldAuditInfo',
          payload: {
            ...payload
          },
          callback: params.callback
        });
      } else {
        console.log('getTheGoldAuditInfo err');
      }
    });
  };
  // isEdit = bool => {
  //   this.setState({ isEdit: bool });
  // };
  // edit = item => {
  //   this.isEdit(true);
  //   this.props.dispatch({
  //     type: 'finance/platformTransferEditInfo',
  //     payload: {
  //       ...item
  //     }
  //   });
  // };
  // isTransfer = bool => {
  //   this.setState({ isTransfer: bool });
  // };
  // transfer = item => {
  //   this.isTransfer(true);
  //   this.props.dispatch({
  //     type: 'finance/platformTransferDetail',
  //     payload: {
  //       ...item
  //     }
  //   });
  //   // 渠道接口
  //   this.props.dispatch({
  //     type: 'finance/getFindPayChannelAll',
  //     payload: {
  //       ach_id: item.ach_id
  //     }
  //   });
  // };
  isBatchtransfer = bool => {
    this.setState({ isBatchtransfer: bool });
  };
  Batchtransfer = item => {
    this.isBatchtransfer(true);
    this.props.dispatch({
      type: 'finance/platformTransferDetail',
      payload: {
        ...item
      }
    });
    // 渠道接口
    this.props.dispatch({
      type: 'finance/getFindPayChannelAll',
      payload: {
        ach_id: item.ach_id,
        group_num: item.group_num

      }
    });
    // 
    this.props.dispatch({
      type: 'finance/getAcmClearMoveByGroupNum',
      payload: {
        group_num: item.group_num
      }
    });
  };
  addPlatformTransferInfo = () => {
    this.isBatchtransfer(false);
    this.getTheGoldAuditInfo();
    this.state.pagination.current = 1
  };
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getTheGoldAuditInfo(values);
      } else {
        console.log('getTheGoldAuditInfo submit');
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getTheGoldAuditInfo({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  // 时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.getTheGoldAuditInfos;

    return (
      <Card bordered={false}>
        {this.state.isBatchtransfer && (
          <Modal
            title="批次号转账"
            visible={this.state.isBatchtransfer}
            onCancel={() => this.isBatchtransfer(false)}
            footer={null}
          >
            <TheGoldAuditTransferDetail
              onClose={this.addPlatformTransferInfo}
            />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                      initialValue: getTimeDistance('today'),
                      rules: [
                        {
                          validator: (rule, value, callback) => {
                            let startTm;
                            let endTm;
                            if (value.length !== 0) {
                              startTm = parseInt(value[0].valueOf() / 1000);
                              endTm = parseInt(value[1].valueOf() / 1000);
                              if (endTm - startTm > 90 * 24 * 3600) {
                                callback('最大范围 3个月');
                              }
                            } else {
                              startTm = 0;
                              endTm = 0;
                            }
                            callback();
                          }
                        }
                      ]
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        showTime
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="商户" className="form-inline-item">
                    {getFieldDecorator('ach_id', {
                      initialValue: this.props.match.params.account
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="批次号" className="form-inline-item">
                    {getFieldDecorator('group_num', {
                      initialValue: this.props.match.params.group_num
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    {/* <Button
                      onClick={() => {
                        this.Batchtransfer();
                      }}
                      type="primary"
                      // htmlType="button"
                    >
                      上传批次号转账
                    </Button>
                    &nbsp;&nbsp;&nbsp; */}
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
