import React from 'react';
import { message, Form, Input, Select, Button, Radio, Modal } from 'antd';
import { connect } from 'dva';
import { debug } from 'util';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ finance }) => ({
  finance
}))
export default class MerchantProxyTransfer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      statusMap: {
        '-1': '拒绝',
        3: '通过'
      }
    };
  }
  componentDidMount() {}
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (values.status === '3') {
        values.status = values.channel_id === 1 ? 1 : 3;
      }
      values.id = +this.props.finance.merchantProxyTransfer.id;
      values.status = +values.status;
      if (!err) {
        this.props.dispatch({
          type: 'finance/mchProxyTransfer',
          payload: {
            ...this.props.finance.mchProxyTransferInfo,
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.findPayChannelAll;
    const proxySettlement = this.props.finance.merchantProxyTransfer;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem
          style={{ marginBottom: 10 }}
          {...formItemLayout}
          label="收款账户"
        >
          {getFieldDecorator('bank_card', {
            initialValue: ''
          })(<span>{proxySettlement.bank_card}</span>)}
        </FormItem>
        <FormItem
          style={{ marginBottom: 10 }}
          {...formItemLayout}
          label="开户人"
        >
          {getFieldDecorator('open', {
            initialValue: ''
          })(<span>{proxySettlement.open}</span>)}
        </FormItem>
        <FormItem
          style={{ marginBottom: 10 }}
          {...formItemLayout}
          label="代理收入"
        >
          {getFieldDecorator('agent_earnings_total', {
            initialValue: ''
          })(<span>{proxySettlement.agent_earnings_total}</span>)}
        </FormItem>
        {/* <FormItem
          {...formItemLayout}
          style={{ marginBottom: 10, color: '#20baf9', paddingLeft: '73px' }}
        >
          可提现金额(元)：
          <span>{info.odd_amount ? info.odd_amount : 0}元</span>
        </FormItem> */}
        <FormItem style={{ marginBottom: 10 }} {...formItemLayout} label="渠道">
          {getFieldDecorator('channel_id', {
            initialValue: 1,
            rules: [
              {
                required: true,
                message: '请选择渠道'
                // whitespace: true
              },
              {
                validator: (rule, value, callback) => {
                  if (value === '1') {
                    callback('请选择渠道');
                    return;
                  }
                  callback();
                }
              }
            ]
          })(
            <RadioGroup onChange={this.onChangeBank}>
              {(info.channel ? info.channel : []).map(item => (
                item.id ===3 ?
                 <Radio disabled value={item.id} >{item.name}</Radio>
                 : <Radio value={item.id} >{item.name}</Radio>
                // <Radio value={item.id}>{item.name}</Radio>
              ))}
            </RadioGroup>
          )}
        </FormItem>
        <FormItem style={{ marginBottom: 10 }} {...formItemLayout} label="状态">
          {getFieldDecorator('status', {
            initialValue: '3'
          })(
            <RadioGroup>
              <Radio value="3">通过</Radio>
              {this.props.form.getFieldValue('channel_id') !== 1 ? (
                ''
              ) : (
                <Radio value="-1">拒绝</Radio>
              )}
            </RadioGroup>
          )}
        </FormItem>
        <FormItem style={{ marginBottom: 10 }} {...formItemLayout} label="备注">
          {getFieldDecorator('plt_remark', {
            initialValue: '',
            rules: [
              {
                required: true,
                message: '请输入备注'
                // whitespace: true
              }
            ]
          })(<TextArea rows={3} />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
