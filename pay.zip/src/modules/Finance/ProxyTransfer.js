import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Divider,
  Row,
  Col,
  Modal,
  message,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import PreviewImg from '@/components/PreviewImg';
import ProxyTransferEdit from './ProxyTransferEdit';
import ProxyTransferStatus from './ProxyTransferStatus';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ finance, global, loading }) => ({
  finance,
  global,
  loading: loading.effects['finance/getProxyTransferInfo']
}))
export default class ProxyTransfer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isEdit: false,
      isChangeStatus: false,
      statusMap: {
        0: '没有上传凭证',
        1: '未处理',
        2: '已处理',
        '-1': '已拒绝'
      },
      backoutMap: {
        0: '未撤销',
        1: '已撤销'
      },
      columns: [
        {
          isExpand: true,
          title: '流水ID',
          dataIndex: 'id'
        },
        {
          isExpand: true,
          title: '结算日期',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          title: '代理账号',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '代理姓名',
          dataIndex: 'proxy_name'
        },
        {
          isExpand: true,
          title: '商户',
          dataIndex: 'ach_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '银行',
          dataIndex: 'pay_info.type_name'
        },
        {
          isExpand: true,
          title: '账号',
          dataIndex: 'pay_info.account'
        },
        {
          title: '付款人',
          dataIndex: 'open'
        },
        {
          title: '金额',
          dataIndex: 'price'
        },
        {
          isExpand: true,
          title: '对账码',
          dataIndex: 'pay_code'
        },
        {
          isExpand: true,
          title: '凭据',
          dataIndex: 'ticket',
          render: text =>
            text === '' ? (
              '无'
            ) : (
              <PreviewImg src={text} style={{ height: '50px' }} />
            )
        },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'status',
          render: text => <span>{this.state.statusMap[text]}</span>
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <a onClick={() => this.edit(record)} href="javascript:;">
              查看
            </a>
          )
        },
        // {
        //   isExpand: true,
        //   title: '操作人',
        //   dataIndex: ''
        // },
        // {
        //   isExpand: true,
        //   title: '审核',
        //   dataIndex: '',
        //   render: (text, record) => (
        //     <a onClick={() => this.changeStatus(record)} href="javascript:;">
        //       编辑
        //     </a>
        //   )
        // },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => {
            return (
              <span>
                {record.status === -1 && (
                  <span style={{ color: 'red' }}>已拒绝</span>
                )}
                {record.status === 2 && (
                  <span style={{ color: 'green' }}>已通过</span>
                )}
                {record.status === 0 && (
                  <div>
                    <Popconfirm
                      title="确定吗？"
                      onConfirm={() => this.pass(record)}
                    >
                      <a href="javascript:;">通过</a>
                    </Popconfirm>
                    <Divider type="vertical" />
                    <Popconfirm
                      title="确定吗？"
                      onConfirm={() => this.refuse(record)}
                    >
                      <a href="javascript:;">拒绝</a>
                    </Popconfirm>
                  </div>
                )}
                {record.status === 1 && (
                  <div>
                    <Popconfirm
                      title="确定吗？"
                      onConfirm={() => this.pass(record)}
                    >
                      <a href="javascript:;">通过</a>
                    </Popconfirm>
                    <Divider type="vertical" />
                    <Popconfirm
                      title="确定吗？"
                      onConfirm={() => this.refuse(record)}
                    >
                      <a href="javascript:;">拒绝</a>
                    </Popconfirm>
                  </div>
                )}
              </span>
            );
          }
        }
      ]
    };
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'finance/getBankList'
    });
    // this.handleLast1Hours()
    this.getProxyTransferInfo();
  }
  getProxyTransferInfo = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.finance.proxyTransferInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'finance/getProxyTransferInfo',
          payload: {
            ...payload
          },
          callback: params.callback
        });
      } else {
        console.log('getProxyTransferInfo err');
      }
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'finance/proxyTransferEditInfo',
      payload: {
        ...item
      }
    });
    this.props.dispatch({
      type: 'finance/getProxyTransferEdit',
      payload: {
        id: item.pay_info.id
      }
    });
  };
  isChangeStatus = bool => {
    this.setState({ isChangeStatus: bool });
  };
  changeStatus = item => {
    this.isChangeStatus(true);
    this.props.dispatch({
      type: 'finance/proxyTransferStatus',
      payload: {
        ...item
      }
    });
  };
  closeProxyTransferEdit = () => {
    this.isEdit(false);
  };
  changeProxyTransfer = () => {
    this.isEdit(false);
    this.isChangeStatus(false);
    this.getProxyTransferInfo();
  };
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    // this.props.form.setFieldsValue({
    //   timeRange: [
    //     moment(new Date().getTime() - 3600000),
    //     moment(new Date().getTime())
    //   ]
    // })
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getProxyTransferInfo(values);
      } else {
        console.log('getProxyTransferInfo');
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getProxyTransferInfo({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  // 时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  pass = item => {
    item.status = 2;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'finance/getProxyTransferPass',
          payload: {
            id: String(item.id),
            status: 2
          }
        });
      } else {
        console.log('getPass parameters error');
      }
    });
  };
  refuse = item => {
    item.status = -1;
    // this.props.dispatch({
    //   type: 'finance/deleteProxyTransfer',
    //   payload: {
    //       ...item
    //   }
    // })
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'finance/getProxyTransferRefuse', //qrAudit
          payload: {
            id: String(item.id),
            status: -1
          }
        });
      } else {
        console.log('getRefuse parameters error');
      }
    });
  };
  onChangeBank = e => {
    this.props.form.setFieldsValue({
      card_no: '',
      card_owner: '',
      amount: '',
      ach_remark: ''
    });
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.finance.proxyTransferInfo;
    return (
      <Card bordered={false}>
        {this.state.isEdit && (
          <Modal
            title="其他信息"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <ProxyTransferEdit onClose={this.closeProxyTransferEdit} />
          </Modal>
        )}
        {this.state.isChangeStatus && (
          <Modal
            title="编辑"
            visible={this.state.isChangeStatus}
            onCancel={() => this.isChangeStatus(false)}
            footer={null}
          >
            <ProxyTransferStatus onClose={this.changeProxyTransfer} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                      initialValue: getTimeDistance('today'),
                      rules: [
                        {
                          validator: (rule, value, callback) => {
                            let startTm;
                            let endTm;
                            if (value.length !== 0) {
                              startTm = parseInt(value[0].valueOf() / 1000);
                              endTm = parseInt(value[1].valueOf() / 1000);
                              if (endTm - startTm > 90 * 24 * 3600) {
                                callback('最大范围 3个月');
                              }
                            } else {
                              startTm = 0;
                              endTm = 0;
                            }
                            callback();
                          }
                        }
                      ]
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        showTime
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col md={12} sm={24}>
                  <FormItem label="审核状态" className="form-inline-item">
                    {getFieldDecorator('status', {
                      initialValue: '3'
                    })(
                      <RadioGroup>
                        <Radio value="3">全部</Radio>
                        <Radio value="0">未上传凭证</Radio>
                        <Radio value="1">未处理</Radio>
                        <Radio value="2">已通过</Radio>
                        <Radio value="-1">已拒绝</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="商户ID" className="form-inline-item">
                    {getFieldDecorator('ach_id', {
                      initialValue: this.props.match.params.account
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="代理ID" className="form-inline-item">
                    {getFieldDecorator('account')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="银行" className="form-inline-item">
                    {getFieldDecorator('bank', {
                      initialValue: ''
                    })(
                      <Select
                        placeholder="请选择银行"
                        onChange={this.onChangeBank}
                      >
                        <Option value="">全部</Option>
                        {this.props.finance.bankListInfo.list.map(item => (
                          <Option key={item.id} value={item.name}>
                            {item.name}
                          </Option>
                        ))}
                      </Select>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
