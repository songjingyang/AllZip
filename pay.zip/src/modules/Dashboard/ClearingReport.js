import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Alert,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ stat, global, loading }) => ({
  stat,
  global,
  loading: loading.effects['stat/getClearingReport']
}))
export default class ClearingReport extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      statusMap: {
        0: '结算中',
        1: '结算完成'
      },
      loading: false,
      columns_nowList: [
        {
          isExpand: true,
          title: '商户',
          dataIndex: 'ach_id'
        },
        {
          title: '当前账期',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '成单额',
          dataIndex: 'amount'
        },
        {
          isExpand: true,
          title: '先期回款',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '在途回款',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '历史未结',
          dataIndex: 'his_amount'
        },
        {
          title: '操作',
          dataIndex: '',
          render: (text, record) => {
            return (
              <Popconfirm title="确定吗?" onConfirm={() => this.notify(record)}>
                <a onClick={() => this.clearing(record)} href="javascript:;">
                  结算
                </a>
              </Popconfirm>
            );
          }
        }
      ],
      columns_hisList: [
        {
          isExpand: true,
          title: '账期',
          dataIndex: ''
        },
        {
          title: '成单额',
          dataIndex: 'amount'
        },
        {
          isExpand: true,
          title: '先期回款',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '已到/在途',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '历史未结',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '平台转账',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '结算状态',
          dataIndex: 'status',
          render: (text, record) => (
            <span>{this.state.statusMap[record.status]}</span>
          )
        },
        {
          title: '操作',
          dataIndex: '',
          render: (text, record) => {
            return (
              <Popconfirm title="确定吗?" onConfirm={() => this.notify(record)}>
                <a onClick={() => this.clearing(record)} href="javascript:;">
                  平台转账
                </a>
              </Popconfirm>
            );
          }
        }
      ]
    };
  }

  componentDidMount() {
    this.getClearingReport();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getClearingReport(values);
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getClearingReport({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getClearingReport = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.stat.clearingReportInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        payload.ach_id = this.props.match.params.account;
        this.props.dispatch({
          type: 'stat/getClearingReport',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getClearingReport parameters error');
      }
    });
  };
  // getJumpPrevLevel = (params = {}) => {
  //   if (params.parent_account === "") {
  //     message.warning('没有上级')
  //     return
  //   } else {
  //     this.props.form.validateFields((err, values) => {
  //       if (!err) {
  //         this.props.dispatch({
  //           type: 'stat/getJumpPrevLevel',
  //           payload: {
  //             parent_account: params.parent_account
  //           }
  //         })
  //       } else {
  //         console.log('getJumpPrevLevel parameters error')
  //       }
  //     })
  //   }
  // }
  // getJumpNextLevel = (params = {}) => {
  //   this.props.form.validateFields((err, values) => {
  //     if (!err) {
  //       this.props.dispatch({
  //         type: 'stat/getJumpNextLevel',
  //         payload: {
  //           account: params.account
  //         }
  //       })
  //     } else {
  //       console.log('getJumpNextLevel parameters error')
  //     }
  //   })
  // }
  // jumpPrevLevel = item => {
  //   this.getJumpPrevLevel(item)
  // }
  // jumpNextLevel = item => {
  //   this.getJumpNextLevel(item)
  // }
  render() {
    const info = this.props.stat.clearingReportInfo;
    return (
      <Card bordered={false}>
        <div
          style={{
            width: '70rem',
            display: 'inline-block',
            marginRight: '30px'
          }}
          className={'tableList'}
        >
          <SimpleTable
            width={1000}
            title={() => '当前账期'}
            bordered={true}
            columns={this.state.columns_nowList}
            rowKey={record => record.id}
            dataSource={info.nowList}
            pagination={false}
            loading={this.props.loading}
            onChange={this.handleTableChange}
            style={{ textAlign: 'center !important', marginBottom: '50px' }}
          />
        </div>
        {/* <Button style={{display: 'inline-block'}} type="primary">清算</Button> */}
        {/* <SimpleTable
          title = {() => '当前账期'}          
          bordered={true}
          columns={this.state.columns_hisList}
          rowKey={record => record.id}
          // dataSource={info.nowList}
          pagination={false}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        /> */}
        <SimpleTable
          title={() => '历史账期'}
          bordered={true}
          columns={this.state.columns_hisList}
          rowKey={record => record.id}
          dataSource={info.hisList}
          pagination={false}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
