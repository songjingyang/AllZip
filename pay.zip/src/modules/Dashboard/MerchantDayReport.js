import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Alert,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import classNames from 'classnames';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ stat, global, loading }) => ({
  stat,
  global,
  loading: loading.effects['stat/getMerchantDayReport']
}))
export default class MerchantDayReport extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      statusMap: {
        0: '结算中',
        1: '结算完成'
      },
      loading: false,
      columns: [
        {
          isExpand: true,
          title: '日期',
          dataIndex: 'create_time'
        },
        {
          title: '总收入',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '成单总量',
          dataIndex: 'previous_total',
          render: (text, record) => (
            <Link to={{ pathname: `/order/orderInfo/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '支付宝收入',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '支付宝单量',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '微信收入',
          dataIndex: ''
        },
        {
          isExpand: true,
          title: '微信单量',
          dataIndex: ''
        }
        // {
        //   title: '操作',
        //   dataIndex: '',
        //   render: (text, record) => {
        //     return (
        //       <Popconfirm title="确定吗?" onConfirm={() => this.notify(record)}>
        //         <a onClick={() => this.clearing(record)} href="javascript:;">
        //           结算
        //         </a>
        //       </Popconfirm>
        //     );
        //   }
        // }
      ]
    };
  }
  componentDidMount() {
    this.getMerchantDayReport();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getMerchantDayReport(values);
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getMerchantDayReport({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getMerchantDayReport = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.stat.merchantDayReportInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        payload.ach_id = this.props.match.params.account;
        this.props.dispatch({
          type: 'stat/getMerchantDayReport',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getMerchantDayReport parameters error');
      }
    });
  };
  // getJumpPrevLevel = (params = {}) => {
  //   if (params.parent_account === "") {
  //     message.warning('没有上级')
  //     return
  //   } else {
  //     this.props.form.validateFields((err, values) => {
  //       if (!err) {
  //         this.props.dispatch({
  //           type: 'stat/getJumpPrevLevel',
  //           payload: {
  //             parent_account: params.parent_account
  //           }
  //         })
  //       } else {
  //         console.log('getJumpPrevLevel parameters error')
  //       }
  //     })
  //   }
  // }
  // getJumpNextLevel = (params = {}) => {
  //   this.props.form.validateFields((err, values) => {
  //     if (!err) {
  //       this.props.dispatch({
  //         type: 'stat/getJumpNextLevel',
  //         payload: {
  //           account: params.account
  //         }
  //       })
  //     } else {
  //       console.log('getJumpNextLevel parameters error')
  //     }
  //   })
  // }
  // jumpPrevLevel = item => {
  //   this.getJumpPrevLevel(item)
  // }
  // jumpNextLevel = item => {
  //   this.getJumpNextLevel(item)
  // }

  // 时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  render() {
    const global = this.props.global;
    const info = this.props.stat.merchantDayReportInfo;
    const { getFieldDecorator } = this.props.form;
    return (
      <Card bordered={false}>
        <div
          style={{
            width: '70rem',
            display: 'inline-block',
            marginRight: '30px'
          }}
          className={'tableList'}
        >
          <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
            <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
              <Col xl={12} md={24} sm={24}>
                <FormItem label="时间范围" className="form-inline-item">
                  {getFieldDecorator('timeRange', {
                    initialValue: getTimeDistance('today'),
                    rules: [
                      {
                        validator: (rule, value, callback) => {
                          let startTm;
                          let endTm;
                          if (value.length !== 0) {
                            startTm = parseInt(value[0].valueOf() / 1000);
                            endTm = parseInt(value[1].valueOf() / 1000);
                            if (endTm - startTm > 90 * 24 * 3600) {
                              callback('最大范围 3个月');
                            }
                          } else {
                            startTm = 0;
                            endTm = 0;
                          }
                          callback();
                        }
                      }
                    ]
                  })(
                    <RangePicker
                      disabledDate={this.disabledDate}
                      showTime
                      format="YYYY-MM-DD HH:mm:ss"
                    />
                  )}
                </FormItem>
              </Col>
              <Col xl={8} md={12} sm={12}>
                <div className={'submitButtons'}>
                  <Button type="primary" htmlType="submit">
                    查询
                  </Button>
                </div>
              </Col>
            </Row>
          </Form>
        </div>
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
