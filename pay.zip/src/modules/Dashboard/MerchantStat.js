import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  message
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import { spawn } from 'redux-saga/effects';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ stat, global, loading }) => ({
  stat,
  global,
  loading: loading.effects['stat/getStatTop10']
}))
export default class MerchantStat extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        0: '已发送',
        1: '未支付',
        2: '已支付'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          isExpand: true,
          title: '商户名称',
          dataIndex: 'name'
        },
        {
          isExpand: true,
          title: '商户ID',
          dataIndex: 'ach_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '总收入(元)',
          dataIndex: 'amount_total'
        },
        {
          isExpand: true,
          title: '总手续费(元)',
          dataIndex: 'total_pundage'
        },
        {
          isExpand: true,
          title: '总成单量',
          dataIndex: 'order_total'
        },
        {
          isExpand: true,
          title: '支付宝收入(元)',
          dataIndex: 'ali_amount_total'
        },
        {
          isExpand: true,
          title: '支付宝单量',
          dataIndex: 'ali_order_total'
        },
        {
          isExpand: true,
          title: '微信收入(元)',
          dataIndex: 'wx_amount_total'
        },
        {
          isExpand: true,
          title: '微信单量',
          dataIndex: 'wx_order_total'
        }
      ]
    };
  }
  componentDidMount() {
    this.getStatTopList();
    this.props.dispatch({
      type: 'stat/getBaseStat',
      payload: {}
    });
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    this.setState({
      pagination: {
        current: 1
      }
    });
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getStatTopList(values);
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getStatTopList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getStatTopList = (params = {}) => {
    this.props.dispatch({
      type: 'stat/getStatTop10',
      payload: {}
    });
  };

  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const baseStatInfo = this.props.stat.baseStatInfo;
    const info = this.props.stat.statTop10Info;

    const topColResponsiveProps = {
      xs: 24,
      sm: 12,
      md: 6,
      lg: 6,
      xl: 6,
      style: { marginBottom: 24 }
    };

    return (
      <div>
        <Row gutter={{ xs: 8, sm: 16, md: 24, xl: 24 }}>
          <Col {...topColResponsiveProps}>
            <Card>
              今日：￥
              {baseStatInfo.today_paid_total}/{baseStatInfo.today_paid_order}
            </Card>
          </Col>
          <Col {...topColResponsiveProps}>
            <Card>
              昨日：￥
              {baseStatInfo.yesterday_paid_total}/
              {baseStatInfo.yesterday_paid_order}
            </Card>
          </Col>
          <Col {...topColResponsiveProps}>
            <Card>
              本周：￥
              {baseStatInfo.week_paid_total}/{baseStatInfo.week_paid_order}
            </Card>
          </Col>
          <Col {...topColResponsiveProps}>
            <Card>
              本月：￥
              {baseStatInfo.month_paid_total}/{baseStatInfo.month_paid_order}
            </Card>
          </Col>
        </Row>
        {info.isShow && (
          <Card
            title={
              <span>
                今日TOP10 <a onClick={this.getStatTopList}>刷新</a>
              </span>
            }
            bordered={false}
            extra={<Link to="/dashboard/merchantList">更多</Link>}
          >
            <div className={'tableList'}>
              {/* <div
              className={classNames({
                tableListForm: !global.isMobile,
                tableListFormMobile: global.isMobile
              })}
            >
              <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
                <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label='时间范围' className='form-inline-item'>
                      {getFieldDecorator('timeRange', {})(
                        <RangePicker showTime format='YYYY-MM-DD HH:mm:ss' />
                      )}
                    </FormItem>
                  </Col>

                  <Col xl={12} md={24} sm={24}>
                    <FormItem label='商户' className='form-inline-item'>
                      {getFieldDecorator('achId')(<Input />)}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <div className={'submitButtons'}>
                      <Button type='primary' htmlType='submit'>查询</Button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </div> */}
              {/* <div className={'tableListOperator'}>
          <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
            新建
          </Button>
        </div> */}

              <SimpleTable
                columns={this.state.columns}
                rowKey={record => record.id}
                dataSource={info.list}
                // pagination={{ ...this.state.pagination, total: info.total }}
                pagination={false}
                loading={this.props.loading}
                onChange={this.handleTableChange}
              />
            </div>
          </Card>
        )}
      </div>
    );
  }
}
