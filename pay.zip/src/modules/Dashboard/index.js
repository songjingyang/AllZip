import React from 'react'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Input,
  message,
  Row,
  Col
} from 'antd'
import { Chart, Tooltip, Axis, Bar, Coord, Legend } from 'viser-react'
import { connect } from 'dva'
const DataSet = require('@antv/data-set')

@connect(({ cc }) => ({ cc }))
export default class Dashboard extends React.Component {
  componentWillMount () {
    this.props.dispatch({
      type: 'cc/getStat',
      payload: {}
    })
  }

  getChart (data) {
    return (
      <Chart forceFit height={200} data={data} padding={[20, 20, 20, 150]}>
        <Coord type='rect' direction='LB' />
        <Tooltip />
        <Axis dataKey='label' label={{ offset: 20 }} />
        <Bar
          position='label*value'
          adjust={[{ type: 'dodge', marginRatio: 1 / 32 }]}
        />
      </Chart>
    )
  }

  render () {
    const stat = this.props.cc.stat
    let dv = new DataSet.View().source(stat.deal)
    const dealData = dv.transform({
      type: 'reverse'
      // callback (a, b) {
      //   return a.value - b.value < 0
      // }
    }).rows
    dv = new DataSet.View().source(stat.order)
    const orderData = dv.transform({
      type: 'reverse'
    }).rows
    dv = new DataSet.View().source(stat.finishedDeal)
    const finishedDealData = dv.transform({
      type: 'reverse'
    }).rows
    dv = new DataSet.View().source(stat.finishedOrder)
    const finishedOrderData = dv.transform({
      type: 'reverse'
    }).rows
    dv = new DataSet.View().source(stat.total)
    const totalData = dv.transform({
      type: 'reverse'
    }).rows

    const topColResponsiveProps = {
      xs: 24,
      sm: 12,
      md: 12,
      lg: 12,
      xl: 12,
      style: { marginBottom: 24 }
    }

    return (
      <div>
        <Row gutter={{ xs: 8, sm: 16, md: 24, xl: 24 }}>
          <Col {...topColResponsiveProps}>
            {this.getChart(dealData)}
          </Col>
          <Col {...topColResponsiveProps}>
            {this.getChart(orderData)}
          </Col>
          <Col {...topColResponsiveProps}>
            {this.getChart(finishedDealData)}
          </Col>
          <Col {...topColResponsiveProps}>
            {this.getChart(finishedOrderData)}
          </Col>
        </Row>
        {this.getChart(totalData)}
      </div>
    )
  }
}
