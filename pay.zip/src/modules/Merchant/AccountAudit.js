import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import AccountDetail from './AccountDetail';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ merchant, global, loading }) => ({
  merchant,
  global,
  loading: loading.effects['merchant/getAccountAuditList']
}))
export default class AccountAudit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      account_data: {},
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        1: '收款中',
        2: '已停用'
      },
      accoumtType: {
        '3': ''
      },
      isDetail: false,
      columns: [
        {
          title: '收款账户',
          dataIndex: 'account',
          render: (text, record) => (
            <a onClick={() => this.detail(record)} href="javascript:;">
              {record.account}
            </a>
          )
        },
        {
          title: '收款类型',
          dataIndex: 'way_name'
        },
        {
          title: '停止收款时间',
          dataIndex: 'stop_unix',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          title: '汇款额度',
          dataIndex: 'amount'
        },
        {
          title: '已收金额',
          dataIndex: 'use_amount'
        },
        {
          isExpand: true,
          title: '备注信息',
          dataIndex: 'remark'
        },
        {
          title: '更新时间',
          dataIndex: 'updated',
          render: text => <span>{dateFormater(text)}</span>
        },
        // {
        //   title: '在途金额',
        //   dataIndex: ''
        // },
        // {
        //   title: '本期收款',
        //   dataIndex: ''
        // },
        // {
        //   title: '本期在途',
        //   dataIndex: ''
        // },
        // {
        //   title: '收款状态',
        //   dataIndex: 'status',
        //   render: (text, record) => (
        //     <span>{this.state.statusMap[record.status]}</span>
        //   )
        // },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => {
            return (
              <span>
                <Link
                  to={{ pathname: `/merchant/amountDetail/${record.account}` }}
                >
                  收款详情
                </Link>
                <Divider type="vertical" />
                <Popconfirm
                  title="确定操作吗？"
                  onConfirm={() => this.freeze(record)}
                >
                  <a onClick={() => this.freeze(record)} href="javascript:;">
                    冻结
                  </a>
                </Popconfirm>

                {/* {record.status === 1 && <span style={{color: 'green'}}>已通过</span>}
                  {record.status === 2 && <span style={{color: 'red'}}>未通过</span>}
                  {(record.status === 0) &&
                    <div>
                      <a onClick={() => this.pass(record)} href='javascript:;'>通过</a>
                        <Divider type='vertical'></Divider>
                      <a onClick={() => this.refuse(record)} href='javascript:;'>拒绝</a>
                    </div>} */}
              </span>
            );
          }
        }
      ]
    };
  }
  componentDidMount() {
    this.getAccountAuditList({});
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getAccountAuditList(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getAccountAuditList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  getAccountAuditList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.merchant.accountAuditListInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        if (payload.status === undefined) {
          payload.status = '-1';
        }
        this.props.dispatch({
          type: 'merchant/getAccountAuditList',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getAccountAuditList params error');
      }
    });
  };
  //冻结
  freeze = item => {
    item.status = 2;
    // this.props.dispatch({
    //   type: 'merchant/deleteAccountAudit',
    //   payload: {
    //       ...item
    //   }
    // })
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'merchant/getAccountAuditFreeze',
          payload: {
            id: item.id,
            status: 1
          }
        });
      } else {
        console.log('getRefuse parameters error');
      }
    });
  };
  isDetail = bool => {
    this.setState({ isDetail: bool });
  };
  detail = item => {
    this.isDetail(true);
    this.setState({ account_data: item });
    // this.props.form.validateFields((err, values) => {
    //   if (!err) {
    //     this.props.dispatch({
    //       type: 'merchant/getAccountDetail',
    //       payload: {
    //           account: item.account
    //       }
    //     })
    //   } else {
    //     console.log('getAccountDetail parameters error')
    //   }
    // })
  };
  closeAccountDetail = () => {
    this.isDetail(false);
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.merchant.accountAuditListInfo;

    return (
      <Card bordered={false}>
        {this.state.isDetail && (
          <Modal
            title="详情"
            width={1000}
            visible={this.state.isDetail}
            onCancel={() => this.isDetail(false)}
            footer={null}
          >
            <AccountDetail
              account_data={this.state.account_data}
              onClose={this.closeAccountDetail}
            />
          </Modal>
        )}
        <div className={'tableList'}>
          <div className={'tableListForm'}>
            <Form layout="inline" onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={8} sm={24}>
                  <FormItem label="商户名称" className="form-inline-item">
                    {getFieldDecorator('ach_id')(<Input />)}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <FormItem label="收款状态" className="form-inline-item">
                    {getFieldDecorator('status', {
                      initialValue: '1'
                    })(
                      <RadioGroup>
                        <Radio value="">全部</Radio>
                        <Radio value="1">收款中</Radio>
                        <Radio value="2">已停用</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <span className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </span>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.state.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
