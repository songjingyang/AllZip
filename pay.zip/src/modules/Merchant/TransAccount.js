import React from 'react'
import { Form, Input, Button, message } from 'antd'
import { connect } from 'dva'
const FormItem = Form.Item

@Form.create()
@connect(({ merchant }) => ({ merchant }))
export default class TransAccount extends React.Component {
  constructor (props) {
    super(props)
    this.state = {}
  }

  handleSubmit = e => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'merchant/transAccount',
          payload: {
            ...this.props.data,
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              if (this.props.onClose) {
                this.props.onClose()
              }
            } else {
              message.error(res.msg)
            }
          }
        })
      }
    })
  }

  render () {
    const { getFieldDecorator } = this.props.form

    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem label='平台转账金额'>
          {getFieldDecorator('price', {
            rules: [
              {
                required: true,
                message: '请输入平台转账金额',
                whitespace: true
              }
            ]
          })(<Input placeholder='请输入平台转账金额' />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type='primary' htmlType='submit'>提交</Button>
        </FormItem>
      </Form>
    )
  }
}
