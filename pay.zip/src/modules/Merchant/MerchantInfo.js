import React from 'react';
import { routerRedux } from 'dva/router';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  message,
  Divider,
  Tree,
  Popconfirm,
  Modal
} from 'antd';
import { connect } from 'dva';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import PreviewImg from '@/components/PreviewImg';
import DescriptionList from '@/components/DescriptionList';
import './MerchantInfo.css';
import { Link } from 'dva/router';
import MerchantProxyEditRate from './MerchantProxyEditRate';
import MerchantEditStatus from './MerchantEditStatus';
import MerchantProxyEditPass from './MerchantProxyEditPass';
import MerchantProxyTransfer from './MerchantProxyTransfer';
import MerchantInfoEditHistory from './MerchantInfoEditHistory';



const { Description } = DescriptionList;
const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;
const TreeNode = Tree.TreeNode;

@Form.create()
@connect(({ merchant, global, loading }) => ({
  merchant,
  global
  // loading: loading.effects['proxy/getProxyTreeList']
}))
export default class MerchantInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isDisable: false,
      isEditHistory: false,
      IsStopAlipay: '',
      IsStopWxPay: '',
      levelMap: {
        1: '总代',
        2: '一级代理',
        3: '二级代理'
      },
      statusMap: {
        0: '审核中',
        1: '正常',
        2: '封停'
      },
      // loading: false,
      expandedKeys: ['1', '2'],
      autoExpandParent: true,
      selectedKeys: [],
      treeData: [
        {
          title: '0-0',
          key: '0-0',
          children: [
            {
              title: '0-0-0',
              key: '0-0-0',
              children: [
                { title: '0-0-0-0', key: '0-0-0-0' },
                { title: '0-0-0-1', key: '0-0-0-1' },
                { title: '0-0-0-2', key: '0-0-0-2' }
              ]
            },
            {
              title: '0-0-1',
              key: '0-0-1',
              children: [
                { title: '0-0-1-0', key: '0-0-1-0' },
                { title: '0-0-1-1', key: '0-0-1-1' },
                { title: '0-0-1-2', key: '0-0-1-2' }
              ]
            },
            {
              title: '0-0-2',
              key: '0-0-2'
            }
          ]
        },
        {
          title: '0-1',
          key: '0-1',
          children: [
            { title: '0-1-0-0', key: '0-1-0-0' },
            { title: '0-1-0-1', key: '0-1-0-1' },
            { title: '0-1-0-2', key: '0-1-0-2' }
          ]
        },
        {
          title: '0-2',
          key: '0-2'
        }
      ]
    };
  }
  componentDidMount() {
    this.getMerchantTreeList();
    this.getMerchantUserInfo();
  }
  getMerchantTreeList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }
        payload = { ...payload, ...params };
        payload.account = this.props.match.params.account;
        this.props.dispatch({
          type: 'merchant/getMerchantTreeList',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getMerchantTreeList parameters error');
      }
    });
  };
  getMerchantUserInfo = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }
        payload = { ...payload, ...params };
        // console.log("12312313",this.props.match.params.account)
        payload.account = this.props.match.params.account;
        // payload.account = "1234";
        this.props.dispatch({
          type: 'merchant/getMerchantUserInfo',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getMerchantUserInfo parameters error');
      }
    });
  };
  onExpand = info => {
    console.log('onExpand', info);
    // if not set autoExpandParent to false, if children expanded, parent can not collapse.
    // or, you can remove all expanded children keys.
    this.setState({
      expandedKeys: info,
      autoExpandParent: false
    });
    // this.props.form.setFieldsValue({
    //   id: expandedKeys
    // })
    // console.log('onExpandaaaa', expandedKeys);
  };
  onCheck = checkedKeys => {
    console.log('onCheck', checkedKeys);
    this.setState({ checkedKeys });
  };
  onSelect = (selectedKeys, info) => {
    this.setState({ selectedKeys });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        if (info.selectedNodes.length !== 0) {
          values.account = String(info.selectedNodes[0].props.dataRef.Account);
          this.props.dispatch(
            routerRedux.push(`/merchant/merchantInfo/${values.account}`)
          );
          this.props.dispatch({
            type: 'merchant/getMerchantUserInfo',
            payload: {
              ...values
            }
          });
        }
        return;
      }
    });
  };
  renderTreeNodes = data => {
    return data.map(item => {
      if (item.children == null) item.children = [];
      if (item.children) {
        if (item.Id === undefined) {
          return (
            <TreeNode
              title={item.Account}
              key={item.Account}
              dataRef={item}
              disabled
            >
              {this.renderTreeNodes(item.children)}
            </TreeNode>
          );
        } else {
          return (
            <TreeNode title={item.Account} key={item.Account} dataRef={item}>
              {this.renderTreeNodes(item.children)}
            </TreeNode>
          );
        }
      }
      return <TreeNode {...item} />;
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'merchant/editMerchantProxyRateInfo',
      payload: {
        ...item
      }
    });
  };
  isEditHistory = bool => {
    this.setState({ isEditHistory: bool });
  };
  editHistory  = item => {
    this.isEditHistory(true);
    this.props.dispatch({
      type: 'merchant/editMerchantProxyRateInfo',
      payload: {
        ...item
      }
    });
  };
  isCheck = bool => {
    this.setState({ isCheck: bool });
  };
  isReset = bool => {
    this.setState({ isReset: bool });
  };
  disable = item => {
    var data = {
      account: this.props.merchant.merchantUserInfo.BusinessUser.Account,
      status: item
    };
    this.props.dispatch({
      type: 'merchant/businessUpdateStatus',
      payload: {
        ...data
      },
      callback: res => {
        if (res.code === 200) {
          message.success('操作成功');
          this.getMerchantUserInfo();
        }
      }
    });
  };
  reload = () => {
    this.isEdit(false);
    this.isCheck(false);
    this.isReset(false);
    this.isEditHistory(false);
    this.isTransfer(false);
    this.getMerchantUserInfo();
  };
  isTransfer = bool => {
    this.setState({ isTransfer: bool });
  };
  transfer = item => {
    this.isTransfer(true);
  };
  render() {
    const global = this.props.global;
    const treeData = this.props.merchant.merchantTreeListInfo.list;
    const account_info = this.props.merchant.merchantUserInfo;
    const treeLeftLayout = {
      xs: 24,
      sm: 12,
      md: 12,
      lg: 9,
      xl: 6,
      xxl: 6
    };
    const treeRightLayout = {
      xs: 24,
      sm: 12,
      md: 12,
      lg: 15,
      xl: 18,
      xxl: 18
    };
    const layout = {
      xs: 24,
      sm: 24,
      md: 24,
      lg: 12,
      xl: 8,
      xxl: 6
    };
    return (
      
      <Card bordered={false}>
      {this.state.isEditHistory && (
        <Modal
          title="修改历史信息"
          visible={this.state.isEditHistory}
          onCancel={() => this.isEditHistory(false)}
          footer={null}
        >
          <MerchantInfoEditHistory onClose={this.reload} />
        </Modal>
      )}
        {this.state.isEdit && (
          <Modal
            title="修改费率"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <MerchantProxyEditRate onClose={this.reload} />
          </Modal>
        )}
        {this.state.isCheck && (
          <Modal
            title="编辑"
            visible={this.state.isCheck}
            onCancel={() => this.isCheck(false)}
            footer={null}
          >
            <MerchantEditStatus onClose={this.reload} />
          </Modal>
        )}
        {this.state.isReset && (
          <Modal
            title="重置密码"
            visible={this.state.isReset}
            onCancel={() => this.isReset(false)}
            footer={null}
          >
            <MerchantProxyEditPass onClose={this.reload} />
          </Modal>
        )}
        {this.state.isTransfer && (
          <Modal
            title="转账"
            visible={this.state.isTransfer}
            onCancel={() => this.isTransfer(false)}
            footer={null}
          >
            <MerchantProxyTransfer onClose={this.reload} />
          </Modal>
        )}

        <Row type="flex" gutter={24} className="vertical-gutter">
          <Col
            style={{ maxHeight: '1040px', overflow: 'auto' }}
            {...treeLeftLayout}
          >
            <Card style={{ height: '100%', overflow: 'auto' }} title="商户">
              <Tree
                onExpand={this.onExpand}
                expandedKeys={this.state.expandedKeys}
                // defaultExpandedKeys={this.state.expandedKeys}
                autoExpandParent={this.state.autoExpandParent}
                onSelect={this.onSelect}
                selectedKeys={this.state.selectedKeys}
              >
                {this.renderTreeNodes(treeData)}
              </Tree>
            </Card>
          </Col>
          <Col {...treeRightLayout}>
            <Row gutter={24} className="vertical-gutter">
              <Col {...layout}>
                <Card style={{ height: 330 }} title="基本信息">
                  <DescriptionList col={1} size="large" title="">
                    <Description term="商户名称">
                      {account_info.BusinessUser.Name}
                    </Description>
                    <Description term="商户号">
                      {account_info.BusinessUser.Account}
                    </Description>
                    <Description term="状态">
                      {this.state.statusMap[account_info.BusinessUser.Status]}
                    </Description>
                    <Description term="创建日期">
                      {dateFormater(account_info.BusinessUser.CreateTime)}
                    </Description>
                    {/* <Description term="上次修改">
                    {dateFormater(account_info.BusinessUser.rate_update)}
                  </Description> */}
                  </DescriptionList>
                </Card>
              </Col>
              <Col {...layout}>
                <Card style={{ height: 330 }} title="账户认证">
                  <DescriptionList col={1} size="large" title="">
                    <Description term="真实姓名">
                      {account_info.real_auth.real_name}
                    </Description>
                    <Description term="身份证号">
                      {account_info.real_auth.id_card}
                    </Description>
                    <Description term="手机号">
                      {account_info.real_auth.phone}
                    </Description>
                    <Description term="地址">
                      {account_info.real_auth.address}
                    </Description>
    
                    {/* <Description term="上次修改">
                    {dateFormater(account_info.BusinessUser.rate_update)}
                  </Description> */}
                  </DescriptionList>
                </Card>
              </Col>
              <Col {...layout}>
                <Card style={{ height: 330 }} title="财富">
                  <DescriptionList col={1} size="large" title="">
                    <Description term="应收">
                      {account_info.wealth.Receivable}
                    </Description>
                    <Description term="实收">
                      {account_info.wealth.Received}
                    </Description>
                    <Description term="未收">
                      {account_info.wealth.Unreceived}
                    </Description>
                    <Description term="在途">
                      {account_info.wealth.OnOrder}
                    </Description>
                    <Description term="总手续费">
                      {account_info.wealth.TotalTradePundage}
                    </Description>
                    <Description term="总可提现">
                      {account_info.wealth.TotalWithdrawalAmount}
                    </Description>
                  </DescriptionList>
                </Card>
              </Col>
              {/* <Col {...layout}>
                <Card className="rate" style={{ height: 330 }} title="历史信息">
                  <DescriptionList col={1} size="large" title="">
                    <Description term="历史订单收入(v1.0)">
                      {account_info.history.total_amount_history}
                    </Description>
                    <Description term="历史手续费(v1.0)">
                      {account_info.history.total_pundage_history}
                    </Description>
                    <Description term="历史提现总额(v1.0)">
                      {account_info.history.total_withdrawal_history}
                    </Description>
                  </DescriptionList>
                  <a
                    className="rate-btn"
                    onClick={() => this.editHistory(account_info)}
                  >
                    编辑
                  </a>
                </Card>
              </Col> */}
              <Col {...layout}>
                <Card className="rate" style={{ height: 330 }} title="费率">
                  <DescriptionList col={1} size="large" title="">
                    <Description term="支付宝点数(%)">
                      {account_info.rate.ali_rate}
                      <span>（ 例：1%=1）</span>
                    </Description>
                    <Description term="微信点数(%)">
                      {account_info.rate.wx_rate}
                      <span>（ 例：1%=1）</span>
                    </Description>
                    <Description term="上次修改">
                      {account_info.rate.rate_update
                        ? dateFormater(account_info.rate.rate_update)
                        : '--'}
                    </Description>
                  </DescriptionList>
                  <a
                    className="rate-btn"
                    onClick={() => this.edit(account_info)}
                  >
                    编辑
                  </a>
                </Card>
              </Col>
              {account_info.agent.name ? (
                <Col {...layout}>
                  <Card style={{ height: 330 }} title="中间商">
                    <DescriptionList col={1} size="large" title="">
                      <Description term="名称">
                        {account_info.agent.name}
                      </Description>
                      <Description term="支付宝点数(%)">
                        {account_info.agent.ali_rate}
                      </Description>
                      <Description term="微信点数(%)">
                        {account_info.agent.wx_rate}
                      </Description>
                      <Description term="上次修改">
                        {dateFormater(account_info.agent.created)}
                      </Description>
                    </DescriptionList>
                  </Card>
                </Col>
              ) : (
                ''
              )}
              <Col span={24}>
                <Card title="快捷链接">
                  <Link
                    className="btn_router"
                    to={{
                      pathname: `/finance/proxyTransfer/${
                        account_info.BusinessUser.Account
                      }`
                    }}
                  >
                    代理转账
                  </Link>
                  {/* <Link
                    className="btn_router"
                    to={{
                      pathname: `/finance/platformTransfer/${
                        account_info.BusinessUser.Account
                      }`
                    }}
                  >
                    平台转账
                  </Link> */}
                  <Link
                    className="btn_router"
                    to={{
                      pathname: `/merchant/cardManage/${
                        account_info.BusinessUser.Account
                      }`
                    }}
                  >
                    银行账户信息
                  </Link>
                </Card>
              </Col>
              <Col span={24} style={{ marginBottom: 0 }}>
                <Card title="操作">
                  {account_info.BusinessUser.Status === 0 ? (
                    <Button
                      onClick={() => this.isCheck(true)}
                      type="primary"
                      ghost
                      style={{ marginRight: 16 }}
                    >
                      审核
                    </Button>
                  ) : (
                    ''
                  )}
                  {account_info.BusinessUser.Status === 1 && (
                    <Popconfirm
                      title="确定封停吗？"
                      onConfirm={() => this.disable(2)}
                    >
                      <Button
                        type="primary"
                        ghost
                        style={{ marginRight: 16, marginBottom: 16 }}
                      >
                        封停
                      </Button>
                    </Popconfirm>
                  )}
                  {account_info.BusinessUser.Status === 0 && (
                    <Popconfirm title="确定解封吗？">
                      <Button
                        type="primary"
                        ghost
                        disabled
                        style={{ marginRight: 16, marginBottom: 16 }}
                      >
                        解封
                      </Button>
                    </Popconfirm>
                  )}
                  {account_info.BusinessUser.Status === 2 && (
                    <Popconfirm
                      title="确定解封吗？"
                      onConfirm={() => this.disable(1)}
                    >
                      <Button
                        type="primary"
                        ghost
                        style={{ marginRight: 16, marginBottom: 16 }}
                      >
                        解封
                      </Button>
                    </Popconfirm>
                  )}
                  <Button
                    type="primary"
                    ghost
                    style={{ marginRight: 16, marginBottom: 16 }}
                  >
                    <a onClick={() => this.isReset(true)}>密码重置</a>
                  </Button>
                  <Button
                    type="primary"
                    ghost
                    style={{ marginRight: 16, marginBottom: 16 }}
                  >
                    <a onClick={() => this.transfer()}>转账</a>
                  </Button>
                </Card>
              </Col>
            </Row>
          </Col>
        </Row>
      </Card>
    );
  }
}
