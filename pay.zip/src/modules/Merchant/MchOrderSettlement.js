import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm,
  Divider,
  Checkbox
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import SwitchConfirm from '@/components/SwitchConfirm';
// import MerchantEdit from './MerchantProxyEditStatus';
import MerchantTransfer from './MerchantTransfer';
import MerchantListView from './MerchantListView';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ merchant, global, loading }) => ({
  merchant,
  global
  // loading: loading.effects['merchant/mchOrderSettlementList']
}))
export default class MchOrderSettlement extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        0: '审核中',
        1: '正常',
        2: '封停'
      },
      merchantMap: {
        0: '签约商户',
        1: '平台商户'
      },
      isEdit: false,
      isTransfer: false,
      isView: false,
      columns: [
        {
          isExpand: true,
          title: 'id',
          dataIndex: 'id'
        },
        {
          isExpand: true,
          title: '结算日期',
          dataIndex: 'date',
          // render: (text, record) => <span>{dateFormater(text)}</span>
        },
        {
          title: '商户ID',
          dataIndex: 'ach_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
              {text}
            </Link>
          )
        },
        {
          title: '商户名称',
          dataIndex: 'bu_name'
        },
        {
          isExpand: true,
          title: '总金额',
          dataIndex: 'amount'
        },
        {
          title: '手续费总金额',
          dataIndex: 'pundage'
        },
        {
          title: '支付宝总金额',
          dataIndex: 'ali_amount'
        },
        {
          title: '支付宝总手续费',
          dataIndex: 'ali_pundage'
        },
        {
          title: '微信总金额',
          dataIndex: 'wx_amount'
        },
        {
          title: '微信总手续费',
          dataIndex: 'wx_pundage'
        },
        {
          title: '复核单数',
          dataIndex: 'review_num'
        },
        {
          title: '总订单数',
          dataIndex: 'order_num'
        },
        {
          title: '掉单率',
          dataIndex: 'review_rate'
        },
        // {
        //   isExpand: true,
        //   title: '创建时间',
        //   dataIndex: 'created',
        //   render: (text, record) => <span>{dateFormater(text)}</span>
        // },
        // {
        //   isExpand: true,
        //   title: '更新时间',
        //   dataIndex: 'updated',
        //   render: (text, record) => <span>{dateFormater(text)}</span>
        // }
      ]
    };
  }
  componentDidMount() {
    // let arch_id = this.props.match.params.arch_id;
    // if (arch_id != 0) {
    //   this.props.form.setFieldsValue({ name: arch_id });
    // }
    this.mchOrderSettlementList();
  }
  // handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.mchOrderSettlementList(values);
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.mchOrderSettlementList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  mchOrderSettlementList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.merchant.merchantListInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }
        this.state.pagination.current = 1
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'merchant/mchOrderSettlementList',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('mchOrderSettlementList parameters error');
      }
    });
  };
  enabled = () => {
    console.log('enabled');
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'merchant/merchantEditInfo',
      payload: {
        ...item
      }
    });
  };
  isTransfer = bool => {
    this.setState({ isTransfer: bool });
  };
  transfer = item => {
    this.isTransfer(true);
    this.mchOrderSettlementList();
    //传ach_id
    this.props.dispatch({
      type: 'merchant/getMerchantTransfer',
      payload: {
        ach_id: String(item.account)
      }
    });
    this.props.dispatch({
      type: 'merchant/merchantTransfer',
      payload: {
        ach_id: item.account
      }
    });
  };
  isView = bool => {
    this.setState({ isView: bool });
  };
  view = item => {
    this.isView(true);
    this.props.dispatch({
      type: 'merchant/merchantListViewEdit',
      payload: {
        ...item
      }
    });
  };
  closeView = () => {
    this.isView(false);
  };
  changeMerchantStatus = () => {
    this.isEdit(false);
    this.isTransfer(false);
    this.mchOrderSettlementList();
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.merchant.mchOrderSettlementListInfo;

    return (
      <Card bordered={false} title="订单日结">
        {this.state.isTransfer && (
          <Modal
            title="编辑"
            visible={this.state.isTransfer}
            onCancel={() => this.isTransfer(false)}
            footer={null}
          >
            <MerchantTransfer onClose={this.changeMerchantStatus} />
          </Modal>
        )}
        {this.state.isView && (
          <Modal
            title="其他信息"
            visible={this.state.isView}
            onCancel={() => this.isView(false)}
            footer={null}
          >
            <MerchantListView onClose={this.closeView} />
          </Modal>
        )}
        <div className={'tableList'}>
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={12} sm={24}>
                  <FormItem label="商户ID" className="form-inline-item">
                    {getFieldDecorator('ach_id')(<Input />)}
                  </FormItem>
                </Col>
                <Col md={12} sm={24}>
                  <FormItem label="结算日期" className="form-inline-item">
                    {getFieldDecorator('date')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          {/* <div className={'tableListOperator'}>
          <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
            新建
          </Button>
        </div> */}

          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
