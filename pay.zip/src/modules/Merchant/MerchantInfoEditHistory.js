import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ merchant }) => ({
  merchant
}))
export default class MerchantInfoEditHistory extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    // e.preventDefault();
    
    this.props.form.validateFields((err, values) => {
      var data = {
        ach_id: this.props.merchant.merchantUserInfo.BusinessUser.Account,
        total_amount_history: Number(values.total_amount_history*100),
        total_pundage_history: Number(values.total_pundage_history*10000),
        total_withdrawal_history: Number(values.total_withdrawal_history*100)
      };
      // 
      if (!err) {
        this.props.dispatch({
          type: 'merchant/editHistory',
          payload: {
            // ...this.props.finance.platformTransferDetail,
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('修改成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    // const info = this.props.merchant.editMerchantProxyRateInfo;
    const info = this.props.merchant.merchantUserInfo;
    
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="历史订单收入">
          {getFieldDecorator('total_amount_history', {
            initialValue: info.history.total_amount_history
            // rules: [
            //   {
            //     required: true,
            //     message: '请填写账号!',
            //     writespace: true
            //   }
            // ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="历史手续费">
          {getFieldDecorator('total_pundage_history', {
            initialValue: info.history.total_pundage_history
            // rules: [
            //   {
            //     required: true,
            //     message: '请填写名称!',
            //     writespace: true
            //   }
            // ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="历史提现总额">
          {getFieldDecorator('total_withdrawal_history', {
            initialValue: info.history.total_withdrawal_history
            // rules: [
            //   {
            //     required: true,
            //     message: '请填写名称!',
            //     writespace: true
            //   }
            // ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            修改
          </Button>
        </FormItem>
      </Form>
    );
  }
}
