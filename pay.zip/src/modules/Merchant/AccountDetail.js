import React from 'react';
import moment from 'moment';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  message
} from 'antd';
import { connect } from 'dva';
import classNames from 'classnames';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import PreviewImg from '@/components/PreviewImg';
import SimpleTable from '@/components/SimpleTable';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ merchant, global, loading }) => ({
  merchant,
  global,
  loading: loading.effects['merchant/getAccountDetail']
}))
export default class AccountDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        1: '已停用',
        2: '停止收款'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          isExpand: true,
          title: '账户',
          dataIndex: 'account'
        },
        {
          isExpand: true,
          title: '开户人',
          dataIndex: 'open'
        },
        // {
        //   isExpand: true,
        //   title: '开始收款时间',
        //   dataIndex: '',
        //   render: text => (
        //     <span>{dateFormater(text)}</span>
        //   )
        // },
        {
          isExpand: true,
          title: '停止收款时间',
          dataIndex: 'stop_unix',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '账户状态',
          dataIndex: 'status',
          render: (text, record) => (
            <span>{this.state.statusMap[record.status]}</span>
          )
        }
      ]
    };
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.onClose();
    // this.setState({
    //   pagination :{
    //     current : 1
    //   }
    // })
    // this.props.form.validateFields((err, values) => {
    //   if(!err) {
    //     this.props.dispatch({
    //         type: 'proxy/saveProfitFlowEdit',
    //         payload: {
    //             ...this.props.proxy.profitFlowEdit,
    //             ...values
    //         },
    //         callback: res => {
    //             if (res.code === 200) {
    //                 if (this.props.onClose) {
    //                     this.props.onClose()
    //                 }
    //             }
    //         }
    //     })
    //   }
    // })
  };
  // handleTableChange = (pagination, filters, sorter) => {
  //   const pager = { ...this.state.pagination }
  //   pager.current = pagination.current
  //   this.setState({
  //     pagination: pager
  //   })
  //   this.getAccountDetail({
  //     pageSize: pagination.pageSize,
  //     page: pagination.current
  //   })
  // }
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.account_data;
    console.log('info', this.props.account_data);
    const formItemLayout = {
      labelCol: { span: 12 },
      wrapperCol: { span: 24 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="">
          {getFieldDecorator('detail')(
            <SimpleTable
              columns={this.state.columns}
              rowKey={record => record.id}
              // dataSource={...info}
              // pagination={{ ...this.state.pagination, total: info.total }}
              loading={this.props.loading}
              onChange={this.handleTableChange}
            />
          )}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            关闭
          </Button>
        </FormItem>
      </Form>
    );
  }
}
