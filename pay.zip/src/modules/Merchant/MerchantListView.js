import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';
import PreviewImg from '@/components/PreviewImg';
import { dateFormater, getTimeDistance } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;

@Form.create()
@connect(({ merchant }) => ({
  merchant
}))
export default class MerchantListView extends React.Component {
  componentDidMount() {
    console.log(typeof this.props.merchant.merchantListViewEdit.account);
    this.props.dispatch({
      type: 'merchant/getMerchantListView',
      payload: {
        ach_id: String(this.props.merchant.merchantListViewEdit.account)
      }
    });
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.onClose();
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.merchant.merchantListViewInfo;
    console.log('info', info);
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="累计应收">
          {getFieldDecorator('Receivable', {
            initialValue: info.Receivable
          })(<Input disabled />)}
        </FormItem>
        <FormItem {...formItemLayout} label="累计实收">
          {getFieldDecorator('Received', {
            initialValue: info.Received
          })(<Input disabled />)}
        </FormItem>
        <FormItem {...formItemLayout} label="累计未到账">
          {getFieldDecorator('Unreceived', {
            initialValue: info.Unreceived
          })(<Input disabled />)}
        </FormItem>
        <FormItem {...formItemLayout} label="在途金额">
          {getFieldDecorator('OnOrder', {
            initialValue: info.OnOrder
          })(<Input disabled />)}
        </FormItem>
        <FormItem {...formItemLayout} label="总手续费">
          {getFieldDecorator('TotalTradePundage', {
            initialValue: info.TotalTradePundage
          })(<Input disabled />)}
        </FormItem>
        <FormItem {...formItemLayout} label="总可提现额度">
          {getFieldDecorator('TotalWithdrawalAmount', {
            initialValue: info.TotalWithdrawalAmount
          })(<Input disabled />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            关闭
          </Button>
        </FormItem>
      </Form>
    );
  }
}
