import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm,
  Divider,
  Checkbox
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import SwitchConfirm from '@/components/SwitchConfirm';
import CardManageEdit from './CardManageEdit';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ merchant, global, loading }) => ({
  merchant,
  global,
  loading: loading.effects['merchant/getCardManageList']
}))
export default class CardManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        0: '审核中',
        1: '已通过',
        2: '未通过'
      },
      merchantMap: {
        0: '签约商户',
        1: '平台商户'
      },
      isEdit: false,
      isTransfer: false,
      columns: [
        {
          title: '商户ID',
          dataIndex: 'ach_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '银行',
          dataIndex: 'way_name'
        },
        {
          isExpand: true,
          title: '卡号',
          dataIndex: 'account'
        },
        {
          isExpand: true,
          title: '开户人',
          dataIndex: 'open'
        },
        {
          isExpand: true,
          title: '收款上限',
          dataIndex: 'amount'
        },
        {
          title: '已收额度',
          dataIndex: 'use_amount'
        },
        {
          isExpand: true,
          title: '备注',
          dataIndex: 'remark'
        },
        {
          isExpand: true,
          title: '停止收款时间',
          dataIndex: 'stop_unix',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '申请时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '状态',
          dataIndex: 'status',
          render: text => (
            <span>
              {text === 1 && <span style={{ color: 'green' }}>已通过</span>}
              {text === 2 && <span style={{ color: 'red' }}>已拒绝</span>}
              {text === 0 && <span>审核中</span>}
            </span>
          )
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => {
            return (
              <span>
                {record.status === 1 && (
                  // <span style={{ color: 'green' }}>已通过</span>
                  <Popconfirm
                    title="确定吗？"
                    onConfirm={() => this.refuse(record)}
                  >
                    <a href="javascript:;">拒绝</a>
                  </Popconfirm>
                )}
                {record.status === 2 && (
                  <span style={{ color: 'red' }}>已拒绝</span>
                )}
                {record.status === 0 && (
                  <div>
                    <Popconfirm
                      title="确定吗？"
                      onConfirm={() => this.pass(record)}
                    >
                      <a href="javascript:;">通过</a>
                    </Popconfirm>
                    <Divider type="vertical" />
                    <Popconfirm
                      title="确定吗？"
                      onConfirm={() => this.refuse(record)}
                    >
                      <a href="javascript:;">拒绝</a>
                    </Popconfirm>
                  </div>
                )}
              </span>
            );
          }
          // render: (text, record) => (
          //   <a onClick={() => this.edit(record)} href="javascript:;">
          //     编辑
          //   </a>
          // )
        }
      ]
    };
  }
  componentDidMount() {
    // let arch_id = this.props.match.params.arch_id;
    // if (arch_id != 0) {
    //   this.props.form.setFieldsValue({ name: arch_id });
    // }
    this.getCardManageList();
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getCardManageList(values);
      }
    });
  };

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getCardManageList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };

  getCardManageList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.merchant.cardManageInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }

        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'merchant/getCardManageList',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getCardManageList parameters error');
      }
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'merchant/cardManageStatus',
      payload: {
        ...item
      }
    });
  };
  changeStatus = () => {
    this.isEdit(false);
    this.getCardManageList();
  };
  pass = item => {
    item.status = 1;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'merchant/getCardManagePass',
          payload: {
            id: Number(item.id),
            status: 1
          }
        });
      } else {
        console.log('getPass parameters error');
      }
    });
  };
  refuse = item => {
    item.status = 2;
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'merchant/getCardManageRefuse',
          payload: {
            id: Number(item.id),
            status: 2
          }
        });
      } else {
        console.log('getRefuse parameters error');
      }
    });
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.merchant.cardManageInfo;

    return (
      <Card bordered={false} title="银卡管理">
        {this.state.isEdit && (
          <Modal
            title="编辑"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <CardManageEdit onClose={this.changeStatus} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={12} sm={24}>
                  <FormItem label="商户ID" className="form-inline-item">
                    {getFieldDecorator('ach_id', {
                      initialValue: this.props.match.params.account
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col md={12} sm={24}>
                  <FormItem label="审核状态" className="form-inline-item">
                    {getFieldDecorator('status', {
                      initialValue: '3'
                    })(
                      <RadioGroup>
                        <Radio value="3">全部</Radio>
                        <Radio value="0">审核中</Radio>
                        <Radio value="1">已通过</Radio>
                        <Radio value="2">已拒绝</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col md={12} sm={24}>
                  <FormItem label="条件" className="form-inline-item">
                    {getFieldDecorator('type', {
                      initialValue: ''
                    })(
                      <RadioGroup>
                        <Radio value="">全部</Radio>
                        <Radio value="1">将要到期</Radio>
                        <Radio value="2">将要到上限</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                {/* <Col md={8} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="button">
                      将要到期
                    </Button>
                  </div>
                </Col>
                <Col md={8} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="button">
                      将要到上限
                    </Button>
                  </div>
                </Col> */}
                <Col md={8} sm={24}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
