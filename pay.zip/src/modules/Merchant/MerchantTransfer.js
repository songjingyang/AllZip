import React from 'react';
import { Modal, message, Form, Input, Select, Button, Alert } from 'antd';
import { connect } from 'dva';
import _ from 'lodash';
import { commafy, toFixed } from '@/utils/utils';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ merchant, global, loading }) => ({
  merchant,
  global,
  loading: loading.effects['merchant/getClearingRecordInfo']
}))
export default class MerchantTransfer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      info: '',
      data: []
    };
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'merchant/getBankList'
    });
    // this.props.dispatch({
    //   type: 'merchant/getMerchantTransfer'
    // })
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.setState({
          ...this.state,
          info: {
            ...values
          }
        });
        const stateInfo = values;
        const formItemLayout = {
          labelCol: { span: 6 },
          wrapperCol: { span: 14 }
        };
        const bank = this.props.merchant.bankListInfo.list.find(
          item => item.id === stateInfo.account_way_id && item
        );
        // console.log(bank)
        Modal.confirm({
          title: '提交确认',
          okText: '确认',
          cancelText: '取消',
          onOk: () => {
            return this.save();
          },
          content: (
            <Form>
              <FormItem {...formItemLayout} label="商户">
                {stateInfo.ach_id}
              </FormItem>
              <FormItem {...formItemLayout} label="银行">
                {bank.name}
              </FormItem>
              <FormItem {...formItemLayout} label="收款账户">
                {stateInfo.card_no}
              </FormItem>
              <FormItem {...formItemLayout} label="开户人">
                {stateInfo.card_owner}
              </FormItem>
              <FormItem {...formItemLayout} label="转账金额">
                {commafy(stateInfo.amount)}
              </FormItem>
              <FormItem {...formItemLayout} label="备注">
                {stateInfo.plt_remark}
              </FormItem>
            </Form>
          )
        });
      }
    });
  };
  save = e => {
    return new Promise((resolve, reject) => {
      // e.preventDefault()
      this.props.form.validateFields((err, values) => {
        if (!err) {
          this.props.dispatch({
            type: 'merchant/saveMerchantTransfer',
            payload: {
              ...values,
              amount: +values.amount,
              account_way_id: +values.account_way_id,
              ach_id: this.props.merchant.merchantTransfer.ach_id
            },
            callback: res => {
              if (res.code === 200) {
                message.success('保存成功');
                resolve();
                if (this.props.onClose) {
                  this.props.onClose();
                }
              }
            }
          });
        }
      });
    });
  };

  withdrawAll = () => {
    this.props.form.setFieldsValue({
      amount: parseInt(this.props.merchant.merchantTransferInfo.odd_amount)
    });
    // amount
    // this.props.merchant.merchantTransferInfo.odd_amount
  };
  onChangeBank = e => {
    this.props.form.setFieldsValue({
      card_no: '',
      card_owner: '',
      amount: '',
      ach_remark: ''
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    // const info = this.props.merchant.merchantTransferInfo.withdrawalList
    const info = this.props.merchant.merchantTransfer;
    const stateInfo = this.state.info;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <div>
        <Form onSubmit={this.handleSubmit}>
          <FormItem {...formItemLayout} label="">
            <Alert
              style={{ width: '28rem' }}
              message={`从88888888商户扣除相应转账金额`}
              type="warning"
              showIcon
            />
          </FormItem>
          <FormItem {...formItemLayout} label="商户">
            {getFieldDecorator('ach_id', {
              initialValue: info.ach_id
            })(<Input disabled />)}
          </FormItem>
          <FormItem {...formItemLayout} label="银行">
            {getFieldDecorator('account_way_id', {
              // initialValue: info.account_way_id,
              rules: [
                {
                  required: true,
                  message: '请选择银行'
                  // whitespace: true
                }
              ]
            })(
              <Select placeholder="请选择银行" onChange={this.onChangeBank}>
                {this.props.merchant.bankListInfo.list.map(item => (
                  <Option value={item.id}>{item.name}</Option>
                ))}
              </Select>
            )}
          </FormItem>
          <FormItem {...formItemLayout} label="收款账户">
            {getFieldDecorator('card_no', {
              // initialValue: info.card_no,
              rules: [
                {
                  required: true,
                  message: '请输入收款账户',
                  whitespace: true
                }
              ]
            })(<Input />)}
          </FormItem>
          <FormItem {...formItemLayout} label="开户人">
            {getFieldDecorator('card_owner', {
              // initialValue: info.card_owner,
              rules: [
                {
                  required: true,
                  message: '请输入开户人',
                  whitespace: true
                }
              ]
            })(<Input />)}
          </FormItem>
          <FormItem {...formItemLayout} label="转账金额">
            {getFieldDecorator('amount', {
              // initialValue: info.amount == '' ? '' : info.amount / 100,
              rules: [
                {
                  required: true,
                  message: '请输入转账金额'
                  // whitespace: true
                },
                // {
                //   type: 'integer',
                //   message: '只能输入整数'
                // },
                {
                  validator: (rule, value, callback) => {
                    if (
                      value &&
                      value >
                        this.props.merchant.merchantTransferInfo.odd_amount
                    ) {
                      callback('不能大于可转账金额');
                      return;
                    }
                    // console.log(value, 'sss')
                    // console.log(Number.isInteger(value))

                    if (value && !Number.isInteger(+value)) {
                      callback('只能输入整数金额');
                      return;
                    }

                    callback();
                  }
                }
              ]
            })(<Input />)}
            可转账金额
            {commafy(
              _.floor(this.props.merchant.merchantTransferInfo.odd_amount, 2)
            )}
            ￥<a onClick={this.withdrawAll}>全部</a>
          </FormItem>

          <FormItem {...formItemLayout} label="备注">
            {getFieldDecorator('plt_remark', {
              // initialValue: info.ach_remark,
              rules: [
                {
                  required: true,
                  message: '请输入备注,最多100个字符',
                  whitespace: true
                },
                {
                  validator: (rule, value, callback) => {
                    if (value && value.length > 100) {
                      callback('最多100个字符');
                      return;
                    }

                    callback();
                  }
                }
              ]
            })(<TextArea />)}
          </FormItem>
          <FormItem wrapperCol={{ span: 12, offset: 6 }}>
            <Button type="primary" htmlType="submit">
              提交
            </Button>
          </FormItem>
        </Form>
      </div>
    );
  }
}
