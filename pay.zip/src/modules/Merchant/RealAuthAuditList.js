import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Divider
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import PreviewImg from '@/components/PreviewImg';
import SimpleTable from '@/components/SimpleTable';

const FormItem = Form.Item;
const Option = Select.Option;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;
const RangePicker = DatePicker.RangePicker;

@Form.create()
@connect(({ merchant, global, loading }) => ({
  merchant,
  global,
  loading: loading.effects['merchant/getRealAuthAuditList']
}))
export default class RealAuthAuditList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        1: '审核中',
        2: '已通过'
      },
      columns: [
        {
          title: 'id',
          dataIndex: 'id'
        },
        {
          title: '商户',
          dataIndex: 'ach_id'
        },
        {
          title: '真实姓名',
          dataIndex: 'real_name'
        },
        {
          title: '手机号',
          dataIndex: 'phone'
        },
        {
          title: '身份证号',
          dataIndex: 'id_card'
        },
        {
          title: '地址',
          dataIndex: 'address'
        },
        {
          title: '身份证',
          dataIndex: 'fron_pic',
          render: (text, record) => (
            <span>
              <PreviewImg
                src={record.front_pic}
                alt="查看"
                style={{
                  marginRight: '5px',
                  width: '50px',
                  height: '50px',
                  borderRadius: '50px'
                }}
              />
              <PreviewImg
                src={record.back_pic}
                alt="查看"
                style={{
                  marginRight: '5px',
                  width: '50px',
                  height: '50px',
                  borderRadius: '50px'
                }}
              />
            </span>
          )
        },
        {
          title: '状态',
          dataIndex: 'status',
          render: (text, record) => (
            <span>{this.state.statusMap[record.status]}</span>
          )
        },
        {
          title: '操作',
          dataIndex: 'name',
          render: (text, record) => {
            return (
              <span>
                {record.status === 2 && (
                  <span style={{ color: 'green' }}>已通过</span>
                )}
                {record.status === 1 && (
                  <div>
                    <a onClick={() => this.pass(record)} href="javascript:;">
                      通过
                    </a>
                    <Divider type="vertical" />
                    <a onClick={() => this.refuse(record)} href="javascript:;">
                      拒绝
                    </a>
                  </div>
                )}
              </span>
            );
          }
        }
      ]
    };
  }
  componentDidMount() {
    this.getRealAuthAuditList({});
  }
  handleChangeDate = date => {};
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getRealAuthAuditList(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getRealAuthAuditList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  getRealAuthAuditList = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.merchant.realAuthAuditListInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          payload.start = parseInt(payload.timeRange[0].valueOf() / 1000);
          payload.end = parseInt(payload.timeRange[1].valueOf() / 1000);
        }

        payload = { ...payload, ...params };

        this.props.dispatch({
          type: 'merchant/getRealAuthAuditList',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getRealAuthAuditList params error');
      }
    });
  };
  getPass = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'merchant/getRealAuthAuditPass',
          payload: {
            id: params.id,
            status: 1
          }
        });
      } else {
        console.log('getPass parameters error');
      }
    });
  };
  getRefuse = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'merchant/getRealAuthAuditRefuse',
          payload: {
            id: params.id,
            status: 2
          }
        });
      } else {
        console.log('getRefuse parameters error');
      }
    });
  };
  notify = item => {
    this.props.dispatch({
      type: 'merchant/orderNotify',
      payload: {
        ...item
      },
      callback: res => {
        if (res.code === 200) {
          message.success('通知成功');
        } else {
          message.danger(res.msg);
        }
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.merchant.realAuthAuditListInfo;

    return (
      <Card bordered={false}>
        <div className={'tableList'}>
          <div className={'tableListForm'}>
            <Form layout="inline" onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col md={8} sm={24}>
                  <FormItem label="认证状态" className="form-inline-item">
                    {getFieldDecorator('status')(
                      <RadioGroup>
                        <Radio value="">全部</Radio>
                        <Radio value="0">审核中</Radio>
                        <Radio value="1">已通过</Radio>
                        <Radio value="2">未通过</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <FormItem label="商户" className="form-inline-item">
                    {getFieldDecorator('ach_id')(<Input />)}
                  </FormItem>
                </Col>
                <Col md={8} sm={24}>
                  <span className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </span>
                </Col>
              </Row>
            </Form>
          </div>
          {/* <div className={'tableListOperator'}>
          <Button icon="plus" type="primary" onClick={() => this.handleModalVisible(true)}>
            新建
          </Button>
        </div> */}

          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.state.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
