import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ merchant }) => ({
  merchant
}))
export default class MerchantProxyEditPass extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    // e.preventDefault();
    
    this.props.form.validateFields((err, values) => {
      var data = {
        account: this.props.merchant.merchantUserInfo.BusinessUser.Account,
        password: values.password,
        newPassWord: values.confirm
      };
      if (!err) {
        this.props.dispatch({
          type: 'merchant/editBusinessPassWord',
          payload: {
            // ...this.props.finance.platformTransferDetail,
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('修改成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  compareToFirstPassword = (rule, value, callback) => {
    const form = this.props.form;
    if (value && value !== form.getFieldValue('password')) {
      callback('两次密码输出不一致!');
    } else {
      callback();
    }
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    // const info = this.props.merchant.editMerchantProxyRateInfo;
    const info = this.props.merchant.merchantUserInfo;
    
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="密码">
          {getFieldDecorator('password', {
            rules: [
              {
                required: true,
                message: '请填写密码!'
              },
              {
                validator: this.validateToNextPassword
              }
            ]
          })(<Input type="password" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="确认密码">
          {getFieldDecorator('confirm', {
            rules: [
              {
                required: true,
                message: '请填写确认密码!'
              },
              {
                validator: this.compareToFirstPassword
              }
            ]
          })(<Input type="password" onBlur={this.handleConfirmBlur} />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            修改
          </Button>
        </FormItem>
      </Form>
    );
  }
}
