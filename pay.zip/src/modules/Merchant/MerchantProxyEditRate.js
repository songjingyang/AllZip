import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

@Form.create()
@connect(({ merchant }) => ({
  merchant
}))
export default class MerchantProxyEditRate extends React.Component {
  componentDidMount() {}

  handleSubmit = e => {
    // e.preventDefault();
    
    this.props.form.validateFields((err, values) => {
      var data = {
        account: this.props.merchant.merchantUserInfo.BusinessUser.Account,
        wx_rate: Number(values.wx_rate*100),
        ali_rate: Number(values.ali_rate*100)
      };
      if (!err) {
        this.props.dispatch({
          type: 'merchant/editBusinessUser',
          payload: {
            // ...this.props.finance.platformTransferDetail,
            ...data
          },
          callback: res => {
            if (res.code === 200) {
              message.success('修改成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    // const info = this.props.merchant.editMerchantProxyRateInfo;
    const info = this.props.merchant.merchantUserInfo;
    
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="支付宝点数(%)">
          {getFieldDecorator('ali_rate', {
            initialValue: info.rate.ali_rate
            // rules: [
            //   {
            //     required: true,
            //     message: '请填写账号!',
            //     writespace: true
            //   }
            // ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem {...formItemLayout} label="微信点数(%)">
          {getFieldDecorator('wx_rate', {
            initialValue: info.rate.wx_rate
            // rules: [
            //   {
            //     required: true,
            //     message: '请填写名称!',
            //     writespace: true
            //   }
            // ]
          })(<Input type="type" />)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            修改
          </Button>
        </FormItem>
      </Form>
    );
  }
}
