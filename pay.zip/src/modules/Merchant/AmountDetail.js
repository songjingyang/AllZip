import React from 'react'
import moment from 'moment'
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  message
} from 'antd'
import { connect } from 'dva'
import classNames from 'classnames'
import { dateFormater, getTimeDistance } from '@/utils/utils'
import UploadImg from '@/components/UploadImg'
import PreviewImg from '@/components/PreviewImg'
import SimpleTable from '@/components/SimpleTable'
import { spawn } from 'redux-saga/effects'

const FormItem = Form.Item
const Option = Select.Option
const RadioButton = Radio.Button
const RadioGroup = Radio.Group
const RangePicker = DatePicker.RangePicker

@Form.create()
@connect(({ merchant, global, loading }) => ({
  merchant,
  global,
  loading: loading.effects['merchant/getAmountDetail']
}))
export default class AmountDetail extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      statusMap: {
        1: '已到账',
        2: '在途'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          isExpand: true,
          title: '账户',
          dataIndex: 'account'
        },
        {
          isExpand: true,
          title: '账期',
          dataIndex: 'period'
        },
        {
          isExpand: true,
          title: '转账金额',
          dataIndex: 'price'
        },
        {
          isExpand: true,
          title: '代理',
          dataIndex: 'proxy'
        },
        {
          isExpand: true,
          title: '对账码',
          dataIndex: 'code'
        },
        {
          isExpand: true,
          title: '转账状态',
          dataIndex: 'status',
          render: (text, record) => (
            <span>{this.state.statusMap[record.status]}</span>
          )
        },
        {
          isExpand: true,
          title: '到账时间',
          dataIndex: 'created',
          render: text => (
            <span>{dateFormater(text)}</span>
          )
        },
        {
          isExpand: true,
          title: '审核员',
          dataIndex: 'assessor'
        },
        {
          isExpand: true,
          title: '转账凭证',
          dataIndex: 'img',
          render: (text, record) => (
            <PreviewImg src={text} />
          )
        }
      ]
    }
  }
  componentDidMount () {
    this.getAmountDetail()
  }
  handleChangeDate = date => {}
  handleSubmit = e => {
    e.preventDefault()
    this.setState({
      pagination :{
        current : 1
      } 
    })
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getAmountDetail(values)
      }
    })
  }

  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination }
    pager.current = pagination.current
    this.setState({
      pagination: pager
    })
    this.getAmountDetail({
      pageSize: pagination.pageSize,
      page: pagination.current
    })
  }

  getAmountDetail = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values }

        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000)
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000)
          } else {
            payload.startTm = 0
            payload.endTm = 0
          }
        }

        payload = { ...payload, ...params }

        this.props.dispatch({
          type: 'merchant/getAmountDetail',
          payload: {
            ...payload
          }
        })
      } else {
        console.log('查询参数错误')
      }
    })
  }

  disabledDate = current => {
    const now = new Date()
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true
      }
    }
    return false
  }

  render () {
    const global = this.props.global
    const { getFieldDecorator } = this.props.form
    const info = this.props.merchant.amountDetailInfo

    const topColResponsiveProps = {
      xs: 24,
      sm: 12,
      md: 6,
      lg: 6,
      xl: 6,
      style: { marginBottom: 24 }
    }

    return (
      <div>

        <Card bordered={false}>

          <div className={'tableList'}>
            <div
              className={classNames({
                tableListForm: !global.isMobile,
                tableListFormMobile: global.isMobile
              })}
            >
              <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
                <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label='时间范围' className='form-inline-item'>
                      {getFieldDecorator('timeRange', {
                        initialValue: getTimeDistance('today'),
                        rules: [
                          {
                            validator: (rule, value, callback) => {
                              let startTm
                              let endTm
                              if (value.length !== 0) {
                                  startTm = parseInt(value[0].valueOf() / 1000)
                                  endTm = parseInt(value[1].valueOf() / 1000)
                                  if (endTm - startTm > 90 * 24 * 3600) {
                                      callback('最大范围 3个月')
                                  }
                              } else {
                                  startTm = 0
                                  endTm = 0
                              }
                              callback()
                            }
                          }
                        ]
                      })(
                        <RangePicker
                          disabledDate={this.disabledDate}
                          showTime
                          format='YYYY-MM-DD HH:mm:ss'
                        />
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <FormItem label='转账状态' className='form-inline-item'>
                      {getFieldDecorator('status', {
                        initialValue: ''
                      })(
                        <RadioGroup>
                          <Radio value=''>全部</Radio>
                          <Radio value='1'>已到账</Radio>
                          <Radio value='2'>在途</Radio>
                        </RadioGroup>
                      )}
                    </FormItem>
                  </Col>
                  <Col xl={12} md={24} sm={24}>
                    <div className={'submitButtons'}>
                      <Button type='primary' htmlType='submit'>查询</Button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </div>
            <SimpleTable
              columns={this.state.columns}
              rowKey={record => record.id}
              dataSource={info.list}
              pagination={{ ...this.state.pagination, total: info.total }}
              loading={this.props.loading}
              onChange={this.handleTableChange}
            />
          </div>
        </Card>
      </div>
    )
  }
}
