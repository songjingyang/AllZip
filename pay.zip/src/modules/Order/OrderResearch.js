import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  message
} from 'antd';
import { connect } from 'dva';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';

const FormItem = Form.Item;

@Form.create()
@connect(({ order, global, loading }) => ({
  order,
  global,
  loading: loading.effects['order/getOrderResearch']
}))
export default class OrderInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      columns: [
        {
          title: '流水id',
          dataIndex: 'flowId'
        }
      ]
    };
  }
  componentDidMount() {}
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;

    return (
      <Card bordered={false} title="订单复核">
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 16, xl: 24 }}>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="订单号" className="form-inline-item">
                    {getFieldDecorator('merchant')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <span className="submitButtons">
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </span>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
        <Table columns={this.state.columns} rowKey={record => record.id} />
      </Card>
    );
  }
}
