import React from 'react';
import { Table, message, Form, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;

@Form.create()
@connect(({ order }) => ({ order }))
export default class StatementRepay extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      columns: [
        {
          title: '分润的用户',
          dataIndex: 'user'
        },
        {
          title: '分润的金额',
          dataIndex: 'price'
        },
        {
          title: '创建的时间',
          dataIndex: 'time'
        }
      ]
    };
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'order/getStatementRepay'
    });
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'order/saveStatementRepay',
          payload: {
            ...this.props.order.statementRepay,
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.order.statementRepay;
    const formItemLayout = {
      labelCol: { span: 12 },
      wrapperCol: { span: 24 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="">
          {getFieldDecorator('repay')(
            <div>
              <h6>需要代付此订单吗？</h6>
              <span>1. 【代理降额申请】生成降额记录，无需手动处理；</span>
            </div>
          )}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 18 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
