import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';

@Form.create()
@connect(({ order, global, loading }) => ({
  order,
  global,
  loading: loading.effects['order/getOrderRelist']
}))
export default class OrderInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isTip: false,
      statusMap: {
        0: '已发送',
        1: '未支付',
        2: '已支付'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          isExpand: true,
          title: '订单id',
          dataIndex: 'order_id'
        },
        {
          isExpand: true,
          title: '支付类型',
          dataIndex: 'pay_type',
          render: (text, record) => (
            <span>{this.state.payMap[record.pay_type]}</span>
          )
        },
        {
          isExpand: true,
          title: '订单生成日期',
          dataIndex: 'order_gen_ts'
        },
        {
          isExpand: true,
          title: '收款商户',
          dataIndex: 'ach_id'
        },
        {
          title: '商品',
          dataIndex: 'goods'
        },
        {
          title: '购买价格',
          dataIndex: 'price'
        },
        {
          title: '收款代理',
          dataIndex: 'proxy'
        },
        {
          isExpand: true,
          title: '实际支付时间',
          dataIndex: 'pay_ts'
        },
        {
          title: '订单状态',
          dataIndex: 'status',
          render: (text, record) => (
            <span>{this.state.statusMap[record.status]}</span>
          )
        },
        {
          title: '支付描述',
          dataIndex: 'descp'
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: 'edit',
          render: (text, record) => (
            <a onClick={() => this.delete(record)} href="javascript:;">
              复核结清
            </a>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getOrderRelist();
  }
  getOrderRelist = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.order.orderFeedback.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'order/getOrderRelist',
          payload: { ...payload },
          callback: params.callback
        });
      } else {
        console.log('getOrderRelist err');
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getIncomeAccountList({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  delete = item => {
    this.props.dispatch({
      type: 'order/orderRelist',
      payload: { ...item }
    });
  };
  deleteOrderRelist = () => {
    this.getOrderRelist();
  };
  render() {
    const info = this.props.order.orderRelist;
    return (
      <Card bordered={false} title="订单复核列表">
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
