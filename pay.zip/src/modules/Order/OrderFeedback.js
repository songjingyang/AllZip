import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import PreviewImg from '@/components/PreviewImg';
import SimpleTable from '@/components/SimpleTable';

const FormItem = Form.Item;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ order, global, loading }) => ({
  order,
  global,
  loading: loading.effects['order/getOrderFeedback']
}))
export default class OrderInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      columns: [
        {
          isExpand: true,
          title: '流水id',
          dataIndex: 'flowId'
        },
        {
          isExpand: true,
          title: '支付类型',
          dataIndex: 'payType'
        },
        {
          isExpand: true,
          title: '订单生产日期',
          dataIndex: 'createAt'
        },
        {
          title: '收款商户',
          dataIndex: 'account'
        },
        {
          title: '商品',
          dataIndex: 'goods'
        },
        {
          isExpand: true,
          title: '购买价格',
          dataIndex: 'price'
        },
        {
          isExpand: true,
          title: '收款代理',
          dataIndex: 'proxy'
        },
        {
          title: '凭证',
          dataIndex: 'img',
          render: (text, record) => (
            <PreviewImg style={{ height: '50px' }} src={text} alt="凭证" />
          )
        },
        {
          isExpand: true,
          title: '反馈时间',
          dataIndex: 'time'
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: 'edit',
          render: (text, record) => {
            <a href="javascript:;">编辑</a>;
          }
        }
      ]
    };
  }
  componentDidMount() {
    this.getOrderFeedback();
  }
  getOrderFeedback = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.order.orderFeedback.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'order/getOrderFeedback',
          payload: { ...payload },
          callback: params.callback
        });
      } else {
        console.log('getOrderFeedback err');
      }
    });
  };
  handleTableChange = (pagination, filter, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({ pagination: pager });
    this.getOrderFeedback({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.order.orderFeedback;
    return (
      <Card bordered={false} title="订单复核反馈">
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 16, xl: 24 }}>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange')(
                      <RangePicker showTime format="YYYY-MM-DD HH:mm:ss" />
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <span className="submitButtons">
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </span>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
