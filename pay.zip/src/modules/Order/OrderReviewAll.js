import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ order, global, loading }) => ({
  order,
  global,
  loading: loading.effects['order/getOrderReviewAll']
}))
export default class OrderReviewAll extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isTip: false,
      statusMap: {
        0: '已发送',
        1: '未支付',
        2: '已支付'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          isExpand: true,
          title: '消息ID',
          dataIndex: 'msg_id'
        },
        {
          isExpand: true,
          title: '消息内容',
          dataIndex: 'descp'
        },
        {
          title: '收款账号',
          dataIndex: 'proxy'
        },
        {
          isExpand: true,
          title: '收款人名称',
          dataIndex: '',
          render: (text, record) => (
            <span>
              {record.pay_type === 100
                ? record.ali_account_nick
                : record.wx_account_nick}
            </span>
          )
        },
        {
          isExpand: true,
          title: '支付类型',
          dataIndex: 'pay_type',
          render: (text, record) => (
            <span>{this.state.payMap[record.pay_type]}</span>
          )
        },
        {
          title: '金额',
          dataIndex: 'price'
        },
        {
          isExpand: true,
          title: '商户ID',
          dataIndex: 'ach_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '代理名称',
          dataIndex: 'proxy_name'
        },
        {
          isExpand: true,
          title: '订单时间',
          dataIndex: 'order_gen_ts',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '支付时间',
          dataIndex: 'pay_ts',
          render: text => <span>{dateFormater(text)}</span>
        },
        {
          isExpand: true,
          title: '接收消息时间',
          dataIndex: 'created',
          render: text => <span>{dateFormater(text)}</span>
        }
        // {
        //     title: '收款代理',
        //     dataIndex: 'proxy'
        // },
        // {
        //     isExpand: true,
        //     title: '实际支付时间',
        //     dataIndex: 'pay_ts'
        // },
        // {
        //     title: '订单状态',
        //     dataIndex: 'status',
        //     render: (text, record) => (
        //         <span>{ this.state.statusMap[record.status] }</span>
        //     )
        // },
        // {
        //     title: '支付描述',
        //     dataIndex: 'descp'
        // },
        // {
        //     isExpand: true,
        //     title: '操作',
        //     dataIndex: '',
        //     render: (text, record) => (
        //         <Popconfirm title="确定吗?" onConfirm={() => this.handleDelete(record)} >
        //             <a href="javascript:;">复核结清</a>
        //         </Popconfirm>
        //     )
        // }
      ]
    };
  }
  componentDidMount() {
    this.getOrderReviewAll();
  }
  getOrderReviewAll = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };

        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.order.orderReviewAll.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }

        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }

        payload = { ...payload, ...params };

        this.props.dispatch({
          type: 'order/getOrderReviewAll',
          payload: {
            ...payload
          }
        });
      } else {
        console.log('getOrderReviewAll parameters error');
      }
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getOrderReviewAll(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getOrderReviewAll({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  handleDelete = item => {
    this.props.dispatch({
      type: 'order/updateOrderReviewAll',
      payload: {
        ...item
      }
    });
  };
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.order.orderReviewAll;
    return (
      <Card bordered={false} title="订单复核列表">
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                      initialValue: getTimeDistance('today'),
                      rules: [
                        {
                          validator: (rule, value, callback) => {
                            let startTm;
                            let endTm;
                            if (value.length !== 0) {
                              startTm = parseInt(value[0].valueOf() / 1000);
                              endTm = parseInt(value[1].valueOf() / 1000);
                              if (endTm - startTm > 90 * 24 * 3600) {
                                callback('最大范围 3个月');
                              }
                            } else {
                              startTm = 0;
                              endTm = 0;
                            }
                            callback();
                          }
                        }
                      ]
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        disabledTime={this.disabledRangeTime}
                        showTime={{
                          hideDisabledOptions: true,
                          defaultValue: [
                            moment('00:00:00', 'HH:mm:ss'),
                            moment('11:59:59', 'HH:mm:ss')
                          ]
                        }}
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                {/* <Col xl={12} md={24} sm={24}>
                  <FormItem label='订单id' className='form-inline-item'>
                      {
                          getFieldDecorator('orderId')(<Input />)
                      }
                  </FormItem>
                </Col> */}
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="消息类型" className="form-inline-item">
                    {getFieldDecorator('type', {
                      initialValue: ''
                    })(
                      <RadioGroup
                        onChange={this.onChange}
                        value={this.state.value}
                      >
                        <Radio value="">全部</Radio>
                        <Radio value="1">收款消息</Radio>
                        <Radio value="2">其他消息</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
