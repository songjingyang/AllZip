import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import ProxyPushNoticeEdit from './ProxyPushNoticeEdit';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ order, global, loading }) => ({
  order,
  global,
  loading: loading.effects['order/getProxyPushNotice']
}))
export default class ProxyPushNotice extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      orderInfo_extend: {},
      loading: false,
      isEdit: false,
      statusMap: {
        0: '已发送',
        1: '未支付',
        2: '已支付'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      columns: [
        {
          isExpand: true,
          title: 'ID',
          dataIndex: 'id'
        },
        {
          title: '代理账户',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          title: '金额',
          dataIndex: 'amount'
        },
        {
          isExpand: true,
          title: '支付类型',
          dataIndex: 'pay_type',
          render: (text, record) => (
            <span>{this.state.payMap[record.pay_type]}</span>
          )
        },
        {
          isExpand: true,
          title: '订单生成日期',
          dataIndex: 'created',
          render: text => {
            return <span>{dateFormater(text)}</span>;
          }
        },
        {
          isExpand: true,
          title: '扩展信息',
          dataIndex: 'edit',
          render: (text, record) => (
            <a onClick={() => this.edit(record)} href="javascript:;">
              查看
            </a>
          )
        }
      ]
    };
  }
  componentDidMount() {
    // this.handleLast1Hours()
    this.getProxyPushNotice();
  }
  getProxyPushNotice = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.order.proxyPushNotice.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'order/getProxyPushNotice',
          payload: {
            ...payload
          },
          callback: params.callback
        });
      } else {
        console.log('getProxyPushNotice err');
      }
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.setState({ orderInfo_extend: item });
  };
  addOrderInfo = () => {
    this.isEdit(false);
  };
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getProxyPushNotice(values);
      } else {
        console.log('123');
      }
    });
  };
  handleLast1Hours = () => {
    this.props.form.setFieldsValue({
      timeRange: [
        moment(new Date().getTime() - 3600000),
        moment(new Date().getTime())
      ]
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getProxyPushNotice(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getProxyPushNotice({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  //时间范围
  disabledDate = current => {
    const now = new Date();
    if (current) {
      if (current < moment(now).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.order.proxyPushNotice;
    return (
      <Card bordered={false} title="代理推送通知">
        {this.state.isEdit && (
          <Modal
            width={1000}
            title="其他信息"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <ProxyPushNoticeEdit
              item={this.state.orderInfo_extend}
              onClose={this.addOrderInfo}
            />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                      initialValue: getTimeDistance('today'),
                      rules: [
                        {
                          validator: (rule, value, callback) => {
                            let startTm;
                            let endTm;
                            if (value.length !== 0) {
                              startTm = parseInt(value[0].valueOf() / 1000);
                              endTm = parseInt(value[1].valueOf() / 1000);
                              if (endTm - startTm > 90 * 24 * 3600) {
                                callback('最大范围 3个月');
                              }
                            } else {
                              startTm = 0;
                              endTm = 0;
                            }
                            callback();
                          }
                        }
                      ]
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        showTime
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="订单状态" className="form-inline-item">
                    {getFieldDecorator('pay_type', {
                      initialValue: ''
                    })(
                      <RadioGroup
                        onChange={this.onChange}
                        value={this.state.value}
                      >
                        <Radio checked value="">
                          全部
                        </Radio>
                        <Radio value="100">支付宝</Radio>
                        <Radio value="200">微信</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="代理账户" className="form-inline-item">
                    {getFieldDecorator('account')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={8} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
