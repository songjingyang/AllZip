import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;

@Form.create()
@connect(({ order }) => ({ order }))
export default class ProxyPushNoticeEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: []
    };
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'order/getProxyPushNoticeEdit'
    });
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.onClose();
  };
  render() {
    const extend_data = JSON.stringify(
      JSON.parse(this.props.item.msg),
      null,
      2
    );
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="商户调用参数">
          {getFieldDecorator('extend')(<pre>{extend_data}</pre>)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            关闭
          </Button>
        </FormItem>
      </Form>
    );
  }
}
