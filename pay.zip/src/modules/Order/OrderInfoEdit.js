import React from 'react';
import { Table, message, Form, Input, Select, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;

@Form.create()
@connect(({ order }) => ({ order }))
export default class OrderInfoEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: []
    };
  }
  componentDidMount() {}
  handleSubmit = e => {
    e.preventDefault();
    this.props.onClose();
  };
  render() {
    const info = this.props.order.orderInfoEdit;
    const extend_data = info.extend
      ? JSON.stringify(JSON.parse(info.extend), null, 2)
      : '';
    const { getFieldDecorator } = this.props.form;
    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="商户名">
          {getFieldDecorator('bu_name')(<pre>{info.bu_name}</pre>)}
        </FormItem>
        <FormItem {...formItemLayout} label="商品">
          {getFieldDecorator('product_id')(<pre>{info.product_id}</pre>)}
        </FormItem>
        <FormItem {...formItemLayout} label="商户费率">
          {getFieldDecorator('product_id')(<pre>{info.ach_rate}%</pre>)}
        </FormItem>
        <FormItem {...formItemLayout} label="手续费金额">
          {getFieldDecorator('product_id')(<pre>{info.pundage}元</pre>)}
        </FormItem>
        <FormItem {...formItemLayout} label="商户代理点数">
          {getFieldDecorator('product_id')(<pre>{info.agent_rate}%</pre>)}
        </FormItem>
        <FormItem {...formItemLayout} label="商户代理收益">
          {getFieldDecorator('product_id')(<pre>{info.agent_earnings}元</pre>)}
        </FormItem>
        <FormItem {...formItemLayout} label="商户调用参数">
          {getFieldDecorator('extend')(<pre>{extend_data}</pre>)}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            关闭
          </Button>
        </FormItem>
      </Form>
    );
  }
}
