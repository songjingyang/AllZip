import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message,
  Popconfirm
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import moment from 'moment';
import { dateFormater, getTimeDistance } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import OrderInfoEdit from './OrderInfoEdit';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ order, global, loading }) => ({
  order,
  global,
  loading: loading.effects['order/getOrderInfo']
}))
export default class OrderInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isEdit: false,
      statusMap: {
        0: '已发送',
        1: '未支付',
        2: '已支付'
      },
      payMap: {
        100: '支付宝',
        200: '微信'
      },
      titleMap: {
        0: '已回调',
        1: '强制复核',
        2: '通知回调商户'
      },
      columns: [
        {
          isExpand: true,
          title: '订单ID',
          dataIndex: 'order_id'
        },
        {
          isExpand: true,
          title: '商户',
          dataIndex: 'ach_id',
          render: (text, record) => (
            <Link to={{ pathname: `/merchant/merchantInfo/${record.ach_id}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '商户订单号',
          dataIndex: 'ach_order_id'
        },
        {
          isExpand: true,
          title: '商户的用户ID',
          dataIndex: 'ach_order_uid'
        },
        {
          title: '代理账户',
          dataIndex: 'account',
          render: (text, record) => (
            <Link to={{ pathname: `/proxy/proxyTree/${record.account}` }}>
              {text}
            </Link>
          )
        },
        {
          isExpand: true,
          title: '代理姓名',
          dataIndex: 'p_name'
        },
        {
          isExpand: true,
          title: '收款昵称',
          dataIndex: 'pay_type',
          render: (text, record) =>
          record.pay_type === 100 ? (
            <span>
              {record.ali_account_nick}
            </span>
          ) : (
            <span>
              {record.wx_account_nick}
            </span>
          )
        },
        {
          isExpand: true,
          title: '支付类型',
          dataIndex: 'pay_type',
          render: (text, record) => (
            <span>{this.state.payMap[record.pay_type]}</span>
          )
        },
        {
          title: '价格',
          dataIndex: 'amount'
        },
        {
          isExpand: true,
          title: '订单生成日期',
          dataIndex: 'created',
          render: text => (text === 0 ? '' : <span>{dateFormater(text)}</span>)
        },
        {
          isExpand: true,
          title: '支付时间',
          dataIndex: 'pay_time',
          render: text =>
            text === 0 ? (
              ''
            ) : (
              <span>{dateFormater(String(text).substring(0, 10))}</span>
            )
        },
        {
          isExpand: true,
          title: '回调时间',
          dataIndex: 'cb_time',
          render: text => (text === 0 ? '' : <span>{dateFormater(text)}</span>)
        },
        {
          isExpand: true,
          title: '订单状态',
          dataIndex: 'status',
          render: (text, record) =>
            record.status === 1 ? (
              <span style={{ color: 'red' }}>
                {this.state.statusMap[record.status]}
              </span>
            ) : (
              <span style={{ color: 'green' }}>
                {this.state.statusMap[record.status]}
              </span>
            )
          // <span>{ this.state.statusMap[record.status] }</span>
        },
        {
          isExpand: true,
          title: '扩展信息',
          dataIndex: 'edit',
          render: (text, record) => (
            <a onClick={() => this.edit(record)} href="javascript:;">
              查看
            </a>
          )
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: '',
          render: (text, record) => (
            <Popconfirm title="确定吗?" onConfirm={() => this.notify(record)}>
              {record.status === 1 && <a href="javascript:;">强制复核</a>}
              {record.status === 2 &&
                record.cb_done === 0 && <a href="javascript:;">通知回调商户</a>}
              {record.status === 2 &&
                record.cb_done === 1 && <a href="javascript:;">已回调</a>}
            </Popconfirm>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getOrderInfo();
  }
  getOrderInfo = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.order.orderInfo.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        if (payload.timeRange) {
          if (payload.timeRange.length !== 0) {
            payload.startTm = parseInt(payload.timeRange[0].valueOf() / 1000);
            payload.endTm = parseInt(payload.timeRange[1].valueOf() / 1000);
          } else {
            payload.startTm = 0;
            payload.endTm = 0;
          }
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'order/getOrderInfo',
          payload: {
            ...payload
          },
          callback: params.callback
        });
      } else {
        console.log('getOrderInfo err');
      }
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'order/orderInfoEdit',
      payload: {
        ...item
      }
    });
  };
  closeEdit = () => {
    this.isEdit(false);
  };
  notify = item => {
    if (item.status === 2) {
      if (item.cb_done === 0) {
        this.props.form.validateFields((err, values) => {
          if (!err) {
            this.props.dispatch({
              type: 'order/getOrdeNotify',
              payload: {
                oid: item.order_id
              }
            });
          } else {
            console.log('getOrdeNotify parameters error');
          }
        });
        item.cb_done = 1;
      }
    } else if (item.status === 1) {
      item.status = 2;
      this.props.form.validateFields((err, values) => {
        if (!err) {
          this.props.dispatch({
            type: 'order/getForcedReview',
            payload: {
              oid: item.order_id,
              remark: '强制复核',
              unknowid: '0',
              isCallBack: '0'
            }
          });
        } else {
          console.log('getForcedReview parameters error');
        }
      });
    }
  };
  handleSubmit = e => {
    e.preventDefault();
    this.setState({
      pagination: {
        current: 1
      }
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getOrderInfo(values);
      } else {
        console.log('123');
      }
    });
  };
  handleLast1Hours = () => {
    this.props.form.setFieldsValue({
      timeRange: [
        moment(new Date().getTime() - 3600000),
        moment(new Date().getTime())
      ]
    });
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getOrderInfo(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getOrderInfo({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  // 时间限制（3个月之内）
  disabledDate = current => {
    const now = new Date();
    const three = new Date();
    if (current) {
      if (current < moment(three).subtract(3, 'months')) {
        return true;
      }
    }
    return false;
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.order.orderInfo;
    return (
      <Card bordered={false} title="订单管理">
        {this.state.isEdit && (
          <Modal
            width={800}
            title="其他信息"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <OrderInfoEdit onClose={() => this.isEdit(false)} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange', {
                      initialValue: getTimeDistance('today'),
                      rules: [
                        {
                          validator: (rule, value, callback) => {
                            let startTm;
                            let endTm;
                            if (value.length !== 0) {
                              startTm = parseInt(value[0].valueOf() / 1000);
                              endTm = parseInt(value[1].valueOf() / 1000);
                              if (endTm - startTm > 90 * 24 * 3600) {
                                callback('最大范围 3个月');
                              }
                            } else {
                              startTm = 0;
                              endTm = 0;
                            }
                            callback();
                          }
                        }
                      ]
                    })(
                      <RangePicker
                        disabledDate={this.disabledDate}
                        showTime
                        format="YYYY-MM-DD HH:mm:ss"
                      />
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="订单状态" className="form-inline-item">
                    {getFieldDecorator('status', {
                      initialValue: ''
                    })(
                      <RadioGroup
                        onChange={this.onChange}
                        value={this.state.value}
                      >
                        <Radio checked value="">
                          全部
                        </Radio>
                        <Radio value="1">未支付</Radio>
                        <Radio value="2">已支付</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="订单ID" className="form-inline-item">
                    {getFieldDecorator('orderId')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="商户订单号" className="form-inline-item">
                    {getFieldDecorator('ach_order_id')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="商户" className="form-inline-item">
                    {getFieldDecorator('achId')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="代理账户" className="form-inline-item">
                    {getFieldDecorator('account', {
                      initialValue: this.props.match.params.account
                    })(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <FormItem label="代理姓名" className="form-inline-item">
                    {getFieldDecorator('proxy_name')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={8} md={12} sm={12}>
                  <div className={'submitButtons'}>
                    <Button
                      type="primary"
                      htmlType="submit"
                      style={{ marginRight: '20px' }}
                    >
                      查询
                    </Button>
                    <Button
                      onClick={() => {
                        this.handleLast1Hours();
                      }}
                      type="primary"
                      htmlType="button"
                    >
                      最近1小时订单
                    </Button>
                  </div>
                </Col>
              </Row>
            </Form>
          </div>
          <SimpleTable
            columns={this.state.columns}
            rowKey={record => record.id}
            dataSource={info.list}
            pagination={{ ...this.state.pagination, total: info.total }}
            loading={this.props.loading}
            onChange={this.handleTableChange}
          />
        </div>
      </Card>
    );
  }
}
