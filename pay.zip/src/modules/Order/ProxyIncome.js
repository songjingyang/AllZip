import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import PreviewImg from '../../components/PreviewImg';
import ProxyIncomeEdit from './ProxyIncomeEdit';
import ProxyIncomeDetail from './ProxyIncomeDetail';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ order, global, loading }) => ({
  order,
  global,
  loading: loading.effects['order/getProxyIncome']
}))
export default class proxyIncome extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isEdit: false,
      isDetail: false,
      dealMap: {
        0: '已发送',
        1: '未处理',
        2: '已处理'
      },
      columns: [
        {
          isExpand: true,
          title: 'id',
          dataIndex: 'id'
        },
        {
          title: '用户',
          dataIndex: 'user'
        },
        {
          title: '分润金额',
          dataIndex: 'price'
        },
        {
          isExpand: true,
          title: '日结日期',
          dataIndex: 'dayEnd'
        },
        {
          title: '状态',
          dataIndex: 'status',
          render: (text, record) => (
            <span>{this.state.dealMap[record.status]}</span>
          )
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: 'edit',
          render: (text, record) => (
            <span>
              <a
                onClick={() => this.edit(record)}
                style={{ marginRight: '16px' }}
                href="javascript:;"
              >
                编辑
              </a>
              <a onClick={() => this.detail(record)} href="javascript:;">
                详情
              </a>
            </span>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getProxyIncome();
  }
  getProxyIncome = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.order.proxyIncome.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'order/getProxyIncome',
          payload: { ...payload },
          callback: params.callback
        });
      } else {
        console.log('getProxyIncome err');
      }
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getProxyIncome(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getProxyIncome({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'order/proxyIncomeEdit',
      payload: { ...item }
    });
  };
  isDetail = bool => {
    this.setState({ isDetail: bool });
  };
  detail = item => {
    this.isDetail(true);
    this.props.dispatch({
      type: 'order/proxyIncomeDetail',
      payload: { ...item }
    });
  };
  addProxyIncom = () => {
    this.isEdit(false);
    this.isDetail(false);
    this.getProxyIncome();
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.order.proxyIncome;
    return (
      <Card bordered={false} title="所有商户">
        {this.state.isEdit && (
          <Modal
            title="编辑"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <ProxyIncomeEdit onClose={this.addProxyIncom} />
          </Modal>
        )}
        {this.state.isDetail && (
          <Modal
            title="详情"
            width={600}
            visible={this.state.isDetail}
            onCancel={() => this.isDetail(false)}
            footer={null}
          >
            <ProxyIncomeDetail onClose={this.addProxyIncom} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 16, xl: 24 }}>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="时间范围" className="form-inline-item">
                    {getFieldDecorator('timeRange')(
                      <RangePicker showTime format="YYYY-MM-DD HH:mm:ss" />
                    )}
                  </FormItem>
                </Col>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="商户" className="form-inline-item">
                    {getFieldDecorator('merchant')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="状态" className="form-inline-item">
                    {getFieldDecorator('status')(
                      <RadioGroup
                        onChange={this.onChange}
                        value={this.state.value}
                      >
                        <Radio value="">全部</Radio>
                        <Radio value="1">未处理</Radio>
                        <Radio value="2">已处理</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <span className="submitButtons">
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </span>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
