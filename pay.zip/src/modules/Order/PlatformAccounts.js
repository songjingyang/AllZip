import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { RangePicker } = DatePicker;

@Form.create()
@connect(({ order, global, loading }) => ({
  order,
  global,
  loading: loading.effects['order/getPlatformAccounts']
}))
export default class OrderInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      statusMap: {
        0: '已发送',
        1: '未支付',
        2: '已支付'
      },
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      columns: [
        {
          isExpand: true,
          title: '流水Id',
          dataIndex: 'flowId'
        },
        {
          title: '商户Id',
          dataIndex: 'merchantId'
        },
        {
          title: '转账金额',
          dataIndex: 'price'
        },
        {
          title: '操作人',
          dataIndex: 'editor'
        },
        {
          isExpand: true,
          title: '操作时间',
          dataIndex: 'editTime'
        }
      ]
    };
  }
  componentDidMount() {
    this.getPlatformAccounts();
  }
  getPlatformAccounts = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.order.platformAccounts.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'order/getPlatformAccounts',
          payload: { ...payload },
          callback: params.callback
        });
      } else {
        console.log('getPlatformAccounts err');
      }
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.getPlatformAccounts(values);
      }
    });
  };
  handleTableChange = (pagination, filters, sorter) => {
    const pager = { ...this.state.pagination };
    pager.current = pagination.current;
    this.setState({
      pagination: pager
    });
    this.getPlatformAccounts({
      pageSize: pagination.pageSize,
      page: pagination.current
    });
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.order.platformAccounts;
    return (
      <Card bordered={false} title="平台转账信息">
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 16, xl: 24 }}>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="商户id" className="form-inline-item">
                    {getFieldDecorator('merchantId')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <span className="submitButtons">
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </span>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
