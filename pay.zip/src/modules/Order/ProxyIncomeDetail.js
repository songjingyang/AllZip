import React from 'react';
import { Table, message, Form, Input, Select, DatePicker, Button } from 'antd';
import { connect } from 'dva';

const FormItem = Form.Item;
const Option = Select.Option;

@Form.create()
@connect(({ order }) => ({ order }))
export default class ProxyIncomeDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      columns: [
        {
          title: '分润的用户',
          dataIndex: 'user'
        },
        {
          title: '分润的金额',
          dataIndex: 'price'
        },
        {
          title: '创建的时间',
          dataIndex: 'time'
        }
      ]
    };
  }
  componentDidMount() {
    this.props.dispatch({
      type: 'order/getProxyIncomeDetail'
    });
  }
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.dispatch({
          type: 'order/saveProxyIncomeDetail',
          payload: {
            ...this.props.order.proxyIncomeDetail,
            ...values
          },
          callback: res => {
            if (res.code === 200) {
              message.success('保存成功');
              if (this.props.onClose) {
                this.props.onClose();
              }
            }
          }
        });
      }
    });
  };
  render() {
    const { getFieldDecorator } = this.props.form;
    const info = this.props.order.proxyIncomeDetail;
    const formItemLayout = {
      labelCol: { span: 12 },
      wrapperCol: { span: 24 }
    };
    return (
      <Form onSubmit={this.handleSubmit}>
        <FormItem {...formItemLayout} label="">
          {getFieldDecorator('detail')(
            <Table
              columns={this.state.columns}
              rowKey={record => record.id}
              dataSource={info.list}
              pagination={false}
            />
          )}
        </FormItem>
        <FormItem wrapperCol={{ span: 12, offset: 6 }}>
          <Button type="primary" htmlType="submit">
            保存
          </Button>
        </FormItem>
      </Form>
    );
  }
}
