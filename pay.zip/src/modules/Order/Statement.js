import React from 'react';
import {
  Form,
  Select,
  InputNumber,
  Switch,
  Radio,
  Slider,
  Button,
  Upload,
  Icon,
  Rate,
  Tooltip,
  Input,
  Table,
  Card,
  DatePicker,
  Row,
  Col,
  Modal,
  message
} from 'antd';
import { connect } from 'dva';
import { Link } from 'dva/router';
import classNames from 'classnames';
import { dateFormater } from '@/utils/utils';
import UploadImg from '@/components/UploadImg';
import SimpleTable from '@/components/SimpleTable';
import PreviewImg from '../../components/PreviewImg';
import StatementEdit from './StatementEdit';
import StatementRepay from './StatementRepay';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;

@Form.create()
@connect(({ order, global, loading }) => ({
  order,
  global,
  loading: loading.effects['order/getStatement']
}))
export default class OrderInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      pagination: {
        current: 1,
        pageSize: 20,
        total: 0
      },
      loading: false,
      isEdit: false,
      isRepay: false,
      columns: [
        {
          isExpand: true,
          title: '流水id',
          dataIndex: 'flowId'
        },
        {
          isExpand: true,
          title: '结算日期',
          dataIndex: 'endTime'
        },
        {
          isExpand: true,
          title: '商户id',
          dataIndex: 'merchantId'
        },
        {
          isExpand: true,
          title: '代理id',
          dataIndex: 'proxyId'
        },
        {
          title: '金额',
          dataIndex: 'price'
        },
        {
          title: '银行名称',
          dataIndex: 'bankName'
        },
        {
          isExpand: true,
          title: '银行账号',
          dataIndex: 'bankAccount'
        },
        {
          title: '转账凭据',
          dataIndex: 'img',
          render: (text, record) => (
            <PreviewImg src={text} style={{ height: 50 }} />
          )
        },
        {
          isExpand: true,
          title: '开户人',
          dataIndex: 'holder'
        },
        {
          isExpand: true,
          title: '对账码',
          dataIndex: 'checkCode'
        },
        {
          title: '状态',
          dataIndex: 'status'
        },
        {
          isExpand: true,
          title: '操作',
          dataIndex: 'edit',
          render: (text, record) => (
            <span>
              <a
                onClick={() => this.edit(record)}
                href="javascript:;"
                style={{ marginRight: 16 }}
              >
                编辑
              </a>
              <a onClick={() => this.repay(record)} href="javascript:;">
                平台代付
              </a>
            </span>
          )
        }
      ]
    };
  }
  componentDidMount() {
    this.getStatement();
  }
  getStatement = (params = {}) => {
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let payload = { ...values };
        if (!params.page) {
          params.page = 1;
        }
        if (params.page === 1) {
          params.ts = Date.parse(new Date()) / 1000;
        } else {
          params.ts = this.props.order.statement.ts;
        }
        if (!params.pageSize) {
          params.pageSize = 20;
        }
        payload = { ...payload, ...params };
        this.props.dispatch({
          type: 'order/getStatement',
          payload: { ...payload },
          callback: params.callback
        });
      } else {
        console.log('getStatement err');
      }
    });
  };
  isEdit = bool => {
    this.setState({ isEdit: bool });
  };
  edit = item => {
    this.isEdit(true);
    this.props.dispatch({
      type: 'order/statementEdit',
      payload: { ...item }
    });
  };
  isRepay = bool => {
    this.setState({ isRepay: bool });
  };
  repay = item => {
    this.isRepay(true);
    this.props.dispatch({
      type: 'order/statementRepay',
      payload: { ...item }
    });
  };
  addStatement = () => {
    this.isEdit(false);
    this.isRepay(false);
    this.getStatement();
  };
  render() {
    const global = this.props.global;
    const { getFieldDecorator } = this.props.form;
    const info = this.props.order.statement;
    return (
      <Card bordered={false} title="对账单">
        {this.state.isEdit && (
          <Modal
            title="编辑"
            visible={this.state.isEdit}
            onCancel={() => this.isEdit(false)}
            footer={null}
          >
            <StatementEdit onClose={this.addStatement} />
          </Modal>
        )}
        {this.state.isRepay && (
          <Modal
            title="平台支付"
            width={600}
            visible={this.state.isRepay}
            onCancel={() => this.isRepay(false)}
            footer={null}
          >
            <StatementRepay onClose={this.addStatement} />
          </Modal>
        )}
        <div className="tableList">
          <div
            className={classNames({
              tableListForm: !global.isMobile,
              tableListFormMobile: global.isMobile
            })}
          >
            <Form layout={global.form.layout} onSubmit={this.handleSubmit}>
              <Row gutter={{ md: 8, lg: 16, xl: 24 }}>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="商户id" className="form-inline-item">
                    {getFieldDecorator('merchantId')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="代理id" className="form-inline-item">
                    {getFieldDecorator('proxyId')(<Input />)}
                  </FormItem>
                </Col>
                <Col xl={8} md={24} sm={24}>
                  <FormItem label="状态" className="form-inline-item">
                    {getFieldDecorator('status')(
                      <RadioGroup
                        onChange={this.onChange}
                        value={this.state.value}
                      >
                        <Radio value="">全部</Radio>
                        <Radio value="20">未处理</Radio>
                        <Radio value="30">已处理</Radio>
                      </RadioGroup>
                    )}
                  </FormItem>
                </Col>
                <Col xl={12} md={24} sm={24}>
                  <span className="submitButtons">
                    <Button type="primary" htmlType="submit">
                      查询
                    </Button>
                  </span>
                </Col>
              </Row>
            </Form>
          </div>
        </div>
        <SimpleTable
          columns={this.state.columns}
          rowKey={record => record.id}
          dataSource={info.list}
          pagination={{ ...this.state.pagination, total: info.total }}
          loading={this.props.loading}
          onChange={this.handleTableChange}
        />
      </Card>
    );
  }
}
